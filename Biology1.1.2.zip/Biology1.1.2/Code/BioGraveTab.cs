using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Threading;
using HarmonyLib;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace RimWorldMod {
    public sealed class BioGraveModalKeys : MonoBehaviour {
        public InputField Input;
        public Action Accept;
        public Action Cancel;

        private void Update() {
            if (UnityEngine.Input.GetKeyDown(KeyCode.Escape)) {
                if (Cancel != null) Cancel();
                return;
            }
            if ((UnityEngine.Input.GetKeyDown(KeyCode.Return)
                || UnityEngine.Input.GetKeyDown(KeyCode.KeypadEnter)) && Accept != null) Accept();
        }
    }

    public sealed class BioGraveMainThreadPump : MonoBehaviour {
        private void Update() { BioGraveTab.FlushPendingRefresh(); }
        private void LateUpdate() { BioGraveTab.ReleaseReviveBlockIfReady(); }
    }

    /// <summary>独立已故收藏窗口的内容渲染器，只读取死亡快照。</summary>
    public static class BioGraveTab {
        public const string WindowId = "bio_grave_window";
        private const string RawTooltipType = "bio_grave_raw";

        private static readonly Color ColorGold = new Color(1f, 0.84f, 0.35f, 1f);
        private static readonly Color ColorGray = new Color(0.72f, 0.74f, 0.78f, 1f);
        private static readonly Color ColorDim = new Color(0.55f, 0.57f, 0.60f, 1f);
        private static readonly Color ColorRevive = new Color(0.55f, 0.90f, 0.60f, 1f);
        private static readonly Color ColorWarn = new Color(1f, 0.52f, 0.30f, 1f);

        private static Transform _content;
        private static ScrollWindow _window;
        private static GameObject _modal;
        private static Button _modalOpener;
        private static int _mainThreadId;
        private static int _refreshPending;
        private static bool _rawTooltipRegistered;
        private static bool _favoriteRowPrefabLogged;
        private static PrefabUnitElement _favoriteRowPrefab;
        private static float _nextFavoriteRowFailureLog;
        private static bool _blockReviveActions;
        private static bool _releaseReviveBlockPending;
        private static InputField _inlineInput;
        private static Text _inlineText;
        private static LayoutElement _inlineLayout;
        private static RectMask2D _inlineMask;
        private static bool _inlineCreatedLayout;
        private static bool _inlineCreatedMask;
        private static string _inlineDisplayText;
        private static long _inlineId;
        private static UnityAction<string> _inlineEndEdit;
        private static Button _inlineAgeButton;
        private static bool _cleaningInline;
        private static TextAnchor _inlineOldAlignment;
        private static HorizontalWrapMode _inlineOldHorizontal;
        private static VerticalWrapMode _inlineOldVertical;
        private static bool _inlineOldRichText;
        private static float _inlineOldMinWidth;
        private static float _inlineOldPreferredWidth;
        private static float _inlineOldFlexibleWidth;
        private static float _inlineOldMinHeight;
        private static float _inlineOldPreferredHeight;
        private static float _inlineOldFlexibleHeight;
        private const float FavoriteRowFailureLogInterval = 10f;
        private const string FavoriteWindowId = "list_favorite_units";
        private const string FavoriteWindowResourcePath = "windows/list_favorite_units";
        private static readonly FieldInfo ListElementPrefabField =
            AccessTools.Field(typeof(ListWindow), "_list_element_prefab");

        /// <summary>幂等创建并绑定独立的已故收藏窗口。</summary>
        public static bool Initialize() {
            if (_window != null && _content != null) return true;
            try {
                ScrollWindow existing = ScrollWindow.windowLoaded(WindowId)
                    ? ScrollWindow.get(WindowId) : null;
                if (existing != null) {
                    Transform existingContent = existing.transform_content;
                    BiologyGraveWindow host = existingContent != null
                        ? existingContent.GetComponent<BiologyGraveWindow>() : null;
                    if (host != null) return true;
                    Main.LogError("生物学:已故收藏窗口ID已被其他窗口占用 " + WindowId);
                    return false;
                }
                BiologyGraveWindow.CreateWindow(WindowId, "bio_grave_window_title");
                return _window != null && _content != null;
            } catch (Exception e) {
                Main.LogError("生物学:初始化已故收藏窗口失败 " + e);
                return false;
            }
        }

        /// <summary>打开独立的已故收藏窗口。</summary>
        public static void Open() {
            if (!Initialize()) return;
            ScrollWindow.showWindow(WindowId);
        }

        /// <summary>绑定独立 ScrollWindow 的滚动内容宿主。</summary>
        internal static void BindWindow(ScrollWindow pWindow, Transform pContent) {
            if (pWindow == null || pContent == null)
                throw new ArgumentNullException(pWindow == null ? "pWindow" : "pContent");
            _mainThreadId = Thread.CurrentThread.ManagedThreadId;
            _window = pWindow;
            _content = pContent;
            RegisterRawTooltip();
            EnsureMainThreadPump(pWindow.transform);
        }

        /// <summary>窗口关闭时清理输入和确认层，墓碑数据仍留在 BioResurrect。</summary>
        public static void OnWindowClosed() {
            CancelInlineEdit();
            CloseModal();
            _blockReviveActions = false;
            _releaseReviveBlockPending = false;
        }

        public static void RefreshIfOpen() {
            Interlocked.Exchange(ref _refreshPending, 1);
            if (_modal == null && _inlineInput == null && _mainThreadId != 0
                && Thread.CurrentThread.ManagedThreadId == _mainThreadId) FlushPendingRefresh();
        }

        public static void FlushPendingRefresh() {
            if (_mainThreadId == 0 || Thread.CurrentThread.ManagedThreadId != _mainThreadId
                || Interlocked.Exchange(ref _refreshPending, 0) == 0) return;
            if (IsOpen()) Render();
        }

        private static bool IsOpen() {
            return _window != null && _window.gameObject.activeInHierarchy && _content != null;
        }

        /// <summary>使用原版收藏列表的单行 prefab 重画死亡快照。</summary>
        public static void Render() {
            try {
                Interlocked.Exchange(ref _refreshPending, 0);
                CancelInlineEdit();
                if (_content == null || !IsOpen()) return;
                CloseModal();
                for (int i = _content.childCount - 1; i >= 0; i--)
                    UnityEngine.Object.DestroyImmediate(_content.GetChild(i).gameObject);

                List<BioResurrect.Grave> graves = BioResurrect.All();
                AddHeaderBar(BioText.T("bio_grave_header", "所有已故收藏单位"), graves.Count.ToString());
                if (graves.Count == 0) {
                    Text empty = AddMessage(BioText.T("bio_grave_empty", "还没有收藏单位死去。"), ColorDim);
                    empty.alignment = TextAnchor.MiddleCenter;
                    RebuildLayout();
                    return;
                }

                PrefabUnitElement prefab = GetFavoriteRowPrefab();
                if (prefab == null) {
                    Text error = AddMessage(BioText.T("bio_grave_template_error",
                        "无法加载原版收藏行模板，请查看日志。"), ColorWarn);
                    error.alignment = TextAnchor.MiddleCenter;
                    RebuildLayout();
                    return;
                }
                for (int i = 0; i < graves.Count; i++) AddGrave(prefab, graves[i]);
                RebuildLayout();
            } catch (Exception e) {
                Main.LogError("生物学:重画已故收藏失败 " + e);
            }
        }

        private static PrefabUnitElement GetFavoriteRowPrefab() {
            if (_favoriteRowPrefab != null) return _favoriteRowPrefab;

            StringBuilder diagnostic = new StringBuilder(384);
            PrefabUnitElement prefab = TryGetInitializedFavoriteRow(diagnostic);
            if (CacheFavoriteRowPrefab(prefab, "已实例化收藏窗口 WindowFavorites.element_prefab"))
                return _favoriteRowPrefab;

            GameObject windowResource = null;
            try {
                windowResource = Resources.Load<GameObject>(FavoriteWindowResourcePath);
                if (windowResource == null) diagnostic.Append("; 窗口资源GameObject=null");
                else {
                    ListWindow listWindow = windowResource.GetComponent<ListWindow>();
                    if (listWindow == null) listWindow = windowResource.GetComponentInChildren<ListWindow>(true);
                    if (listWindow == null) diagnostic.Append("; 资源ListWindow=null");
                    else if (ListElementPrefabField == null)
                        diagnostic.Append("; ListWindow._list_element_prefab反射字段=null");
                    else {
                        GameObject rowObject = ListElementPrefabField.GetValue(listWindow) as GameObject;
                        if (rowObject == null) diagnostic.Append("; 资源ListWindow._list_element_prefab=null");
                        else {
                            prefab = rowObject.GetComponent<PrefabUnitElement>();
                            if (prefab == null) prefab = rowObject.GetComponentInChildren<PrefabUnitElement>(true);
                            if (prefab == null)
                                diagnostic.Append("; _list_element_prefab无PrefabUnitElement 名=")
                                    .Append(rowObject.name);
                        }
                    }
                }
            } catch (Exception ex) {
                diagnostic.Append("; 资源ListWindow字段分支异常=").Append(ex);
            }
            if (CacheFavoriteRowPrefab(prefab,
                "资源 windows/list_favorite_units 的 ListWindow._list_element_prefab"))
                return _favoriteRowPrefab;

            // 当前 resources.assets 没有独立行资源路径；行对象只由窗口的序列化字段引用。
            diagnostic.Append("; 独立行资源路径=不存在(已确认resources.assets)");
            AppendResourceDiagnostics(diagnostic, windowResource);
            LogFavoriteRowFailure(diagnostic.ToString());
            return null;
        }

        private static PrefabUnitElement TryGetInitializedFavoriteRow(StringBuilder pDiagnostic) {
            try {
                ScrollWindow window = ScrollWindow.get(FavoriteWindowId);
                if (window == null) {
                    pDiagnostic.Append("实例窗口=null");
                    return null;
                }
                WindowFavorites favorites = window.GetComponent<WindowFavorites>();
                if (favorites == null) favorites = window.GetComponentInChildren<WindowFavorites>(true);
                if (favorites == null) {
                    pDiagnostic.Append("实例WindowFavorites=null");
                    return null;
                }
                if (favorites.element_prefab == null) {
                    pDiagnostic.Append("实例WindowFavorites.element_prefab=null");
                    return null;
                }
                return favorites.element_prefab;
            } catch (Exception ex) {
                pDiagnostic.Append("实例窗口分支异常=").Append(ex);
                return null;
            }
        }

        private static bool CacheFavoriteRowPrefab(PrefabUnitElement pPrefab, string pSource) {
            if (pPrefab == null) return false;
            _favoriteRowPrefab = pPrefab;
            if (!_favoriteRowPrefabLogged) {
                _favoriteRowPrefabLogged = true;
                Main.LogInfo("生物学:原版收藏行模板加载成功 来源=" + pSource
                    + " 模板名=" + pPrefab.gameObject.name);
            }
            return true;
        }

        private static void AppendResourceDiagnostics(StringBuilder pDiagnostic, GameObject pResource) {
            pDiagnostic.Append("; 字段ListWindow._list_element_prefab=")
                .Append(ListElementPrefabField != null ? ListElementPrefabField.FieldType.FullName : "未找到");
            if (pResource == null) return;
            MonoBehaviour[] components = pResource.GetComponentsInChildren<MonoBehaviour>(true);
            pDiagnostic.Append("; 资源MonoBehaviour[");
            for (int i = 0; i < components.Length; i++) {
                if (i > 0) pDiagnostic.Append(',');
                pDiagnostic.Append(components[i] == null ? "MissingScript" : components[i].GetType().FullName);
            }
            pDiagnostic.Append(']');
        }

        private static void LogFavoriteRowFailure(string pDiagnostic) {
            float now = Time.realtimeSinceStartup;
            if (now < _nextFavoriteRowFailureLog) return;
            _nextFavoriteRowFailureLog = now + FavoriteRowFailureLogInterval;
            Main.LogError("生物学:原版收藏行模板所有分支失败 " + pDiagnostic);
        }

        private static void AddGrave(PrefabUnitElement pPrefab, BioResurrect.Grave pGrave) {
            PrefabUnitElement row = UnityEngine.Object.Instantiate(pPrefab, _content, false);
            row.gameObject.SetActive(true);
            row.transform.localScale = Vector3.one;
            row.name = "BioGraveRow_" + pGrave.Id;
            ClearLiveBindings(row);
            BindStaticRow(row, pGrave);
            RectTransform rowRect = row.transform as RectTransform;
            if (rowRect != null) {
                rowRect.anchorMin = new Vector2(0f, rowRect.anchorMin.y);
                rowRect.anchorMax = new Vector2(1f, rowRect.anchorMax.y);
                rowRect.sizeDelta = new Vector2(0f, rowRect.sizeDelta.y);
                LayoutElement element = row.GetComponent<LayoutElement>() ?? row.gameObject.AddComponent<LayoutElement>();
                element.preferredWidth = -1f;
                element.flexibleWidth = 1f;
                LayoutRebuilder.ForceRebuildLayoutImmediate(rowRect);
            }
            RebuildLayout();
        }

        private static void ClearLiveBindings(PrefabUnitElement pRow) {
            pRow._actor = null;
            pRow.enabled = false;
            foreach (Button button in pRow.GetComponentsInChildren<Button>(true))
                button.onClick = new Button.ButtonClickedEvent();
            foreach (TipButton tip in pRow.GetComponentsInChildren<TipButton>(true)) {
                tip.hoverAction = null;
                tip.clickAction = null;
                tip.showOnClick = false;
                tip.enabled = false;
            }
            foreach (CountUpOnClick counter in pRow.GetComponentsInChildren<CountUpOnClick>(true))
                counter.enabled = false;
            if (pRow.avatarElement != null) {
                pRow.avatarElement._actor = null;
                pRow.avatarElement.show_banner_kingdom = false;
                pRow.avatarElement.show_banner_clan = false;
                pRow.avatarElement.enabled = false;
                foreach (Button button in pRow.avatarElement.GetComponentsInChildren<Button>(true))
                    button.onClick = new Button.ButtonClickedEvent();
                foreach (TipButton tip in pRow.avatarElement.GetComponentsInChildren<TipButton>(true)) {
                    tip.hoverAction = null;
                    tip.clickAction = null;
                    tip.enabled = false;
                }
                if (pRow.avatarElement.kingdomBanner != null)
                    pRow.avatarElement.kingdomBanner.gameObject.SetActive(false);
                if (pRow.avatarElement.clanBanner != null)
                    pRow.avatarElement.clanBanner.gameObject.SetActive(false);
            }
        }

        private static void BindStaticRow(PrefabUnitElement pRow, BioResurrect.Grave pGrave) {
            string displayName = string.IsNullOrEmpty(pGrave.ColoredName) ? pGrave.Name : pGrave.ColoredName;
            if (pRow.unitName != null) pRow.unitName.text = displayName;
            if (pRow._icon_favorite != null) pRow._icon_favorite.SetActive(true);

            ActorAsset asset = null;
            try {
                asset = AssetManager.actor_library.get(pGrave.AssetId);
            } catch (Exception ex) {
                Main.LogError("生物学:读取死者种族资源失败 " + pGrave.AssetId + " " + ex);
            }
            if (pRow._icon_species != null) {
                try {
                    pRow._icon_species.sprite = asset != null ? asset.getSpriteIcon() : null;
                } catch (Exception ex) {
                    Main.LogError("生物学:设置死者种族图标失败 " + pGrave.AssetId + " " + ex);
                }
            }
            if (pRow.icon_sex != null) {
                int displayGender = pGrave.DisplayGender;
                bool legacyGender = pGrave.DiedYear <= 0 && pGrave.DiedMonth <= 0 && pGrave.DiedDay <= 0;
                if (displayGender < 0 || displayGender > 3 || (legacyGender && displayGender == 0))
                    displayGender = pGrave.Sex == ActorSex.Male ? 1 : 2;
                bool showSex = (asset == null || asset.inspect_sex) && displayGender != 0;
                Sprite sexSprite = null;
                if (showSex) {
                    try {
                        if (displayGender == 3) sexSprite = SexIconSync.ResolveHermaphSprite();
                        else sexSprite = SpriteTextureLoader.getSprite(displayGender == 1
                            ? "ui/icons/IconMale" : "ui/icons/IconFemale");
                    } catch (Exception ex) {
                        Main.LogError("生物学:设置死者性别图标失败 gender=" + displayGender + " " + ex);
                    }
                }
                pRow.icon_sex.sprite = sexSprite;
                pRow.icon_sex.raycastTarget = false;
                pRow.icon_sex.gameObject.SetActive(showSex && sexSprite != null);
            }
            if (pRow.health_bar != null)
                pRow.health_bar.setBar(pGrave.Health, Mathf.Max(1, pGrave.MaxHealth), "", true,
                    false, true, 0f);
            SetCounterText(pRow.text_level, pGrave.Level.ToString());
            SetCounterText(pRow.text_kills, pGrave.Kills.ToString());
            SetCounterText(pRow.text_age, CurrentAge(pGrave) + "/" + EffectiveLifespan(pGrave));

            bool dynamicAvatar = TryLoadStaticAvatar(pRow.avatarElement, pGrave, asset);
            if (!dynamicAvatar) ShowSpeciesIconFallback(pRow.avatarElement, asset);
            HideDynamicAvatarLayers(pRow.avatarElement, dynamicAvatar);
            EnsureDeadGrayOverlay(pRow.avatarElement);
            BindRowInteraction(pRow, pGrave);
        }

        private static void SetCounterText(CountUpOnClick pCounter, string pValue) {
            if (pCounter == null) return;
            pCounter.enabled = false;
            Text text = pCounter.getText();
            if (text != null) text.text = pValue;
        }

        private static bool TryLoadStaticAvatar(UiUnitAvatarElement pAvatar,
            BioResurrect.Grave pGrave, ActorAsset pAsset) {
            if (pAvatar == null || pAvatar.avatarLoader == null || pAsset == null) return false;
            if (pAsset.has_override_sprite || pAsset.has_override_avatar_frames) {
                Main.LogInfo("生物学:死者头像特殊渲染需Actor，安全回退种族图标 asset=" + pAsset.id);
                return false;
            }
            try {
                ActorAvatarData data = new ActorAvatarData();
                data.setData(pAsset, pGrave.MutationSkinAsset, pGrave.Sex, pGrave.Id,
                    pGrave.Head, pGrave.HeadSprite, pGrave.PhenotypeIndex, pGrave.PhenotypeShade,
                    pGrave.KingdomColor, pGrave.IsEgg, pGrave.WasKing, pGrave.WasWarrior,
                    pGrave.WasWise, pGrave.EggAsset, pGrave.IsAdult, false, false, false,
                    false, false, false, false, null, (int)pGrave.Id, null, null);
                UnitAvatarLoader loader = pAvatar.avatarLoader;
                loader._actor = null;
                loader.enabled = true;
                loader.load(data, false);
                loader._actor = null;
                loader.enabled = true;
                return loader._actor_image != null && loader._actor_image.sprite != null;
            } catch (Exception e) {
                if (pAvatar.avatarLoader != null) pAvatar.avatarLoader._actor = null;
                Main.LogError("生物学:死者动态头像回退为种族图标 " + e);
                return false;
            }
        }

        private static void ShowSpeciesIconFallback(UiUnitAvatarElement pAvatar, ActorAsset pAsset) {
            if (pAvatar == null || pAvatar.avatarLoader == null) return;
            UnitAvatarLoader loader = pAvatar.avatarLoader;
            loader._actor = null;
            loader.enabled = false;
            if (loader._actor_image != null) {
                try {
                    loader._actor_image.sprite = pAsset != null ? pAsset.getSpriteIcon() : null;
                } catch (Exception ex) {
                    Main.LogError("生物学:设置死者回退种族图标失败 " + ex);
                }
                loader._actor_image.enabled = loader._actor_image.sprite != null;
                loader._actor_image.color = Color.white;
                loader._actor_image.preserveAspect = true;
            }
        }

        private static void HideDynamicAvatarLayers(UiUnitAvatarElement pAvatar, bool pDynamicLoaded) {
            if (pAvatar == null) return;
            pAvatar._actor = null;
            pAvatar.enabled = false;
            UnitAvatarLoader loader = pAvatar.avatarLoader;
            if (loader != null) {
                loader._actor = null;
                loader._show_item = false;
                if (pDynamicLoaded) loader.enabled = true;
                if (loader._item_image != null) loader._item_image.gameObject.SetActive(false);
                HideTransform(loader._effects_parent_attached_below);
                HideTransform(loader._effects_parent_attached_above);
                HideTransform(loader._effects_parent_below);
                HideTransform(loader._effects_parent_above);
            }
            if (pAvatar.unit_type_bg != null) pAvatar.unit_type_bg.gameObject.SetActive(false);
            if (pAvatar._tile_graphics_1 != null) pAvatar._tile_graphics_1.gameObject.SetActive(false);
            if (pAvatar._tile_graphics_2 != null) pAvatar._tile_graphics_2.gameObject.SetActive(false);
        }

        private static void EnsureDeadGrayOverlay(UiUnitAvatarElement pAvatar) {
            if (pAvatar == null) return;
            Transform mask = pAvatar.transform.Find("Mask");
            if (mask == null) {
                Main.LogError("生物学:死者头像缺少 UnitAvatarElement/Mask，无法添加灰层");
                return;
            }
            if (mask.GetComponent<Mask>() == null && mask.GetComponent<RectMask2D>() == null)
                mask.gameObject.AddComponent<RectMask2D>();
            Transform first = null;
            for (int i = mask.childCount - 1; i >= 0; i--) {
                Transform child = mask.GetChild(i);
                if (child.name != "BioDeadGrayOverlay") continue;
                if (first == null) first = child;
                else UnityEngine.Object.DestroyImmediate(child.gameObject);
            }
            GameObject overlayObject;
            if (first == null) {
                overlayObject = new GameObject("BioDeadGrayOverlay", typeof(RectTransform), typeof(Image));
                overlayObject.transform.SetParent(mask, false);
            } else overlayObject = first.gameObject;
            RectTransform rect = overlayObject.GetComponent<RectTransform>();
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
            rect.localScale = Vector3.one;
            Image overlay = overlayObject.GetComponent<Image>() ?? overlayObject.AddComponent<Image>();
            overlay.color = new Color(0.35f, 0.35f, 0.35f, 0.5f);
            overlay.raycastTarget = false;
            Transform avatarLoaderTransform = mask.Find("AvatarLoader");
            if (avatarLoaderTransform == null) {
                UnitAvatarLoader loader = pAvatar.avatarLoader;
                if (loader != null && loader.transform.parent == mask)
                    avatarLoaderTransform = loader.transform;
            }
            if (avatarLoaderTransform != null)
                overlayObject.transform.SetSiblingIndex(Mathf.Min(
                    avatarLoaderTransform.GetSiblingIndex() + 1, mask.childCount - 1));
            else overlayObject.transform.SetAsLastSibling();
        }

        private static void HideTransform(Transform pTransform) {
            if (pTransform != null) pTransform.gameObject.SetActive(false);
        }

        private static void BindRowInteraction(PrefabUnitElement pRow, BioResurrect.Grave pGrave) {
            long id = pGrave.Id;
            string who = pGrave.Name;
            Button rowButton = pRow.GetComponent<Button>() ?? pRow.gameObject.AddComponent<Button>();
            rowButton.targetGraphic = pRow.GetComponent<Graphic>();
            rowButton.onClick.RemoveAllListeners();
            SetRawTip(pRow.gameObject, who, BuildRowTooltip(pGrave));

            if (pRow.text_age != null) {
                GameObject ageObject = pRow.text_age.gameObject;
                Button ageButton = ageObject.GetComponent<Button>() ?? ageObject.AddComponent<Button>();
                ageButton.targetGraphic = pRow.text_age.getText();
                ageButton.onClick.RemoveAllListeners();
                ageButton.onClick.AddListener(() => BeginInlineLifespanEdit(pRow, id));
                SetRawTip(ageObject, BioText.T("bio_grave_lifespan_title", "编辑寿命"),
                    BuildAgeTooltip(pGrave));
            }

            Transform locateTransform = pRow.transform.Find("Top/Grid/Button Container/Locate");
            Button locate = locateTransform != null ? locateTransform.GetComponent<Button>() : null;
            if (locate == null) {
                Main.LogError("生物学:收藏行缺少 Top/Grid/Button Container/Locate");
                return;
            }
            locate.enabled = true;
            locate.interactable = true;
            Image locateBackground = locateTransform.GetComponent<Image>();
            if (locateBackground == null) {
                locateBackground = locateTransform.gameObject.AddComponent<Image>();
                locateBackground.color = Color.clear;
            }
            locateBackground.enabled = true;
            locateBackground.raycastTarget = true;
            locate.targetGraphic = locateBackground;
            locate.onClick.RemoveAllListeners();
            locate.onClick.AddListener(() => RequestRevive(id, who, locate));
            SetLocateVisual(locateTransform);
            SetRawTip(locate.gameObject, BioText.T("bio_grave_revive", "复活"),
                BioText.T("bio_grave_revive_tip", "点击复活；阳寿已尽时需要确认"));
        }

        private static void SetLocateVisual(Transform pLocate) {
            Transform iconTransform = pLocate.Find("Icon");
            Image icon = iconTransform != null ? iconTransform.GetComponent<Image>() : null;
            Sprite revive = null;
            try { revive = SpriteTextureLoader.getSprite("ui/Icons/iconDivineLight"); }
            catch (Exception ex) { Main.LogError("生物学:读取复活按钮图标失败 " + ex); }
            if (icon != null) {
                if (revive != null) icon.sprite = revive;
                icon.raycastTarget = false;
            }
            Image locateImage = pLocate.GetComponent<Image>();
            if (locateImage != null) locateImage.raycastTarget = true;
            Transform textTransform = pLocate.Find("Text");
            Text text = textTransform != null ? textTransform.GetComponent<Text>() : null;
            if (text != null) { text.text = ""; text.enabled = false; text.raycastTarget = false; }
        }

        private static string BuildAgeTooltip(BioResurrect.Grave pGrave) {
            int age;
            float lifespan;
            bool expired;
            if (!BioResurrect.TryGetResurrectionState(pGrave.Id, out age, out lifespan, out expired)) {
                age = pGrave.AgeAtDeath;
                lifespan = EffectiveLifespan(pGrave);
                expired = lifespan > 0f && age >= lifespan;
            }
            return BioText.F("bio_grave_age_click_tip",
                "死亡年龄 {0}\n寿命上限 {1}\n{2}\n点击修改",
                age, Mathf.Max(1, Mathf.RoundToInt(lifespan)),
                BioText.T(expired ? "bio_grave_expired" : "bio_grave_unfinished",
                    expired ? "阳寿已尽" : "阳寿未尽"));
        }

        private static string BuildRowTooltip(BioResurrect.Grave pGrave) {
            string death = BioDeathLocalization.Localize(pGrave.DeathType);
            return BioText.F("bio_grave_row_tip", "死因：{0}\n死亡日期：{1}\n{2}/{3} · {4}",
                death, FormatDiedDate(pGrave), CurrentAge(pGrave),
                EffectiveLifespan(pGrave), LifeState(pGrave));
        }

        private static string FormatDiedDate(BioResurrect.Grave pGrave) {
            if (pGrave == null) return "?";
            try {
                if (pGrave.DiedTime > 0.0) {
                    string formatted = Date.getDate(pGrave.DiedTime);
                    if (!string.IsNullOrEmpty(formatted)) return formatted;
                }
            } catch (Exception ex) {
                Main.LogError("生物学:格式化死亡日期失败 id=" + pGrave.Id + " " + ex.Message);
            }
            if (pGrave.DiedYear > 0 && pGrave.DiedMonth > 0 && pGrave.DiedDay > 0) {
                try { return Date.formatDate(pGrave.DiedDay, pGrave.DiedMonth, pGrave.DiedYear); }
                catch { return pGrave.DiedYear + "-" + pGrave.DiedMonth + "-" + pGrave.DiedDay; }
            }
            try {
                if (pGrave.DiedTime > 0.0) {
                    int[] raw = Date.getRawDate(pGrave.DiedTime);
                    if (raw != null && raw.Length >= 3)
                        return Date.formatDate(raw[0], raw[1], raw[2]);
                }
            } catch (Exception ex) {
                Main.LogError("生物学:死亡日期原始值回退失败 id=" + pGrave.Id + " " + ex.Message);
            }
            return "?";
        }

        private static void SetRawTip(GameObject pOwner, string pTitle, string pDescription) {
            if (pOwner == null) return;
            TipButton tip = pOwner.GetComponent<TipButton>() ?? pOwner.AddComponent<TipButton>();
            tip.enabled = true;
            tip.showOnClick = false;
            tip.type = RawTooltipType;
            tip.clickAction = null;
            tip.hoverAction = () => Tooltip.show(pOwner, RawTooltipType,
                new TooltipData { tip_name = pTitle ?? "", tip_description = pDescription ?? "" });
        }

        private static void RegisterRawTooltip() {
            if (_rawTooltipRegistered) return;
            try {
                AssetManager.tooltips.add(new TooltipAsset { id = RawTooltipType, callback = ShowRawTooltip });
                _rawTooltipRegistered = true;
            } catch (Exception ex) {
                _rawTooltipRegistered = true;
                Main.LogError("生物学:注册已故收藏提示类型失败 " + ex);
            }
        }

        private static void ShowRawTooltip(Tooltip pTooltip, string pType, TooltipData pData) {
            if (pTooltip == null || pData == null) return;
            if (!string.IsNullOrEmpty(pData.tip_name)) pTooltip.name.text = pData.tip_name;
            if (!string.IsNullOrEmpty(pData.tip_description)) pTooltip.setDescription(pData.tip_description);
        }

        private static int EffectiveLifespan(BioResurrect.Grave pGrave) {
            int age;
            float lifespan;
            bool expired;
            if (BioResurrect.TryGetResurrectionState(pGrave.Id, out age, out lifespan, out expired))
                return Mathf.Max(1, Mathf.RoundToInt(lifespan));
            float value = pGrave.LifespanOverride > 0 ? pGrave.LifespanOverride : pGrave.LifespanAtDeath;
            return Mathf.Max(1, Mathf.RoundToInt(value));
        }

        private static int CurrentAge(BioResurrect.Grave pGrave) {
            int age;
            float lifespan;
            bool expired;
            return BioResurrect.TryGetResurrectionState(pGrave.Id, out age, out lifespan, out expired)
                ? age : pGrave.AgeAtDeath;
        }

        private static int EffectiveLifespanById(long pId) {
            BioResurrect.Grave grave;
            return BioResurrect.TryGet(pId, out grave) ? EffectiveLifespan(grave) : 1;
        }

        private static string LifeState(BioResurrect.Grave pGrave) {
            int age;
            float lifespan;
            bool expired;
            if (!BioResurrect.TryGetResurrectionState(pGrave.Id, out age, out lifespan, out expired))
                expired = pGrave.AgeAtDeath >= EffectiveLifespan(pGrave);
            return BioText.T(expired ? "bio_grave_expired" : "bio_grave_unfinished",
                expired ? "阳寿已尽" : "阳寿未尽");
        }

        private static void RequestRevive(long pId, string pWho, Button pButton) {
            int age = 0;
            float lifespan = 0f;
            bool expired = false;
            bool found = BioResurrect.TryGetResurrectionState(pId, out age, out lifespan, out expired);
            bool busy = BioResurrect.IsBusy(pId);
            Main.LogInfo("生物学:RequestRevive id=" + pId + " block=" + _blockReviveActions
                + " busy=" + busy + " age=" + age + " lifespan=" + lifespan
                + " expired=" + expired);
            if (pButton == null) {
                Main.LogError("生物学:复活按钮为空 id=" + pId);
                ShowWorldTip(BioText.T("bio_grave_revive_failed", "复活失败，请稍后重试。"));
                return;
            }
            if (_blockReviveActions) {
                ShowWorldTip(BioText.T("bio_grave_revive_blocked", "正在编辑寿命，请完成后再复活。"));
                return;
            }
            if (busy) {
                ShowWorldTip(BioText.T("bio_grave_revive_busy", "复活正在处理中，请稍候。"));
                return;
            }
            CancelInlineEdit();
            if (!found) {
                pButton.enabled = true;
                pButton.interactable = true;
                ShowWorldTip(BioText.T("bio_grave_life_missing", "该死者已不在名单中。"));
                return;
            }
            if (expired) {
                OpenReviveModal(pId, pWho, pButton, age, lifespan);
                return;
            }
            pButton.interactable = false;
            if (BioResurrect.Resurrect(pId)) Render();
            else {
                pButton.enabled = true;
                pButton.interactable = true;
                ShowWorldTip(BioText.T("bio_grave_revive_failed", "复活失败，请稍后重试。"));
            }
        }

        private static void ShowWorldTip(string pMessage) {
            try { WorldTip.showNow(pMessage, false, "top"); }
            catch (Exception ex) { Main.LogError("生物学:显示提示失败 " + ex); }
        }

        private static void BeginInlineLifespanEdit(PrefabUnitElement pRow, long pId) {
            CancelInlineEdit();
            if (pRow == null || pRow.text_age == null) return;
            BioResurrect.Grave grave;
            if (!BioResurrect.TryGet(pId, out grave)) {
                ShowWorldTip(BioText.T("bio_grave_life_missing", "该死者已不在名单中。"));
                return;
            }
            Text text = pRow.text_age.getText();
            RectTransform rect = text != null ? text.rectTransform : null;
            if (rect == null) return;
            int current = EffectiveLifespan(grave);
            _blockReviveActions = true;
            _releaseReviveBlockPending = false;
            _inlineId = pId;
            _inlineText = text;
            _inlineAgeButton = pRow.text_age.gameObject.GetComponent<Button>();
            if (_inlineAgeButton != null) _inlineAgeButton.interactable = false;
            _inlineDisplayText = CurrentAge(grave) + "/" + current;
            _inlineCreatedLayout = text.GetComponent<LayoutElement>() == null;
            _inlineLayout = text.GetComponent<LayoutElement>() ?? text.gameObject.AddComponent<LayoutElement>();
            _inlineOldMinWidth = _inlineLayout.minWidth;
            _inlineOldPreferredWidth = _inlineLayout.preferredWidth;
            _inlineOldFlexibleWidth = _inlineLayout.flexibleWidth;
            _inlineOldMinHeight = _inlineLayout.minHeight;
            _inlineOldPreferredHeight = _inlineLayout.preferredHeight;
            _inlineOldFlexibleHeight = _inlineLayout.flexibleHeight;
            Vector2 size = rect.rect.size;
            _inlineLayout.minWidth = size.x;
            _inlineLayout.preferredWidth = size.x;
            _inlineLayout.flexibleWidth = 0f;
            _inlineLayout.minHeight = size.y;
            _inlineLayout.preferredHeight = size.y;
            _inlineLayout.flexibleHeight = 0f;
            _inlineCreatedMask = text.GetComponent<RectMask2D>() == null;
            _inlineMask = text.GetComponent<RectMask2D>() ?? text.gameObject.AddComponent<RectMask2D>();
            _inlineOldAlignment = text.alignment;
            _inlineOldHorizontal = text.horizontalOverflow;
            _inlineOldVertical = text.verticalOverflow;
            _inlineOldRichText = text.supportRichText;
            text.text = current.ToString();
            text.alignment = TextAnchor.MiddleCenter;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Truncate;
            text.supportRichText = false;
            _inlineInput = text.gameObject.AddComponent<InputField>();
            _inlineInput.textComponent = text;
            _inlineInput.lineType = InputField.LineType.SingleLine;
            _inlineInput.contentType = InputField.ContentType.IntegerNumber;
            _inlineInput.characterLimit = 7;
            _inlineInput.text = current.ToString();
            _inlineInput.caretColor = Color.white;
            _inlineInput.selectionColor = new Color(0.35f, 0.55f, 0.85f, 0.75f);
            _inlineInput.customCaretColor = true;
            _inlineInput.shouldHideMobileInput = true;
            _inlineEndEdit = FinishInlineEdit;
            _inlineInput.onEndEdit.AddListener(_inlineEndEdit);
            _inlineInput.Select();
            _inlineInput.ActivateInputField();
            _inlineInput.selectionAnchorPosition = 0;
            _inlineInput.selectionFocusPosition = _inlineInput.text.Length;
        }

        private static void FinishInlineEdit(string pValue) {
            if (_cleaningInline || _inlineInput == null) return;
            bool canceled = _inlineInput.wasCanceled;
            int value;
            bool valid = int.TryParse(pValue, out value)
                && value >= MortalityGuard.MinLifespanOverride
                && value <= MortalityGuard.MaxLifespanOverride;
            if (!canceled && !valid) {
                CleanupInlineEdit(false);
                ShowWorldTip(BioText.T("bio_grave_life_invalid",
                    "请输入 1 到 1000000 之间的整数。"));
                return;
            }
            if (!canceled && !BioResurrect.SetLifespanOverride(_inlineId, value)) {
                CleanupInlineEdit(false);
                ShowWorldTip(BioText.T("bio_grave_life_failed", "保存失败。"));
                return;
            }
            CleanupInlineEdit(!canceled);
        }

        private static void CancelInlineEdit() {
            if (_inlineInput != null) CleanupInlineEdit(false);
        }

        private static void CleanupInlineEdit(bool pRefreshNextFrame) {
            if (_cleaningInline) return;
            _cleaningInline = true;
            try {
                InputField input = _inlineInput;
                Text text = _inlineText;
                if (input != null && _inlineEndEdit != null)
                    input.onEndEdit.RemoveListener(_inlineEndEdit);
                if (input != null) input.enabled = false;
                if (text != null) {
                    text.alignment = _inlineOldAlignment;
                    text.horizontalOverflow = _inlineOldHorizontal;
                    text.verticalOverflow = _inlineOldVertical;
                    text.supportRichText = _inlineOldRichText;
                    text.text = _inlineDisplayText ?? "";
                }
                if (_inlineLayout != null) {
                    if (_inlineCreatedLayout) UnityEngine.Object.Destroy(_inlineLayout);
                    else {
                        _inlineLayout.minWidth = _inlineOldMinWidth;
                        _inlineLayout.preferredWidth = _inlineOldPreferredWidth;
                        _inlineLayout.flexibleWidth = _inlineOldFlexibleWidth;
                        _inlineLayout.minHeight = _inlineOldMinHeight;
                        _inlineLayout.preferredHeight = _inlineOldPreferredHeight;
                        _inlineLayout.flexibleHeight = _inlineOldFlexibleHeight;
                    }
                }
                if (_inlineMask != null && _inlineCreatedMask) UnityEngine.Object.Destroy(_inlineMask);
                if (input != null) UnityEngine.Object.Destroy(input);
                if (_inlineAgeButton != null) _inlineAgeButton.interactable = true;
            } finally {
                _inlineInput = null;
                _inlineText = null;
                _inlineLayout = null;
                _inlineMask = null;
                _inlineEndEdit = null;
                _inlineAgeButton = null;
                _inlineDisplayText = null;
                _inlineId = 0;
                _inlineCreatedLayout = false;
                _inlineCreatedMask = false;
                _releaseReviveBlockPending = true;
                _cleaningInline = false;
                if (pRefreshNextFrame) Interlocked.Exchange(ref _refreshPending, 1);
            }
        }

        public static void ReleaseReviveBlockIfReady() {
            if (!_releaseReviveBlockPending || _inlineInput != null
                || UnityEngine.Input.GetMouseButton(0)) return;
            _releaseReviveBlockPending = false;
            _blockReviveActions = false;
        }

        private static void OpenReviveModal(long pId, string pWho, Button pOpener,
            int pAge, float pLifespan) {
            if (_blockReviveActions) return;
            CancelInlineEdit();
            CloseModal();
            _modalOpener = pOpener;
            BioResurrect.Grave grave;
            if (!BioResurrect.TryGet(pId, out grave)) return;
            RectTransform panel = CreateModal(BioText.T("bio_grave_confirm_title", "确认复活"));
            if (panel == null) return;
            AddModalLabel(panel, BioText.F("bio_grave_confirm_text", "确定要复活 {0} 吗？", pWho),
                12, ColorGray, 34f);
            AddModalLabel(panel, BuildRowTooltip(grave), 10, ColorDim, 62f);
            int lifespan = Mathf.Max(1, Mathf.RoundToInt(pLifespan));
            AddModalLabel(panel, BioText.F("bio_grave_confirm_warning",
                "警告：寿命上限 {0} 不高于复活年龄 {1}，复活后会再次寿终。",
                lifespan, pAge), 10, ColorWarn, 48f);
            Action accept = () => {
                if (_blockReviveActions) {
                    ShowWorldTip(BioText.T("bio_grave_revive_blocked", "正在编辑寿命，请完成后再复活。"));
                    return;
                }
                if (BioResurrect.IsBusy(pId)) {
                    ShowWorldTip(BioText.T("bio_grave_revive_busy", "复活正在处理中，请稍候。"));
                    return;
                }
                CloseModal();
                if (pOpener != null) pOpener.interactable = false;
                if (BioResurrect.Resurrect(pId)) Render();
                else {
                    if (pOpener != null) { pOpener.enabled = true; pOpener.interactable = true; }
                    ShowWorldTip(BioText.T("bio_grave_revive_failed", "复活失败，请稍后重试。"));
                }
            };
            AddModalButtons(panel, BioText.T("bio_grave_confirm", "确认复活"), accept,
                BioText.T("bio_grave_cancel", "取消"), CloseModal);
            BioGraveModalKeys keys = _modal.AddComponent<BioGraveModalKeys>();
            keys.Accept = accept;
            keys.Cancel = CloseModal;
            FinalizeModal(panel);
        }

        private static RectTransform CreateModal(string pTitle) {
            Canvas canvas = null;
            if (_modalOpener != null) canvas = _modalOpener.GetComponentInParent<Canvas>();
            if (canvas == null && _window != null) canvas = _window.GetComponentInParent<Canvas>();
            if (canvas == null && CanvasMain.instance != null) canvas = CanvasMain.instance.canvas_windows;
            if (canvas == null) return null;

            GameObject root = new GameObject("BioGraveModal", typeof(RectTransform), typeof(Image));
            root.transform.SetParent(canvas.transform, false);
            RectTransform rootRect = root.GetComponent<RectTransform>();
            rootRect.anchorMin = Vector2.zero;
            rootRect.anchorMax = Vector2.one;
            rootRect.offsetMin = Vector2.zero;
            rootRect.offsetMax = Vector2.zero;
            Image blocker = root.GetComponent<Image>();
            blocker.color = new Color(0f, 0f, 0f, 0.45f);
            blocker.raycastTarget = true;
            _modal = root;

            GameObject panelObject = new GameObject("Panel", typeof(RectTransform), typeof(Image),
                typeof(VerticalLayoutGroup), typeof(ContentSizeFitter));
            panelObject.transform.SetParent(root.transform, false);
            RectTransform panel = panelObject.GetComponent<RectTransform>();
            panel.anchorMin = new Vector2(0.5f, 0.5f);
            panel.anchorMax = new Vector2(0.5f, 0.5f);
            panel.pivot = new Vector2(0.5f, 0.5f);
            panel.sizeDelta = new Vector2(330f, 0f);
            ApplyPanelSprite(panelObject.GetComponent<Image>(), new Color(0.10f, 0.11f, 0.09f, 1f));
            VerticalLayoutGroup layout = panelObject.GetComponent<VerticalLayoutGroup>();
            layout.padding = new RectOffset(14, 14, 12, 12);
            layout.spacing = 7f;
            layout.childControlWidth = true;
            layout.childForceExpandWidth = true;
            layout.childControlHeight = true;
            layout.childForceExpandHeight = false;
            ContentSizeFitter fitter = panelObject.GetComponent<ContentSizeFitter>();
            fitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            AddModalLabel(panel, pTitle, 14, ColorGold, 32f).fontStyle = FontStyle.Bold;
            return panel;
        }

        private static Text AddModalLabel(Transform pParent, string pText, int pSize,
            Color pColor, float pHeight) {
            Text text = AddText(pParent, pText, pSize, pColor, FontStyle.Normal);
            LayoutElement element = text.gameObject.AddComponent<LayoutElement>();
            element.minHeight = pHeight;
            element.preferredHeight = pHeight;
            text.alignment = TextAnchor.MiddleLeft;
            return text;
        }

        private static InputField AddNumberInput(Transform pParent, string pValue) {
            GameObject fieldObject = new GameObject("LifespanInput", typeof(RectTransform),
                typeof(Image), typeof(InputField), typeof(LayoutElement));
            fieldObject.transform.SetParent(pParent, false);
            Image image = fieldObject.GetComponent<Image>();
            ApplyPanelSprite(image, new Color(0.04f, 0.05f, 0.04f, 1f));
            image.raycastTarget = true;
            LayoutElement element = fieldObject.GetComponent<LayoutElement>();
            element.minHeight = 34f;
            element.preferredHeight = 34f;

            Text valueText = AddText(fieldObject.transform, pValue, 12, Color.white, FontStyle.Normal);
            Stretch(valueText.rectTransform, 8f, 8f);
            valueText.alignment = TextAnchor.MiddleLeft;
            valueText.raycastTarget = false;
            InputField input = fieldObject.GetComponent<InputField>();
            input.textComponent = valueText;
            input.contentType = InputField.ContentType.IntegerNumber;
            input.characterLimit = 7;
            input.text = pValue;
            input.caretColor = Color.white;
            input.selectionColor = new Color(0.35f, 0.55f, 0.85f, 0.75f);
            return input;
        }

        private static void AddModalButtons(Transform pParent, string pAcceptText, Action pAccept,
            string pCancelText, Action pCancel) {
            GameObject row = new GameObject("Buttons", typeof(RectTransform),
                typeof(HorizontalLayoutGroup), typeof(LayoutElement));
            row.transform.SetParent(pParent, false);
            LayoutElement rowElement = row.GetComponent<LayoutElement>();
            rowElement.minHeight = 32f;
            rowElement.preferredHeight = 32f;
            HorizontalLayoutGroup layout = row.GetComponent<HorizontalLayoutGroup>();
            layout.spacing = 8f;
            layout.childControlWidth = true;
            layout.childForceExpandWidth = true;
            layout.childControlHeight = true;
            layout.childForceExpandHeight = true;
            AddModalButton(row.transform, pAcceptText, pAccept, ColorRevive);
            AddModalButton(row.transform, pCancelText, pCancel, ColorGray);
        }

        private static void AddModalButton(Transform pParent, string pText, Action pAction, Color pColor) {
            GameObject buttonObject = new GameObject("Button", typeof(RectTransform),
                typeof(Image), typeof(Button));
            buttonObject.transform.SetParent(pParent, false);
            Image image = buttonObject.GetComponent<Image>();
            Sprite sprite = null;
            try {
                sprite = SpriteTextureLoader.getSprite("ui/special/button");
            } catch (Exception ex) {
                Main.LogError("生物学:读取弹窗按钮背景失败 " + ex);
            }
            if (sprite != null) {
                image.sprite = sprite;
                image.type = sprite.border == Vector4.zero ? Image.Type.Simple : Image.Type.Sliced;
            }
            image.color = new Color(0.19f, 0.22f, 0.18f, 1f);
            Text label = AddText(buttonObject.transform, pText, 11, pColor, FontStyle.Bold);
            Stretch(label.rectTransform, 4f, 4f);
            label.alignment = TextAnchor.MiddleCenter;
            Button button = buttonObject.GetComponent<Button>();
            button.targetGraphic = image;
            button.transition = Selectable.Transition.ColorTint;
            button.onClick.AddListener(() => { if (pAction != null) pAction(); });
        }

        private static void FinalizeModal(RectTransform pPanel) {
            if (pPanel == null) return;
            LayoutRebuilder.ForceRebuildLayoutImmediate(pPanel);
            LayoutRebuilder.ForceRebuildLayoutImmediate(pPanel);
        }

        private static void CloseModal() {
            if (_modal != null) UnityEngine.Object.Destroy(_modal);
            _modal = null;
            _modalOpener = null;
        }

        private static void AddHeaderBar(string pTitle, string pCount) {
            GameObject bar = new GameObject("Header", typeof(RectTransform), typeof(Image), typeof(LayoutElement));
            bar.transform.SetParent(_content, false);
            RectTransform barRect = bar.GetComponent<RectTransform>();
            barRect.anchorMin = new Vector2(0f, 0f);
            barRect.anchorMax = new Vector2(1f, 0f);
            barRect.sizeDelta = new Vector2(0f, 22f);
            ApplyPanelSprite(bar.GetComponent<Image>(), new Color(0.07f, 0.08f, 0.06f, 0.95f));
            LayoutElement element = bar.GetComponent<LayoutElement>();
            element.minHeight = 22f;
            element.preferredHeight = 22f;
            element.preferredWidth = -1f;
            element.flexibleWidth = 1f;
            Text title = AddText(bar.transform, pTitle, 12, ColorGold, FontStyle.Bold);
            Stretch(title.rectTransform, 8f, 40f);
            title.alignment = TextAnchor.MiddleLeft;
            title.horizontalOverflow = HorizontalWrapMode.Wrap;
            title.verticalOverflow = VerticalWrapMode.Truncate;
            Text count = AddText(bar.transform, pCount, 12, ColorGold, FontStyle.Bold);
            RectTransform countRect = count.rectTransform;
            countRect.anchorMin = new Vector2(1f, 0f);
            countRect.anchorMax = new Vector2(1f, 1f);
            countRect.pivot = new Vector2(1f, 0.5f);
            countRect.sizeDelta = new Vector2(32f, 0f);
            countRect.anchoredPosition = new Vector2(-8f, 0f);
            count.alignment = TextAnchor.MiddleRight;
            count.horizontalOverflow = HorizontalWrapMode.Wrap;
            count.verticalOverflow = VerticalWrapMode.Truncate;
        }

        private static Text AddMessage(string pText, Color pColor) {
            Text text = AddText(_content, pText, 11, pColor, FontStyle.Normal);
            LayoutElement element = text.gameObject.AddComponent<LayoutElement>();
            element.minHeight = 36f;
            element.preferredHeight = 36f;
            element.preferredWidth = -1f;
            element.flexibleWidth = 1f;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Truncate;
            return text;
        }

        private static void ApplyPanelSprite(Image pImage, Color pColor) {
            if (pImage == null) return;
            pImage.color = pColor;
            pImage.raycastTarget = false;
            Sprite sprite = null;
            try {
                sprite = SpriteTextureLoader.getSprite("ui/special/windowInnerSliced");
            } catch (Exception ex) {
                Main.LogError("生物学:读取面板背景失败 ui/special/windowInnerSliced " + ex);
            }
            if (sprite == null) {
                try {
                    sprite = SpriteTextureLoader.getSprite("ui/special/button");
                } catch (Exception ex) {
                    Main.LogError("生物学:读取面板备用背景失败 ui/special/button " + ex);
                }
            }
            if (sprite == null) {
                pImage.type = Image.Type.Simple;
                return;
            }
            pImage.sprite = sprite;
            pImage.type = sprite.border == Vector4.zero ? Image.Type.Simple : Image.Type.Sliced;
            pImage.fillCenter = true;
        }

        private static void Stretch(RectTransform pRect, float pLeft, float pRight) {
            pRect.anchorMin = new Vector2(0f, 0f);
            pRect.anchorMax = new Vector2(1f, 1f);
            pRect.offsetMin = new Vector2(pLeft, 0f);
            pRect.offsetMax = new Vector2(-pRight, 0f);
        }

        private static Text AddText(Transform pParent, string pText, int pSize,
            Color pColor, FontStyle pStyle) {
            GameObject textObject = new GameObject("Row", typeof(RectTransform), typeof(Text));
            textObject.transform.SetParent(pParent, false);
            Text text = textObject.GetComponent<Text>();
            text.font = LocalizedTextManager.current_font;
            text.fontSize = pSize;
            text.color = pColor;
            text.fontStyle = pStyle;
            text.text = pText;
            text.alignment = TextAnchor.UpperLeft;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Overflow;
            text.raycastTarget = false;
            text.supportRichText = true;
            return text;
        }

        private static void RebuildLayout() {
            RectTransform contentRect = _content as RectTransform;
            if (contentRect == null) return;
            LayoutRebuilder.ForceRebuildLayoutImmediate(contentRect);
            LayoutRebuilder.ForceRebuildLayoutImmediate(contentRect);
        }

        private static void EnsureMainThreadPump(Transform pParent) {
            if (pParent == null || pParent.GetComponent<BioGraveMainThreadPump>() != null) return;
            pParent.gameObject.AddComponent<BioGraveMainThreadPump>();
        }
    }
}
