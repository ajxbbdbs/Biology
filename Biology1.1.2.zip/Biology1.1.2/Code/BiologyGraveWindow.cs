using System.Collections;
using System.Text;
using NeoModLoader.General.UI.Window;
using UnityEngine;
using UnityEngine.UI;

namespace RimWorldMod {
    /// <summary>独立的已故收藏 ScrollWindow，不依赖当前选中的 Actor。</summary>
    internal sealed class BiologyGraveWindow : AutoLayoutWindow<BiologyGraveWindow> {
        public const string WindowId = "bio_grave_window";
        public static BiologyGraveWindow Instance;

        private VerticalLayoutGroup _contentLayout;
        private bool _diagnosticsLogged;

        protected override void Init() {
            Instance = this;
            ConfigureWindowHost();
            BioGraveTab.BindWindow(ScrollWindowComponent, ContentTransform);
        }

        public override void OnNormalEnable() {
            ConfigureWindowHost();
            BioGraveTab.BindWindow(ScrollWindowComponent, ContentTransform);
            BioGraveTab.Render();
            if (!_diagnosticsLogged) StartCoroutine(LogLayoutAfterFrame());
        }

        public override void OnNormalDisable() {
            BioGraveTab.OnWindowClosed();
        }

        private void ConfigureWindowHost() {
            RectTransform content = ContentTransform as RectTransform;
            if (content == null) return;

            // windows/empty 当前没有设置页内容；仍主动清掉任何克隆/热重载遗留子节点。
            for (int i = content.childCount - 1; i >= 0; i--)
                Object.DestroyImmediate(content.GetChild(i).gameObject);
            DisableOptionalNode("Tabs Right");
            DisableOptionalNode("Background/Tabs");

            // AutoLayoutWindow.CreateWindow already installs the only root VerticalLayoutGroup.
            _contentLayout = GetLayoutGroup();
            foreach (LayoutGroup group in content.GetComponents<LayoutGroup>())
                group.enabled = group == _contentLayout;
            _contentLayout.padding = new RectOffset(8, 8, 8, 8);
            _contentLayout.spacing = 5f;
            _contentLayout.childAlignment = TextAnchor.UpperCenter;
            _contentLayout.childControlWidth = true;
            _contentLayout.childForceExpandWidth = true;
            _contentLayout.childControlHeight = false;
            _contentLayout.childForceExpandHeight = false;

            ContentSizeFitter selectedFitter = content.GetComponent<ContentSizeFitter>();
            foreach (ContentSizeFitter candidate in content.GetComponents<ContentSizeFitter>()) {
                candidate.enabled = candidate == selectedFitter;
                if (candidate != selectedFitter) continue;
                candidate.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
                candidate.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            }

            // Content 横向完全服从 Viewport；左右留白只由上面的 layout.padding 提供。
            Vector2 offsetMin = content.offsetMin;
            Vector2 offsetMax = content.offsetMax;
            content.anchorMin = new Vector2(0f, content.anchorMin.y);
            content.anchorMax = new Vector2(1f, content.anchorMax.y);
            content.offsetMin = new Vector2(0f, offsetMin.y);
            content.offsetMax = new Vector2(0f, offsetMax.y);
            content.localScale = Vector3.one;

            ScrollRect scroll = ScrollWindowComponent.scrollRect;
            if (scroll != null) {
                RectTransform scrollRect = ScrollWindowComponent.transform_scrollRect;
                RectTransform viewport = scroll.viewport != null
                    ? scroll.viewport : ScrollWindowComponent.transform_viewport;
                if (scrollRect != null) scrollRect.localScale = Vector3.one;
                if (viewport != null) {
                    // NML empty-window helper gives Viewport sizeDelta.x=30; neutralize that
                    // expansion so clipping bounds exactly match the visible Scroll View.
                    Vector2 viewportMin = viewport.offsetMin;
                    Vector2 viewportMax = viewport.offsetMax;
                    viewport.anchorMin = new Vector2(0f, viewport.anchorMin.y);
                    viewport.anchorMax = new Vector2(1f, viewport.anchorMax.y);
                    viewport.offsetMin = new Vector2(0f, viewportMin.y);
                    viewport.offsetMax = new Vector2(0f, viewportMax.y);
                    viewport.localScale = Vector3.one;
                    if (viewport.GetComponent<Mask>() == null
                        && viewport.GetComponent<RectMask2D>() == null)
                        viewport.gameObject.AddComponent<RectMask2D>();
                }
                scroll.viewport = viewport;
                scroll.content = content;
                scroll.horizontal = false;
                scroll.vertical = true;
            }
        }

        private void DisableOptionalNode(string pPath) {
            Transform node = transform.Find(pPath);
            if (node != null) node.gameObject.SetActive(false);
        }

        private IEnumerator LogLayoutAfterFrame() {
            if (_diagnosticsLogged) yield break;
            _diagnosticsLogged = true;
            yield return null;
            yield return new WaitForEndOfFrame();
            Canvas.ForceUpdateCanvases();
            RectTransform content = ContentTransform as RectTransform;
            if (content != null) LayoutRebuilder.ForceRebuildLayoutImmediate(content);
            StringBuilder log = new StringBuilder(768);
            log.Append("生物学:已故收藏首次布局");
            AppendRect(log, " window", transform as RectTransform);
            AppendRect(log, " background", BackgroundTransform as RectTransform);
            AppendRect(log, " scroll", ScrollWindowComponent.transform_scrollRect);
            AppendRect(log, " viewport", ScrollWindowComponent.scrollRect != null
                ? ScrollWindowComponent.scrollRect.viewport : ScrollWindowComponent.transform_viewport);
            AppendRect(log, " content", content);
            Transform header = content != null ? content.Find("Header") : null;
            AppendRect(log, " header", header as RectTransform);
            log.Append(" layoutPadding=").Append(_contentLayout != null
                ? _contentLayout.padding.left + "," + _contentLayout.padding.right : "null");
            Main.LogInfo(log.ToString());
        }

        private static void AppendRect(StringBuilder pLog, string pLabel, RectTransform pRect) {
            if (pRect == null) { pLog.Append("\n").Append(pLabel).Append("=<null>"); return; }
            pLog.Append("\n").Append(pLabel).Append(" path=").Append(FullPath(pRect))
                .Append(" rect=").Append(pRect.rect).Append(" sizeDelta=").Append(pRect.sizeDelta)
                .Append(" anchors=").Append(pRect.anchorMin).Append("..").Append(pRect.anchorMax)
                .Append(" offsets=").Append(pRect.offsetMin).Append("..").Append(pRect.offsetMax)
                .Append(" scale=").Append(pRect.localScale);
        }

        private static string FullPath(Transform pNode) {
            if (pNode == null) return "<null>";
            string path = pNode.name;
            while (pNode.parent != null) { pNode = pNode.parent; path = pNode.name + "/" + path; }
            return path;
        }
    }
}
