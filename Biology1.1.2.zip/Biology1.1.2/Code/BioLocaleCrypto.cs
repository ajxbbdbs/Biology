using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using HarmonyLib;
using Newtonsoft.Json.Linq;

namespace RimWorldMod {

    /// <summary>
    /// 本地化文本的运行时解密与注入。
    ///
    /// 背景:Locales/*.json 会被 NeoModLoader/游戏本体当作明文本地化自动加载,
    /// 任何外部程序都能直接打开读取里面的疾病文案/对话文本。为了不让明文躺在磁盘上,
    /// 真正的文案改成用 AES-256-CBC 加密后放在 SecureData/<语言>.dat,
    /// Locales/*.json 只留一个空 {} 占位(保证 NML 的自动加载流程不报错)。
    ///
    /// 游戏调用 LocalizedTextManager.loadLocalizedText 完成一次本地化加载后
    /// (首次启动或运行时切换语言都会触发),这里的 Postfix 会:
    ///   1. 读出当前语言 id(ch/cz/en);
    ///   2. 解密对应的 SecureData/<语言>.dat;
    ///   3. 把解出来的键值对写进 LocalizedTextManager 的 _localized_text 字典。
    ///
    /// 说明:NML 在运行时直接编译 .cs 源码,所以密钥必然存在于源码里,这只是"混淆/防直接抓取",
    /// 不是真正意义上的强加密——能挡住直接打开 json 或扫描目录的程序,挡不住愿意读源码的人。
    /// </summary>
    public static class BioLocaleCrypto {

        // 加密文件所在目录(模组根目录下,NML 不会把它当作 Locales/GameResources/Sounds 自动扫描)。
        private const string DataFolder = "SecureData";
        // 游戏本体自动加载的本地化目录。
        private const string LocalesFolder = "Locales";

        private static bool _patched;
        // 编辑模式:true = 明文态(Locales/*.json 是真内容,游戏直接读,不再从 .dat 注入);
        //           false = 加密态(Locales/*.json 为空占位,运行时从 .dat 解密注入)。
        public static bool EditMode;
        // 缓存本体的本地化加载方法,切换后用它重载,免重启。
        private static MethodInfo _loadMethod;

        // 密钥/IV 不直接以明文常量出现:各字节先与掩码逐位异或后保存,运行时再异或还原。
        // 对应加密时使用的:
        //   KEY = 7b2f91c4a6d83e05f1c7b9204ea6d3128c5f0a7be49d61325f87a0cd4e9b6f21
        //   IV  = a3f5c9018d2e4b6079c1e5a4b8d20f6c
        private const byte Mask = 0x5A;
        private static readonly byte[] KeyObf = {
            0x21, 0x75, 0xcb, 0x9e, 0xfc, 0x82, 0x64, 0x5f, 0xab, 0x9d, 0xe3, 0x7a, 0x14, 0xfc, 0x89, 0x48,
            0xd6, 0x05, 0x50, 0x21, 0xbe, 0xc7, 0x3b, 0x68, 0x05, 0xdd, 0xfa, 0x97, 0x14, 0xc1, 0x35, 0x7b
        };
        private static readonly byte[] IvObf = {
            0xf9, 0xaf, 0x93, 0x5b, 0xd7, 0x74, 0x11, 0x3a, 0x23, 0x9b, 0xbf, 0xfe, 0xe2, 0x88, 0x55, 0x36
        };

        private static byte[] Deobfuscate(byte[] pSrc) {
            byte[] outBytes = new byte[pSrc.Length];
            for (int i = 0; i < pSrc.Length; i++) outBytes[i] = (byte)(pSrc[i] ^ Mask);
            return outBytes;
        }

        /// <summary>
        /// 挂上对 LocalizedTextManager.loadLocalizedText 的 Postfix。首次启动和切换语言都会走到。
        /// </summary>
        public static void Ensure() {
            if (_patched) return;
            try {
                _loadMethod = AccessTools.Method(typeof(LocalizedTextManager), "loadLocalizedText");
                if (_loadMethod == null) throw new MissingMethodException("LocalizedTextManager.loadLocalizedText");
                Harmony harmony = new Harmony("rimworld_biology_locale_crypto");
                harmony.Patch(_loadMethod,
                    postfix: new HarmonyMethod(AccessTools.Method(typeof(BioLocaleCrypto), nameof(AfterLoad))));
                _patched = true;
                Main.LogInfo("生物学:本地化解密守卫已启用");
                // 若模组加载时本地化早已完成一次,Postfix 不会补触发,这里立即补注入一次。
                InjectCurrent();
            } catch (Exception e) {
                Main.LogError("生物学:本地化解密守卫启用失败 " + e);
            }
        }

        // 游戏每次完成本地化加载后调用。
        private static void AfterLoad() {
            InjectCurrent();
        }

        /// <summary>
        /// 编辑模式开关回调(见 Main.OnLocaleEditModeChanged)。
        ///   开启:把每种语言的 .dat 解密写回 Locales/*.json,让玩家直接用文本编辑器改;
        ///   关闭:把改好的 Locales/*.json 加密回 .dat,再把明文清空为 {} 占位。
        /// 切换后立刻重载本地化并重新注入,不用重启游戏。
        /// </summary>
        public static void ApplyEditMode(bool pEnabled) {
            try {
                EditMode = pEnabled;
                string root = Main.Instance.GetDeclaration().FolderPath;
                string localesDir = Path.Combine(root, LocalesFolder);
                string dataDir = Path.Combine(root, DataFolder);
                Directory.CreateDirectory(dataDir);

                if (pEnabled) {
                    // 加密态 -> 明文态:解密 .dat 写回 json
                    int n = 0;
                    foreach (string lang in EnumLangs(dataDir)) {
                        byte[] plain = DecryptLangFile(lang);
                        if (plain == null) continue;
                        File.WriteAllBytes(Path.Combine(localesDir, lang + ".json"), plain);
                        n++;
                    }
                    Main.LogInfo("生物学:本地化编辑模式已开启,已还原 " + n + " 门语言的明文到 Locales/。改完记得关掉开关以重新加密。");
                } else {
                    // 明文态 -> 加密态:加密 json 回 .dat,再清空明文
                    int n = 0;
                    foreach (string lang in EnumLangs(localesDir)) {
                        string jsonPath = Path.Combine(localesDir, lang + ".json");
                        byte[] plain = File.ReadAllBytes(jsonPath);
                        // 跳过空占位({}),避免把占位当成真内容加密覆盖掉 .dat
                        string text = Encoding.UTF8.GetString(plain).Trim();
                        if (text.Length <= 2) continue;
                        // 校验 JSON 合法,坏文件不加密,防止整门语言丢失
                        try { JObject.Parse(text); } catch (Exception pe) {
                            Main.LogError("生物学:" + lang + ".json 不是合法 JSON,已跳过加密 " + pe.Message);
                            continue;
                        }
                        EncryptToDat(plain, Path.Combine(dataDir, lang + ".dat"));
                        File.WriteAllText(jsonPath, "{}", Encoding.UTF8);
                        n++;
                    }
                    Main.LogInfo("生物学:本地化编辑模式已关闭,已重新加密 " + n + " 门语言并清空明文。");
                }

                ReloadLocalization();
            } catch (Exception e) {
                Main.LogError("生物学:切换本地化编辑模式失败 " + e);
            }
        }

        // 触发本体重新加载本地化(会连带走一次 AfterLoad -> InjectCurrent)。
        private static void ReloadLocalization() {
            try {
                if (_loadMethod != null && LocalizedTextManager.instance != null) {
                    _loadMethod.Invoke(LocalizedTextManager.instance, null);
                } else {
                    InjectCurrent();
                }
            } catch (Exception e) {
                Main.LogError("生物学:重载本地化失败,退回直接注入 " + e);
                InjectCurrent();
            }
        }

        // 列出某目录下存在的语言(按 ch/cz/en 过滤)。
        private static IEnumerable<string> EnumLangs(string pDir) {
            var list = new List<string>();
            foreach (string lang in new[] { "ch", "cz", "en" }) {
                string p = Path.Combine(pDir, lang + (pDir.EndsWith(DataFolder) ? ".dat" : ".json"));
                if (File.Exists(p)) list.Add(lang);
            }
            return list;
        }

        /// <summary>
        /// 按当前语言解密并注入。编辑模式下明文已经在 Locales/,游戏自己会读,这里跳过注入。
        /// 找不到文件或解密失败时静默保底(留空占位,不影响游戏运行)。
        /// </summary>
        public static void InjectCurrent() {
            try {
                if (EditMode) return; // 明文态:游戏直接读 Locales/*.json,无需注入
                var inst = LocalizedTextManager.instance;
                if (inst == null || inst._localized_text == null) return;

                string lang = ResolveLanguageId();
                if (string.IsNullOrEmpty(lang)) return;

                byte[] plain = DecryptLangFile(lang);
                if (plain == null) return;

                string json = Encoding.UTF8.GetString(plain);
                JObject obj = JObject.Parse(json);
                int n = 0;
                foreach (var kv in obj) {
                    if (kv.Value == null) continue;
                    inst._localized_text[kv.Key] = kv.Value.ToString();
                    n++;
                }
                Main.LogInfo("生物学:已注入本地化 " + lang + " 共 " + n + " 条");
            } catch (Exception e) {
                Main.LogError("生物学:本地化解密注入失败 " + e);
            }
        }

        // 读出当前语言 id。优先反射常见字段/属性,退回默认 "en"。
        private static string ResolveLanguageId() {
            try {
                var inst = LocalizedTextManager.instance;
                if (inst == null) return null;

                // 常见字段名:language / current_language / language_id
                foreach (string field in new[] { "language", "current_language", "language_id" }) {
                    object v = TryGetMember(inst, field);
                    string id = NormalizeLang(v);
                    if (!string.IsNullOrEmpty(id)) return id;
                }

                // 兜底:直接看 SecureData 里存在哪些语言,默认取 en。
                return "en";
            } catch {
                return "en";
            }
        }

        // 语言对象/字符串统一转成文件名用的小写 id(ch/cz/en)。
        private static string NormalizeLang(object pValue) {
            if (pValue == null) return null;
            string s;
            if (pValue is string str) {
                s = str;
            } else {
                // 语言可能是个对象,尝试它的 id / code / name 字段,否则 ToString。
                object id = TryGetMember(pValue, "id") ?? TryGetMember(pValue, "code") ?? TryGetMember(pValue, "name");
                s = id != null ? id.ToString() : pValue.ToString();
            }
            if (string.IsNullOrEmpty(s)) return null;
            s = s.Trim().ToLowerInvariant();
            // 只接受实际存在的语言文件名,避免把 "LanguageData" 之类的对象名当语言。
            if (s == "ch" || s == "cz" || s == "en") return s;
            return null;
        }

        private static object TryGetMember(object pObj, string pName) {
            if (pObj == null) return null;
            try {
                Type t = pObj.GetType();
                FieldInfo f = t.GetField(pName,
                    BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static);
                if (f != null) return f.GetValue(pObj);
                PropertyInfo p = t.GetProperty(pName,
                    BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static);
                if (p != null && p.CanRead) return p.GetValue(pObj, null);
            } catch { }
            return null;
        }

        private static byte[] DecryptLangFile(string pLang) {
            try {
                string root = Main.Instance.GetDeclaration().FolderPath;
                string path = Path.Combine(Path.Combine(root, DataFolder), pLang + ".dat");
                if (!File.Exists(path)) {
                    Main.LogError("生物学:找不到加密本地化文件 " + path);
                    return null;
                }
                byte[] cipher = File.ReadAllBytes(path);
                using (Aes aes = Aes.Create()) {
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;
                    aes.KeySize = 256;
                    aes.Key = Deobfuscate(KeyObf);
                    aes.IV = Deobfuscate(IvObf);
                    using (var dec = aes.CreateDecryptor())
                    using (var msIn = new MemoryStream(cipher))
                    using (var cs = new CryptoStream(msIn, dec, CryptoStreamMode.Read))
                    using (var msOut = new MemoryStream()) {
                        byte[] buf = new byte[8192];
                        int read;
                        while ((read = cs.Read(buf, 0, buf.Length)) > 0) msOut.Write(buf, 0, read);
                        return msOut.ToArray();
                    }
                }
            } catch (Exception e) {
                Main.LogError("生物学:解密本地化文件失败 " + pLang + " " + e);
                return null;
            }
        }

        // 用与解密相同的密钥/IV 把明文字节 AES 加密写到 .dat。
        private static void EncryptToDat(byte[] pPlain, string pOutPath) {
            using (Aes aes = Aes.Create()) {
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                aes.KeySize = 256;
                aes.Key = Deobfuscate(KeyObf);
                aes.IV = Deobfuscate(IvObf);
                using (var enc = aes.CreateEncryptor())
                using (var msOut = new MemoryStream()) {
                    using (var cs = new CryptoStream(msOut, enc, CryptoStreamMode.Write)) {
                        cs.Write(pPlain, 0, pPlain.Length);
                        cs.FlushFinalBlock();
                    }
                    File.WriteAllBytes(pOutPath, msOut.ToArray());
                }
            }
        }
    }
}
