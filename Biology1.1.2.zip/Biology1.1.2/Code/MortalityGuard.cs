using System;
using System.Collections.Generic;
using System.Reflection;
using System.Collections.Concurrent;
using HarmonyLib;
using UnityEngine;

namespace RimWorldMod {

    // 统一死亡入口:主线程自然死亡更新覆盖全部单位,并强制结算年龄、致命器官和零血量。
    public static class MortalityGuard {
        public const string LifespanOverrideKey = "bio_lifespan_override";
        public const int MinLifespanOverride = 1;
        public const int MaxLifespanOverride = 1000000;

        private static readonly HashSet<string> FatalOrgans = new HashSet<string> {
            "heart", "brain", "blood", "head", "neck", "gills"
        };

        private static bool _patched;
        private static bool _killing;
        private static MethodInfo _dieMethod;
        // 记录哪些单位有寿命覆盖值。仅用于 updateStats 热路径(每帧/并行)快速判断是否需要重写 lifespan;
        // 不再作为"是否斩杀"的判定依据 —— 斩杀一律以 data 里的权威覆盖值为准,避免漏登记导致覆盖失效。
        private static readonly ConcurrentDictionary<long, byte> _lifespanOverrideIds = new ConcurrentDictionary<long, byte>();
        private const float StateCheckInterval = 0.5f;

        public static void Ensure() {
            if (_patched) return;
            try {
                MethodInfo update = AccessTools.Method(typeof(Actor), "b55_updateNaturalDeaths");
                _dieMethod = ResolveDieMethod();
                if (update == null) throw new MissingMethodException("Actor.b55_updateNaturalDeaths");
                if (_dieMethod == null) throw new MissingMethodException("Actor.die(bool, AttackType, bool, bool)");
                Harmony harmony = new Harmony("rimworld_health_mortality_guard");
                harmony.Patch(update,
                    prefix: new HarmonyMethod(AccessTools.Method(typeof(MortalityGuard), nameof(NaturalDeathsPrefix))));
                _patched = true;
                Main.LogInfo("生物学:统一死亡守卫已启用");
            } catch (Exception e) {
                Main.LogError("生物学:统一死亡守卫启用失败 " + e);
            }
        }

        private static MethodInfo ResolveDieMethod() {
            MethodInfo method = AccessTools.Method(typeof(Actor), "die",
                new Type[] { typeof(bool), typeof(AttackType), typeof(bool), typeof(bool) });
            if (method == null) return null;
            ParameterInfo[] args = method.GetParameters();
            return args.Length == 4 ? method : null;
        }

        // 原版自然死亡更新由主线程逐单位调用(随机 0-20 tick 跑一轮,非热路径),前置只强制应死者,其余仍走原版逻辑。
        public static bool NaturalDeathsPrefix(Actor __instance) {
            try {
                if (__instance == null || !__instance.isAlive()) return true;
                long id = __instance.getID();

                // 有效寿命一律以 data 里的权威覆盖值为准:直接读(TryGetValue,开销可忽略),不依赖登记表,
                // 从根本上杜绝"漏登记 → 覆盖失效 → 用原版物种寿命把单位斩杀晚了"的问题。
                float lifespan;
                int overrideValue = GetLifespanOverride(__instance);
                if (overrideValue > 0) {
                    lifespan = overrideValue;
                    // 顺手自愈登记:让 updateStats 热路径能把 stats["lifespan"] 持续重写回覆盖值(仅显示/其他系统用)。
                    if (!_lifespanOverrideIds.ContainsKey(id)) _lifespanOverrideIds[id] = 1;
                } else {
                    // 没有覆盖值:清掉可能残留的登记(换存档 id 复用等),避免热路径误重写。
                    if (!_lifespanOverrideIds.IsEmpty) { byte removed; _lifespanOverrideIds.TryRemove(id, out removed); }
                    try { lifespan = __instance.stats["lifespan"]; } catch { lifespan = 0f; }
                }
                bool reachedLifespan = false;
                if (lifespan > 0f) {
                    try { reachedLifespan = __instance.getAge() >= lifespan; } catch { }
                }
                ActorWoundState state = null;
                bool hasState = HealthSimulator.HasAnyState && HealthSimulator.TryGetState(id, out state) && state != null;
                if (!reachedLifespan && !hasState) return true;

                if (reachedLifespan) {
                    bool immortal = HasImmortal(__instance);
                    if (!immortal) {
                        ForceDie(__instance, AttackType.Age);
                        return false;
                    }
                }
                if (hasState && ProcessExistingState(__instance, state)) return false;
                // 不朽单位到了覆盖寿命上限,只跳过原版自然死亡,不能直接杀。
                if (reachedLifespan) return false;
            } catch (Exception e) {
                Main.LogError("生物学:自然死亡守卫异常 " + e);
            }
            return true;
        }

        public static float GetEffectiveLifespan(Actor pActor) {
            if (pActor == null) return 0f;
            int lifespanOverride = GetLifespanOverride(pActor);
            if (lifespanOverride > 0) return lifespanOverride;
            try { return pActor.stats["lifespan"]; }
            catch (Exception e) {
                Main.LogError("生物学:读取有效寿命失败 " + e);
                return 0f;
            }
        }

        public static int GetLifespanOverride(Actor pActor) {
            try {
                if (pActor == null || pActor.data == null) return 0;
                float value = pActor.data[LifespanOverrideKey];
                if (value < MinLifespanOverride) return 0;
                return Math.Min(MaxLifespanOverride, Math.Max(MinLifespanOverride, (int)Math.Round(value)));
            } catch {
                return 0;
            }
        }

        public static bool SetLifespanOverride(Actor pActor, int pLifespan) {
            if (pActor == null || pActor.data == null
                || pLifespan < MinLifespanOverride || pLifespan > MaxLifespanOverride) return false;
            try {
                pActor.data.set(LifespanOverrideKey, (float)pLifespan);
                pActor.stats["lifespan"] = pLifespan;
                try { _lifespanOverrideIds[pActor.getID()] = 1; } catch { }
                return true;
            } catch (Exception e) {
                Main.LogError("生物学:写入寿命上限失败 " + e);
                return false;
            }
        }

        public static void ReapplyLifespanOverride(Actor pActor) {
            if (pActor == null || _lifespanOverrideIds.IsEmpty) return;
            long id = -1L;
            try { id = pActor.getID(); } catch { }
            if (id < 0L || !_lifespanOverrideIds.ContainsKey(id)) return;
            int lifespanOverride = GetLifespanOverride(pActor);
            if (lifespanOverride <= 0) {
                byte removed;
                _lifespanOverrideIds.TryRemove(id, out removed);
                return;
            }
            try { pActor.stats["lifespan"] = lifespanOverride; } catch { }
        }

        public static bool HasReachedLifespan(Actor pActor) {
            try {
                float lifespan = GetEffectiveLifespan(pActor);
                return lifespan > 0f && pActor.getAge() >= lifespan;
            } catch (Exception e) {
                Main.LogError("生物学:寿命检测失败 " + e);
                return false;
            }
        }

        private static bool HasImmortal(Actor pActor) {
            try { return pActor != null && pActor.hasTrait("immortal"); }
            catch { return false; }
        }

        /// <summary>切换/重新加载世界时清空寿命覆盖登记表:单位 id 会在新世界里被复用,残留登记会误伤新单位。</summary>
        public static void ResetForNewWorld() {
            try { _lifespanOverrideIds.Clear(); } catch { }
        }

        // 高频入口只读已有状态,绝不为全世界无关单位创建器官状态。
        public static bool ProcessExistingState(Actor pActor) {
            if (pActor == null || !pActor.isAlive()) return false;
            ActorWoundState state;
            if (!HealthSimulator.TryGetState(pActor.getID(), out state)) return false;
            return ProcessExistingState(pActor, state);
        }

        // 传入已取好的状态,避免重复字典查询;完整模拟按 StateCheckInterval 节流。
        public static bool ProcessExistingState(Actor pActor, ActorWoundState pState) {
            if (pActor == null || !pActor.isAlive() || pState == null) return false;
            if (HasFatalFailure(pState)) {
                return ForceDie(pActor, AttackType.Divine);
            }
            if (pState.Mods == null) return false;
            float now = Time.unscaledTime;
            if (now < pState.NextDeathCheck) return false;
            pState.NextDeathCheck = now + StateCheckInterval;
            BodyHealth body = HealthSimulator.Simulate(pActor);
            foreach (OrganHealth organ in body.Organs) {
                if (organ != null && organ.Def != null && organ.Hp <= 0 && FatalOrgans.Contains(organ.Def.Id)) {
                    return ForceDie(pActor, AttackType.Divine);
                }
            }
            return false;
        }
        private static bool HasFatalFailure(ActorWoundState pState) {
            if (pState == null || pState.Mods == null) return false;
            foreach (string organ in FatalOrgans) {
                if (pState.Mods.RemovedOrgans != null && pState.Mods.RemovedOrgans.Contains(organ)) return true;
                int modifier;
                if (pState.Mods.HpMods != null && pState.Mods.HpMods.TryGetValue(organ, out modifier)
                    && modifier <= -100) return true;
            }
            return false;
        }

        public static bool ForceDie(Actor pActor, AttackType pAttackType) {
            if (pActor == null || _killing) return false;
            try {
                if (!pActor.isAlive()) return false;
                if (_dieMethod == null) _dieMethod = ResolveDieMethod();
                if (_dieMethod == null) {
                    Main.LogError("生物学:强制死亡失败,无法解析 Actor.die(bool, AttackType, bool, bool)");
                    return false;
                }
                _killing = true;
                _dieMethod.Invoke(pActor, new object[] { false, pAttackType, true, true });
                return true;
            } catch (TargetInvocationException e) {
                Main.LogError("生物学:强制死亡调用失败 " + (e.InnerException ?? e));
                return false;
            } catch (Exception e) {
                Main.LogError("生物学:强制死亡失败 " + e);
                return false;
            } finally {
                _killing = false;
            }
        }

        public static void ClampHealthToMax(Actor pActor) {
            try {
                if (pActor == null || pActor.data == null || !pActor.isAlive() || !HealthSimulator.HasAnyState) return;
                int max = Math.Max(0, (int)pActor.stats["health"]);
                if (pActor.getHealth() > max) pActor.data.health = max;
            } catch (Exception e) {
                Main.LogError("生物学:生命值上限兜底失败 " + e);
            }
        }
    }
}
