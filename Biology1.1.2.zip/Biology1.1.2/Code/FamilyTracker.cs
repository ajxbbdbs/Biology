using System;
using System.Collections.Generic;
using HarmonyLib;

namespace RimWorldMod {

    // 血缘追踪:记录每个孩子的父亲与母亲,用于"\u6027\u4ea4/肛交伴侣=孩子父亲"的真实姓名显示
    public static class FamilyTracker {

        // 孩子 ActorData id → (父 id, 母 id)
        private static readonly Dictionary<long, long[]> _parents = new Dictionary<long, long[]>();
        // 血缘表上限:世界跑久了每次生育都会往里加,不封顶会无限涨。满了整表清空(只影响父母姓名显示,
        // 与 _states/_wear 的处理一致)。makeBaby 在主线程执行,这里用普通字典即可。
        private const int MaxEntries = 20000;
        private static bool _patched;

        public static void Ensure() {
            if (_patched) return;
            _patched = true;
            try {
                Harmony harmony = new Harmony("rimworld_health_family");
                harmony.Patch(
                    AccessTools.Method(typeof(BabyMaker), "makeBaby"),
                    postfix: new HarmonyMethod(AccessTools.Method(typeof(FamilyTracker), nameof(OnBabyBorn)))
                );
                Main.LogInfo("生物学:血缘追踪已启用");
            } catch (Exception e) {
                Main.LogError("生物学:血缘追踪启用失败 " + e);
            }
        }

        /// <summary>切换/重新加载世界时清空血缘表:表按 id 存父母,新世界复用 id 会导致父母姓名张冠李戴。</summary>
        public static void ResetForNewWorld() {
            try { _parents.Clear(); } catch { }
        }

        // makeBaby 之后:记录孩子 → (父, 母);生孩子约 1/3 概率引发母亲\u9ad8\u6f6e;父亲\u5c04\u7cbe次数 +1
        public static void OnBabyBorn(Actor __result, Actor pParent1, Actor pParent2) {
            try {
                if (__result == null || __result.data == null) return;
                long childId = __result.data.id;
                long f1 = pParent1 != null && pParent1.data != null ? pParent1.data.id : -1L;
                long f2 = pParent2 != null && pParent2.data != null ? pParent2.data.id : -1L;
                if (_parents.Count >= MaxEntries && !_parents.ContainsKey(childId)) _parents.Clear();
                _parents[childId] = new[] { f1, f2 };
                // 母亲:优先选女性亲代,其次 pParent2
                Actor mother = null;
                if (pParent1 != null && pParent1.isSexFemale()) mother = pParent1;
                else if (pParent2 != null && pParent2.isSexFemale()) mother = pParent2;
                else mother = pParent2;
                if (mother != null && new System.Random().Next(3) == 0) {
                    ActorWoundState st = HealthSimulator.GetState(mother.getID());
                    st.Mods.OrgasmCount++;
                }
                // 父亲:非母亲的另一方;生育必然\u5c04\u7cbe,\u5c04\u7cbe次数 +1
                Actor father = null;
                if (mother == pParent1) father = pParent2;
                else father = pParent1;
                if (father != null) {
                    ActorWoundState st = HealthSimulator.GetState(father.getID());
                    st.Mods.EjaculationCount++;
                    Main.LogDebug("生物学:生育,父亲\u5c04\u7cbe次数+1(累计 " + st.Mods.EjaculationCount + ")");
                }
            } catch (Exception e) {
                Main.LogError("生物学:记录血缘失败 " + e);
            }
        }

        // 查询某单位作为父亲时,孩子的母亲们的真实姓名(去重);找不到返回空
        public static List<string> GetChildMotherNames(Actor pFather) {
            List<string> result = new List<string>();
            if (pFather == null || pFather.data == null) return result;
            long fatherId = pFather.data.id;
            HashSet<long> seen = new HashSet<long>();
            foreach (KeyValuePair<long, long[]> kv in _parents) {
                long f1 = kv.Value[0];
                long f2 = kv.Value[1];
                if (f1 != fatherId && f2 != fatherId) continue;
                long motherId = f1 == fatherId ? f2 : f1;
                if (motherId < 0 || seen.Contains(motherId)) continue;
                seen.Add(motherId);
                string name = GetActorName(motherId);
                if (!string.IsNullOrEmpty(name)) result.Add(name);
            }
            return result;
        }

        // 查询某单位作为母亲时,孩子的父亲们的真实姓名(去重);找不到返回空
        public static List<string> GetChildFatherNames(Actor pMother) {
            List<string> result = new List<string>();
            if (pMother == null || pMother.data == null) return result;
            long motherId = pMother.data.id;
            HashSet<long> seen = new HashSet<long>();
            foreach (KeyValuePair<long, long[]> kv in _parents) {
                long f1 = kv.Value[0];
                long f2 = kv.Value[1];
                long fatherId = f1 == motherId ? f2 : (f2 == motherId ? f1 : -1L);
                if (fatherId < 0 || seen.Contains(fatherId)) continue;
                seen.Add(fatherId);
                string name = GetActorName(fatherId);
                if (!string.IsNullOrEmpty(name)) result.Add(name);
            }
            return result;
        }

        private static string GetActorName(long pActorId) {
            try {
                Actor a = World.world.units.get(pActorId);
                if (a == null) return null;
                string n = a.getName();
                return string.IsNullOrEmpty(n) ? null : n;
            } catch {
                return null;
            }
        }
    }
}
