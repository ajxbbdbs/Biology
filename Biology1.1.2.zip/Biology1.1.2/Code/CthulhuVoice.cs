using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace RimWorldMod {

    /// <summary>
    /// 克苏鲁之脑的音效与台词。
    ///
    /// 音效是从 Terraria 里抽出来的原始音效(Content/Sounds/*.xnb → wav),见 Mod 目录的 Sounds 文件夹。
    /// 播放优先走游戏自己的 FMOD 核心系统(FMODUnity.RuntimeManager.CoreSystem),
    /// 这样和游戏本体共用一条音频总线、能吃游戏音量设置;万一 FMOD 不可用,
    /// 再退回 Unity 的 AudioSource(会自己补一个 AudioListener,否则 2D 音源是没声音的)。
    /// </summary>
    public static class CthulhuVoice {

        // 音效文件名(相对 Mod 目录的 Sounds 子目录)—— 换音效直接覆盖同名文件即可。
        public const string SndShellBreak = "Shatter.wav";       // 躯壳破碎(金脑被打碎)
        public const string SndAwaken = "Roar_0.wav";            // 苏醒咆哮
        public const string SndPhase2 = "Roar_2.wav";            // 二阶段登场咆哮
        public const string SndLaser = "Item_8.wav";             // 攻击:克苏鲁之脑的尖啸
        public const string SndDeath = "NPC_Killed_11.wav";      // 死亡
        // 小怪(爬行者 NPC 267)攻击时的叫声。
        // 注意:Terraria 里爬行者的 AI(aiStyle 55)是直接撞人、本身不放任何攻击音效,
        // 它自己只有"被打"(NPCHit9)和"死亡"(NPCDeath11)两个音。
        // 所以这里用同族的 BoC 尖啸(Item8)并调高音调,听起来就是"小一号的同类"。
        // 想换:Terraria 里爬行者的音色是 "NPC_Hit_9.wav";想更短更尖是 "Roar_1.wav"。
        public const string SndMinionAttack = "Item_8.wav";
        /// <summary>小怪叫声的音调(>1 更高更细,像小一号的生物)。</summary>
        public const float MinionAttackPitch = 1.3f;

        /// <summary>大字提示的默认停留秒数。</summary>
        public const float TipSeconds = 3f;

        private static readonly Dictionary<string, FMOD.Sound> _fmodSounds = new Dictionary<string, FMOD.Sound>();
        private static readonly HashSet<string> _fmodFailedFiles = new HashSet<string>();
        private static readonly Dictionary<string, AudioClip> _clips = new Dictionary<string, AudioClip>();
        private static AudioSource _source;
        private static bool _fmodNotReadyLogged;
        private static bool _missingLogged;
        private static bool _folderLogged;

        // ---------------------------------------------------------------- 播放

        public static void Play(string pFile, float pVolume = 1f, float pPitch = 1f) {
            try {
                if (string.IsNullOrEmpty(pFile)) return;
                string path = Path.Combine(SoundsFolder, pFile);
                if (!File.Exists(path)) {
                    if (!_missingLogged) {
                        _missingLogged = true;
                        Main.LogError("生物学[克苏鲁之脑] 找不到音效文件 " + path);
                    }
                    return;
                }
                if (PlayFmod(pFile, path, pVolume, pPitch)) return;
                PlayUnity(pFile, path, pVolume, pPitch);
            } catch (Exception e) {
                Main.LogError("生物学[克苏鲁之脑] 播放音效失败 " + pFile + " " + e);
            }
        }

        /// <summary>按语言文件里的 key 弹提示;没有该 key 就用内置文案。</summary>
        public static void ShowTip(string pKey, string pFallback, string pColor, float pSeconds = 7f) {
            try {
                string text = pFallback;
                if (!string.IsNullOrEmpty(pKey) && LocalizedTextManager.stringExists(pKey)) {
                    string localized = LocalizedTextManager.getText(pKey);
                    if (!string.IsNullOrEmpty(localized)) text = localized;
                }
                WorldTip.showNow(text, false, "top", pSeconds, pColor);
            } catch (Exception e) {
                Main.LogError("生物学[克苏鲁之脑] 显示提示失败 " + pKey + " " + e);
            }
        }

        // ---------------------------------------------------------------- FMOD(首选)

        private static bool PlayFmod(string pFile, string pPath, float pVolume, float pPitch) {
            if (_fmodFailedFiles.Contains(pFile)) return false;
            try {
                FMOD.System core = FMODUnity.RuntimeManager.CoreSystem;
                if (core.handle == IntPtr.Zero) {
                    // 读档那一瞬间 FMOD 可能还没初始化好,这里不要记成永久失败,下次再试。
                    if (!_fmodNotReadyLogged) {
                        _fmodNotReadyLogged = true;
                        Main.LogInfo("生物学[克苏鲁之脑] FMOD 尚未就绪,本次改用 Unity 音源");
                    }
                    return false;
                }
                FMOD.Sound sound;
                if (!_fmodSounds.TryGetValue(pFile, out sound) || sound.handle == IntPtr.Zero) {
                    FMOD.RESULT load = core.createSound(pPath,
                        FMOD.MODE.DEFAULT | FMOD.MODE.CREATESAMPLE | FMOD.MODE.LOOP_OFF, out sound);
                    if (load != FMOD.RESULT.OK) {
                        _fmodFailedFiles.Add(pFile);
                        Main.LogError("生物学[克苏鲁之脑] FMOD 载入音效失败 " + pFile + " -> " + load);
                        return false;
                    }
                    _fmodSounds[pFile] = sound;
                    Main.LogInfo("生物学[克苏鲁之脑] 音效已载入(FMOD): " + pFile);
                }
                FMOD.Channel channel;
                FMOD.RESULT played = core.playSound(sound, default(FMOD.ChannelGroup), false, out channel);
                if (played != FMOD.RESULT.OK) {
                    Main.LogError("生物学[克苏鲁之脑] FMOD 播放失败 " + pFile + " -> " + played);
                    return false;
                }
                channel.setVolume(Mathf.Clamp01(pVolume));
                if (Mathf.Abs(pPitch - 1f) > 0.001f) channel.setPitch(Mathf.Clamp(pPitch, 0.5f, 2f));
                return true;
            } catch (Exception e) {
                _fmodFailedFiles.Add(pFile);
                Main.LogError("生物学[克苏鲁之脑] FMOD 播放异常 " + e);
                return false;
            }
        }

        // ---------------------------------------------------------------- Unity(兜底)

        private static void PlayUnity(string pFile, string pPath, float pVolume, float pPitch) {
            try {
                if (_source == null) {
                    GameObject go = new GameObject("CthulhuVoiceSource");
                    UnityEngine.Object.DontDestroyOnLoad(go);
                    // 游戏里平时是没有 AudioListener 的(只有预告片模式才临时挂一个),
                    // 不补一个的话 Unity 音源会静默播放。
                    go.AddComponent<AudioListener>();
                    _source = go.AddComponent<AudioSource>();
                    _source.playOnAwake = false;
                    _source.loop = false;
                    _source.spatialBlend = 0f;
                    _source.volume = 1f;
                }
                AudioClip clip;
                if (!_clips.TryGetValue(pFile, out clip) || clip == null) {
                    byte[] bytes = File.ReadAllBytes(pPath);
                    float[] samples;
                    int channels, rate;
                    if (!ParseWav(bytes, out samples, out channels, out rate)) {
                        Main.LogError("生物学[克苏鲁之脑] 音效不是 16bit PCM wav: " + pFile);
                        return;
                    }
                    clip = AudioClip.Create(pFile, samples.Length / channels, channels, rate, false);
                    if (clip == null) return;
                    clip.SetData(samples, 0);
                    _clips[pFile] = clip;
                    Main.LogInfo("生物学[克苏鲁之脑] 音效已载入(Unity): " + pFile);
                }
                _source.pitch = Mathf.Clamp(pPitch, 0.5f, 2f);
                _source.PlayOneShot(clip, Mathf.Clamp01(pVolume));
                _source.pitch = 1f;
            } catch (Exception e) {
                Main.LogError("生物学[克苏鲁之脑] Unity 播放音效失败 " + pFile + " " + e);
            }
        }

        // ---------------------------------------------------------------- 路径 / 解析

        /// <summary>Mod 目录下的 Sounds 文件夹。</summary>
        public static string SoundsFolder {
            get {
                try {
                    string folder = Main.Instance.GetDeclaration().FolderPath;
                    if (!string.IsNullOrEmpty(folder)) return Path.Combine(folder, "Sounds");
                } catch (Exception e) {
                    Main.LogError("生物学[克苏鲁之脑] 取 Mod 目录失败,改用默认路径 " + e.Message);
                }
                string gameRoot = Path.GetDirectoryName(Application.dataPath);
                return Path.Combine(gameRoot, "Mods\\生物学1.0.9\\Sounds");
            }
        }

        /// <summary>解析 16bit PCM 的 wav(Unity 兜底通道用)。</summary>
        private static bool ParseWav(byte[] pBytes, out float[] pSamples, out int pChannels, out int pRate) {
            pSamples = null; pChannels = 1; pRate = 44100;
            if (pBytes == null || pBytes.Length < 44) return false;
            if (pBytes[0] != 'R' || pBytes[1] != 'I' || pBytes[2] != 'F' || pBytes[3] != 'F') return false;
            int bits = 16, channels = 1, rate = 44100, dataStart = -1, dataLength = 0;
            int pos = 12;
            while (pos + 8 <= pBytes.Length) {
                string id = "" + (char)pBytes[pos] + (char)pBytes[pos + 1] + (char)pBytes[pos + 2] + (char)pBytes[pos + 3];
                int size = BitConverter.ToInt32(pBytes, pos + 4);
                int body = pos + 8;
                if (id == "fmt ") {
                    channels = BitConverter.ToUInt16(pBytes, body + 2);
                    rate = (int)BitConverter.ToUInt32(pBytes, body + 4);
                    bits = BitConverter.ToUInt16(pBytes, body + 14);
                } else if (id == "data") {
                    dataStart = body;
                    dataLength = Math.Min(size, pBytes.Length - body);
                    break;
                }
                if (size <= 0) break;
                pos = body + size + (size & 1);
            }
            if (dataStart < 0 || dataLength <= 1 || bits != 16 || channels < 1) return false;
            int count = dataLength / 2;
            float[] samples = new float[count];
            for (int i = 0; i < count; i++) {
                samples[i] = BitConverter.ToInt16(pBytes, dataStart + i * 2) / 32768f;
            }
            pSamples = samples;
            pChannels = channels;
            pRate = rate;
            return true;
        }

        /// <summary>第一次播放时打印一次音效目录,方便排查。</summary>
        public static void LogFolderOnce() {
            if (_folderLogged) return;
            _folderLogged = true;
            try {
                Main.LogInfo("生物学[克苏鲁之脑] 音效目录 " + SoundsFolder
                    + " 存在=" + Directory.Exists(SoundsFolder));
            } catch {
            }
        }
    }
}
