using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace RimWorldMod {

    // 大脑强化/弱化:强化 → 取消法力上限 + 增加智力;弱化 → 反之(恢复/压低法力上限 + 降低智力)
    // 法力上限通过补丁 getMaxMana 全局生效(任何单位都实时生效);
    // 智力加成写入持久自定义数据 data["intelligence"],updateStats 每次会自动并入,
    // 不会与基础智力/亚种特质冲突,存盘也不会丢失。
    public static class BrainStat {
        private static bool _patched;

        // 每级强化智力 +3(基础智力通常个位数,3 级约 +9);弱化每级 -3
        private const float INT_PER_LEVEL = 3f;
        // 弱化时每级压低法力上限 10%(最低保留 5%)
        private const float MANA_WEAKEN_STEP = 0.10f;
        private const float MANA_WEAKEN_MIN = 0.05f;
        // 强化时取消法力上限(返回超大值,实际存储不设限)
        private const int MANA_UNCAPPED = 1000000;

        public static void Ensure() {
            if (_patched) return;
            _patched = true;
            try {
                Harmony harmony = new Harmony("rimworld_health_brain");
                harmony.Patch(
                    AccessTools.Method(typeof(Actor), "getMaxMana"),
                    postfix: new HarmonyMethod(AccessTools.Method(typeof(BrainStat), nameof(GetMaxManaPostfix)))
                );
                Main.LogInfo("生物学:大脑强化/弱化守卫已启用");
            } catch (Exception e) {
                Main.LogError("生物学:大脑守卫启用失败 " + e);
            }
        }

        // 大脑强化等级:正数=强化,负数=弱化(HpMods 每级 ±10)
        public static int GetBrainLevel(Actor pActor) {
            if (pActor == null || !HealthSimulator.HasAnyState) return 0;
            ActorWoundState state;
            if (!HealthSimulator.TryGetState(pActor.getID(), out state) || state.Mods == null) return 0;
            int hm = 0;
            if (state.Mods.HpMods != null) state.Mods.HpMods.TryGetValue("brain", out hm);
            return hm / 10;
        }

        // 法力上限:强化 → 取消上限;弱化 → 每级压低,最低保留 5%
        public static void GetMaxManaPostfix(Actor __instance, ref int __result) {
            try {
                if (__instance == null || !HealthSimulator.HasAnyState) return;
                int lvl = GetBrainLevel(__instance);
                if (lvl > 0) {
                    __result = MANA_UNCAPPED;
                } else if (lvl < 0) {
                    float mult = Mathf.Max(MANA_WEAKEN_MIN, 1f + lvl * MANA_WEAKEN_STEP);
                    __result = Mathf.Max(1, (int)(__result * mult));
                }
            } catch {
            }
        }

        // 选中单位常驻刷新时应用智力加成:写入持久自定义数据 data["intelligence"]
        // (updateStats 里 stats["intelligence"] += data["intelligence"],存盘保留、不与其他来源冲突)
        public static void ApplyStats(Actor pActor) {
            if (pActor == null || !HealthSimulator.IsOrganSupported(pActor)) return;
            try {
                int lvl = GetBrainLevel(pActor);
                float target = lvl * INT_PER_LEVEL;
                if (pActor.data != null && Mathf.Abs(pActor.data["intelligence"] - target) > 0.01f) {
                    pActor.data["intelligence"] = target;
                    pActor.setStatsDirty();
                }
            } catch (Exception e) {
                Main.LogError("生物学:应用大脑智力加成失败 " + e);
            }
        }
    }
}