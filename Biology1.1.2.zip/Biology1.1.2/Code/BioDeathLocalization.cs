namespace RimWorldMod {
    /// <summary>将死亡快照中的 AttackType token 映射到本地化文本。</summary>
    public static class BioDeathLocalization {
        public static string Localize(string pToken) {
            string key;
            switch (pToken) {
                case "Acid": key = "bio_grave_death_acid"; break;
                case "Fire": key = "bio_grave_death_fire"; break;
                case "Plague": key = "bio_grave_death_plague"; break;
                case "Infection": key = "bio_grave_death_infection"; break;
                case "Tumor": key = "bio_grave_death_tumor"; break;
                case "Other": key = "bio_grave_death_other"; break;
                case "Divine": key = "bio_grave_death_divine"; break;
                case "AshFever": key = "bio_grave_death_ash_fever"; break;
                case "Metamorphosis": key = "bio_grave_death_metamorphosis"; break;
                case "Starvation": key = "bio_grave_death_starvation"; break;
                case "Eaten": key = "bio_grave_death_eaten"; break;
                case "Age": key = "bio_grave_death_age"; break;
                case "Weapon": key = "bio_grave_death_weapon"; break;
                case "None": key = "bio_grave_death_none"; break;
                case "Poison": key = "bio_grave_death_poison"; break;
                case "Gravity": key = "bio_grave_death_gravity"; break;
                case "Drowning": key = "bio_grave_death_drowning"; break;
                case "Water": key = "bio_grave_death_water"; break;
                case "Explosion": key = "bio_grave_death_explosion"; break;
                case "Smile": key = "bio_grave_death_smile"; break;
                default: return BioText.T("bio_grave_unknown_death", "未知");
            }
            return BioText.T(key, BioText.T("bio_grave_unknown_death", "未知"));
        }
    }
}
