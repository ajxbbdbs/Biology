using System.Collections.Generic;

namespace RimWorldMod {

    /// <summary>
    /// 本地化查询辅助类，为 BioDialogue 提供台词池的本地化支持。
    /// 使用 BioText.T / BioText.Has 在 LocalizedTextManager 中查找键，
    /// 找不到时自动回退到硬编码的中文原文。
    /// </summary>
    public static class BioDialogueLocalizer {

        /// <summary>
        /// 查找单条本地化文本。
        /// </summary>
        public static string L(string key, string fallback) {
            return BioText.T(key, fallback);
        }

        /// <summary>
        /// 查找一组本地化文本（键名 = prefix + _0, _1, _2, ...）。
        /// 若所有本地化键都不存在则返回 fallback 数组。
        /// </summary>
        public static string[] Pool(string prefix, string[] fallback) {
            var result = new List<string>();
            for (int i = 0; i < 20; i++) {
                string k = prefix + "_" + i;
                if (BioText.Has(k))
                    result.Add(BioText.T(k, ""));
                else
                    break;
            }
            return result.Count > 0 ? result.ToArray() : fallback;
        }

        /// <summary>
        /// 查找本地化字典（键名 = prefix_key）。
        /// </summary>
        public static Dictionary<string, string> Dict(string prefix, Dictionary<string, string> fallback) {
            var result = new Dictionary<string, string>();
            bool found = false;
            foreach (var kv in fallback) {
                string k = prefix + "_" + kv.Key;
                if (BioText.Has(k)) {
                    result[kv.Key] = BioText.T(k, kv.Value);
                    found = true;
                } else {
                    result[kv.Key] = kv.Value;
                }
            }
            return found ? result : fallback;
        }

        /// <summary>
        /// 查找本地化二维文本池（键名 = prefix_part_0, _1, ...）。
        /// </summary>
        public static Dictionary<string, string[]> PoolDict(string prefix, Dictionary<string, string[]> fallback) {
            var result = new Dictionary<string, string[]>();
            foreach (var kv in fallback) {
                result[kv.Key] = Pool(prefix + "_" + kv.Key, kv.Value);
            }
            return result;
        }

        /// <summary>
        /// 查找本地化嵌套文本池（键名 = prefix_tier_0, _1, ...）。
        /// </summary>
        public static string[][] TierPool(string prefix, string[][] fallback) {
            var result = new string[fallback.Length][];
            for (int t = 0; t < fallback.Length; t++) {
                result[t] = Pool(prefix + "_t" + t, fallback[t]);
            }
            return result;
        }
    }
}
