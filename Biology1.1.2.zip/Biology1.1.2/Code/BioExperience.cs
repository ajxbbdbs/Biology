using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using HarmonyLib;
using UnityEngine;

namespace RimWorldMod {

    /// <summary>
    /// 器官磨损:让小人在原版世界里真正经历过的事情反映到器官百分比上,而不是只能靠玩家手动强化/弱化。
    ///
    /// 三条来源,都挂在原版已有的事件上,不新开每帧循环:
    ///   打架   Actor.getHit             —— 累计受到的伤害,够一档就磨一个"挨打会伤到"的器官
    ///   生孩子 Actor.birthEvent         —— 每分娩一次,\u5b50\u5bab/\u9634\u9053/关节骨各磨一点
    ///   走路   Actor.precalcMovementSpeed —— 只在移动中才会被原版调用,量累计移动时长,够一档就
    ///                                       磨腿/脚/关节骨
    ///
    /// 性能:
    ///   · 三个钩子里都只做一次字典查找 + 几个浮点累加,稳定态不分配内存
    ///   · 是否参与器官模拟只问一次就记在条目里(IsOrganSupported 要走 isAnimal 虚调用)
    ///   · 真正写进器官数据(要 GetState)只在跨档时发生,平时不碰 HealthSimulator 的状态表 ——
    ///     那张表是按 4000 条封顶、满了整表清空的,不能让全世界的单位往里挤
    ///   · 磨损有下限 WearFloor:磨到那儿就停手,否则活得久的单位迟早全成残废
    ///   · 「功能开关>器官磨损」可以整个关掉
    ///
    /// 磨损写的是和手动弱化同一个通道(HpMods),所以面板上立刻能看到,也能被强化治回去。
    /// </summary>
    public static class BioExperience {

        /// <summary> 累计多少伤害磨一档 </summary>
        private const float DamagePerWear = 50f;
        /// <summary> 一档伤害磨掉多少个百分点 </summary>
        private const int DamageWearStep = 2;
        /// <summary> 累计"在移动中"多少秒磨一档 </summary>
        private const float WalkSecondsPerWear = 240f;
        private const int WalkWearStep = 1;
        /// <summary> 两次看到同一个单位移动之间超过这么久,就认为中间没在走,这段不计入 </summary>
        private const float WalkGapMax = 2f;
        /// <summary> 磨损下限:HpMods 到了这个值就不再往下磨(玩家手动弱化不受此限) </summary>
        private const int WearFloor = -50;
        /// <summary> 磨损条目上限,超了整表清空(条目本身可以随时重建,丢了只是少算一段累计) </summary>
        private const int MaxEntries = 8000;

        // 挨打会伤到的部位:每档随机挑一个
        private static readonly string[] CombatOrgans = {
            "skin", "muscle", "bone", "arm", "hand", "leg", "foot", "chest", "abdomen", "spine"
        };
        // 走路磨的部位
        private static readonly string[] WalkOrgans = { "leg", "foot", "bone" };
        // 分娩磨的部位与幅度
        private static readonly KeyValuePair<string, int>[] BirthWear = {
            new KeyValuePair<string, int>("uterus", 3),
            new KeyValuePair<string, int>("vagina", 2),
            new KeyValuePair<string, int>("bone", 1),
        };

        private class Wear {
            public bool Supported;      // 该单位是否参与器官模拟
            public bool Asked;          // 问过没有(IsOrganSupported 要走虚调用,只问一次)
            public float Damage;        // 累计受到的伤害
            public float WalkSeconds;   // 累计"在移动中"的秒数
            public float LastMoveAt;    // 上次看到它在移动的时刻
        }

        // 线程安全:走路钩子挂在并行 Job 的 precalcMovementSpeed 上(worker 线程),
        // 多个线程会同时往这张表结构性写入,必须用并发字典;每个单位只被一个线程处理,条目本身无需再锁。
        private static readonly ConcurrentDictionary<long, Wear> _wear = new ConcurrentDictionary<long, Wear>();
        // System.Random 非线程安全,多个 worker 线程并发 Next() 会把内部状态搅坏(恒返回 0 甚至异常),
        // 这里给每个线程一份独立的 Random。
        [ThreadStatic] private static System.Random _tRng;
        private static int Rand(int pBound) {
            System.Random r = _tRng;
            if (r == null) {
                r = new System.Random(unchecked(0x5EED + Environment.TickCount * 31 + Thread.CurrentThread.ManagedThreadId));
                _tRng = r;
            }
            return r.Next(pBound);
        }
        private static bool _patched;

        public static void Ensure() {
            if (_patched) return;
            _patched = true;
            try {
                Harmony harmony = new Harmony("rimworld_health_experience");
                harmony.Patch(
                    AccessTools.Method(typeof(Actor), "getHit"),
                    postfix: new HarmonyMethod(AccessTools.Method(typeof(BioExperience), nameof(OnGetHit)))
                );
                harmony.Patch(
                    AccessTools.Method(typeof(Actor), "birthEvent"),
                    postfix: new HarmonyMethod(AccessTools.Method(typeof(BioExperience), nameof(OnBirth)))
                );
                // 这一个钩子同时干两件事:走路磨损,以及\u53cc\u817f没了就真的走不动(见 OnMovementSpeed)
                harmony.Patch(
                    AccessTools.Method(typeof(Actor), "precalcMovementSpeed"),
                    postfix: new HarmonyMethod(AccessTools.Method(typeof(BioExperience), nameof(OnMovementSpeed)))
                );
                Main.LogInfo("生物学:器官磨损与移动接管已启用");
            } catch (Exception e) {
                Main.LogError("生物学:器官磨损启用失败 " + e);
            }
        }

        /// <summary> 单位死亡/移除时清掉累计,免得 id 复用后接着老账算 </summary>
        public static void Forget(long pActorId) {
            Wear removed;
            _wear.TryRemove(pActorId, out removed);
        }

        // ===== 钩子 =====

        public static void OnGetHit(Actor __instance, float pDamage) {
            try {
                if (!Main.OrganWear || pDamage <= 0f) return;
                Wear w = Get(__instance);
                if (w == null) return;
                w.Damage += pDamage;
                if (w.Damage < DamagePerWear) return;
                int steps = (int)(w.Damage / DamagePerWear);
                w.Damage -= steps * DamagePerWear;
                string organ = CombatOrgans[Rand(CombatOrgans.Length)];
                ApplyWear(__instance, organ, DamageWearStep * steps, "挨打");
            } catch (Exception e) {
                Main.LogError("生物学:战斗磨损失败 " + e);
            }
        }

        public static void OnBirth(Actor __instance) {
            try {
                if (!Main.OrganWear) return;
                if (Get(__instance) == null) return;
                for (int i = 0; i < BirthWear.Length; i++) {
                    ApplyWear(__instance, BirthWear[i].Key, BirthWear[i].Value, "分娩");
                }
            } catch (Exception e) {
                Main.LogError("生物学:分娩磨损失败 " + e);
            }
        }

        /// <summary>
        /// 原版算完移动速度之后接手。
        ///
        /// \u53cc\u817f被摘掉时把最终速度直接压成 0。不能只改 stats["speed"] —— 原版在
        /// precalcMovementSpeed 末尾有一句 "combined &lt; 1 就抬到 1" 的硬保底,
        /// 所以把 speed 设成 0 之后小人照样以速度 1 走,这就是"移速显示 1 还能动"的来处。
        /// 这里改的是保底之后的最终值,才真的走不动。
        /// </summary>
        public static void OnMovementSpeed(Actor __instance) {
            try {
                if (__instance == null || !HealthSimulator.HasAnyState) return;
                ActorWoundState st;
                if (!HealthSimulator.TryGetState(__instance.getID(), out st) || st == null || st.Mods == null) return;
                if (!HealthSimulator.IsOrganSupported(__instance)) return;
                if (!HealthSimulator.HasUsableLegsFast(__instance)) {
                    __instance._current_combined_movement_speed = 0f;
                    return;
                }
                if (!Main.OrganWear) return;
                Wear w = Get(__instance);
                if (w == null) return;
                // 累计"在移动中"的秒数。不能直接加 Time.deltaTime —— 这个钩子不保证每帧都响
                // (原版是在 updateParallelChecks 里分批调的,自己还带 6 次跳一次的节流),
                // 那样会漏算。改成量两次看见它移动之间的间隔:间隔太大说明中间根本没在走,不计。
                float now = Time.unscaledTime;
                float gap = now - w.LastMoveAt;
                w.LastMoveAt = now;
                if (gap <= 0f || gap > WalkGapMax) return;
                w.WalkSeconds += gap;
                if (w.WalkSeconds < WalkSecondsPerWear) return;
                int steps = (int)(w.WalkSeconds / WalkSecondsPerWear);
                w.WalkSeconds -= steps * WalkSecondsPerWear;
                string organ = WalkOrgans[Rand(WalkOrgans.Length)];
                ApplyWear(__instance, organ, WalkWearStep * steps, "走路");
            } catch (Exception e) {
                Main.LogError("生物学:移动磨损失败 " + e);
            }
        }

        // ===== 内部 =====

        // 取(或建)该单位的磨损条目;不参与器官模拟的单位返回 null
        private static Wear Get(Actor pActor) {
            if (pActor == null) return null;
            long id;
            try { id = pActor.getID(); } catch { return null; }
            Wear w;
            if (!_wear.TryGetValue(id, out w)) {
                if (_wear.Count >= MaxEntries) _wear.Clear();
                w = new Wear();
                _wear[id] = w;
            }
            if (!w.Asked) {
                w.Asked = true;
                w.Supported = HealthSimulator.IsOrganSupported(pActor);
            }
            return w.Supported ? w : null;
        }

        // 把磨损写进器官数据。到下限就不再往下压
        private static void ApplyWear(Actor pActor, string pOrganId, int pAmount, string pReason) {
            if (pAmount <= 0) return;
            try {
                ActorWoundState st = HealthSimulator.GetState(pActor.getID());
                if (st == null || st.Mods == null) return;
                int cur;
                st.Mods.HpMods.TryGetValue(pOrganId, out cur);
                if (cur <= WearFloor) return;
                int next = Mathf.Max(cur - pAmount, WearFloor);
                if (next == cur) return;
                st.Mods.HpMods[pOrganId] = next;
                Main.LogDebug("生物学:[磨损] " + pActor.getName() + " " + pReason
                    + " → " + pOrganId + " " + cur + "% → " + next + "%");
            } catch (Exception e) {
                Main.LogError("生物学:写入磨损失败 " + e);
            }
        }
    }
}
