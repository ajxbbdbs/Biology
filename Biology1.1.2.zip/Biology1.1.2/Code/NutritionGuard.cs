using System;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace RimWorldMod {

    // 胃部消化守卫与饱食度上限
    // 原版 getMaxNutrition() 保持"基础上限"不变(如 100)。
    // "能装多少食物"的存储上限由 setNutrition / addNutritionFromEating 的 clamp 决定:
    //   → HealthSimulator.GetScaledMaxNutrition():强化→扩容、弱化→削减、无胃/衰竭→0。
    // 饥饿条改为数字格式显示(当前/上限),上限即扩容后的存储上限,强化胃会直观显示 110/110。
    public static class NutritionGuard {
        private static bool _patched;

        private static readonly FieldInfo _actorField = AccessTools.Field(typeof(UnitElement), "actor");
        private static readonly FieldInfo _hungerField = AccessTools.Field(typeof(UnitBarsElement), "_hunger");
        private static readonly FieldInfo _barHungerField = AccessTools.Field(typeof(SelectedUnitTab), "_bar_hunger");

        public static void Ensure() {
            if (_patched) return;
            _patched = true;
            try {
                Harmony harmony = new Harmony("rimworld_health_stomach");
                harmony.Patch(
                    AccessTools.Method(typeof(Actor), "setNutrition"),
                    prefix: new HarmonyMethod(AccessTools.Method(typeof(NutritionGuard), nameof(SetNutritionPrefix)))
                );
                harmony.Patch(
                    AccessTools.Method(typeof(Actor), "addNutritionFromEating"),
                    prefix: new HarmonyMethod(AccessTools.Method(typeof(NutritionGuard), nameof(AddNutritionPrefix)))
                );
                // 三处饥饿条显示,统一改为数字 当前/上限
                harmony.Patch(
                    AccessTools.Method(typeof(UnitBarsElement), "showHunger"),
                    postfix: new HarmonyMethod(AccessTools.Method(typeof(NutritionGuard), nameof(UnitBarsHungerPostfix)))
                );
                harmony.Patch(
                    AccessTools.Method(typeof(SelectedUnitTab), "showStatBars"),
                    postfix: new HarmonyMethod(AccessTools.Method(typeof(NutritionGuard), nameof(SelectedUnitHungerPostfix)))
                );
                harmony.Patch(
                    AccessTools.Method(typeof(TooltipLibrary), "showActorBars"),
                    postfix: new HarmonyMethod(AccessTools.Method(typeof(NutritionGuard), nameof(TooltipHungerPostfix)))
                );
                Main.LogInfo("生物学:胃部消化守卫已启用");
            } catch (Exception e) {
                Main.LogError("生物学:胃部消化守卫启用失败 " + e);
            }
        }

        // setNutrition:改用扩容后的上限做 clamp(原版只按基础上限 clamp)
        public static bool SetNutritionPrefix(Actor __instance, int pVal, bool pClamp) {
            if (__instance == null || !HealthSimulator.HasAnyState) return true;
            try {
                ActorWoundState state;
                if (!HealthSimulator.TryGetState(__instance.getID(), out state) || state == null || state.Mods == null) return true;
                if (pClamp) {
                    pVal = Mathf.Clamp(pVal, 0, HealthSimulator.GetScaledMaxNutrition(__instance));
                }
                __instance.data.nutrition = pVal;
            } catch (Exception e) {
                Main.LogError("生物学:setNutrition 拦截失败 " + e);
            }
            return false;
        }

        // addNutritionFromEating:按扩容上限进食,避免吃到基础上限就停止
        public static bool AddNutritionPrefix(Actor __instance, int pVal, bool pSetMaxNutrition, bool pSetJustAte) {
            if (__instance == null || !HealthSimulator.HasAnyState) return true;
            ActorWoundState state;
            if (!HealthSimulator.TryGetState(__instance.getID(), out state) || state == null || state.Mods == null) return true;
            try {
                if (pSetMaxNutrition) {
                    __instance.setNutrition(HealthSimulator.GetScaledMaxNutrition(__instance));
                } else {
                    int target = Math.Min(HealthSimulator.GetScaledMaxNutrition(__instance),
                        __instance.getNutrition() + pVal);
                    __instance.setNutrition(target);
                }
                if (pSetJustAte) {
                    __instance.justAte();
                }
            } catch (Exception e) {
                Main.LogError("生物学:进食拦截失败 " + e);
            }
            return false;
        }

        // 单位头顶/侧边小饥饿条:当前/扩容上限
        public static void UnitBarsHungerPostfix(UnitBarsElement __instance) {
            try {
                Actor actor = (Actor)_actorField.GetValue(__instance);
                if (actor == null || !actor.needsFood()) return;
                StatBar bar = (StatBar)_hungerField.GetValue(__instance);
                if (bar == null) return;
                int cur = actor.getNutrition();
                int max = HealthSimulator.GetScaledMaxNutrition(actor);
                bar.setBar(cur, max, "/" + max, false, false, true, 0.1f);
            } catch (Exception e) {
                Main.LogError("生物学:单位饥饿条显示失败 " + e);
            }
        }

        // 选中单位面板底部饥饿条:当前/扩容上限
        public static void SelectedUnitHungerPostfix(SelectedUnitTab __instance, Actor pActor) {
            try {
                if (pActor == null || !pActor.needsFood()) return;
                StatBar bar = (StatBar)_barHungerField.GetValue(__instance);
                if (bar == null) return;
                int cur = pActor.getNutrition();
                int max = HealthSimulator.GetScaledMaxNutrition(pActor);
                bar.setBar(cur, max, "/" + max, false, false, true, 0.1f);
            } catch (Exception e) {
                Main.LogError("生物学:选中面板饥饿条显示失败 " + e);
            }
        }

        // 鼠标悬停信息面板饥饿条:当前/扩容上限
        public static void TooltipHungerPostfix(TooltipLibrary __instance, Tooltip pTooltip, Actor pActor) {
            try {
                if (pTooltip == null || pActor == null || !pActor.needsFood()) return;
                Transform fitter = pTooltip.transform.FindRecursive("HungerBarFitter");
                if (fitter == null) return;
                StatBar bar = fitter.GetComponentInChildren<StatBar>(true);
                if (bar == null) return;
                int cur = pActor.getNutrition();
                int max = HealthSimulator.GetScaledMaxNutrition(pActor);
                bar.setBar(cur, max, "/" + max, false, false, true, 0.1f);
            } catch (Exception e) {
                Main.LogError("生物学:悬停面板饥饿条显示失败 " + e);
            }
        }
    }
}
