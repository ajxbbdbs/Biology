using System.Reflection;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;

namespace RimWorldMod
{
    // 单位窗口(UnitWindow)性别图标每帧守卫。
    // 原版 UnitStatsElement.showContent / UnitGenealogyElement.showContent 是协程,
    // 内部用 isSexMale() 写入 _icon_sex/_sex_icon;补丁难以可靠拦协程内部,
    // 改为每帧廉价守卫:仅在选中单位为双性(GetGenderFast,纯HashSet查询)时,
    // 反射覆盖单位窗口内所有 UnitStatsElement._icon_sex 与 UnitGenealogyElement._sex_icon。
    // 非双性时原版已写 ♂/♀,不动,避免开销。
    public class SexIconGuardBehaviour : MonoBehaviour
    {
        private static FieldInfo _statsSexField;
        private static FieldInfo _geneaSexField;

        private UnitWindow _cachedWindow;
        private float _nextFindWindow = 0f;
        private Actor _cachedActor;
        private int _cachedGender;
        private float _nextGenderCheck;

        private void Awake()
        {
            try
            {
                if (_statsSexField == null)
                {
                    var t = System.Type.GetType("UnitStatsElement, Assembly-CSharp");
                    _statsSexField = t != null ? AccessTools.Field(t, "_icon_sex") : null;
                }
                if (_geneaSexField == null)
                {
                    var t = System.Type.GetType("UnitGenealogyElement, Assembly-CSharp");
                    _geneaSexField = t != null ? AccessTools.Field(t, "_sex_icon") : null;
                }
            }
            catch (System.Exception e)
            {
                Main.LogError("生物学:SexIconGuard 初始化失败 " + e);
            }
        }

        private void Update()
        {
            try
            {
                // 非双性或未选中:完全不动,零开销
                Actor a = null;
                try { if (SelectedUnit.isSet()) a = SelectedUnit.unit; } catch { }
                if (a == null)
                {
                    _cachedActor = null;
                    return;
                }
                if (a != _cachedActor)
                {
                    _cachedActor = a;
                    _cachedGender = 0;
                    _nextGenderCheck = 0f;
                }
                // 非双性单位每 0.5 秒检查一次即可;双性单位仍保持每帧覆盖图标。
                if (_cachedGender != 3 && Time.unscaledTime < _nextGenderCheck) return;
                if (Time.unscaledTime >= _nextGenderCheck)
                {
                    _nextGenderCheck = Time.unscaledTime + 0.5f;
                    try { _cachedGender = HealthSimulator.GetGenderFast(_cachedActor); } catch { _cachedGender = 0; }
                }
                if (_cachedGender != 3) return;

                UnitWindow win = GetWindow();
                if (win == null) return;

                Sprite hermaph = SexIconSync.ResolveHermaphSprite();
                if (hermaph == null) return;

                // 覆盖单位窗口 Header 里的性别图标
                if (_statsSexField != null)
                {
                    UnitStatsElement[] stats = win.GetComponentsInChildren<UnitStatsElement>(true);
                    foreach (UnitStatsElement el in stats)
                    {
                        if (el == null) continue;
                        Image img = _statsSexField.GetValue(el) as Image;
                        if (img == null) continue;
                        Apply(img, hermaph);
                    }
                }
                if (_geneaSexField != null)
                {
                    UnitGenealogyElement[] genea = win.GetComponentsInChildren<UnitGenealogyElement>(true);
                    foreach (UnitGenealogyElement el in genea)
                    {
                        if (el == null) continue;
                        Image img = _geneaSexField.GetValue(el) as Image;
                        if (img == null) continue;
                        Apply(img, hermaph);
                    }
                }
            }
            catch (System.Exception e)
            {
                Main.LogError("生物学:SexIconGuard 每帧同步失败 " + e);
            }
        }

        private UnitWindow GetWindow()
        {
            // 每 0.5 秒才重新找窗口,窗口对象通常不变
            if (_cachedWindow == null && Time.time < _nextFindWindow) return null;
            _nextFindWindow = Time.time + 0.5f;
            _cachedWindow = null;
            try { _cachedWindow = UnityEngine.Object.FindObjectOfType<UnitWindow>(); } catch { }
            return _cachedWindow;
        }

        private static void Apply(Image img, Sprite pHermaph)
        {
            if (img.sprite == pHermaph) return;
            img.raycastTarget = false;
            img.enabled = true;
            img.sprite = pHermaph;
            img.color = Color.white;
            img.type = Image.Type.Simple;
            img.preserveAspect = true;
        }
    }
}
