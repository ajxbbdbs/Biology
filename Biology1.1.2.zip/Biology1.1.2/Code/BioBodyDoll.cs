using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace RimWorldMod {

    /// <summary>
    /// 眨眼协程。每隔一段随机时间把眼睛换成闭眼贴图,过一小会儿再换回来;
    /// 有一定概率连眨两下,看着比等间隔的机械眨眼自然。
    ///
    /// 挂在立绘根节点上:切走标签页时根节点被禁用,OnDisable 会把眼睛掰回睁开,
    /// 协程也随之停止,不需要额外管生命周期。
    /// </summary>
    public class BioEyeBlink : MonoBehaviour {

        public float MinGap = 2.5f;         // 两次眨眼之间的最短间隔(秒)
        public float MaxGap = 6.5f;         // 最长间隔
        public float CloseTime = 0.12f;     // 闭眼持续时长
        public float DoubleChance = 0.25f;  // 连眨两下的概率
        public float DoubleGap = 0.13f;     // 连眨时两下之间的间隔

        private void OnEnable() {
            StartCoroutine(Loop());
        }

        private void OnDisable() {
            // 别把眼睛留在闭着的状态
            BioBodyDoll.SetBlink(false);
        }

        private IEnumerator Loop() {
            while (true) {
                yield return new WaitForSeconds(UnityEngine.Random.Range(MinGap, MaxGap));
                yield return Blink();
                if (UnityEngine.Random.value < DoubleChance) {
                    yield return new WaitForSeconds(DoubleGap);
                    yield return Blink();
                }
            }
        }

        private IEnumerator Blink() {
            BioBodyDoll.SetBlink(true);
            yield return new WaitForSeconds(CloseTime);
            BioBodyDoll.SetBlink(false);
        }
    }

    /// <summary>
    /// 盯着身高变化。身高不是存档字段,而是按「巨大」「渺小」特质加年龄现算出来的(见 BioHeight),
    /// 所以玩家给单位加上或去掉这两个特质时,没有任何事件会通知我们 —— 面板还在原地按旧比例画着,
    /// 得等下次切标签页或改器官才跟着变。这里隔一小会儿自己对一次身高,变了就更新。
    ///
    /// 绝大多数时候只是重新摆位(便宜);只有预烘倍率真跳了档才会重烘一套贴图,
    /// 所以小孩长个子这种连续变化不会一直重烘。
    ///
    /// 挂在立绘根节点上:切走标签页时根节点被禁用,轮询自然停。
    /// </summary>
    public class BioDollWatch : MonoBehaviour {

        public float Interval = 0.25f;   // 对数间隔(秒)

        private float _next;

        private void OnEnable() {
            _next = 0f;
        }

        private void Update() {
            if (Time.unscaledTime < _next) return;
            _next = Time.unscaledTime + Interval;
            BioBodyDoll.CheckMetrics();
        }
    }

    /// <summary>
    /// 点击立绘部位 → 打开该部位下器官的操作菜单(只有一个器官时直接打开该器官)
    /// </summary>
    public class BioDollPartClick : MonoBehaviour, IPointerClickHandler {
        public Actor Actor;
        public string Title;
        public List<string> OrganIds = new List<string>();

        public void OnPointerClick(PointerEventData pEvent) {
            try {
                if (Actor == null || OrganIds == null || OrganIds.Count == 0) return;
                RectTransform anchor = transform as RectTransform;
                if (OrganIds.Count == 1) {
                    OrganEditorUI.OpenOrganMenu(Actor, OrganIds[0], anchor, pEvent.position);
                } else {
                    OrganEditorUI.OpenPartMenu(Actor, Title, OrganIds, anchor, pEvent.position);
                }
            } catch (Exception e) {
                Main.LogError("生物学:点击立绘部位失败 " + e);
            }
        }
    }

    /// <summary>
    /// 点击头像框里的头部副本 → 头发弹发色板,其它皮肤部位弹肤色板。
    /// 器官手术操作只在立绘上点,头像框这边只管改颜色。
    /// </summary>
    public class BioPortraitClick : MonoBehaviour, IPointerClickHandler {
        public Actor Actor;
        public bool Hair;

        public void OnPointerClick(PointerEventData pEvent) {
            try {
                if (Actor == null) return;
                RectTransform anchor = transform as RectTransform;
                if (Hair) {
                    OrganEditorUI.OpenHairColorMenu(Actor, anchor, pEvent.position);
                } else {
                    OrganEditorUI.OpenSkinColorMenu(Actor, anchor, pEvent.position);
                }
            } catch (Exception e) {
                Main.LogError("生物学:点击头像框失败 " + e);
            }
        }
    }

    /// <summary>
    /// 器官面板左下角的人物立绘：按身体部位分层贴图，颜色随该部位下器官的健康度变化
    /// （完好=白 / 强化=蓝 / 轻伤=黄 / 中伤=橙 / 重伤=红 / 缺失=灰），鼠标悬停显示该部位的
    /// 器官明细，点击则直接打开该部位的器官操作菜单。
    ///
    /// 男女两套素材都是 340x882 整张画布分层导出(男性来自 Man.psd,女性来自 body_girl.psd),
    /// 每层的位置由 BioDollSkin 按不透明包围盒自动算出,叠放顺序见 MaleLayout / FemaleLayout。
    /// 贴图里的绿色关键色会换成该单位自己的肤色、品红关键色换成衣服色(毛发层改换发色),
    /// 换色规则见 BioDollSkin。
    ///
    /// \u88f8\u4f53开关(功能开关>\u88f8\u4f53立绘)打开时男性会多出\u777e\u4e38/\u9634\u6bdb/\u9634\u830e三层,\u9634\u830e按生物学器官
    /// 面板里那个\u52c3\u8d77尺寸挑贴图,见 PenisTierOf。
    /// </summary>
    public static class BioBodyDoll {

        // ===== 立绘布局 =====
        // 两套素材都是完整 340x882 画布,位置由 BioDollSkin 按不透明包围盒自动算出。
        // 设计空间:原点在躯干中心, x 向右, y 向下, 单位=贴图像素。
        private class Part {
            public string Id;          // 节点名(同一套布局内唯一)
            public string Sprite;      // GameResources 下的贴图名
            public string Title;       // 悬停/点击菜单标题
            public string[] Organs;    // 参与判定的器官 id(取其中最差的一个上色)
            public float Cx, Cy, W, H;
            public int Layer;          // 越大越靠上层
            public bool Tinted;        // 走关键色换色(女性贴图)
            public int Dress;          // 0=不分穿衣状态 1=仅穿衣 2=仅\u88f8\u4f53
            public bool Always;        // 整体轮廓层:名下器官缺失也不隐藏,否则身体会只剩零散色块
            public int ClothMode;      // 品红系关键色取色来源:0=王国衣服色 1=发色
            public int Penis;          // \u9634\u830e档位专属层:非 PenisNone 时只在该单位正好是这一档时才挂
            public Image Img;          // 运行期实例
            public Image HeadImg;      // 头像框里的放大副本
            public Sprite BaseSprite;      // 按肤色/衣服色染好的那张,健康时显示
            public Sprite BaseHeadSprite;
            public Sprite FlatSprite;      // 中性灰白那张,受伤时显示再乘伤情色。按需生成
            public Sprite FlatHeadSprite;
            public BioDollPartClick Click;

            // ===== 一层多张备选(发型/衣服) =====
            // Variants 填 ui/body/ 下的目录名时,这一层的贴图从那个目录里按单位 id 挑一张
            // (见 BioDollVariants);Sprite 退化成目录读不到时的兜底那张。
            // SpritePath 是这次搭立绘真正用的那张 —— 取图的地方一律用它,不要用 Sprite。
            public string Variants;
            public string SpritePath;

            // ===== 眨眼(只有眼睛这两层用) =====
            public string Closed;              // 闭眼贴图名(GameResources 下,不含 ui/body/ 前缀)
            public Sprite ClosedSprite;        // 闭眼贴图:立绘倍率
            public Sprite ClosedHeadSprite;    // 闭眼贴图:头像框倍率
            // 闭眼贴图的包围盒和睁眼那张不一样,所以两套 rect 都得算好,换图时连位置尺寸一起换,
            // 否则闭眼那一帧会被拉变形或者错位。
            public Vector2 OpenPos, OpenSize, ClosedPos, ClosedSize;
            public Vector2 OpenHeadPos, OpenHeadSize, ClosedHeadPos, ClosedHeadSize;
            public float CCx, CCy, CW, CH;     // 闭眼贴图在设计空间里的位置与大小
            public bool FlatNow;               // 当前是否正显示中性(受伤)贴图,睁眼时按它选回哪一张
        }

        private const int DressAny = 0, DressClothed = 1, DressNude = 2;

        // \u9634\u830e档位。\u88f8\u4f53立绘上按生物学器官面板里那个"\u52c3\u8d77尺寸"挑贴图,见 PenisTierOf。
        private const int PenisNone = 0, PenisFlaccid = 1, PenisSmall = 2, PenisMedium = 3, PenisLarge = 4;
        // 各档的\u52c3\u8d77尺寸下限(cm)。对着 OrganInfo 里那套抽法定的:
        //   生殖困难         6~9   → 疲软
        //   普通             12~17 → 小
        //   兴旺/强壮各 +5   17~27 → 中
        //   巨大 +15         27~42 → 大
        // 所以"大"这一档普通单位再怎么叠特质也够不到,只有巨大特质能推上去 —— 再叠一道
        // IsGiant 判定是为了防止以后有人改了加成数值又忘了这条规则。
        private const int PenisSmallCm = 10;
        private const int PenisMediumCm = 18;
        private const int PenisLargeCm = 27;

        private const float DesignWidth = 340f;    // 设计空间宽度(轮廓图宽)
        private const float DesignTop = -287.5f;   // 设计空间顶边(头顶)
        private const float DesignHeight = 882.5f; // 设计空间高度(头顶到脚底)
        // 立绘不再有固定高度:身高尺和立绘共用这一个比例尺,立绘高度 = 身高 × UnitsPerMeter。
        // 尺子只画到单位自己的头顶,所以不用为巨人预留一段空白,这个值可以按普通人的观感来定
        // (1.89m ≈ 110 单位,正好是以前那个固定高度)。想让整组画大一点就调它。
        private const float UnitsPerMeter = 58f;
        private const float MinHeight = 40f;       // 视口过矮时整组高度的下限
        private const float Margin = 6f;           // 距视口左/下边缘的留白
        private const float RulerGap = 2f;         // 头像框 ↔ 身高尺 的间隔

        // 左侧头像框:长方形证件照,材质取 Header 的框贴图,里面放大显示立绘的头部。
        //
        // 尺寸是"从里往外"定的:先定照片区的高度 PortraitPhotoH(宽度按头部内容的长宽比配),
        // 再往外让出一圈"看得见的花纹"FramePhotoLip,合起来就是框的整体大小。
        //
        // 之前"框大、照片小"的根子在于让照片躲开了整个九宫格边距区。实测那张框贴图
        // (windowAvatarElement, 48x48, 九宫格=23/22/23/25, 中心只剩 2x1)的边距区里,真正画着金属
        // 花纹的只有最外面 5~7 像素,再往里全是纯深色内衬 —— 游戏本来就是让头像压在内衬上的。
        // 所以照片只需要让开花纹那一圈,框贴图改画在照片下面,由照片自己盖掉内衬和上面的暗纹。
        // 这样框能一路收紧到贴住照片,而边框粗细一点没变(pixelsPerUnitMultiplier 没被碰过)。
        //
        // 整个框跟着立绘高度等比缩放:系数 = 当前立绘高度 / FrameRefDollH。下面这三个值是"基准高度处"
        // 的取值,矮个子按比例缩小、巨人按比例放大 —— 照片、花纹留边、边框粗细一起缩,框才不会
        // 变成被拉扁的方盒子。注意边框粗细也参与缩放,所以框的尺寸下限(九宫格对边之和)会跟着一起
        // 缩,矮个子的框才真的能变小。
        private const float FrameRefDollH = 110f;      // 基准立绘高度(≈1.89m,系数为 1)
        private const float PortraitPhotoH = 40f;      // 基准处的照片区高度(大小旋钮)
        // 照片四周留给花纹的宽度。实测这张贴图的花纹厚度约 左5.0 / 下7.5 / 右5.4 / 上5.4 单位,
        // 取 8 是连最厚的下边也不会被照片啃到。调小 → 框更贴照片,但花纹开始被盖掉一点。
        private const float FramePhotoLip = 8f;
        // 边框绘制粗细:九宫格边距区被缩放到这个量级,决定花纹画多粗,以及框的尺寸下限
        // (见 ApplyDollLayout 里的 minW/minH)。
        private const float FrameBorderTarget = 26f;
        // 头像框竖向位置:框顶自动跟立绘的头顶对齐(证件照里装的就是头,和立绘的头排成一排才不别扭)。
        // 这个常量是在对齐结果上再微调的量,正数往上挪。
        private const float PortraitNudgeY = 0f;
        private const float PortraitGap = 0f;         // 头像框与立绘之间的间隔
        // 框贴图深色内衬的颜色(实测 windowAvatarElement 的内衬是 27,28,22)。照片衬底用这个色,
        // 照片边缘与花纹里侧才看不出接缝。
        private static readonly Color FrameLiningColor = new Color(0.106f, 0.110f, 0.086f, 1f);
        // 贴图预烘倍率的安全系数:UI 单位不等于屏幕像素,烘得比算出来的略大一点,宁可清晰也不要糊
        private const float BakeSafety = 1.2f;

        // 头部取景窗(设计空间):正好框住头部内容。
        // 男性:头发内容在画布 x 109..229 / 自顶 7..143 → 窗 132x148、中心 x=-1。
        // 女性:头发内容在画布 x 88..241 / 自顶 9..190 → 窗 158x196、中心 x=-5.5。
        private const float HeadWindowTopMale = DesignTop + 2f;
        private const float HeadWindowHeightMale = 148f;
        private const float HeadWindowWidthMale = 132f;
        private const float HeadWindowCxMale = -1f;
        private const float HeadWindowTopFemale = DesignTop + 6f;
        private const float HeadWindowHeightFemale = 196f;
        private const float HeadWindowWidthFemale = 158f;
        private const float HeadWindowCxFemale = -5.5f;

        // 躯干内脏:上身贴图整块共用这一串器官,取最差的一个上色
        private static readonly string[] TorsoOrgans = {
            "chest", "abdomen", "spine", "stomach", "heart", "lung", "kidney",
            "liver", "intestine", "blood", "bone", "muscle"
        };

        // 全身轮廓层对应的体表器官(哪种存在就用哪种)
        private static readonly string[] SkinOrgans = { "skin", "fur", "scale", "feather" };

        // 男性/性别判不出的单位:严格按 Man.psd 的图层叠放顺序(Layer 越大越靠上)
        //   male_clothed(整体线稿) / male_nude / ClothedTorso / Feet / Leg / Hand /
        //   LowerArm / UpperArm / head / Left Eye / Right Eye / testicles / Pubic hair / \u9634\u830e
        // 原 psd 把脸和头发画在同一个 head 图层里,导出时按关键色分成了 male_Head + male_Hair
        // 两张:这样头发能单独取发色、单独点(点头像框里的头发弹发色板,点脸弹肤色板)。
        // Cx/Cy/W/H 留空,由 BioDollSkin 按贴图实际内容算出,避免手写坐标导致贴图错位。
        private static readonly Part[] MaleLayout = {
            // 整体线稿:psd 最底那层,画的是全身描边(含内裤线)。名下挂体表器官,
            // 而且 Always,所以哪怕四肢器官全没了也还剩一个人形,不会只剩零散色块。
            new Part { Id = "m_outline", Sprite = "male/male_Outline", Title = "皮肤", Organs = SkinOrgans,
                       Layer = 0, Tinted = true, Always = true },
            new Part { Id = "m_torso_nude", Sprite = "male/male_TorsoNude", Title = "躯干", Organs = TorsoOrgans,
                       Layer = 1, Tinted = true, Dress = DressNude },
            new Part { Id = "m_torso_clothed", Sprite = "male/ClothedTorso/male_TorsoClothed",
                       Variants = "male/ClothedTorso", Title = "躯干", Organs = TorsoOrgans,
                       Layer = 2, Tinted = true, Dress = DressClothed },
            new Part { Id = "m_foot", Sprite = "male/male_Feet", Title = "双脚", Organs = new[] { "foot" },
                       Layer = 3, Tinted = true },
            new Part { Id = "m_leg", Sprite = "male/male_Leg", Title = "\u53cc\u817f", Organs = new[] { "leg" },
                       Layer = 4, Tinted = true },
            new Part { Id = "m_hand", Sprite = "male/male_Hand", Title = "双手", Organs = new[] { "hand" },
                       Layer = 5, Tinted = true },
            new Part { Id = "m_arm", Sprite = "male/male_LowerArm", Title = "双小臂", Organs = new[] { "arm" },
                       Layer = 6, Tinted = true },
            new Part { Id = "m_shoulder", Sprite = "male/male_UpperArm", Title = "双肩", Organs = new[] { "shoulder" },
                       Layer = 7, Tinted = true },
            // 男性素材没有单独的鼻/嘴图层(那几笔画在脸上),所以这一层把口鼻的器官一起收进来
            new Part { Id = "m_face", Sprite = "male/male_Head", Title = "头部",
                       Organs = new[] { "brain", "head", "ear", "horn", "nose", "mouth", "teeth", "fang", "beak" },
                       Layer = 8, Tinted = true },
            // 发型和衣服各自是一个目录,里面丢几张就有几种,按单位 id 挑(见 BioDollVariants)
            new Part { Id = "m_hair", Sprite = "male/Hairs/male_Hair", Variants = "male/Hairs",
                       Title = "毛发",
                       Organs = new[] { "hair", "fur", "scale", "feather" },
                       Layer = 9, Tinted = true, ClothMode = BioDollSkin.ClothFromHair },
            // 眼睛的睁眼图和闭眼图一起放在 male/Eye/ 子目录下。Closed 是闭眼贴图,眨眼时临时
            // 换上去(见 BioEyeBlink)。闭眼图只画了一条眼皮线,靠底下 male_Head(Layer 8)在
            // 眼窝这一片是实心的把眼白挡住 —— 脸那层要是掏了洞,闭眼那一帧就会露出后面的层。
            new Part { Id = "m_eye_l", Sprite = "male/Eye/male_LeftEye", Closed = "male/Eye/leftEye_closed",
                       Title = "左眼", Organs = new[] { "eye_l" },
                       Layer = 10, Tinted = true },
            new Part { Id = "m_eye_r", Sprite = "male/Eye/male_RightEye", Closed = "male/Eye/rightEye_closed",
                       Title = "右眼", Organs = new[] { "eye_r" },
                       Layer = 11, Tinted = true },
            new Part { Id = "m_testicle", Sprite = "male/male_Testicles", Title = "\u777e\u4e38", Organs = new[] { "testicle" },
                       Layer = 12, Tinted = true, Dress = DressNude },
            // \u9634\u6bdb原图是一片近黑(#020202),导出时改成了 magenta_4,所以走发色档里最深那一级
            new Part { Id = "m_pubic", Sprite = "male/male_PubicHair", Title = "毛发",
                       Organs = new[] { "hair", "fur" },
                       Layer = 13, Tinted = true, Dress = DressNude, ClothMode = BioDollSkin.ClothFromHair },
            // 四档\u9634\u830e共用一个 Layer:同一时刻只会挂上其中一张(见 PenisTierOf)
            new Part { Id = "m_penis_flaccid", Sprite = "male/male_Flaccid", Title = "\u9634\u830e", Organs = new[] { "penis" },
                       Layer = 14, Tinted = true, Dress = DressNude, Penis = PenisFlaccid },
            new Part { Id = "m_penis_small", Sprite = "male/male_ErectSmall", Title = "\u9634\u830e", Organs = new[] { "penis" },
                       Layer = 14, Tinted = true, Dress = DressNude, Penis = PenisSmall },
            new Part { Id = "m_penis_medium", Sprite = "male/male_ErectMedium", Title = "\u9634\u830e", Organs = new[] { "penis" },
                       Layer = 14, Tinted = true, Dress = DressNude, Penis = PenisMedium },
            new Part { Id = "m_penis_large", Sprite = "male/male_ErectLarge", Title = "\u9634\u830e", Organs = new[] { "penis" },
                       Layer = 14, Tinted = true, Dress = DressNude, Penis = PenisLarge },
        };

        // 女性/扶他:按 body_girl.psd 的图层叠放顺序(Layer 越大越靠上),只有脸/鼻/嘴那三层
        // 合成了一张 body_head:
        //   body_Hair / Left Eye / Right Eye / head / Hand / LowerArm / UpperArm /
        //   ClothedTorso / NudeTorso / Leg / Feet / Nude / Clothed
        // Cx/Cy/W/H 留空,由 BioDollSkin 按贴图实际内容算出,避免手写坐标导致贴图错位。
        private static readonly Part[] FemaleLayout = {
            new Part { Id = "f_clothed", Sprite = "female/body_Clothed", Title = "皮肤", Organs = SkinOrgans,
                       Layer = 0, Tinted = true, Dress = DressClothed, Always = true },
            new Part { Id = "f_nude", Sprite = "female/body_Nude", Title = "皮肤", Organs = SkinOrgans,
                       Layer = 1, Tinted = true, Dress = DressNude, Always = true },
            new Part { Id = "f_foot", Sprite = "female/body_Feet", Title = "双脚", Organs = new[] { "foot" },
                       Layer = 2, Tinted = true },
            new Part { Id = "f_leg", Sprite = "female/body_Leg", Title = "\u53cc\u817f", Organs = new[] { "leg" },
                       Layer = 3, Tinted = true },
            new Part { Id = "f_torso_nude", Sprite = "female/body_NudeTorso", Title = "躯干", Organs = TorsoOrgans,
                       Layer = 4, Tinted = true, Dress = DressNude },
            new Part { Id = "f_torso_clothed", Sprite = "female/ClothedTorso/body_ClothedTorso",
                       Variants = "female/ClothedTorso", Title = "躯干", Organs = TorsoOrgans,
                       Layer = 5, Tinted = true, Dress = DressClothed },
            new Part { Id = "f_shoulder", Sprite = "female/body_UpperArm", Title = "双肩", Organs = new[] { "shoulder" },
                       Layer = 6, Tinted = true },
            new Part { Id = "f_arm", Sprite = "female/body_LowerArm", Title = "双小臂", Organs = new[] { "arm" },
                       Layer = 7, Tinted = true },
            new Part { Id = "f_hand", Sprite = "female/body_Hand", Title = "双手", Organs = new[] { "hand" },
                       Layer = 8, Tinted = true },
            // 脸/鼻/嘴原来是三层。鼻和嘴各自只有一两笔线,单独一层的结果是悬停能弹出"鼻"这种
            // 只有一个器官的提示、点一下还得再选一次,分得太细反而难点;而且那两笔本来就画在
            // 脸的填充里,拆成三层只是把同一块像素重复摊了三遍。现在合成一张 body_head,
            // 口鼻的器官一起收进这一层(男性那套 male_Head 也是同一个做法)。
            new Part { Id = "f_head", Sprite = "female/body_head", Title = "头部",
                       Organs = new[] { "brain", "head", "ear", "horn", "nose", "mouth", "teeth", "fang", "beak" },
                       Layer = 9, Tinted = true },
            // 眼睛的睁眼图和闭眼图一起放在 female/Eye/ 子目录下,Sprite/Closed 里直接带上子目录。
            // Closed 是这只眼睛的闭眼贴图,眨眼时临时换上去(见 BioEyeBlink)。
            // 睁眼图和闭眼图的命名风格不一样(空格大写 vs 驼峰下划线),这是素材本来的名字,别"顺手改整齐"。
            new Part { Id = "f_eye_r", Sprite = "female/Eye/body_Right Eye", Closed = "female/Eye/body_rightEye_closed",
                       Title = "右眼", Organs = new[] { "eye_r" },
                       Layer = 10, Tinted = true },
            new Part { Id = "f_eye_l", Sprite = "female/Eye/body_Left Eye", Closed = "female/Eye/body_leftEye_closed",
                       Title = "左眼", Organs = new[] { "eye_l" },
                       Layer = 11, Tinted = true },
            // 发型和衣服各自是一个目录,里面丢几张就有几种,按单位 id 挑(见 BioDollVariants)
            new Part { Id = "f_hair", Sprite = "female/Hairs/body_Hair", Variants = "female/Hairs",
                       Title = "毛发",
                       Organs = new[] { "hair", "fur", "scale", "feather" },
                       Layer = 12, Tinted = true, ClothMode = BioDollSkin.ClothFromHair },
        };

        // 颜色档位
        private static readonly Color ColorOutline = new Color(0.85f, 0.87f, 0.90f, 1f);
        private static readonly Color ColorIntact = new Color(0.92f, 0.92f, 0.92f, 1f);
        private static readonly Color ColorBoosted = new Color(0.45f, 0.85f, 1f, 1f);
        private static readonly Color ColorLight = new Color(1f, 0.95f, 0.55f, 1f);
        private static readonly Color ColorMedium = new Color(1f, 0.72f, 0.35f, 1f);
        private static readonly Color ColorHeavy = new Color(1f, 0.40f, 0.40f, 1f);
        private static readonly Color ColorMissing = new Color(0.35f, 0.35f, 0.38f, 1f);

        private static RectTransform _root;
        private static UnitWindow _window;

        // 左侧头像框:_portrait=外层, _portraitClip=内部裁剪区, _headGroup=放大的头部副本容器
        private static RectTransform _portrait;
        private static RectTransform _portraitClip;
        private static RectTransform _headGroup;
        private static RectTransform _dollGroup;
        // 框贴图九宫格边距区的实际绘制宽度(左/下/右/上)。它只用来算框的尺寸下限,
        // 因为边框粗细跟着框一起缩放,这个值也会跟着变。
        private static Vector4 _frameInset = new Vector4(8f, 8f, 8f, 8f);
        // 框贴图那两个 Image:边框粗细要随立绘高度重设,所以得留着引用,不能只在建节点时套一次材质
        private static Image _frameBack;
        private static Image _frameSrc;
        private static float _frameLookTarget = -1f;   // 上次套用的边框粗细,没变就不重复设

        // 当前已搭好的那一套
        private static Part[] _built;
        private static bool _builtFemale;
        private static bool _builtNude;
        private static int _builtPenis;
        private static string _builtPalette;

        // ===== 好感度系统 =====
        private const int MaxHearts = 5;
        private const float HeartSize = 10f;
        private const float HeartGap = 1f;
        private static Image[] _hearts;
        private static Text _relationText;
        private static Sprite _heartFilled;
        private static Sprite _heartHalf;
        private static Sprite _heartEmpty;

        // 关系称谓:改为直接复用 BioDialogue 的本地化池(bio_dial_rel_*),
        // 避免这里再硬编码一份中文导致英文/繁体模式露出简体。

        private static void EnsureHeartSprites() {
            if (_heartFilled == null) _heartFilled = SpriteTextureLoader.getSprite("ui/icons/filled heart");
            if (_heartHalf == null) _heartHalf = SpriteTextureLoader.getSprite("ui/icons/half heart");
            if (_heartEmpty == null) _heartEmpty = SpriteTextureLoader.getSprite("ui/icons/outline heart");
        }

        private static void BuildHeartsUI(RectTransform pParent) {
            GameObject container = new GameObject("Hearts", typeof(RectTransform));
            container.transform.SetParent(pParent, false);
            RectTransform crt = container.GetComponent<RectTransform>();
            crt.anchorMin = new Vector2(0f, 0.5f);
            crt.anchorMax = new Vector2(0f, 0.5f);
            crt.pivot = new Vector2(0f, 0.5f);

            float totalW = MaxHearts * HeartSize + (MaxHearts - 1) * HeartGap;
            crt.sizeDelta = new Vector2(totalW+20f, HeartSize + 22f);

            _hearts = new Image[MaxHearts];
            EnsureHeartSprites();

            for (int i = 0; i < MaxHearts; i++) {
                GameObject heartGo = new GameObject("Heart_" + i, typeof(RectTransform), typeof(Image));
                heartGo.transform.SetParent(crt, false);
                RectTransform hrt = heartGo.GetComponent<RectTransform>();
                hrt.anchorMin = new Vector2(0f, 1f);
                hrt.anchorMax = new Vector2(0f, 1f);
                hrt.pivot = new Vector2(0f, 1f);
                hrt.anchoredPosition = new Vector2(i * (HeartSize + HeartGap), 0f);
                hrt.sizeDelta = new Vector2(HeartSize, HeartSize);
                Image img = heartGo.GetComponent<Image>();
                img.sprite = _heartEmpty;
                img.preserveAspect = true;
                img.raycastTarget = false;
                _hearts[i] = img;
            }

            GameObject relGo = new GameObject("RelationText", typeof(RectTransform), typeof(LayoutElement));
            relGo.transform.SetParent(crt, false);
            RectTransform trt = relGo.GetComponent<RectTransform>();
            trt.anchorMin = new Vector2(0f, 1f);
            trt.anchorMax = new Vector2(0f, 1f);
            trt.pivot = new Vector2(0f, 1f);
            trt.anchoredPosition = new Vector2(0f, -(HeartSize + 2f));
            trt.sizeDelta = new Vector2(totalW + 20f, 14f);
            _relationText = relGo.AddComponent<Text>();
            _relationText.font = LocalizedTextManager.current_font;
            _relationText.fontSize = 9;
            _relationText.color = new Color(1f, 0.85f, 0.9f);
            _relationText.alignment = TextAnchor.MiddleCenter;
            _relationText.raycastTarget = false;
            // 英文关系文案(如 "Relation: Indifferent 30%")比中文长得多,
            // 容器只有一行高,默认换行会把后半截挤到看不见的第二行。
            // 关闭水平换行并允许横向溢出,保证单行完整显示。
            _relationText.horizontalOverflow = HorizontalWrapMode.Overflow;
            _relationText.verticalOverflow = VerticalWrapMode.Overflow;
            _relationText.text = BioText.T("bio_dial_rel_header", "\u5173\u7cfb\uff1a")
                + BioDialogue.RelationName(30) + " 30%";
        }

        public static void UpdateAffection(Actor pActor) {
            if (_hearts == null || pActor == null) return;
            int affection = 30;
            try {
                ActorWoundState state = HealthSimulator.GetState(pActor.getID());
                if (state != null && state.Mods != null) affection = state.Mods.Affection;
            } catch { }
            affection = Mathf.Clamp(affection, 0, 100);

            for (int i = 0; i < MaxHearts; i++) {
                float threshold = (i + 1) * 20f;
                if (affection >= threshold) {
                    _hearts[i].sprite = _heartFilled;
                } else if (affection >= threshold - 10f) {
                    _hearts[i].sprite = _heartHalf;
                } else {
                    _hearts[i].sprite = _heartEmpty;
                }
            }
            if (_relationText != null) {
                _relationText.text = BioText.T("bio_dial_rel_header", "\u5173\u7cfb\uff1a")
                    + BioDialogue.RelationName(affection) + " " + affection + "%";
            }
        }
        /// <summary> 生物学标签下显示立绘,切走隐藏 </summary>
        public static void SetVisible(UnitWindow pWindow, bool pVisible)
        {
            try
            {
                if (pVisible)
                {
                    EnsureRoot(pWindow);
                    if (_root != null)
                    {
                        Actor actor = pWindow != null ? pWindow.actor : null;
                        if (actor != null) EnsureParts(actor);
                        ApplyDollLayout(pWindow);
                        _root.gameObject.SetActive(true);
                    }
                }
                else if (_root != null)
                {
                    _root.gameObject.SetActive(false);
                }
            }
            catch (Exception e)
            {
                Main.LogError("生物学:切换人物立绘失败 " + e);
            }
        }

        /// <summary> 模组设置里切换\u88f8\u4f53立绘后,强制重搭一次 </summary>
        public static void ResetBuild()
        {
            _built = null;
            _builtPalette = null;
            BioDollSkin.Invalidate();
        }

        // 创建立绘容器(挂在 Viewport 下,固定在左下角,不随内容滚动)
        private static void EnsureRoot(UnitWindow pWindow)
        {
            if (pWindow == null) return;
            if (_root != null && _window == pWindow) return;

            Transform viewport = pWindow.transform.Find("Background/Scroll View/Viewport");
            if (viewport == null)
            {
                Main.LogError("生物学:人物立绘未找到 Viewport");
                return;
            }
            Transform old = viewport.Find("BioBodyDoll");
            if (old != null) UnityEngine.Object.DestroyImmediate(old.gameObject);

            GameObject go = new GameObject("BioBodyDoll", typeof(RectTransform));
            go.transform.SetParent(viewport, false);
            // 放在最底层:立绘尺寸固定,展开 Header 时它的数值条会盖住立绘顶部,
            // 而不是反过来让立绘挡住数值(数值是要读的,立绘头顶被遮无所谓)
            go.transform.SetAsFirstSibling();
            _root = go.GetComponent<RectTransform>();
            _root.anchorMin = new Vector2(0f, 0f);
            _root.anchorMax = new Vector2(0f, 0f);
            _root.pivot = new Vector2(0f, 0f);
            LayoutElement le = go.AddComponent<LayoutElement>();
            le.ignoreLayout = true;   // 固定定位,不参与视口的布局
            // 眨眼协程挂在根节点上:节点被禁用/销毁时协程自然停,不用另外管生命周期
            go.AddComponent<BioEyeBlink>();
            // 身高跟随也挂在这儿,同样跟着根节点的启用状态走
            go.AddComponent<BioDollWatch>();

            _window = pWindow;
            _built = null;            // 换了窗口,部位要重新挂
            _builtPalette = null;
            BuildContainers(pWindow);
        }

        // 头像框结构(自下往上): 衬底 → 框贴图(整张,含花纹与深色内衬) → 照片衬底 → 裁剪区(头部)
        // 框贴图整张画在最下面,照片压在它的内衬上,只把最外面那圈花纹留在外面。所以框可以一直
        // 收紧到贴住照片,花纹粗细不受影响。
        private static void BuildContainers(UnitWindow pWindow)
        {
            if (_root == null) return;
            ClearChildren(_root);
            _portrait = null;
            _portraitClip = null;
            _headGroup = null;
            _dollGroup = null;
            _frameBack = null;
            _frameSrc = null;
            _frameLookTarget = -1f;
            _built = null;
            _hearts = null;
            _relationText = null;

            GameObject portraitGo = new GameObject("Portrait", typeof(RectTransform));
            portraitGo.transform.SetParent(_root, false);
            _portrait = portraitGo.GetComponent<RectTransform>();
            _portrait.anchorMin = new Vector2(0f, 0f);
            _portrait.anchorMax = new Vector2(0f, 0f);
            _portrait.pivot = new Vector2(0f, 0f);

            // 注意:这里不能再垫一层铺满整个框的深色衬底。框贴图四角是 45° 斜切的,斜切外面是透明的,
            // 衬底会把那几块透明角填成深色方块,看起来就是"黑底比框大了一圈"。照片自己的衬底
            // (下面的 PhotoBack)只盖照片区,框的镂空处就老实露出面板背景。
            _frameBack = NewStretched(_portrait, "FrameBack");
            _frameSrc = FindHeaderAvatarFrame(pWindow);
            _frameLookTarget = -1f;
            EnsureFrameLook(FrameBorderTarget);   // 先按基准粗细套一次,布局时再按当前系数重设

            GameObject clipGo = new GameObject("Clip", typeof(RectTransform), typeof(RectMask2D));
            clipGo.transform.SetParent(_portrait, false);
            _portraitClip = clipGo.GetComponent<RectTransform>();
            _portraitClip.anchorMin = new Vector2(0f, 0f);
            _portraitClip.anchorMax = new Vector2(1f, 1f);

            // 照片衬底:照片区正压在框贴图的内衬上,而内衬上还画着暗纹(左上角那片电路花纹),
            // 垫一层和内衬同色的纯色把它盖掉,证件照背景才是干净的一块。
            Image photoBack = NewStretched(_portraitClip, "PhotoBack");
            photoBack.color = FrameLiningColor;

            GameObject headGo = new GameObject("Head", typeof(RectTransform));
            headGo.transform.SetParent(_portraitClip, false);
            _headGroup = headGo.GetComponent<RectTransform>();
            _headGroup.anchorMin = new Vector2(0f, 1f);
            _headGroup.anchorMax = new Vector2(0f, 1f);
            _headGroup.pivot = new Vector2(0f, 1f);
            _headGroup.anchoredPosition = Vector2.zero;
            _headGroup.sizeDelta = Vector2.zero;

            // 身高尺:夹在头像框和立绘中间。比立绘先建,头顶那条标线才压在立绘下面,
            // 看着像量尺横杆顶着头顶而不是划在脸上。
            BioHeightRuler.Build(_root);

            // 立绘本体
            GameObject dollGo = new GameObject("Doll", typeof(RectTransform));
            dollGo.transform.SetParent(_root, false);
            _dollGroup = dollGo.GetComponent<RectTransform>();
            _dollGroup.anchorMin = new Vector2(0f, 1f);
            _dollGroup.anchorMax = new Vector2(0f, 1f);
            _dollGroup.pivot = new Vector2(0f, 1f);

            BuildHeartsUI(_root);
        }

        private static Image NewStretched(RectTransform pParent, string pName)
        {
            GameObject go = new GameObject(pName, typeof(RectTransform), typeof(Image));
            go.transform.SetParent(pParent, false);
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
            Image img = go.GetComponent<Image>();
            img.raycastTarget = false;
            return img;
        }

        /// <summary>
        /// 边框粗细跟着框整体缩放,所以 pixelsPerUnitMultiplier 得在布局时按当前系数重设。
        /// 粗细没变就什么都不做 —— 反复给 Image 赋值会触发无意义的重建。
        /// </summary>
        private static void EnsureFrameLook(float pBorderTarget)
        {
            if (_frameBack == null) return;
            if (Mathf.Abs(pBorderTarget - _frameLookTarget) < 0.01f) return;
            _frameInset = ApplyFrameLook(_frameBack, _frameSrc, pBorderTarget);
            _frameLookTarget = pBorderTarget;
        }

        /// <summary>
        /// 把 Header 头像框的材质套到目标 Image 上,返回九宫格边距区的实际绘制宽度(左/下/右/上)。
        /// 框贴图带九宫格时用 Sliced 并把边距区缩放到 pBorderTarget 这个量级
        /// (原版那张只有 48x48、边距占满整张,不缩会把小框撑爆)。
        /// 返回值只用来算框的尺寸下限,不用来摆照片 —— 照片让开的是花纹留边那一圈。
        /// </summary>
        private static Vector4 ApplyFrameLook(Image pTarget, Image pSource, float pBorderTarget)
        {
            Vector4 fallback = new Vector4(8f, 8f, 8f, 8f);
            if (pTarget == null) return fallback;
            pTarget.color = new Color(0.10f, 0.12f, 0.16f, 0.92f);
            pTarget.type = Image.Type.Sliced;
            pTarget.fillCenter = true;

            Sprite sprite = pSource != null ? pSource.sprite : null;
            if (sprite == null)
            {
                try { sprite = SpriteTextureLoader.getSprite("ui/special/button"); } catch { }
                if (sprite == null)
                {
                    // 连退路贴图都没有:退化成纯色块
                    pTarget.type = Image.Type.Simple;
                    return fallback;
                }
            }
            else
            {
                pTarget.material = pSource.material;
                pTarget.color = pSource.color;
            }
            pTarget.sprite = sprite;

            Vector4 border = sprite.border;
            if (border == Vector4.zero)
            {
                // 没有九宫格:整张拉伸,没有边距区可言,尺寸下限走退路值
                pTarget.type = Image.Type.Simple;
                return fallback;
            }

            // Unity 画 Sliced 时: 实际边距区 = 九宫格边距 / (pixelsPerUnit * pixelsPerUnitMultiplier)
            float maxBorder = Mathf.Max(Mathf.Max(border.x, border.y), Mathf.Max(border.z, border.w));
            float ppu = pTarget.pixelsPerUnit;
            if (ppu <= 0.0001f) ppu = 1f;
            float mul = Mathf.Max(0.01f, maxBorder / (ppu * Mathf.Max(1f, pBorderTarget)));
            pTarget.pixelsPerUnitMultiplier = mul;
            float denom = ppu * mul;
            Vector4 inset = new Vector4(border.x / denom, border.y / denom, border.z / denom, border.w / denom);
            Main.LogInfo("生物学:头像框 图片=" + sprite.name + " 原图("
                + sprite.rect.width.ToString("F0") + "x" + sprite.rect.height.ToString("F0")
                + ") 九宫格=" + border + " ppu=" + ppu.ToString("F2") + " 倍率=" + mul.ToString("F2")
                + " 边框粗细=" + pBorderTarget.ToString("F1")
                + " 边距区=(" + inset.x.ToString("F1") + "," + inset.y.ToString("F1")
                + "," + inset.z.ToString("F1") + "," + inset.w.ToString("F1")
                + ") 尺寸下限=" + (inset.x + inset.z).ToString("F1")
                + "x" + (inset.y + inset.w).ToString("F1"));
            return inset;
        }

        // Header 头像框。UnitAvatarLoader._frame 只是个缩放用的空节点(没有 Image),
        // 而 clanBanner/kingdomBanner 下面的 clan_frame/kingdom_frame 是旗帜边框、不是头像框,
        // 所以这两处都要排除,只在头像元素自身与其父节点这一层找底板。
        private static Image FindHeaderAvatarFrame(UnitWindow pWindow)
        {
            try
            {
                if (pWindow == null) return null;
                UiUnitAvatarElement el = pWindow.GetComponentInChildren<UiUnitAvatarElement>(true);
                if (el == null) return null;

                // 打开「功能开关>点击探针」时,把头像元素与其父节点整棵图树打进日志,便于对照挑框
                BioClickProbe.DumpImages(el.transform.parent != null ? el.transform.parent : el.transform,
                    "Header头像", 60);

                Transform[] scopes = { el.transform, el.transform.parent };
                for (int s = 0; s < scopes.Length; s++)
                {
                    Image found = ScanForFrame(scopes[s], el);
                    if (found != null) return found;
                }
            }
            catch (Exception e)
            {
                Main.LogError("生物学:查找 Header 头像框失败 " + e);
            }
            return null;
        }

        // 在一层作用域里找底板:跳过旗帜子树和头像本身的立绘/物品图,取面积最大的九宫格底图
        private static Image ScanForFrame(Transform pScope, UiUnitAvatarElement pElement)
        {
            if (pScope == null) return null;
            Image best = null;
            float bestArea = 0f;
            Image[] all = pScope.GetComponentsInChildren<Image>(true);
            for (int i = 0; i < all.Length; i++)
            {
                Image img = all[i];
                if (img == null || img.sprite == null) continue;
                if (IsUnderBanner(img.transform, pElement)) continue;
                if (pElement.avatarLoader != null &&
                    (img == pElement.avatarLoader._actor_image || img == pElement.avatarLoader._item_image)) continue;
                if (img == pElement.unit_type_bg) continue;   // 国王/领主的特殊底板,不是通用框
                RectTransform rt = img.rectTransform;
                float area = Mathf.Abs(rt.rect.width * rt.rect.height);
                if (area <= 1f) continue;
                // 九宫格底图能拉成长方形而不变形,优先选它
                bool sliced = img.sprite.border != Vector4.zero;
                float score = area * (sliced ? 4f : 1f);
                if (score > bestArea)
                {
                    bestArea = score;
                    best = img;
                }
            }
            return best;
        }

        private static bool IsUnderBanner(Transform pNode, UiUnitAvatarElement pElement)
        {
            Transform clan = pElement.clanBanner != null ? pElement.clanBanner.transform : null;
            Transform kingdom = pElement.kingdomBanner != null ? pElement.kingdomBanner.transform : null;
            Transform cur = pNode;
            int guard = 0;
            while (cur != null && guard++ < 12)
            {
                if (cur == clan || cur == kingdom) return true;
                cur = cur.parent;
            }
            return false;
        }

        // 女性与扶他(双性)用女性素材;男性与判不出性别的走男性素材
        private static bool UsesFemaleSkin(Actor pActor)
        {
            try
            {
                int gender = HealthSimulator.GetGender(pActor);
                return gender == 2 || gender == 3;
            }
            catch (Exception e)
            {
                Main.LogError("生物学:立绘判定性别失败 " + e);
                return false;
            }
        }

        /// <summary>
        /// \u88f8\u4f53立绘上该挂哪一张\u9634\u830e贴图。
        /// 档位按生物学器官面板里那个「\u52c3\u8d77尺寸」分 —— 那串数就是悬停弹窗显示的数
        /// (同一个种子同一套抽法,见 OrganInfo.GetPenisSize),所以贴图和文字永远对得上。
        /// 最大号额外锁在「巨大」特质后面。
        /// </summary>
        private static int PenisTierOf(Actor pActor)
        {
            try
            {
                int flaccid, erect;
                OrganInfo.GetPenisSize(pActor, out flaccid, out erect);
                if (erect >= PenisLargeCm && BioHeight.IsGiant(pActor)) return PenisLarge;
                if (erect >= PenisMediumCm) return PenisMedium;
                if (erect >= PenisSmallCm) return PenisSmall;
                return PenisFlaccid;
            }
            catch (Exception e)
            {
                Main.LogError("生物学:立绘取\u9634\u830e档位失败 " + e);
                return PenisFlaccid;
            }
        }

        /// <summary>
        /// 身高变了就跟着更新(BioDollWatch 每隔一小会儿调一次)。
        ///
        /// 身高由特质和年龄现算,改特质不会有事件通知,所以只能自己对数。多数情况只需要重新摆位
        /// —— 预烘倍率按 1/40 的台阶量化,实测身高得变 0.1 米上下才会跳一档,跳档时
        /// EnsureParts 才会真的重烘。加/去掉「巨大」「渺小」必然跨过好几档,所以贴图分辨率跟得上。
        /// </summary>
        public static void CheckMetrics()
        {
            try
            {
                if (_root == null || !_root.gameObject.activeInHierarchy) return;
                Actor actor = _window != null ? _window.actor : null;
                if (actor == null) return;
                float meters = BioHeight.MetersOf(actor);
                if (Mathf.Abs(meters - _lastMeters) < 0.001f) return;
                Main.LogInfo("生物学:立绘身高变化 " + _lastMeters.ToString("F2")
                    + "m → " + meters.ToString("F2") + "m,重新摆位");
                _lastMeters = meters;
                EnsureParts(actor);
                ApplyDollLayout(_window);
            }
            catch (Exception e)
            {
                Main.LogError("生物学:立绘身高跟随失败 " + e);
            }
        }

        // 性别/穿衣/\u9634\u830e档位/肤色/发色/预烘倍率任一变化时重搭部位,否则复用现有节点
        private static void EnsureParts(Actor pActor)
        {
            if (_root == null || pActor == null) return;
            if (_dollGroup == null || _headGroup == null) BuildContainers(_window);
            bool female = UsesFemaleSkin(pActor);
            bool nude = Main.NudeDoll || Main.HideClothing;
            // \u9634\u830e档位只在男性\u88f8\u4f53时才有意义,其余情况一律 None(这样这几层根本不会被挂上)
            int penis = female || !nude ? PenisNone : PenisTierOf(pActor);
            // 身高决定立绘高度和头像框大小 → 决定两处预烘倍率,所以它也得进重建判断
            DollMetrics dm = Measure(_window);
            _dollHeight = dm.Height;
            _photoH = dm.PhotoH;
            _lastMeters = dm.Meters;
            // 男女两套素材现在都走关键色换色,所以肤色/王国色/发色指纹对两边都得进重建键。
            //
            // 后两项直接用最终的预烘倍率,而不是身高和 Canvas 缩放的原始值:那两个原始值任何
            // 一丁点变化都会让键变掉(旧的键是按四舍五入到 1 个单位的立绘高度算的,合 1.7 厘米
            // 身高),而贴图本来只按 1/40 的台阶烘,实测要变 0.1 米上下才真跳一档 —— 中间那些
            // 重烘全是白干。倍率本身已经把 Canvas 缩放算进去了(见 BakeScale),所以不用再单列。
            string palette = BioDollSkin.Signature(pActor)
                + (female ? "|f" : "|m")
                + "|d" + Mathf.RoundToInt(BakeScale(NominalDollScale) * 1000f)
                + "|p" + Mathf.RoundToInt(BakeScale(NominalHeadScale(female)) * 1000f)
                // 发型/衣服是按单位 id 挑的,同肤色同王国的两个单位也可能挑到不同的图,
                // 所以选择结果必须进重建键 —— 不进的话换单位时会直接复用上一个的贴图
                + VariantSignature(female ? FemaleLayout : MaleLayout, pActor);
            if (_built != null && _builtFemale == female && _builtNude == nude
                && _builtPenis == penis && _builtPalette == palette) return;
            BuildParts(pActor, female, nude, penis, palette);
        }

        // 这一套布局里所有"一层多张备选"的部位,这个单位分别挑中了第几张
        private static string VariantSignature(Part[] pLayout, Actor pActor)
        {
            StringBuilder sb = null;
            for (int i = 0; i < pLayout.Length; i++)
            {
                Part p = pLayout[i];
                if (string.IsNullOrEmpty(p.Variants)) continue;
                if (sb == null) sb = new StringBuilder();
                sb.Append("|v").Append(BioDollVariants.PickIndex(p.Variants, pActor));
            }
            return sb == null ? "" : sb.ToString();
        }

        private static void BuildParts(Actor pActor, bool pFemale, bool pNude, int pPenis, string pPalette)
        {
            if (_dollGroup == null || _headGroup == null) BuildContainers(_window);
            ClearChildren(_dollGroup);
            ClearChildren(_headGroup);

            Part[] layout = pFemale ? FemaleLayout : MaleLayout;
            List<Part> live = new List<Part>();
            _blinkClosed = false;   // 换了一套 Image,眨眼状态跟着复位
            for (int i = 0; i < layout.Length; i++)
            {
                Part p = layout[i];
                p.Img = null;
                p.HeadImg = null;
                p.BaseSprite = null;
                p.BaseHeadSprite = null;
                p.FlatSprite = null;
                p.FlatHeadSprite = null;
                p.ClosedSprite = null;
                p.ClosedHeadSprite = null;
                p.Click = null;
                // 这一层这次用哪张:发型/衣服这种有备选目录的按单位挑,其余就是布局表里那张。
                // 放在 Dress/Penis 跳过判断之前,这样被跳过的层也不会留着上一个单位的路径
                p.SpritePath = string.IsNullOrEmpty(p.Variants)
                    ? p.Sprite
                    : BioDollVariants.Pick(p.Variants, p.Sprite, pActor);
                if (p.Dress == DressClothed && pNude) continue;
                if (p.Dress == DressNude && !pNude) continue;
                if (p.Penis != PenisNone && p.Penis != pPenis) continue;

                Sprite sp = null;
                Sprite headSp = null;
                if (p.Tinted)
                {
                    // 立绘与头像框显示倍率差三倍,各自按自己的倍率预缩一张,缩放脏色块就没了
                    BioDollSkin.Piece piece = BioDollSkin.Get("ui/body/" + p.SpritePath, pActor,
                        p.ClothMode, BakeScale(NominalDollScale));
                    if (piece == null) continue;
                    sp = piece.Sprite;
                    p.Cx = piece.Cx;
                    p.Cy = DesignTop + piece.CyTop;
                    p.W = piece.W;
                    p.H = piece.H;
                    BioDollSkin.Piece headPiece = BioDollSkin.Get("ui/body/" + p.SpritePath, pActor,
                        p.ClothMode, BakeScale(NominalHeadScale(pFemale)));
                    headSp = headPiece != null ? headPiece.Sprite : sp;

                    // 闭眼贴图:同样两个倍率各烘一张,并记下它自己的包围盒
                    if (!string.IsNullOrEmpty(p.Closed))
                    {
                        BioDollSkin.Piece cp = BioDollSkin.Get("ui/body/" + p.Closed, pActor,
                            p.ClothMode, BakeScale(NominalDollScale));
                        if (cp != null)
                        {
                            p.ClosedSprite = cp.Sprite;
                            p.CCx = cp.Cx;
                            p.CCy = DesignTop + cp.CyTop;
                            p.CW = cp.W;
                            p.CH = cp.H;
                            BioDollSkin.Piece chp = BioDollSkin.Get("ui/body/" + p.Closed, pActor,
                                p.ClothMode, BakeScale(NominalHeadScale(pFemale)));
                            p.ClosedHeadSprite = chp != null ? chp.Sprite : cp.Sprite;
                        }
                        else
                        {
                            Main.LogError("生物学:找不到闭眼贴图 ui/body/" + p.Closed
                                + " —— 这一层的眨眼关闭。检查文件名是否和布局表里的 Closed 一致");
                        }
                    }
                }
                else
                {
                    try { sp = SpriteTextureLoader.getSprite("ui/body/" + p.SpritePath); } catch { }
                    headSp = sp;
                }
                if (sp == null)
                {
                    Main.LogError("生物学:人物立绘缺少贴图 ui/body/" + p.SpritePath
                        + " —— 如果这张图是游戏运行中才丢进目录的,得重启游戏才会被读进资源表");
                    continue;
                }

                bool decorative = p.Organs == null || p.Organs.Length == 0;
                Color baseColor = decorative ? ColorOutline : (p.Tinted ? Color.white : ColorIntact);
                p.BaseSprite = sp;
                p.BaseHeadSprite = headSp;

                Image img = NewLayer(_dollGroup, p.Id, sp, baseColor);
                img.raycastTarget = !decorative;
                // 按像素透明度命中:女性素材各层都是整张画布,不做透明穿透会互相挡住点击
                if (!decorative)
                {
                    try { img.alphaHitTestMinimumThreshold = 0.5f; }
                    catch (Exception e) { Main.LogInfo("生物学:立绘部位无法启用透明穿透 " + p.Id + " " + e.Message); }
                    p.Click = img.gameObject.AddComponent<BioDollPartClick>();
                    p.Click.Actor = pActor;
                    p.Click.Title = TitleOf(p);
                }
                p.Img = img;

                // 头像框里的副本:同一层,换成按头像倍率预缩的那张。它自己也能点 ——
                // 头发弹发色板,其它皮肤部位弹肤色板。同样按像素透明度命中,所以点脸不会被
                // 压在上面那层透明的头发吃掉。
                Image headImg = NewLayer(_headGroup, p.Id, headSp, baseColor);
                headImg.raycastTarget = true;
                try { headImg.alphaHitTestMinimumThreshold = 0.5f; }
                catch (Exception e) { Main.LogInfo("生物学:头像框部位无法启用透明穿透 " + p.Id + " " + e.Message); }
                BioPortraitClick pc = headImg.gameObject.AddComponent<BioPortraitClick>();
                pc.Actor = pActor;
                pc.Hair = p.ClothMode == BioDollSkin.ClothFromHair;
                p.HeadImg = headImg;

                live.Add(p);
            }

            // 按 Layer 排绘制顺序(索引越大越靠上层)
            live.Sort((a, b) => a.Layer.CompareTo(b.Layer));
            for (int i = 0; i < live.Count; i++)
            {
                if (live[i].Img != null) live[i].Img.transform.SetSiblingIndex(i);
                if (live[i].HeadImg != null) live[i].HeadImg.transform.SetSiblingIndex(i);
            }

            _built = layout;
            _builtFemale = pFemale;
            _builtNude = pNude;
            _builtPenis = pPenis;
            _builtPalette = pPalette;
            ApplyDollLayout(_window);
            Main.LogInfo("生物学:人物立绘已创建(" + (pFemale ? "女性/扶他" : "男性") + (pNude ? "/\u88f8\u4f53" : "")
                + (pPenis != PenisNone ? "/\u9634\u830e" + PenisTierName(pPenis) : "")
                + " 共" + live.Count + "层 Canvas缩放=" + CanvasScale().ToString("F2")
                + " 烘图倍率 立绘=" + BakeScale(NominalDollScale).ToString("F3")
                + " 头像=" + BakeScale(NominalHeadScale(pFemale)).ToString("F3") + ")");
        }

        private static string PenisTierName(int pTier)
        {
            switch (pTier)
            {
                case PenisFlaccid: return "疲软";
                case PenisSmall: return "小";
                case PenisMedium: return "中";
                case PenisLarge: return "大";
                default: return "无";
            }
        }

        private static void ClearChildren(RectTransform pParent)
        {
            if (pParent == null) return;
            for (int i = pParent.childCount - 1; i >= 0; i--)
            {
                UnityEngine.Object.DestroyImmediate(pParent.GetChild(i).gameObject);
            }
        }

        private static Image NewLayer(RectTransform pParent, string pName, Sprite pSprite, Color pColor)
        {
            GameObject go = new GameObject(pName, typeof(RectTransform), typeof(Image));
            go.transform.SetParent(pParent, false);
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0.5f, 0.5f);
            Image img = go.GetComponent<Image>();
            img.sprite = pSprite;
            img.type = Image.Type.Simple;
            img.color = pColor;
            return img;
        }

        // 贴图预烘用的标称倍率:立绘按它当前的高度算,头像框按当前照片区高度算 —— 两者都跟身高联动,
        // 所以身高一变就得重烘,这两个值都进了 palette 键。
        private static float _dollHeight = 60f;
        private static float _photoH = PortraitPhotoH;
        // 上次算出来的身高(米)。BioDollWatch 拿它和现算的值比,变了才动
        private static float _lastMeters = -1f;

        private static float NominalDollScale { get { return _dollHeight / DesignHeight; } }

        // 一次算清整组的竖向比例。身高尺、立绘、头像框、预烘倍率必须用同一套数,所以只在这里算。
        private struct DollMetrics
        {
            public float UnitsPerMeter;   // 每米多少内容区单位
            public float Meters;          // 这个单位的身高
            public float Height;          // 立绘高度 = 身高 × UnitsPerMeter(视口太矮时会被压)
            public float Scale;           // 设计空间 → 内容区
            public float Width;           // 立绘宽度
            public float FrameK;          // 头像框整体缩放系数 = Height / FrameRefDollH
            public float PhotoH;          // 照片区高度
            public float Lip;             // 照片四周留给花纹的宽度
            public float BorderTarget;    // 边框绘制粗细
        }

        private static DollMetrics Measure(UnitWindow pWindow)
        {
            DollMetrics m = new DollMetrics();
            m.Meters = BioHeight.MetersOf(pWindow != null ? pWindow.actor : null);
            m.UnitsPerMeter = UnitsPerMeter;
            m.Height = Mathf.Max(8f, m.Meters * m.UnitsPerMeter);

            // 视口装不下时(巨人 + 矮面板)整组一起压,尺子和立绘还是同一个比例,只是跨单位没法比高矮了
            RectTransform viewport = _root != null ? _root.parent as RectTransform : null;
            if (viewport != null)
            {
                float limit = Mathf.Max(MinHeight, viewport.rect.height - Margin * 2f);
                if (m.Height > limit)
                {
                    m.Height = limit;
                    m.UnitsPerMeter = m.Height / Mathf.Max(0.01f, m.Meters);
                }
            }

            m.Scale = m.Height / DesignHeight;
            m.Width = DesignWidth * m.Scale;
            // 头像框整体跟着立绘高度等比缩放。下限卡 0.3 是防止极端矮个子把框缩成看不清的一小块
            m.FrameK = Mathf.Clamp(m.Height / FrameRefDollH, 0.3f, 3f);
            m.PhotoH = PortraitPhotoH * m.FrameK;
            m.Lip = FramePhotoLip * m.FrameK;
            m.BorderTarget = FrameBorderTarget * m.FrameK;
            return m;
        }

        private static float NominalHeadScale(bool pFemale)
        {
            return _photoH / (pFemale ? HeadWindowHeightFemale : HeadWindowHeightMale);
        }

        /// <summary>
        /// Canvas 的 UI 单位 → 屏幕像素倍率。布局全是按 UI 单位算的,但贴图要按真实像素数烘,
        /// 否则在高 DPI / 大 UI 缩放下贴图分辨率不够,放大后就是一团糊。
        /// </summary>
        private static float CanvasScale()
        {
            try
            {
                // lossyScale 是累积到世界的缩放:Screen Space Overlay 下 Canvas 自身的 localScale
                // 就等于 scaleFactor,所以这一个值就把 Canvas 缩放和中途任何缩放都算进去了
                if (_root != null)
                {
                    float s = _root.lossyScale.y;
                    if (s > 0.01f && s < 100f) return s;
                }
                Canvas c = _root != null ? _root.GetComponentInParent<Canvas>() : null;
                if (c != null && c.scaleFactor > 0.01f) return c.scaleFactor;
            }
            catch { }
            return 1f;
        }

        // 标称倍率 → 实际烘图倍率(考虑 Canvas 缩放,上限 1 表示不放大原图)
        private static float BakeScale(float pNominal)
        {
            float v = Mathf.Clamp(pNominal * CanvasScale() * BakeSafety, 0.02f, 1f);
            // 身高是连续值,倍率也就跟着连续变。不量化的话每个单位都会烘出一套只差 1% 的新贴图
            // 堆在缓存里,所以卡到 1/40 的台阶上 —— 这点分辨率差异看不出来。
            return Mathf.Round(v * 40f) / 40f;
        }

        // 摆好各部位。尺寸固定,不跟随 Header 高度(折叠/展开 Header 不改变立绘大小)
        private static void ApplyDollLayout(UnitWindow pWindow)
        {
            if (_root == null || pWindow == null || _built == null) return;
            if (_dollGroup == null || _headGroup == null || _portrait == null || _portraitClip == null) return;
            RectTransform viewport = _root.parent as RectTransform;
            if (viewport == null) return;

            // 竖向比例只在 Measure 里算一次,身高尺和立绘共用,两者刻度才对得上
            DollMetrics m = Measure(pWindow);
            float height = m.Height;
            float scale = m.Scale;
            float dollW = m.Width;

            // 头像框整体跟着立绘高度缩放:照片、花纹留边、边框粗细同一个系数,所以框只是变大变小,
            // 长宽比和花纹比例都不变。边框粗细变了要重设一次贴图的九宫格倍率,顺手拿回新的边距区。
            EnsureFrameLook(m.BorderTarget);
            _photoH = m.PhotoH;

            // 框 = 照片区 + 一圈花纹。下限 minW/minH = 九宫格对边之和:Unity 画 Sliced 时 rect 比边距
            // 之和还小,会把边距按比例一起压扁,花纹就跟着变细了。这个下限现在也跟着系数缩,
            // 所以矮个子的框能一路缩下去。撞到下限时不拉伸照片,而是把照片居中。
            float windowH = _builtFemale ? HeadWindowHeightFemale : HeadWindowHeightMale;
            float windowW = _builtFemale ? HeadWindowWidthFemale : HeadWindowWidthMale;
            float windowTop = _builtFemale ? HeadWindowTopFemale : HeadWindowTopMale;
            float windowCx = _builtFemale ? HeadWindowCxFemale : HeadWindowCxMale;

            float clipH = m.PhotoH;
            float clipW = clipH * (windowW / windowH);
            float minW = _frameInset.x + _frameInset.z;
            float minH = _frameInset.y + _frameInset.w;
            float portraitW = Mathf.Max(clipW + m.Lip * 2f, minW);
            float portraitH = Mathf.Max(clipH + m.Lip * 2f, minH);
            // 竖向:框顶与立绘头顶齐平。立绘头顶 = 立绘上边再往下让出"取景窗顶到设计空间顶"那点距离。
            float headTopY = height - Mathf.Max(0f, windowTop - DesignTop) * scale;
            float portraitY = Mathf.Max(0f, headTopY - portraitH + PortraitNudgeY);
            // 身高尺只画到头顶,所以整组高度就是"立绘"和"头像框顶"里更高的那个
            float rootH = Mathf.Max(height, portraitY + portraitH);

            // 横向:头像框 → 身高尺 → 立绘 → 好感度,整组贴着视口左下角
            float rulerX = portraitW + RulerGap;
            float dollX = rulerX + BioHeightRuler.Width + PortraitGap;
            float heartsW = MaxHearts * HeartSize + (MaxHearts - 1) * HeartGap + 20f;
            _root.anchoredPosition = new Vector2(Margin, Margin);
            _root.sizeDelta = new Vector2(dollX + dollW + 6f + heartsW, rootH);

            _portrait.anchoredPosition = new Vector2(0f, portraitY);
            _portrait.sizeDelta = new Vector2(portraitW, portraitH);

            // 照片区在框里居中,四周留出的就是花纹那一圈
            float padX = (portraitW - clipW) * 0.5f;
            float padY = (portraitH - clipH) * 0.5f;
            _portraitClip.offsetMin = new Vector2(padX, padY);
            _portraitClip.offsetMax = new Vector2(-padX, -padY);

            // 身高尺:尺底与立绘脚底同在容器底边,尺顶就是头顶
            BioHeightRuler.Apply(rulerX, m.UnitsPerMeter, m.Meters);

            // 立绘脚底落在容器底边(矮个子只是变短,不会浮在半空)
            _dollGroup.anchoredPosition = new Vector2(dollX, -(rootH - height));
            _dollGroup.sizeDelta = new Vector2(dollW, height);

            // 好感度爱心:立绘右侧,垂直居中对齐
            if (_hearts != null && _hearts.Length > 0) {
                RectTransform heartsRt = _hearts[0].rectTransform.parent as RectTransform;
                if (heartsRt != null) {
                    float heartsX = dollX + dollW + 6f;
                    float heartsH = HeartSize + 22f;
                    float dollCenterY = (height - heartsH) * 0.5f - (rootH - height) * 0.5f;
                    heartsRt.anchoredPosition = new Vector2(heartsX, dollCenterY);
                }
                Actor actor = _window != null ? _window.actor : null;
                if (actor != null) UpdateAffection(actor);
            }

            // 头部取景窗铺满照片区,得到放大倍数与偏移
            float headScale = clipH / windowH;

            for (int i = 0; i < _built.Length; i++)
            {
                Part p = _built[i];
                if (p.Img != null)
                {
                    RectTransform prt = p.Img.rectTransform;
                    p.OpenSize = new Vector2(p.W * scale, p.H * scale);
                    // 设计空间 → 容器空间(容器左上角为原点, y 向下取负)
                    p.OpenPos = new Vector2((p.Cx + DesignWidth * 0.5f) * scale,
                        -(p.Cy - DesignTop) * scale);
                    prt.sizeDelta = p.OpenSize;
                    prt.anchoredPosition = p.OpenPos;
                }
                if (p.HeadImg != null)
                {
                    RectTransform hrt = p.HeadImg.rectTransform;
                    p.OpenHeadSize = new Vector2(p.W * headScale, p.H * headScale);
                    p.OpenHeadPos = new Vector2((p.Cx - windowCx) * headScale + clipW * 0.5f,
                        -(p.Cy - windowTop) * headScale);
                    hrt.sizeDelta = p.OpenHeadSize;
                    hrt.anchoredPosition = p.OpenHeadPos;
                }
                // 闭眼贴图的包围盒不一样,按同一套公式再算一遍它自己的 rect,眨眼时整套换上去
                if (p.ClosedSprite != null || p.ClosedHeadSprite != null)
                {
                    p.ClosedSize = new Vector2(p.CW * scale, p.CH * scale);
                    p.ClosedPos = new Vector2((p.CCx + DesignWidth * 0.5f) * scale,
                        -(p.CCy - DesignTop) * scale);
                    p.ClosedHeadSize = new Vector2(p.CW * headScale, p.CH * headScale);
                    p.ClosedHeadPos = new Vector2((p.CCx - windowCx) * headScale + clipW * 0.5f,
                        -(p.CCy - windowTop) * headScale);
                }
            }
            // 眨眼期间重新布局(比如折叠 Header)会把眼睛按睁眼几何摆回去,所以再套一次当前状态
            ApplyBlink();
        }

        /// <summary>
        /// 按当前器官健康度刷新各部位颜色、悬停提示与点击目标(Rebuild 时调用)。
        /// 一个部位取其名下器官里"最差"的那个来上色：缺失 > 重伤 > 中伤 > 轻伤 > 完好 > 强化。
        /// 女性/扶他素材本身已经是肤色/衣服色,所以完好时不加色,只有受伤才染伤情色。
        /// </summary>
        public static void Refresh(Actor pActor, BodyHealth pBody)
        {
            try
            {
                if (_root == null || pActor == null || pBody == null) return;
                ActorWoundState state;
                if (HealthSimulator.TryGetState(pActor.getID(), out state)) LimbDependency.NormalizeState(state);
                EnsureParts(pActor);
                if (_built == null) return;

                Dictionary<string, OrganHealth> byId = new Dictionary<string, OrganHealth>();
                foreach (OrganHealth oh in pBody.Organs)
                {
                    if (oh != null && oh.Def != null) byId[oh.Def.Id] = oh;
                }

                for (int i = 0; i < _built.Length; i++)
                {
                    Part p = _built[i];
                    if (p.Img == null) continue;
                    if (p.Organs == null || p.Organs.Length == 0) continue;

                    int worst = int.MaxValue;
                    bool anyMissing = false;
                    List<string> present = new List<string>();
                    StringBuilder tip = new StringBuilder();
                    for (int k = 0; k < p.Organs.Length; k++)
                    {
                        OrganHealth oh;
                        if (!byId.TryGetValue(p.Organs[k], out oh) || oh == null) continue;
                        present.Add(p.Organs[k]);
                        if (oh.IsMissing) anyMissing = true;
                        else if (oh.Hp < worst) worst = oh.Hp;
                        if (tip.Length > 0) tip.Append("\n");
                        tip.Append(oh.Def.LocalizedName).Append(": ");
                        if (oh.IsMissing) tip.Append("缺失");
                        else if (oh.Hp <= 0) tip.Append("0%·衰竭");
                        else tip.Append(oh.Hp).Append("%");
                        foreach (DiseaseHit hit in oh.Diseases)
                        {
                            if (hit == null || hit.Severity <= 0) continue;
                            tip.Append("  ").Append(hit.Def.Name).Append("→").Append(hit.Severity).Append("%");
                        }
                    }

                    // 该部位没有任何器官(例如动物没有手)→ 隐藏这一块;全身轮廓层例外
                    bool show = present.Count > 0 || p.Always;
                    p.Img.enabled = show;
                    if (p.HeadImg != null) p.HeadImg.enabled = show;
                    if (present.Count == 0)
                    {
                        if (p.Click != null) p.Click.OrganIds = present;
                        if (p.Always && p.Tinted) SetPartTint(p, 100, false);
                        continue;
                    }

                    SetPartTint(p, anyMissing ? -1 : worst, anyMissing);

                    string title = TitleOf(p);
                    OrganTooltip ot = p.Img.GetComponent<OrganTooltip>();
                    if (ot == null) ot = p.Img.gameObject.AddComponent<OrganTooltip>();
                    ot.TipTitle = title;
                    ot.TipDescription = tip.ToString();

                    if (p.Click != null)
                    {
                        p.Click.Actor = pActor;
                        p.Click.Title = title;
                        p.Click.OrganIds = present;
                    }
                }
            }
            catch (Exception e)
            {
                Main.LogError("生物学:刷新人物立绘失败 " + e);
            }
        }

        private static void SetPartColor(Part pPart, Color pColor)
        {
            if (pPart.Img != null) pPart.Img.color = pColor;
            if (pPart.HeadImg != null) pPart.HeadImg.color = pColor;
        }

        private static string TitleOf(Part pPart)
        {
            if (pPart == null) return "";
            if (string.IsNullOrEmpty(pPart.Title)) return pPart.Id;
            // 与器官分组同一套写法:键里带中文原文,缺翻译时直接回退原文
            return BioText.T("bio_doll_" + pPart.Title, pPart.Title);
        }

        private static Color HpColor(int pHp, bool pMissing)
        {
            if (pMissing) return ColorMissing;
            if (pHp <= 0) return ColorHeavy;
            if (pHp > 100) return ColorBoosted;
            if (pHp >= 100) return ColorIntact;
            if (pHp >= 70) return ColorLight;
            if (pHp >= 40) return ColorMedium;
            return ColorHeavy;
        }

        /// <summary>
        /// 给一个部位上伤情色。
        ///
        /// 男性素材是灰白线稿,直接乘伤情色就是伤情色。女性素材自带肤色和衣服色,乘上去会被底色吃掉
        /// —— 深肤色单位乘完还是一团黑,受伤根本看不出来。所以受伤时把贴图换成中性灰白那张再乘,
        /// 出来的就是纯正的伤情色;健康时换回按肤色染好的那张,原样显示。
        /// </summary>
        private static void SetPartTint(Part pPart, int pHp, bool pMissing)
        {
            if (pPart == null) return;
            if (!pPart.Tinted)
            {
                SetPartColor(pPart, HpColor(pHp, pMissing));
                return;
            }
            // 健康(含强化)且不缺失时显示原色;缺失必须按 IsMissing 独立显示灰色
            if (!pMissing && pHp >= 100)
            {
                pPart.FlatNow = false;
                if (!IsBlinking(pPart)) SetPartSprite(pPart, pPart.BaseSprite, pPart.BaseHeadSprite);
                SetPartColor(pPart, Color.white);
                return;
            }
            EnsureFlatSprites(pPart);
            pPart.FlatNow = pPart.FlatSprite != null;
            if (!IsBlinking(pPart))
            {
                SetPartSprite(pPart, pPart.FlatSprite != null ? pPart.FlatSprite : pPart.BaseSprite,
                    pPart.FlatHeadSprite != null ? pPart.FlatHeadSprite : pPart.BaseHeadSprite);
            }
            SetPartColor(pPart, HpColor(pHp, pMissing));
        }

        // 正在眨眼的那一层不要动贴图,否则会把闭眼图顶掉;颜色照常更新,睁眼时 ApplyBlink 会按
        // FlatNow 换回正确的那一张
        private static bool IsBlinking(Part pPart)
        {
            return _blinkClosed && pPart != null && pPart.ClosedSprite != null;
        }

        // 中性灰白贴图按需生成:大多数部位一辈子不受伤,没必要每个单位都多烘一套
        private static void EnsureFlatSprites(Part pPart)
        {
            if (pPart.FlatSprite != null || !pPart.Tinted) return;
            try
            {
                // 用 SpritePath 而不是 Sprite:发型/衣服这种有备选目录的层,中性图得和当前
                // 挂上的那张同一个来源,否则受伤时会闪回目录里的第一张
                string path = "ui/body/" + pPart.SpritePath;
                BioDollSkin.Piece body = BioDollSkin.GetNeutral(path, pPart.ClothMode,
                    BakeScale(NominalDollScale));
                BioDollSkin.Piece head = BioDollSkin.GetNeutral(path, pPart.ClothMode,
                    BakeScale(NominalHeadScale(_builtFemale)));
                if (body != null) pPart.FlatSprite = body.Sprite;
                pPart.FlatHeadSprite = head != null ? head.Sprite : pPart.FlatSprite;
            }
            catch (Exception e)
            {
                Main.LogError("生物学:生成中性部位贴图失败 " + pPart.Id + " " + e);
            }
        }

        private static void SetPartSprite(Part pPart, Sprite pBody, Sprite pHead)
        {
            if (pPart.Img != null && pBody != null && pPart.Img.sprite != pBody) pPart.Img.sprite = pBody;
            if (pPart.HeadImg != null && pHead != null && pPart.HeadImg.sprite != pHead) pPart.HeadImg.sprite = pHead;
        }

        // ===== 眨眼 =====
        // 闭眼贴图的包围盒和睁眼那张不同,所以换图必须连 rect 一起换(两套都在 ApplyDollLayout 里算好了)。
        private static bool _blinkClosed;

        /// <summary> 眨眼协程调用:true=闭眼,false=睁眼 </summary>
        public static void SetBlink(bool pClosed)
        {
            if (_blinkClosed == pClosed) return;
            _blinkClosed = pClosed;
            ApplyBlink();
        }

        private static void ApplyBlink()
        {
            if (_built == null) return;
            try
            {
                for (int i = 0; i < _built.Length; i++)
                {
                    Part p = _built[i];
                    if (p.ClosedSprite == null) continue;
                    if (_blinkClosed)
                    {
                        PutSprite(p.Img, p.ClosedSprite, p.ClosedPos, p.ClosedSize);
                        PutSprite(p.HeadImg, p.ClosedHeadSprite, p.ClosedHeadPos, p.ClosedHeadSize);
                    }
                    else
                    {
                        Sprite body = p.FlatNow && p.FlatSprite != null ? p.FlatSprite : p.BaseSprite;
                        Sprite head = p.FlatNow && p.FlatHeadSprite != null ? p.FlatHeadSprite : p.BaseHeadSprite;
                        PutSprite(p.Img, body, p.OpenPos, p.OpenSize);
                        PutSprite(p.HeadImg, head, p.OpenHeadPos, p.OpenHeadSize);
                    }
                }
            }
            catch (Exception e)
            {
                Main.LogError("生物学:眨眼换图失败 " + e);
            }
        }

        private static void PutSprite(Image pImg, Sprite pSprite, Vector2 pPos, Vector2 pSize)
        {
            if (pImg == null || pSprite == null) return;
            pImg.sprite = pSprite;
            RectTransform rt = pImg.rectTransform;
            rt.sizeDelta = pSize;
            rt.anchoredPosition = pPos;
        }

    }
}
