using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;
using NeoModLoader.General;

namespace RimWorldMod
{
    /// <summary>
    /// 为单位窗口添加“生物学”健康标签页，展示器官健康、疾病、性别等信息，并支持交互式编辑。
    /// 该模组通过Harmony补丁注入到UnitWindow的OnEnable事件，动态创建并管理自定义标签。
    /// </summary>
    public static class UnitHealthTab
    {
        // 标签的标题和描述（用于本地化,显示走 bio_ui_tab_title/bio_ui_tab_desc 键）
        private const string TabName = "RimWorldHealthTab";
        // 标签内容容器的节点名。挂标签前用它判断这个窗口是不是已经挂过了(见 EnsureTabCore)
        private const string ContentName = "RimWorldHealthContent";
        private const string TabTitle = "生物学";
        private const string TabDesc = "查看该单位的器官健康状态";

        // 状态标志
        private static bool _patched;          // 是否已应用Harmony补丁
        private static bool _initialized;      // 是否已成功初始化标签

        // 选中单位标签的 icon_right(性别图标)字段、附身状态条的 _icon_sex 字段(反射拦截重绘用)
        private static FieldInfo _iconRightField;
        private static FieldInfo _iconSexField;
        private static FieldInfo _metaSexField;
        private static FieldInfo _prefabSexField;
        private static FieldInfo _statsSexField;
        private static FieldInfo _geneaSexField;

        private static UnitWindow _window;             // 当前单位窗口实例
        private static WindowMetaTab _tab;             // 自定义标签对象
        private static Transform _content;             // 标签内容容器（ScrollView的Content子对象）
        private static UnitWindow _headerCacheWindow;
        private static Transform _headerCache;
        private static Transform _headerMoreCache;
        private static Transform _headerAgeCache;
        private static StatsIcon _headerAgeIconCache;
        private static Transform _headerKillsCache;
        private static Transform _headerRenownCache;
        private static Transform _headerHealthBarCache;
        private static Transform _headerHappyCache;
        private static float _contentWidth = 520f;     // 内容区域的宽度（根据窗口动态调整）
        private const float ContainerPadding = 10f;    // 内容容器自身的左右内边距(与 VerticalLayoutGroup 设置一致)
        private const float BoxPadding = 8f;           // 器官黑框自身的左右内边距

        // 图标锁定器访问当前单位窗口的选中单位
        internal static Actor CurrentUnitWindowActor()
        {
            return _window != null ? _window.actor : null;
        }

        // 图标锁定器访问当前单位窗口的根 Transform(null 表示窗口未打开/已关闭)
        internal static Transform CurrentUnitWindowRoot()
        {
            return _window != null ? _window.transform : null;
        }

        // 常用颜色
        private static readonly Color ColorGold = new Color(1f, 0.82f, 0.45f);
        private static readonly Color ColorGray = new Color(0.72f, 0.72f, 0.72f);
        private static readonly Color ColorWhite = new Color(0.92f, 0.92f, 0.92f);
        private static readonly Color ColorGreen = new Color(0.40f, 1f, 0.40f);
        private static readonly Color ColorYellow = new Color(1f, 0.85f, 0.40f);
        private static readonly Color ColorRed = new Color(1f, 0.40f, 0.40f);

        /// <summary>
        /// 模组入口：应用Harmony补丁，在UnitWindow启用时注入标签创建逻辑。
        /// 同时补丁选中单位更新事件，用于同步性别图标。
        /// </summary>
        public static void Ensure()
        {
            if (_patched) return;
            _patched = true;
            try
            {
                Harmony harmony = new Harmony("rimworld_health_tab");
                // 补丁UnitWindow.OnEnable，在单位窗口启用时调用OnUnitWindowEnable
                harmony.Patch(
                    AccessTools.Method(typeof(UnitWindow), "OnEnable"),
                    postfix: new HarmonyMethod(AccessTools.Method(typeof(UnitHealthTab), nameof(OnUnitWindowEnable)))
                );

// 补丁PossessionUnitInfo.showForUnit:每帧重绘附身状态条的性别图标,postfix 里反射拦截 _icon_sex
                try
                {
                    Type possType = AccessTools.TypeByName("PossessionUnitInfo");
                    Main.LogInfo("生物学:[patch] PossessionUnitInfo 类型解析=" + (possType != null ? possType.FullName : "null"));
                    if (possType != null)
                    {
                        _iconSexField = AccessTools.Field(possType, "_icon_sex");
                        Main.LogInfo("生物学:[patch] PossessionUnitInfo._icon_sex 字段解析=" + (_iconSexField != null ? "成功" : "null"));
                        MethodInfo m = AccessTools.Method(possType, "showForUnit");
                        Main.LogInfo("生物学:[patch] PossessionUnitInfo.showForUnit patch 目标方法=" + (m != null ? m.DeclaringType.Name + ":" + m.Name : "null"));
                        if (m != null)
                        {
                            harmony.Patch(m,
                                postfix: new HarmonyMethod(AccessTools.Method(typeof(UnitHealthTab), nameof(OnPossessionIconRedraw)))
                            );
                        }
                    }

                    // 新:补丁SelectedUnitTab.showStatsGeneral(选中单位切换时重绘性别图标的原生方法)
                    try
                    {
                        Type tabType = AccessTools.TypeByName("SelectedUnitTab");
                        Main.LogInfo("生物学:[patch] SelectedUnitTab 类型解析=" + (tabType != null ? tabType.FullName : "null"));
                        if (tabType != null)
                        {
                            _iconRightField = AccessTools.Field(typeof(SelectedNanoBase), "icon_right");
                            Main.LogInfo("生物学:[patch] icon_right 字段解析=" + (_iconRightField != null ? "成功" : "null"));
                            MethodInfo m2 = AccessTools.Method(tabType, "showStatsGeneral");
                            Main.LogInfo("生物学:[patch] showStatsGeneral patch 目标方法=" + (m2 != null ? m2.DeclaringType.Name + ":" + m2.Name : "null"));
                            if (m2 != null)
                            {
                                harmony.Patch(m2,
                                    postfix: new HarmonyMethod(AccessTools.Method(typeof(UnitHealthTab), nameof(OnSelectedUnitTabRedraw)))
                                );
                            }
                        }
                    }
                    catch (Exception e2)
                    {
                        Main.LogError("生物学:SelectedUnitTab patch失败 " + e2);
                    }

                    // 其余所有写性别图标(IconMale/IconFemale)的原版方法统一打 postfix,判定走 GetGenderFast
                PatchSexIconWriters(harmony);

                // 器官属性联动必须挂在原版 stats 重建之后:原版 updateStats 每次都会 stats.clear() 重建,
                // 若只靠每 0.2s 的 ApplyStats 写入,下帧重建就把 health 等修正覆盖回基础值。
                try
                {
                    MethodInfo mUpd = AccessTools.Method(typeof(Actor), "updateStats");
                    Main.LogInfo("生物学:[patch] Actor.updateStats 目标方法=" + (mUpd != null ? mUpd.DeclaringType.Name + ":" + mUpd.Name : "null"));
                    if (mUpd != null)
                    {
                        harmony.Patch(mUpd,
                            postfix: new HarmonyMethod(AccessTools.Method(typeof(UnitHealthTab), nameof(OnActorStatsRecalc)))
                        );
                    }
                }
                catch (Exception e)
                {
                    Main.LogError("生物学:Actor.updateStats patch失败 " + e);
                }
                }
                catch (Exception e)
                {
                    Main.LogError("生物学:选中单位性别同步patch失败 " + e);
                }

                Main.LogInfo("生物学模组已加载:已为所有单位窗口添加健康界面。");
            }
            catch (Exception e)
            {
                Main.LogError("生物学模组加载失败: " + e);
            }
        }

        // Actor.updateStats 的 postfix:原版每帧批量重建 stats 时会把器官联动修正覆盖回基础值。
        // 这里在重建完成后立即重新应用修正(OrganStats 内检测 version 避免重复叠加)。
        private static void OnActorStatsRecalc(Actor __instance)
        {
            try
            {
                if (__instance == null || !HealthSimulator.HasAnyState) return;
                OrganStats.ApplyAfterRecalc(__instance);
            }
            catch (Exception e)
            {
                Main.LogError("生物学:重建后器官联动同步失败 " + e);
            }
        }

        // SelectedUnitTab.showStatsGeneral 的 postfix:切换选中单位/性别时强制同步性别图标
        private static void OnSelectedUnitTabRedraw(Actor pActor, MonoBehaviour __instance)
        {
            try
            {
                if (pActor == null) return;
                int gender = 0;
                try { gender = HealthSimulator.GetGenderFast(pActor); } catch { gender = 0; }
                // 双性时直接覆盖 icon_right 字段为雌雄同体图标;非双性时由原版已写♂/♀
                if (gender == 3)
                {
                    ForceIconField(_iconRightField, __instance, pActor);
                }
            }
            catch (Exception e)
            {
                Main.LogError("生物学:SelectedUnitTab性别图标同步失败 " + e);
            }
        }

        private static void PatchSexIconWriters(Harmony harmony)
        {
            // [A] SelectedMetaUnitElement.show(Actor, string):meta单位选中条 _icon_sex
            try
            {
                Type t = AccessTools.TypeByName("SelectedMetaUnitElement");
                if (t != null)
                {
                    _metaSexField = AccessTools.Field(t, "_icon_sex");
                    MethodInfo m = AccessTools.Method(t, "show");
                    Main.LogInfo("生物学:[patch] SelectedMetaUnitElement.show=" + (m != null) + " _icon_sex字段=" + (_metaSexField != null));
                    if (m != null)
                    {
                        harmony.Patch(m, postfix: new HarmonyMethod(AccessTools.Method(typeof(UnitHealthTab), nameof(OnMetaUnitSexRedraw))));
                    }
                }
            }
            catch (Exception e) { Main.LogError("生物学:[patch] SelectedMetaUnitElement 失败 " + e); }

            // [B] PrefabUnitElement.show(Actor):单位列表项 icon_sex
            try
            {
                Type t = AccessTools.TypeByName("PrefabUnitElement");
                if (t != null)
                {
                    _prefabSexField = AccessTools.Field(t, "icon_sex");
                    MethodInfo m = AccessTools.Method(t, "show");
                    Main.LogInfo("生物学:[patch] PrefabUnitElement.show=" + (m != null) + " icon_sex字段=" + (_prefabSexField != null));
                    if (m != null)
                    {
                        harmony.Patch(m, postfix: new HarmonyMethod(AccessTools.Method(typeof(UnitHealthTab), nameof(OnPrefabUnitSexRedraw))));
                    }
                }
            }
            catch (Exception e) { Main.LogError("生物学:[patch] PrefabUnitElement 失败 " + e); }

            // [C] UnitStatsElement 协程 showContent:_icon_sex 写在状态机 MoveNext 里,必须 patch 迭代器状态机
            try
            {
                Type t = AccessTools.TypeByName("UnitStatsElement");
                if (t != null)
                {
                    _statsSexField = AccessTools.Field(t, "_icon_sex");
                    MethodInfo m = AccessTools.Method(t, "showContent");
                    MethodInfo moveNext = m != null ? AccessTools.EnumeratorMoveNext(m) : null;
                    Main.LogInfo("生物学:[patch] UnitStatsElement.showContent=" + (m != null) + " MoveNext=" + (moveNext != null) + " _icon_sex字段=" + (_statsSexField != null));
                    if (moveNext != null)
                    {
                        harmony.Patch(moveNext, postfix: new HarmonyMethod(AccessTools.Method(typeof(UnitHealthTab), nameof(OnStatsElementSexRedraw))));
                    }
                }
            }
            catch (Exception e) { Main.LogError("生物学:[patch] UnitStatsElement 失败 " + e); }

            // [D] UnitGenealogyElement 协程 showContent:_sex_icon 写在状态机 MoveNext 里
            try
            {
                Type t = AccessTools.TypeByName("UnitGenealogyElement");
                if (t != null)
                {
                    _geneaSexField = AccessTools.Field(t, "_sex_icon");
                    MethodInfo m = AccessTools.Method(t, "showContent");
                    MethodInfo moveNext = m != null ? AccessTools.EnumeratorMoveNext(m) : null;
                    Main.LogInfo("生物学:[patch] UnitGenealogyElement.showContent=" + (m != null) + " MoveNext=" + (moveNext != null) + " _sex_icon字段=" + (_geneaSexField != null));
                    if (moveNext != null)
                    {
                        harmony.Patch(moveNext, postfix: new HarmonyMethod(AccessTools.Method(typeof(UnitHealthTab), nameof(OnGenealogySexRedraw))));
                    }
                }
            }
            catch (Exception e) { Main.LogError("生物学:[patch] UnitGenealogyElement 失败 " + e); }
        }

        // SelectedMetaUnitElement.show 的 postfix
        private static void OnMetaUnitSexRedraw(Actor pActor, MonoBehaviour __instance)
        {
            try
            {
                if (pActor == null) return;
                int g = 0; try { g = HealthSimulator.GetGenderFast(pActor); } catch { g = 0; }
                if (g == 3) ForceIconField(_metaSexField, __instance, pActor);
            }
            catch (Exception e) { Main.LogError("生物学:SelectedMetaUnitElement性别图标同步失败 " + e); }
        }

        // PrefabUnitElement.show 的 postfix
        private static void OnPrefabUnitSexRedraw(Actor pActor, MonoBehaviour __instance)
        {
            try
            {
                if (pActor == null) return;
                int g = 0; try { g = HealthSimulator.GetGenderFast(pActor); } catch { g = 0; }
                if (g == 3) ForceIconField(_prefabSexField, __instance, pActor);
            }
            catch (Exception e) { Main.LogError("生物学:PrefabUnitElement性别图标同步失败 " + e); }
        }

        // UnitStatsElement.showContent 协程状态机的 postfix:状态机里取不出 actor,改用 __m4(or __this)宿主组件上的字段
        private static void OnStatsElementSexRedraw(object __instance)
        {
            try
            {
                if (__instance == null) return;
                UnitStatsElement host = ExtractHost<UnitStatsElement>(__instance);
                if (host == null) return;
                Actor actor = GetHostActor(host);
                if (actor == null) return;
                int g = 0; try { g = HealthSimulator.GetGenderFast(actor); } catch { g = 0; }
                if (g == 3) ForceIconField(_statsSexField, host, actor);
            }
            catch (Exception e) { Main.LogError("生物学:UnitStatsElement性别图标同步失败 " + e); }
        }

        // UnitGenealogyElement.showContent 协程状态机的 postfix
        private static void OnGenealogySexRedraw(object __instance)
        {
            try
            {
                if (__instance == null) return;
                UnitGenealogyElement host = ExtractHost<UnitGenealogyElement>(__instance);
                if (host == null) return;
                Actor actor = GetHostActor(host);
                if (actor == null) return;
                int g = 0; try { g = HealthSimulator.GetGenderFast(actor); } catch { g = 0; }
                if (g == 3) ForceIconField(_geneaSexField, host, actor);
            }
            catch (Exception e) { Main.LogError("生物学:UnitGenealogyElement性别图标同步失败 " + e); }
        }

        // 从编译器生成的状态机里取出宿主组件(状态机字段往往名为 __this / <>4__this)
        private static T ExtractHost<T>(object pStateMachine) where T : class
        {
            if (pStateMachine == null) return null;
            foreach (var f in pStateMachine.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
            {
                object v = null;
                try { v = f.GetValue(pStateMachine); } catch { }
                if (v is T t && t != null) return t;
            }
            // 兜底:从当前 host 组合里找(若状态机本身包含宿主字段名 __this)
            return null;
        }

        // 状态机宿主 UnitElement 的 actor 字段(protected Actor actor,UnitElement基类定义)
        private static Actor GetHostActor(UnitElement pHost)
        {
            if (pHost == null) return null;
            try
            {
                var f = AccessTools.Field(typeof(UnitElement), "actor");
                if (f != null) return f.GetValue(pHost) as Actor;
            }
            catch { }
            return null;
        }

        // PossessionUnitInfo.showForUnit 的 postfix:每帧附身状态条重绘,直接拦截 _icon_sex
        private static void OnPossessionIconRedraw(Actor pActor, MonoBehaviour __instance)
        {
            try
            {
                if (pActor == null) return;
                ForceIconField(_iconSexField, __instance, pActor);
            }
            catch (Exception e)
            {
                Main.LogError("生物学:附身状态条性别图标同步失败 " + e);
            }
        }

        // 反射读取目标字段(Image)并强制改写为双性图标;非双性时不动(原版已写♂/♀)
        private static void ForceIconField(FieldInfo pField, object pInstance, Actor pActor)
        {
            if (pField == null || pInstance == null || pActor == null) return;
            int gender = 0;
            try { gender = HealthSimulator.GetGenderFast(pActor); } catch { gender = 0; }
            if (gender != 3) return;
            Image img = pField.GetValue(pInstance) as Image;
            if (img == null) return;
            Sprite hermaph = null;
            try { hermaph = SexIconSync.ResolveHermaphSprite(); } catch { }
            img.raycastTarget = false;
            if (hermaph != null)
            {
                img.enabled = true;
                img.sprite = hermaph;
                img.color = Color.white;
                img.type = Image.Type.Simple;
                img.preserveAspect = true;
            }
            else
            {
                img.enabled = true;
                img.color = new Color(0.75f, 0.40f, 1f, 1f);
                img.sprite = null;
            }
            Main.LogInfo("生物学:[图标] ForceIconField 已改写 actor=" + pActor.getName() + " 字段=" + (pField != null ? pField.Name : "?") + " 双性图标=" + (hermaph != null ? "sprite" : "紫色"));
        }

        // 器官编辑后/窗口重开时强制刷新选中面板(selected_unit)的标题性别图标
        // showStatsGeneral 只在切换选中时触发,加器官后不会重跑,必须直接改图标
        // 目标路径:tab_title_container(unit窗口下叫 tab_title_container_unit)内的 icon_left/icon_right
        internal static void ForceSelectedTabIcon()
        {
            try
            {
                if (!SelectedUnit.isSet()) return;
                Actor a = SelectedUnit.unit;
                if (a == null) return;
                SelectedUnitTab tab = FindSelectedTab();
                if (tab == null) return;
                // transform 搜索:tab_title_container_unit 下的 icon_left/icon_right(含 icon_left)
                SexIconKeeper.SyncRoot(tab.transform, a, true);
                // 字段反射兜底:直接改原版 SelectedNanoBase 的 icon_right 字段
                ForceIconField(_iconRightField, tab, a);
            }
            catch (Exception e)
            {
                Main.LogError("生物学:强制刷新选中面板性别图标失败 " + e);
            }
        }

        // 查找选中面板 SelectedUnitTab 实例。
        // FindObjectOfType 只查激活对象;器官编辑时选中栏可能 inactive,必须用 Resources.FindObjectsOfTypeAll
        private static SelectedUnitTab FindSelectedTab()
        {
            try
            {
                SelectedUnitTab active = UnityEngine.Object.FindObjectOfType<SelectedUnitTab>();
                if (active != null) return active;
            }
            catch { }
            try
            {
                SelectedUnitTab[] all = Resources.FindObjectsOfTypeAll<SelectedUnitTab>();
                if (all != null)
                {
                    foreach (SelectedUnitTab t in all)
                    {
                        if (t == null) continue;
                        if (t.gameObject != null && t.gameObject.scene.IsValid())
                        {
                            return t;
                        }
                    }
                }
            }
            catch { }
            return null;
        }

        /// <summary>
        /// 在UnitWindow启用时执行：确保健康标签存在，刷新内容，并同步性别图标。
        /// </summary>
        private static void OnUnitWindowEnable(UnitWindow __instance)
        {
            try
            {
                EnsureTab(__instance);
                if (_initialized) Rebuild();

                // 窗口重开时按当前标签同步面板宽度(仍在生物学标签则重新加宽)
                try
                {
                    bool bioTab = IsBioTab(__instance);
                    BioPanelWidth.SetExpanded(__instance, bioTab);
                    ApplyColumnSplit(__instance, bioTab && BioPanelWidth.IsExpanded());
                    ApplyBioHiddenParts(__instance, bioTab);
                    BioBodyDoll.SetVisible(__instance, bioTab);
                }
                catch (Exception e) { Main.LogError("生物学:窗口打开同步面板宽度失败 " + e); }

                // 同步窗口中的性别图标（双性人显示⚥）
                try
                {
                    if (_window != null && _window.actor != null)
                    {
                        SexIconKeeper.SyncRoot(_window.transform, _window.actor, true);
                    }
                }
                catch (Exception e)
                {
                    Main.LogError("生物学:同步单位窗口性别图标失败 " + e);
                }

                // 同步底部选中单位标题栏的性别图标(直接改 icon_right 字段)
                ForceSelectedTabIcon();
            }
            catch (Exception e)
            {
                Main.LogError("生物学:刷新界面失败 " + e);
            }
        }

        // 深度优先查找指定名字的节点(含自身)
        internal static Transform FindChildNamed(Transform pRoot, string pName)
        {
            if (pRoot == null) return null;
            if (pRoot.name == pName) return pRoot;
            for (int i = 0; i < pRoot.childCount; i++)
            {
                Transform r = FindChildNamed(pRoot.GetChild(i), pName);
                if (r != null) return r;
            }
            return null;
        }

        // 把 生命条(content_health_bar)与 幸福·法力·耐力·饥饿条(content_happiness_hunger)
        // 从主标签内容移动到 Header,插在 header_more_icons(概览) 之前、格子/年龄之下
        private static void MoveBarsToHeader(UnitWindow pWindow)
        {
            if (pWindow == null) return;
            Transform header = pWindow.transform.Find("Background/Scroll View/Viewport/Header");
            Transform content = pWindow.transform.Find("Background/Scroll View/Viewport/Content");
            if (header == null || content == null) return;

            Transform moreIcons = FindChildNamed(header, "header_more_icons");
            int insertIdx = moreIcons != null ? moreIcons.GetSiblingIndex() : header.childCount;

            foreach (string nm in new[] { "content_health_bar", "content_happiness_hunger" })
            {
                Transform el = content.Find(nm);
                if (el == null)
                {
                    continue;
                }
                if (el.parent == header)
                {
                    continue;
                }
                el.SetParent(header, false);
                el.SetSiblingIndex(insertIdx);
                insertIdx++;
                // 重触发 UnitElement 填充(生命/幸福/法力/耐力/饥饿数值):强制激活并保持激活
                el.gameObject.SetActive(true);
            }
            try
            {
                LayoutRebuilder.ForceRebuildLayoutImmediate(header as RectTransform);
            }
            catch { }
        }

        // 各窗口 Header 折叠状态(winId → 是否折叠)
        private static readonly Dictionary<int, bool> _headerFolded = new Dictionary<int, bool>();

        // 原版 Header 底部 padding(恢复用)
        private static int _origHeaderBottomPadding = -1;

        // 强制刷新 Header 中的数值条(生命/幸福/法力/耐力/饥饿):切到器官面板时,
        // 若数值条已在 Header 且仍激活,不会自动重跑 showContent 协程,需手动刷新。
        // 用 SetActive 强制切换触发 OnEnable → showContent 重新填充,再 refresh() 兜底。
        private static void RefreshBarElements(UnitWindow pWindow)
        {
            if (pWindow == null) return;
            Transform header = pWindow.transform.Find("Background/Scroll View/Viewport/Header");
            if (header == null)
            {
                return;
            }
            foreach (string nm in new[] { "content_health_bar", "content_happiness_hunger" })
            {
                Transform el = FindChildNamed(header, nm);
                if (el == null)
                {
                    continue;
                }
                // 强制激活并触发 OnEnable → showContent 协程重新填充数值,保持激活状态
                el.gameObject.SetActive(false);
                el.gameObject.SetActive(true);
                // refresh() 兜底(仅 activeInHierarchy 时生效)
                foreach (UnitElement ue in el.GetComponentsInChildren<UnitElement>(true))
                {
                    try { ue.refresh(); } catch { }
                }
            }
        }

        private static void AddHeaderFoldButton(UnitWindow pWindow, Transform pHeader)
        {
            if (pWindow == null || pHeader == null) return;
            Transform exist = FindChildNamed(pHeader, "HeaderFoldBtn");
            if (exist != null) return;

            // 加载两张图片（确保文件名正确，不带后缀）
            Sprite downSprite = SpriteTextureLoader.getSprite("ui/icons/DownInput");
            Sprite upSprite = SpriteTextureLoader.getSprite("ui/icons/UpInput");
            if (downSprite == null || upSprite == null)
            {
                Main.LogError("生物学: 无法加载折叠按钮图片 DownInput 或 UpInput");
                return;
            }

            int winId = pWindow.gameObject.GetInstanceID();
            bool folded;
            _headerFolded.TryGetValue(winId, out folded);

            // ---- 创建按钮容器 ----
            GameObject btnGo = new GameObject("HeaderFoldBtn", typeof(RectTransform), typeof(Image), typeof(Button));
            btnGo.transform.SetParent(pHeader, false);
            RectTransform brt = btnGo.GetComponent<RectTransform>();
            brt.anchorMin = new Vector2(0.5f, 0f);
            brt.anchorMax = new Vector2(0.5f, 0f);
            brt.pivot = new Vector2(0.5f, 0.5f);
            brt.anchoredPosition = new Vector2(0f, 8f);
            brt.sizeDelta = new Vector2(40f, 40f);  // 放大以容纳图标

            // 透明背景，仅用于点击
            Image bg = btnGo.GetComponent<Image>();
            bg.color = new Color(0f, 0f, 0f, 0f);
            bg.raycastTarget = true;

            LayoutElement le = btnGo.AddComponent<LayoutElement>();
            le.ignoreLayout = true;

            // ---- 箭头容器（用于切换） ----
            Transform arrow = new GameObject("FoldArrow", typeof(RectTransform)).transform;
            arrow.SetParent(btnGo.transform, false);
            RectTransform art = arrow as RectTransform;
            art.anchorMin = new Vector2(0.5f, 0.5f);
            art.anchorMax = new Vector2(0.5f, 0.5f);
            art.pivot = new Vector2(0.5f, 0.5f);
            art.anchoredPosition = Vector2.zero;
            art.sizeDelta = new Vector2(32f, 32f);  // 图标大小

            // ---- 折叠状态（DownInput） ----
            Transform lam = new GameObject("LamPair", typeof(RectTransform), typeof(Image)).transform;
            lam.SetParent(arrow, false);
            RectTransform lamRt = lam as RectTransform;
            lamRt.anchorMin = new Vector2(0.5f, 0.5f);
            lamRt.anchorMax = new Vector2(0.5f, 0.5f);
            lamRt.pivot = new Vector2(0.5f, 0.5f);
            lamRt.anchoredPosition = Vector2.zero;
            lamRt.sizeDelta = new Vector2(32f, 32f);
            Image lamImg = lam.GetComponent<Image>();
            lamImg.sprite = downSprite;
            lamImg.raycastTarget = false;
            lamImg.preserveAspect = true;

            // ---- 展开状态（UpInput） ----
            Transform vee = new GameObject("VeePair", typeof(RectTransform), typeof(Image)).transform;
            vee.SetParent(arrow, false);
            RectTransform veeRt = vee as RectTransform;
            veeRt.anchorMin = new Vector2(0.5f, 0.5f);
            veeRt.anchorMax = new Vector2(0.5f, 0.5f);
            veeRt.pivot = new Vector2(0.5f, 0.5f);
            veeRt.anchoredPosition = Vector2.zero;
            veeRt.sizeDelta = new Vector2(32f, 32f);
            Image veeImg = vee.GetComponent<Image>();
            veeImg.sprite = upSprite;
            veeImg.raycastTarget = false;
            veeImg.preserveAspect = true;

            // ---- 添加拖拽组件 ----
            LayoutPressable lp = btnGo.GetComponent<LayoutPressable>();
            if (lp != null) UnityEngine.Object.Destroy(lp);
            BioFoldDrag bfd = btnGo.AddComponent<BioFoldDrag>();
            bfd.Target = brt;
            bfd.Folded = folded;

            // 根据当前折叠状态显示对应的图标
            ApplyFoldArrow(arrow, folded, brt);

            // ---- 点击事件 ----
            Button btn = btnGo.GetComponent<Button>();
            btn.transition = Selectable.Transition.None;
            btn.targetGraphic = bg;
            btn.onClick.AddListener(() =>
            {
                bool cur;
                _headerFolded.TryGetValue(winId, out cur);
                cur = !cur;
                _headerFolded[winId] = cur;
                ApplyFold(pHeader, cur);
                ApplyFoldArrow(arrow, cur, brt);
                if (bfd != null) bfd.Folded = cur;
                try { LayoutRebuilder.ForceRebuildLayoutImmediate(pHeader as RectTransform); } catch { }
                // 折叠改变了 Header 高度 → 原版会重设内容区顶部留白,分栏时立即再压掉
                if (_splitActive) EnforceSplitTopPadding();
                // 注意:立绘尺寸固定,与 Header 折叠无关,这里不需要重摆
            });

            ApplyFold(pHeader, folded);
            btnGo.SetActive(true);
        }

        // 标签切换处理:仅生物学标签(器官面板)启用 Header 增强,其他标签恢复默认
        private static void ApplyBiologyHeader(UnitWindow pWindow, bool pBio)
        {
            if (pWindow == null) return;
            Transform header = pWindow.transform.Find("Background/Scroll View/Viewport/Header");
            Transform content = pWindow.transform.Find("Background/Scroll View/Viewport/Content");
            if (header == null || content == null) return;

            Transform btn = FindChildNamed(header, "HeaderFoldBtn");
            if (btn != null) btn.gameObject.SetActive(pBio);
            // 概览(header_more_icons)原版默认隐藏,仅生物学标签显示
            Transform more = FindChildNamed(header, "header_more_icons");
            if (more != null) more.gameObject.SetActive(pBio);

            // Header 底部留空白(padding),给折叠按钮腾位置(仅生物学标签); V下方空白适度缩小
            VerticalLayoutGroup hvl = header.GetComponent<VerticalLayoutGroup>();
            if (hvl != null)
            {
                if (_origHeaderBottomPadding < 0) _origHeaderBottomPadding = hvl.padding.bottom;
                int bottom = pBio ? 20 : _origHeaderBottomPadding;
                if (hvl.padding.bottom != bottom)
                {
                    hvl.padding = new RectOffset(hvl.padding.left, hvl.padding.right, hvl.padding.top, bottom);
                }
            }

            // 面板加宽:仅生物学标签向右扩展宽度,切走自动收缩(带动画)
            BioPanelWidth.SetExpanded(pWindow, pBio);
            // 左右分栏:加宽状态下 Header 靠左、器官内容靠右,各占一半
            ApplyColumnSplit(pWindow, pBio && BioPanelWidth.IsExpanded());
            // 隐藏原版装饰(Header 底板/符文/滚动渐变),切走恢复
            ApplyBioHiddenParts(pWindow, pBio);
            // 左下角人物立绘:仅生物学标签显示
            BioBodyDoll.SetVisible(pWindow, pBio);

            if (pBio)
            {
                MoveBarsToHeader(pWindow);
                RefreshBarElements(pWindow);
                // 隐藏与器官无关的概览项:击杀/声望
                foreach (string nm in new[] { "i_kills", "i_renown" })
                {
                    Transform t = FindChildNamed(header, nm);
                    if (t != null) t.gameObject.SetActive(false);
                }
            }
            else
            {
                MoveBarsBackToContent(pWindow);
                // 恢复其他标签的击杀/声望显示
                foreach (string nm in new[] { "i_kills", "i_renown" })
                {
                    Transform t = FindChildNamed(header, nm);
                    if (t != null) t.gameObject.SetActive(true);
                }
            }
        }
        

        // 把生命/幸福·法力·耐力·饥饿条从 Header 移回主标签内容(恢复默认位置:tab_title_container_unit 之后)
        private static void MoveBarsBackToContent(UnitWindow pWindow)
        {
            if (pWindow == null) return;
            Transform header = pWindow.transform.Find("Background/Scroll View/Viewport/Header");
            Transform content = pWindow.transform.Find("Background/Scroll View/Viewport/Content");
            if (header == null || content == null) return;

            Transform title = content.Find("tab_title_container_unit");
            int insertIdx = title != null ? title.GetSiblingIndex() + 1 : 2;

            foreach (string nm in new[] { "content_health_bar", "content_happiness_hunger" })
            {
                Transform el = FindChildNamed(header, nm);
                if (el == null) continue;
                if (el.parent == content) continue; // 已在原位
                el.SetParent(content, false);
                el.SetSiblingIndex(insertIdx);
                insertIdx++;
            }
            try
            {
                LayoutRebuilder.ForceRebuildLayoutImmediate(header as RectTransform);
                LayoutRebuilder.ForceRebuildLayoutImmediate(content as RectTransform);
            }
            catch { }
        }

        // 箭头的一条边(细长矩形,绕顶点旋转 pAngle 度; pPivotY=1 边从锚点向下(Λ), 0 边从锚点向上(V))
        private static void MakeArrowBar(Transform pParent, float pAngle, float pPivotY)
        {
            GameObject go = new GameObject("ArrowBar", typeof(RectTransform), typeof(Image));
            go.transform.SetParent(pParent, false);
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0.5f, 0.5f);
            rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.pivot = new Vector2(0.5f, pPivotY);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = new Vector2(2.5f, 10f);
            Image img = go.GetComponent<Image>();
            img.sprite = GetWhitePixelSprite();
            img.color = new Color(0.92f, 0.92f, 0.92f, 1f);
            img.raycastTarget = false;
            rt.localRotation = Quaternion.Euler(0f, 0f, pAngle);
        }

        // 箭头状态:折叠=Λ(置于Λ保存位置), 展开=V(置于V保存位置); 各自独立,只移动位置不改Header高度
        private static void ApplyFoldArrow(Transform pArrow, bool pFolded, RectTransform pBtnRt)
        {
            if (pArrow == null) return;
            if (pBtnRt != null)
            {
                Vector2 lam, vee;
                BioFoldDrag.Load(out lam, out vee);
                pBtnRt.anchoredPosition = pFolded ? lam : vee;
            }
            Transform lamT = pArrow.Find("LamPair");
            Transform veeT = pArrow.Find("VeePair");
            if (lamT != null) lamT.gameObject.SetActive(!pFolded);
            if (veeT != null) veeT.gameObject.SetActive(pFolded);
        }

        private static Sprite _whitePx;
        private static Sprite GetWhitePixelSprite()
        {
            if (_whitePx == null)
            {
                Texture2D tex = new Texture2D(1, 1);
                tex.SetPixel(0, 0, Color.white);
                tex.Apply();
                _whitePx = Sprite.Create(tex, new Rect(0, 0, 1, 1), new Vector2(0.5f, 0.5f), 100f);
            }
            return _whitePx;
        }

        // 折叠/展开:生命条/幸福条/概览 隐藏或显示
        private static void ApplyFold(Transform pHeader, bool pFolded)
        {
            foreach (string nm in new[] { "content_health_bar", "content_happiness_hunger", "header_more_icons" })
            {
                Transform t = FindChildNamed(pHeader, nm);
                if (t != null) t.gameObject.SetActive(!pFolded);
            }
        }

        /// <summary>
        /// 刷新顶部 Header 的概览数值(生命/攻击/移速/智力等)与年龄,使修改器官后的属性变化实时可见。
        /// 血条/幸福·法力·耐力·饥饿条由原版 UnitElement 协程填充。
        /// </summary>
        public static UnitWindow GetWindow()
        {
            return _window;
        }

        /// <summary> 当前是否处于生物学标签(器官面板) </summary>
        public static bool IsBioTab(UnitWindow pWindow)
        {
            if (pWindow == null || pWindow.tabs == null || pWindow.tabs.getActiveTab() == null) return false;
            try { return pWindow.tabs.getActiveTab().name == "RimWorldHealthTab"; }
            catch { return false; }
        }

        private static void ClearHeaderCache()
        {
            _headerCache = null;
            _headerMoreCache = null;
            _headerAgeCache = null;
            _headerAgeIconCache = null;
            _headerKillsCache = null;
            _headerRenownCache = null;
            _headerHealthBarCache = null;
            _headerHappyCache = null;
        }

        private static Transform GetHeaderCached()
        {
            if (_headerCacheWindow != _window)
            {
                ClearHeaderCache();
                _headerCacheWindow = _window;
            }
            if (_headerCache == null && _window != null)
            {
                _headerCache = _window.transform.Find("Background/Scroll View/Viewport/Header");
            }
            return _headerCache;
        }
        public static void RefreshHeaderValues(Actor actor)
        {
            if (_window == null || actor == null) return;
            try
            {
                Transform hdr = GetHeaderCached();
                if (hdr == null) return;

                // 是否处于生物学标签(器官面板)
                bool bio = false;
                try
                {
                    if (_window.tabs != null && _window.tabs.getActiveTab() != null)
                    {
                        bio = _window.tabs.getActiveTab().name == "RimWorldHealthTab";
                    }
                }
                catch { }

                // 生物学标签时持续隐藏与器官无关的概览项:击杀/声望(防止原版刷新恢复)
                if (bio)
                {
                    if (_headerKillsCache == null) _headerKillsCache = FindChildNamed(hdr, "i_kills");
                    if (_headerKillsCache != null) _headerKillsCache.gameObject.SetActive(false);
                    if (_headerRenownCache == null) _headerRenownCache = FindChildNamed(hdr, "i_renown");
                    if (_headerRenownCache != null) _headerRenownCache.gameObject.SetActive(false);

                    if (_headerHealthBarCache == null) _headerHealthBarCache = FindChildNamed(hdr, "content_health_bar");
                    if (_headerHealthBarCache != null && !_headerHealthBarCache.gameObject.activeSelf)
                        _headerHealthBarCache.gameObject.SetActive(true);
                    if (_headerHappyCache == null) _headerHappyCache = FindChildNamed(hdr, "content_happiness_hunger");
                    if (_headerHappyCache != null && !_headerHappyCache.gameObject.activeSelf)
                        _headerHappyCache.gameObject.SetActive(true);

                    if (_splitActive) EnforceSplitTopPadding();
                    ApplyBioHiddenParts(_window, true);
                }
                // 年龄
                Transform ageT = _headerAgeCache;
                if (ageT == null) { _headerAgeCache = FindChildNamed(hdr, "i_age"); ageT = _headerAgeCache; }
                if (ageT != null)
                {
                    StatsIcon icon = _headerAgeIconCache;
                    if (icon == null) { _headerAgeIconCache = ageT.GetComponent<StatsIcon>(); icon = _headerAgeIconCache; }
                    if (icon != null)
                    {
                        try { icon.enable_animation = false; icon.setValue(actor.getAge()); } catch { }
                    }
                }

                // 概览属性(header_more_icons 里的 i_* StatsIcon)
                Transform more = _headerMoreCache;
                if (more == null) { _headerMoreCache = FindChildNamed(hdr, "header_more_icons"); more = _headerMoreCache; }
                if (more == null) return;
                if (!more.gameObject.activeInHierarchy) return; // 概览隐藏时不刷新
                StatsIcon[] icons = more.GetComponentsInChildren<StatsIcon>(true);
                foreach (StatsIcon ic in icons)
                {
                    if (ic == null) continue;
                    string id = ic.gameObject.name;
                    float v = 0f;
                    float? max = null;
                    string ending = "";
                    bool isFloat = false;
                    bool known = true;
                    switch (id)
                    {
                        case "i_damage": v = actor.stats["damage"]; break;
                        case "i_armor": v = actor.stats["armor"]; ending = "%"; break;
                        case "i_speed": v = actor.stats["speed"]; break;
                        case "i_critical_chance": v = actor.stats["critical_chance"] * 100f; ending = "%"; break;
                        case "i_attack_speed": v = actor.stats["attack_speed"]; isFloat = true; break;
                        case "i_diplomacy": v = actor.stats["diplomacy"]; break;
                        case "i_warfare": v = actor.stats["warfare"]; break;
                        case "i_stewardship": v = actor.stats["stewardship"]; break;
                        case "i_intelligence": v = actor.stats["intelligence"]; break;
                        case "i_lifespan": v = actor.stats["lifespan"]; break;
                        case "i_level": v = actor.data.level; break;
                        case "i_experience": v = actor.data.experience; max = actor.getExpToLevelup(); break;
                        case "i_children": v = actor.current_children_count; max = actor.getMaxOffspring(); break;
                        case "i_births": v = actor.data.births; break;
                        case "i_kills":
                        case "i_renown":
                            // 与器官无关,显示/隐藏由标签切换(ApplyBiologyHeader)控制,此处不干预
                            continue;
                        default: known = false; break;
                    }
                    if (!known) continue;
                    try
                    {
                        ic.enable_animation = false;
                        ic.setValue(v, max, "", isFloat, ending, '/');
                    }
                    catch { }
                }
            }
            catch (Exception e)
            {
                Main.LogError("生物学:刷新Header数值失败 " + e);
            }
        }

        /// <summary>
        /// 核心初始化方法：在单位窗口的Tabs容器中创建“生物学”标签，设置内容容器，并绑定点击事件。
        /// </summary>
        private static void EnsureTab(UnitWindow pWindow)
        {
            if (pWindow == null || _initialized) return;
            try
            {
                EnsureTabCore(pWindow);
            }
            catch (Exception e)
            {
                Main.LogError("生物学:挂载生物学标签失败 " + e);
                // 挂到一半失败时把半成品拆掉。留着的话 _initialized 还是 false,下次开窗口
                // 会再克隆一个 —— 标签列里就会出现两个一模一样的心形图标
                if (!_initialized) DropHalfBuiltTab(pWindow);
            }
        }

        // 把没挂完的标签和它的内容容器拆掉,恢复到"一个都没有"的状态
        private static void DropHalfBuiltTab(UnitWindow pWindow)
        {
            try
            {
                Transform tabsContainer = pWindow.transform.Find("Background/Tabs");
                Transform half = tabsContainer != null ? tabsContainer.Find(TabName) : null;
                if (half != null)
                {
                    WindowMetaTab wmt = half.GetComponent<WindowMetaTab>();
                    if (wmt != null && pWindow.tabs != null) pWindow.tabs._tabs.Remove(wmt);
                    UnityEngine.Object.Destroy(half.gameObject);
                }
                Transform realContent = pWindow.transform.Find("Background/Scroll View/Viewport/Content");
                Transform halfContent = realContent != null ? realContent.Find(ContentName) : null;
                if (halfContent != null) UnityEngine.Object.Destroy(halfContent.gameObject);
            }
            catch (Exception e)
            {
                Main.LogError("生物学:清理未挂完的生物学标签失败 " + e);
            }
        }

        private static void EnsureTabCore(UnitWindow pWindow)
        {
            _window = pWindow;

            RegisterTabLocales(); // 注册本地化字符串

            Transform tabsContainer = pWindow.transform.Find("Background/Tabs");
            if (tabsContainer == null)
            {
                Main.LogError("生物学:未找到 Background/Tabs");
                return;
            }

            // 获取ScrollView的内容容器。放在克隆标签之前找:找不到就直接退出,
            // 不会留下一个已经挂进标签列、却没有内容的空标签
            Transform realContent = pWindow.transform.Find("Background/Scroll View/Viewport/Content");
            if (realContent == null)
            {
                Main.LogError("生物学:未找到 Background/Scroll View/Viewport/Content");
                return;
            }

            // 这个窗口上已经有生物学标签了。两种情况:上一次挂到一半失败了,或者模组被装了两份
            // (比如某个别的模组目录里嵌了一整份生物学的源码,NeoModLoader 会把它一起编译进去,
            //  于是 OnModLoad 跑两遍)。不管哪种,都不能再克隆一个,否则标签列里会有两个心形图标。
            Transform exist = tabsContainer.Find(TabName);
            if (exist != null)
            {
                Transform existContent = realContent.Find(ContentName);
                if (existContent != null)
                {
                    _tab = exist.GetComponent<WindowMetaTab>();
                    _content = existContent;
                    _initialized = true;
                    Main.LogInfo("生物学:窗口上已有生物学标签,直接接管,没有重复创建");
                    return;
                }
                // 有标签没内容 —— 上一次挂到一半死了,拆掉重来
                Main.LogError("生物学:发现一个没挂完的生物学标签,拆掉重新挂");
                DropHalfBuiltTab(pWindow);
            }

            // 找一个现有的标签作为克隆模板（任意一个）
            WindowMetaTab source = null;
            for (int i = 0; i < tabsContainer.childCount; i++)
            {
                source = tabsContainer.GetChild(i).GetComponent<WindowMetaTab>();
                if (source != null) break;
            }
            if (source == null)
            {
                Main.LogError("生物学:未找到可克隆的标签");
                return;
            }

            // 克隆新标签，并设置属性
            WindowMetaTab tab = UnityEngine.Object.Instantiate(source, tabsContainer);
            tab.name = TabName;
            tab.transform.SetSiblingIndex(4);
            tab.tab_action = new WindowMetaTabEvent();
            if (tab._tip_button != null)
            {
                tab._tip_button.textOnClick = "bio_ui_tab_title";
                tab._tip_button.textOnClickDescription = "bio_ui_tab_desc";
            }
            tab._worldtip_text = tab.getWorldTipText();

            // 设置标签图标
            Transform iconT = tab.transform.Find("Icon");
            if (iconT != null)
            {
                Image iconImage = iconT.GetComponent<Image>();
                if (iconImage != null) iconImage.sprite = SpriteTextureLoader.getSprite("ui/icons/iconBiology");
            }

            // 创建专用于健康标签的内容容器（带VerticalLayoutGroup自适应）
            GameObject container = new GameObject(ContentName, typeof(RectTransform), typeof(VerticalLayoutGroup), typeof(ContentSizeFitter), typeof(LayoutElement));
            container.transform.SetParent(realContent, false);
            _contentWidth = ResolveWidth(pWindow, realContent);
            RectTransform crt = container.GetComponent<RectTransform>();
            crt.anchorMin = new Vector2(0, 1);
            crt.anchorMax = new Vector2(0, 1);
            crt.pivot = new Vector2(0, 1);
            crt.anchoredPosition = Vector2.zero;
            crt.sizeDelta = new Vector2(_contentWidth, 0);
            LayoutElement cle = container.GetComponent<LayoutElement>();
            cle.minWidth = _contentWidth;
            cle.preferredWidth = _contentWidth;
            cle.flexibleWidth = 0;
            VerticalLayoutGroup vlg = container.GetComponent<VerticalLayoutGroup>();
            vlg.childControlWidth = true;
            vlg.childForceExpandWidth = true;
            vlg.childControlHeight = true;
            vlg.childForceExpandHeight = false;
            vlg.spacing = 6f;
            vlg.childAlignment = TextAnchor.UpperLeft;
            vlg.padding = new RectOffset(10, 10, 8, 8);
            ContentSizeFitter fitter = container.GetComponent<ContentSizeFitter>();
            fitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            // 关联标签与内容容器
            tab.tab_elements = new List<Transform>();
            tab.container = pWindow.tabs;
            pWindow.tabs._tabs.Insert(Mathf.Min(4, pWindow.tabs._tabs.Count), tab);
            pWindow.tabs.addTabContent(tab, container.transform);

            // 照搬原版/师徒标签机制:把 Header 的状态/特质/装备格子与年龄行注册进本标签的 tab_elements,
            // 切换到此标签时这些格子随标签一起激活显示(内容由原版协程自动填充)
            try
            {
                Transform headerT = pWindow.transform.Find("Background/Scroll View/Viewport/Header");
                if (headerT != null)
                {
                    foreach (string nm in new[] { "Status Background", "Traits Container", "Equipment Container", "Bottom" })
                    {
                        Transform el = FindChildNamed(headerT, nm);
                        if (el != null && !tab.tab_elements.Contains(el))
                        {
                            tab.tab_elements.Add(el);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Main.LogError("生物学:注册Header格子到标签失败 " + e);
            }

            pWindow.tabs.refillTabsWithContent();

            // 原版 Tabs 中有两个 space 占位项。旧代码只删第一个便停止，剩下的那个会把
            // “心智”和“地图跟随/操纵”一组标签隔开，并导致标签列溢出。全部移除后统一重排。
            try
            {
                int removedSpaces = 0;
                for (int i = tabsContainer.childCount - 1; i >= 0; i--)
                {
                    Transform c = tabsContainer.GetChild(i);
                    if (c == null || c == tab.transform || !c.name.ToLower().Contains("space")) continue;

                    WindowMetaTab st = c.GetComponent<WindowMetaTab>();
                    if (st != null) pWindow.tabs._tabs.Remove(st);
                    UnityEngine.Object.Destroy(c.gameObject);
                    removedSpaces++;
                }
                if (removedSpaces > 0)
                {
                    pWindow.tabs.refillTabsWithContent();
                    Main.LogInfo("生物学:已移除 " + removedSpaces + " 个原版标签空位占位项");
                }
            }
            catch (Exception e)
            {
                Main.LogError("生物学:移除空位占位按钮失败 " + e);
            }

            // 注册标签点击事件：显示标签并刷新内容
            tab.tab_action.AddListener((WindowMetaTab t) =>
            {
                try
                {
                    pWindow.showTab(t);
                    Rebuild();
                }
                catch (Exception e)
                {
                    Main.LogError("生物学:标签动作失败 " + e);
                }
            });

            // 注册标签切换回调:切到生物学标签应用 Header 增强(数值条/概览/折叠按钮),切走恢复默认
            try
            {
                pWindow.tabs.addTabShowCallback((WindowMetaTab shownTab) =>
                {
                    try
                    {
                        if (shownTab == null) return;
                        bool bio = shownTab.name == "RimWorldHealthTab";
                        ApplyBiologyHeader(pWindow, bio);
                        if (bio)
                        {
                            Transform hd = pWindow.transform.Find("Background/Scroll View/Viewport/Header");
                            if (hd != null) AddHeaderFoldButton(pWindow, hd);
                        }
                    }
                    catch (Exception e)
                    {
                        Main.LogError("生物学:标签切换Header处理失败 " + e);
                    }
                });
            }
            catch { }

            _tab = tab;
            _content = container.transform;
            _initialized = true;
        }

        // ===== 左右分栏(面板加宽时:Header 居左,器官内容居右) =====

        private const float SplitGap = 8f;             // 两栏基准间隙(内容区局部单位)
        private const float OrganPullLeftPx = 35f;     // 器官栏左边缘往左拉的屏幕像素
        private const float OrganRightGapPx = 12f;     // 器官黑框右边缘与内容区右边缘的留空(屏幕像素)
        private const float SplitGapMin = -14f;        // 间隙下限:允许压进 Header 矩形(底板已隐藏,右缘那片是空的)

        private static TextAnchor _origHeaderAlign;
        private static bool _origHeaderAlignSet;
        private static TextAnchor _origContentAlign;
        private static bool _origContentAlignSet;
        private static bool _origContentExpand;
        private static bool _origContentExpandSet;
        private static bool _splitActive;

        /// <summary> 当前是否处于左右分栏状态(器官内容只占右半边) </summary>
        internal static bool IsSplitColumns()
        {
            return _splitActive;
        }

        // 只替换水平对齐分量,保留原有的垂直分量(TextAnchor 按 行=Upper/Middle/Lower,列=Left/Center/Right 排列)
        private static TextAnchor WithHorizontal(TextAnchor pBase, int pHorizontal)
        {
            int row = ((int)pBase) / 3;
            return (TextAnchor)(row * 3 + Mathf.Clamp(pHorizontal, 0, 2));
        }

        /// <summary>
        /// 切换左右分栏:分栏时 Header 的各行靠左对齐,器官内容容器靠右对齐并只占约一半宽度;
        /// 取消分栏时恢复原版对齐与整宽。原始值只记录一次,保证能精确还原。
        /// </summary>
        private static void ApplyColumnSplit(UnitWindow pWindow, bool pSplit)
        {
            if (pWindow == null) return;
            try
            {
                Transform header = pWindow.transform.Find("Background/Scroll View/Viewport/Header");
                Transform content = pWindow.transform.Find("Background/Scroll View/Viewport/Content");

                LayoutGroup hlg = header != null ? header.GetComponent<LayoutGroup>() : null;
                if (hlg != null)
                {
                    if (!_origHeaderAlignSet)
                    {
                        _origHeaderAlign = hlg.childAlignment;
                        _origHeaderAlignSet = true;
                    }
                    TextAnchor want = pSplit ? WithHorizontal(_origHeaderAlign, 0) : _origHeaderAlign;
                    if (hlg.childAlignment != want) hlg.childAlignment = want;
                }

                LayoutGroup clg = content != null ? content.GetComponent<LayoutGroup>() : null;
                if (clg != null)
                {
                    if (!_origContentAlignSet)
                    {
                        _origContentAlign = clg.childAlignment;
                        _origContentAlignSet = true;
                    }
                    TextAnchor want = pSplit ? WithHorizontal(_origContentAlign, 2) : _origContentAlign;
                    if (clg.childAlignment != want) clg.childAlignment = want;

                    // 内容区默认可能强制子级撑满宽度,分栏时必须关掉,否则半宽设置无效
                    HorizontalOrVerticalLayoutGroup hv = clg as HorizontalOrVerticalLayoutGroup;
                    if (hv != null)
                    {
                        if (!_origContentExpandSet)
                        {
                            _origContentExpand = hv.childForceExpandWidth;
                            _origContentExpandSet = true;
                        }
                        bool wantExpand = pSplit ? false : _origContentExpand;
                        if (hv.childForceExpandWidth != wantExpand) hv.childForceExpandWidth = wantExpand;
                    }
                }

                if (_splitActive == pSplit) return;
                _splitActive = pSplit;
                _geometryLogged = false;
                Main.LogInfo("生物学:左右分栏 " + (pSplit ? "开启(Header居左/器官居右)" : "关闭(恢复整宽)"));
                // 先调留白(顶部压到 0、右侧留出间距),宽度计算依赖右内边距
                if (pSplit) EnforceSplitTopPadding();
                else RestoreContentTopPadding();
                // 再按新口径重排一次
                SyncContentWidth();
            }
            catch (Exception e)
            {
                Main.LogError("生物学:切换左右分栏失败 " + e);
            }
        }

        private const int SplitTopPadding = 2;             // 分栏时内容区顶部留白(内容区单位)
        private static int _gameContentTopPadding = -1;    // 原版算出的顶部留白(= Header 高度),用于还原
        private static int _origContentPadRight;           // 原版的右内边距
        private static bool _origContentPadRightSet;
        private static bool _geometryLogged;               // 分栏后只打一次几何诊断

        /// <summary>
        /// 分栏后打印一次各关键横向边界(屏幕像素)，用于核对右侧留白到底剩多少。
        /// </summary>
        private static void LogSplitGeometry()
        {
            try
            {
                if (!_splitActive || _geometryLogged || _window == null || _content == null) return;
                RectTransform ours = _content as RectTransform;
                RectTransform contentRt = _content.parent as RectTransform;
                RectTransform bgRt = _window.transform.Find("Background") as RectTransform;
                RectTransform headerRt = _window.transform.Find("Background/Scroll View/Viewport/Header") as RectTransform;
                if (ours == null || contentRt == null) return;
                _geometryLogged = true;

                RectTransform boxRt = null;
                for (int i = 0; i < ours.childCount; i++)
                {
                    if (ours.GetChild(i).name == "GroupBox") { boxRt = ours.GetChild(i) as RectTransform; break; }
                }
                Transform bar = FindChildNamed(_window.transform, "Scrollbar Vertical Mask");

                Main.LogInfo("生物学:[分栏几何] 面板右=" + EdgeX(bgRt, true)
                    + " 内容区右=" + EdgeX(contentRt, true)
                    + " Header右=" + EdgeX(headerRt, true)
                    + " 器官栏 左=" + EdgeX(ours, false) + " 右=" + EdgeX(ours, true)
                    + " 黑框 左=" + EdgeX(boxRt, false) + " 右=" + EdgeX(boxRt, true)
                    + " 滚动条左=" + EdgeX(bar as RectTransform, false));
            }
            catch (Exception e)
            {
                Main.LogError("生物学:打印分栏几何失败 " + e);
            }
        }

        // 矩形左/右边缘的世界坐标 x(屏幕像素口径)
        private static string EdgeX(RectTransform pRect, bool pRight)
        {
            if (pRect == null) return "?";
            float x = pRect.rect.xMin;
            if (pRight) x = pRect.rect.xMax;
            return Mathf.RoundToInt(pRect.TransformPoint(new Vector3(x, 0f, 0f)).x).ToString();
        }


        /// <summary>
        /// 分栏时把内容区顶部留白压掉：原版把 padding.top 设成 Header 的高度(实测 208)，好让内容
        /// 落在固定 Header 的下方；分栏后器官栏在右边、不会被 Header 压住，这段留白就只是空区。
        /// 压掉后器官文字直接顶到视口顶部，滚动范围也同步缩短(往上拉不再有空区)。
        /// 原版会反复重设这个值，所以每帧 LateUpdate 校正一次(UI 布局在 LateUpdate 之后结算，不会闪)。
        /// </summary>
        internal static void EnforceSplitTopPadding()
        {
            try
            {
                if (!_splitActive || _window == null || _content == null) return;
                HorizontalOrVerticalLayoutGroup clg = GetContentLayout();
                if (clg == null) return;

                int cur = clg.padding.top;
                if (cur != SplitTopPadding)
                {
                    _gameContentTopPadding = cur;    // 记住原版值(Header 折叠会变,取最近一次)
                    SetPaddingTop(clg, SplitTopPadding);
                    Main.LogInfo("生物学:内容区顶部留白 " + cur + " → " + SplitTopPadding);
                }

                // 右侧留白:黑框右边缘留出 OrganRightGapPx 的空(黑框自身还落在容器 ContainerPadding 内,这里把两者一起算)
                // 只影响右边缘:器官栏左边缘由 Header 右边缘 + 间隙决定,与右内边距无关
                int wantRight = OrigPadRight(clg)
                    + Mathf.RoundToInt(OrganRightGapPx / ContentScale() - ContainerPadding);
                if (clg.padding.right != wantRight)
                {
                    SetPaddingRight(clg, wantRight);
                    Main.LogInfo("生物学:内容区右内边距 " + _origContentPadRight + " → " + wantRight);
                }
            }
            catch (Exception e)
            {
                Main.LogError("生物学:压缩内容区留白失败 " + e);
            }
        }

        private static void RestoreContentTopPadding()
        {
            try
            {
                HorizontalOrVerticalLayoutGroup clg = GetContentLayout();
                if (clg != null && _gameContentTopPadding >= 0 && clg.padding.top != _gameContentTopPadding)
                {
                    SetPaddingTop(clg, _gameContentTopPadding);
                    Main.LogInfo("生物学:内容区顶部留白已还原 " + _gameContentTopPadding);
                }
                _gameContentTopPadding = -1;
                if (clg != null && _origContentPadRightSet && clg.padding.right != _origContentPadRight)
                {
                    SetPaddingRight(clg, _origContentPadRight);
                    Main.LogInfo("生物学:内容区右侧留白已还原 " + _origContentPadRight);
                }
            }
            catch (Exception e)
            {
                Main.LogError("生物学:还原内容区留白失败 " + e);
            }
        }

        private static HorizontalOrVerticalLayoutGroup GetContentLayout()
        {
            if (_content == null) return null;
            RectTransform crt = _content.parent as RectTransform;
            return crt != null ? crt.GetComponent<HorizontalOrVerticalLayoutGroup>() : null;
        }

        // 内容区的像素/局部单位换算比
        private static float ContentScale()
        {
            RectTransform crt = _content != null ? _content.parent as RectTransform : null;
            float s = crt != null ? Mathf.Abs(crt.lossyScale.x) : 1f;
            return s < 0.0001f ? 1f : s;
        }

        // 原版的右内边距(首次改动前记录一次,用于还原与叠加留白)
        private static int OrigPadRight(LayoutGroup pGroup)
        {
            if (!_origContentPadRightSet && pGroup != null)
            {
                _origContentPadRight = pGroup.padding.right;
                _origContentPadRightSet = true;
            }
            return _origContentPadRight;
        }

        private static void SetPaddingTop(LayoutGroup pGroup, int pTop)
        {
            if (pGroup == null) return;
            RectOffset p = pGroup.padding;
            pGroup.padding = new RectOffset(p.left, p.right, pTop, p.bottom);
        }

        private static void SetPaddingRight(LayoutGroup pGroup, int pRight)
        {
            if (pGroup == null) return;
            RectOffset p = pGroup.padding;
            pGroup.padding = new RectOffset(p.left, pRight, p.top, p.bottom);
        }

        // ===== 生物学标签下隐藏的原版装饰(切走时恢复) =====
        // Header 自带的不透明底板 headerBig:会压在器官栏上,且左栏各行本身有底板,用不到它
        // runes:内容区的符文装饰,宽度是原面板宽度,加宽后位置对不上
        // Scrollgradient:滚动渐变遮罩,在加宽后的空白区很显眼
        private static readonly string[] HiddenPaths = {
            "Background/Scroll View/Viewport/Content/runes_parent/runes",
            "Background/Scrollgradient"
        };
        private static readonly string[] HiddenNames = { "runes", "Scrollgradient" };

        /// <summary>
        /// 生物学标签下隐藏几处原版装饰，切到其他标签恢复。原版会自己重新激活(如滚动渐变)，
        /// 所以除标签切换外，0.2 秒巡检也会再校正一次。
        /// </summary>
        private static void ApplyBioHiddenParts(UnitWindow pWindow, bool pBio)
        {
            if (pWindow == null) return;
            try
            {
                // Header 的底板图(headerBig):只关 Image 组件,子级(头像/状态/数值条)照常显示
                Transform header = pWindow.transform.Find("Background/Scroll View/Viewport/Header");
                if (header != null)
                {
                    Image himg = header.GetComponent<Image>();
                    if (himg != null && himg.enabled == pBio) himg.enabled = !pBio;
                }
                for (int i = 0; i < HiddenPaths.Length; i++)
                {
                    // 先按确切路径找,找不到再退回按名字搜索(不同单位类型层级可能略有差异)
                    Transform t = pWindow.transform.Find(HiddenPaths[i]);
                    if (t == null) t = FindChildNamed(pWindow.transform, HiddenNames[i]);
                    if (t == null) continue;
                    if (t.gameObject.activeSelf == pBio) t.gameObject.SetActive(!pBio);
                }
            }
            catch (Exception e)
            {
                Main.LogError("生物学:切换隐藏装饰失败 " + e);
            }
        }


        /// <summary>
        /// 加宽动画期间同步内容宽度(廉价:不销毁重建,只更新布局宽度),
        /// 让容器与各行/器官黑框跟着视口一起变宽,避免动画中内容宽度滞后。
        /// </summary>
        internal static void SyncContentWidth()
        {
            if (_content == null || _window == null) return;
            try
            {
                if (!_content.gameObject.activeInHierarchy) return;
                float w = ResolveWidth(_window, _content.parent != null ? _content.parent : _content);
                if (w <= 20f || Mathf.Abs(w - _contentWidth) < 0.5f) return;
                _contentWidth = w;

                RectTransform crt = _content as RectTransform;
                if (crt == null) crt = _content.GetComponent<RectTransform>();
                if (crt != null) crt.sizeDelta = new Vector2(_contentWidth, crt.sizeDelta.y);

                LayoutElement cle = _content.GetComponent<LayoutElement>();
                if (cle != null)
                {
                    cle.minWidth = _contentWidth;
                    cle.preferredWidth = _contentWidth;
                    cle.flexibleWidth = 0;
                }
                // 直接子级(名字行/文本行/器官黑框)的布局宽度同步跟随(用容器内宽,避免溢出到容器外)
                float inner = InnerWidth();
                for (int i = 0; i < _content.childCount; i++)
                {
                    LayoutElement le = _content.GetChild(i).GetComponent<LayoutElement>();
                    if (le == null) continue;
                    le.minWidth = inner;
                    le.preferredWidth = inner;
                    le.flexibleWidth = 0;
                }
                // 宽度变了 → 器官条目按新宽度重排(黑框高度随之重算)
                RelayoutFlows();
            }
            catch (Exception e)
            {
                Main.LogError("生物学:同步内容宽度失败 " + e);
            }
        }

        /// <summary>
        /// 加宽动画结束后重排器官流式布局(每行能放的器官数量随宽度变化)。
        /// </summary>
        internal static void RefreshAfterResize()
        {
            try
            {
                if (_window == null || _content == null) return;
                if (!IsBioTab(_window)) return;
                Rebuild();
            }
            catch (Exception e)
            {
                Main.LogError("生物学:加宽后重排内容失败 " + e);
            }
        }

        /// <summary>
        /// 计算内容区域的宽度：整宽由滚动视口决定；左右分栏时取 Header 右边缘到内容区右边缘之间的空间。
        /// </summary>
        internal static float ResolveWidth(UnitWindow pWindow, Transform pContent)
        {
            float full = ResolveFullWidth(pWindow, pContent);
            if (!_splitActive) return full;
            float w = ResolveSplitWidth(pWindow, full);
            return Mathf.Clamp(w, Mathf.Min(160f, full), full);
        }

        // 分栏宽度:器官栏靠右对齐,左边缘落在 Header 右边缘 + SplitGap 处(按实际几何算,不依赖假设的边距)
        private static float ResolveSplitWidth(UnitWindow pWindow, float pFull)
        {
            try
            {
                UnitWindow win = pWindow != null ? pWindow : _window;
                if (win == null) return pFull * 0.5f - 4f;
                RectTransform hrt = win.transform.Find("Background/Scroll View/Viewport/Header") as RectTransform;
                RectTransform crt = win.transform.Find("Background/Scroll View/Viewport/Content") as RectTransform;
                if (hrt == null || crt == null) return pFull * 0.5f - 4f;
                float scale = Mathf.Abs(crt.lossyScale.x);
                if (scale < 0.0001f) return pFull * 0.5f - 4f;

                float headerRight = hrt.TransformPoint(new Vector3(hrt.rect.xMax, 0f, 0f)).x;
                float contentRight = crt.TransformPoint(new Vector3(crt.rect.xMax, 0f, 0f)).x;
                // 内容区布局组自身的右内边距也要让出来,否则算出的左边缘会偏右
                LayoutGroup clg = crt.GetComponent<LayoutGroup>();
                float padRight = clg != null ? clg.padding.right : 0f;
                // 间隙:基准值按 OrganPullLeftPx 缩小,可以为负(压进 Header 矩形的空白右缘)
                float gap = Mathf.Max(SplitGapMin, SplitGap - OrganPullLeftPx / scale);
                return (contentRight - headerRight) / scale - padRight - gap;
            }
            catch
            {
                return pFull * 0.5f - 4f;
            }
        }

        /// <summary>
        /// 内容区域的整宽，优先从父级滚动视口获取，否则使用默认值。
        /// </summary>
        private static float ResolveFullWidth(UnitWindow pWindow, Transform pContent)
        {
            if (pContent != null && pContent.parent != null)
            {
                RectTransform vrt = pContent.parent as RectTransform;
                if (vrt == null) vrt = pContent.parent.GetComponent<RectTransform>();
                if (vrt != null && vrt.rect.width > 20f) return Mathf.Max(60f, vrt.rect.width - 16f);
            }
            if (pWindow != null)
            {
                ScrollWindow sw = pWindow.GetComponentInParent<ScrollWindow>();
                if (sw != null && sw.transform_viewport != null && sw.transform_viewport.rect.width > 20f)
                {
                    return Mathf.Max(60f, sw.transform_viewport.rect.width - 16f);
                }
            }
            RectTransform crt = pContent as RectTransform;
            if (crt == null) crt = pContent != null ? pContent.GetComponent<RectTransform>() : null;
            if (crt != null && crt.rect.width > 20f) return Mathf.Max(60f, crt.rect.width - 16f);
            return 500f;
        }

        /// <summary>
        /// 强制立即重新计算布局，确保所有元素正确排列。
        /// </summary>
        private static void ForceLayout()
        {
            try
            {
                RectTransform crt = _content as RectTransform;
                if (crt == null) crt = _content != null ? _content.GetComponent<RectTransform>() : null;
                if (crt == null || !crt.gameObject.activeInHierarchy) return;
                LayoutRebuilder.ForceRebuildLayoutImmediate(crt);
                if (_content.parent != null)
                {
                    LayoutRebuilder.ForceRebuildLayoutImmediate(_content.parent as RectTransform);
                }
            }
            catch (Exception e)
            {
                Main.LogError("生物学:刷新布局失败 " + e);
            }
        }

        /// <summary>
        /// 重建整个健康标签页内容：清空容器，根据当前单位重新渲染属性区、器官列表。
        /// </summary>
        private static void Rebuild()
        {
            if (_content == null) return;

            // 更新内容宽度
            Transform widthRef = _content.parent != null ? _content.parent : _content;
            float w = ResolveWidth(_window, widthRef);
            if (w > 20f) _contentWidth = w;
            RectTransform crt = _content as RectTransform;
            if (crt == null) crt = _content.GetComponent<RectTransform>();
            if (crt != null) crt.sizeDelta = new Vector2(_contentWidth, crt.sizeDelta.y);
            LayoutElement cle = _content.GetComponent<LayoutElement>();
            if (cle != null)
            {
                cle.minWidth = _contentWidth;
                cle.preferredWidth = _contentWidth;
                cle.flexibleWidth = 0;
            }

            ClearChildren(_content); // 清空所有子对象

            Actor actor = _window != null ? _window.actor : null;
            if (actor == null)
            {
                AddRow(BioText.T("bio_ui_no_actor", "未选择单位"), 11, Color.gray);
                return;
            }

            // 动物器官未启用:动物只显示提示,不模拟器官、不显示立绘
            if (!HealthSimulator.IsOrganSupported(actor))
            {
                AddRow(BioText.T("bio_ui_animal_off",
                    "该单位是动物,器官系统未启用。\n如需查看动物器官,请在模组设置中打开「启用动物器官」。"),
                    12, ColorGray);
                BioBodyDoll.SetVisible(_window, false);
                ForceLayout();
                return;
            }

            // 天生天才 → 大脑初始就带强化(必须在 Simulate 之前,否则这一帧血量还是旧的)
            OrganEditorUI.PrimeBrainMods(actor);
            // 模拟身体器官健康状态（由HealthSimulator提供）
            BodyHealth body = HealthSimulator.Simulate(actor);
            // 同步因器官满血而应该移除的负面特质/疾病
            OrganEditorUI.SyncRestoredTraits(actor, body);
            // 大脑 ≤70% → 愚蠢;>100% → 摘掉脑震荡与愚蠢;≥150% → 天才
            OrganEditorUI.SyncBrainTraits(actor, body);
            // 关节骨 ≥150% → 巨大;≤80% → 渺小(阈值按面板显示的百分比,不是强化修正量)。
            // 只在这里调:强化/弱化那几个操作后面都会 Refresh → Rebuild 回到这儿,
            // 而这里才有 Simulate 出来的 body,能拿到真正的显示值
            OrganEditorUI.SyncBoneTrait(actor, body);
            // 左下角人物立绘:按器官健康度上色(从动物切回人形时重新显示)
            BioBodyDoll.SetVisible(_window, IsBioTab(_window));
            BioBodyDoll.Refresh(actor, body);

            RenderBody(actor, body); // 渲染器官分组列表

            ForceLayout();

            // 布局稳定后再排一次:此时 Text 能算出真实换行高度,黑框高度按实际内容向下扩充
            RelayoutFlows();
            ForceLayout();
            LogSplitGeometry();

            // 重排会触发布局重建,原版可能顺手把顶部留白改回来 → 再压一次
            if (_splitActive) EnforceSplitTopPadding();

            // 最后再次同步性别图标
            try
            {
                if (_window != null)
                {
                    SexIconKeeper.SyncRoot(_window.transform, actor, true);
                }
            }
            catch (Exception e)
            {
                Main.LogError("生物学:同步性别图标失败 " + e);
            }
        }

        /// <summary>
        /// 外部调用入口（例如器官编辑后）用于刷新界面。
        /// 调用两次以确保布局完全更新。
        /// </summary>
        public static void RefreshAfterEdit()
        {
            if (_window == null) return;
            Rebuild();
            Rebuild();
            // 器官编辑可能改变性别 → 同步选中面板与单位窗口的性别图标
            SexIconKeeper.SyncNow();
            ForceSelectedTabIcon();
            // 强制重填 Header 数值条(生命/幸福/法力/耐力/饥饿):SetActive 切换触发 OnEnable → showContent,
            // 与点击 V/Λ 折叠开关等效,否则强化器官后血量等数值不刷新。
            try { RefreshBarElements(_window); } catch (Exception e) { Main.LogError("生物学:编辑后刷新Header数值条失败 " + e); }
            try { RefreshHeaderValues(_window.actor); } catch (Exception e) { Main.LogError("生物学:编辑后刷新Header概览失败 " + e); }
        }

        /// <summary>
        /// <summary>
        /// 渲染身体器官主区域：显示单位名称、种族、性别、整体健康摘要、然后按器官分组显示。
        /// </summary>
        private static void RenderBody(Actor actor, BodyHealth body)
        {
            string species = actor.asset != null ? actor.asset.id : BioText.T("bio_ui_unknown_species", "未知种族");
            string nameLine = BioText.F("bio_ui_name_line", "{0}  <color=#B0B0B0>({1})</color>",
                actor.getName(), species);
            // 性别由性器官组合判定（HealthSimulator.GetGender）
            int gender = HealthSimulator.GetGender(actor);
            AddNameRow(nameLine, gender);

            // 整体健康百分比和疾病数量
            Color overallColor = body.HealthPercent >= 70 ? ColorGreen : (body.HealthPercent >= 40 ? ColorYellow : ColorRed);
            AddRow(BioText.F("bio_ui_overall", "整体健康 {0}%    疾病 {1} 种", body.HealthPercent, body.TotalDiseases), 11, overallColor);

            // 图例（如果有）
            if (body.Legend.Count > 0)
            {
                foreach (string line in body.Legend)
                {
                    AddRow("  " + line, 10, ColorGray);
                }
            }

            // 构建器官ID到器官健康数据的字典，便于快速查找
            Dictionary<string, OrganHealth> byId = new Dictionary<string, OrganHealth>();
            foreach (OrganHealth oh in body.Organs)
            {
                byId[oh.Def.Id] = oh;
            }

            // 根据性别决定显示哪些性器官（男/女/双性全部显示）
            bool showMale = gender != 2;
            bool showFemale = gender != 1;

            // 获取器官分组方案（动物与人类可能不同）
            List<OrganGroup> groups = OrganData.GetPlan(actor.isAnimal());
            foreach (OrganGroup g in groups)
            {
                List<OrganHealth> organs = new List<OrganHealth>();
                foreach (string oid in g.OrganIds)
                {
                    // 根据性别过滤仍存在的性器官;明确的缺失状态必须保留显示
                    OrganHealth oh;
                    if (!byId.TryGetValue(oid, out oh)) continue;
                    if (!showFemale && (oid == "uterus" || oid == "ovary" || oid == "vagina") && !oh.IsMissing) continue;
                    if (!showMale && (oid == "testicle" || oid == "prostate" || oid == "penis") && !oh.IsMissing) continue;
                    organs.Add(oh);
                }

                // 特殊逻辑：如果单位有毒牙（fang）且当前组是头部组，则用毒牙替代牙齿
                bool hasFang = byId.ContainsKey("fang");
                bool isFullHead = g.OrganIds.Contains("head") && g.OrganIds.Contains("brain");
                if (isFullHead && hasFang)
                {
                    organs.RemoveAll(o => o.Def.Id == "teeth");
                    if (!organs.Exists(o => o.Def.Id == "fang"))
                    {
                        organs.Add(byId["fang"]);
                    }
                }

                if (organs.Count == 0) continue;

                // 分组标题
                AddRow(g.LocalizedName, 13, ColorGold, FontStyle.Bold);
                // 该组器官以流式布局显示在带边框的容器中
                AddGroupBox(organs, actor);
            }
        }

        /// <summary>
        /// 创建一个带边框的容器（GroupBox），内部以流式布局排列器官条目。
        /// 每个器官条目可点击打开操作菜单，悬停显示数据详情。
        /// </summary>
        private static void AddGroupBox(List<OrganHealth> organs, Actor actor)
        {
            if (_content == null || organs == null || organs.Count == 0) return;

            // 创建GroupBox GameObject
            GameObject box = new GameObject("GroupBox", typeof(RectTransform));
            box.transform.SetParent(_content, false);
            RectTransform brt = box.GetComponent<RectTransform>();
            brt.anchorMin = new Vector2(0, 1);
            brt.anchorMax = new Vector2(1, 1);
            brt.pivot = new Vector2(0.5f, 1);
            brt.anchoredPosition = Vector2.zero;
            brt.sizeDelta = new Vector2(0, 0);

            // 添加背景图片（带边框样式）
            Image bg = box.AddComponent<Image>();
            Sprite border = SpriteTextureLoader.getSprite("ui/special/button");
            if (border != null)
            {
                bg.sprite = border;
                bg.type = Image.Type.Sliced;
            }
            bg.color = new Color(0.10f, 0.12f, 0.16f, 0.85f);
            bg.raycastTarget = true;

            // 布局元素：宽度用容器内宽(容器自身左右各有内边距),否则黑框会溢出到容器右侧之外
            LayoutElement ble = box.AddComponent<LayoutElement>();
            ble.minWidth = InnerWidth();
            ble.preferredWidth = InnerWidth();
            ble.flexibleWidth = 0;

            // 垂直布局（用于内部排列）
            VerticalLayoutGroup vlg = box.AddComponent<VerticalLayoutGroup>();
            vlg.childControlWidth = true;
            vlg.childForceExpandWidth = true;
            vlg.childControlHeight = false;
            vlg.childForceExpandHeight = false;
            vlg.padding = new RectOffset(8, 8, 5, 5);
            vlg.spacing = 0f;
            vlg.childAlignment = TextAnchor.UpperLeft;
            ContentSizeFitter fitter = box.AddComponent<ContentSizeFitter>();
            fitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            // 点击黑框空白区域可添加器官（AddOrganTrigger组件）
            AddOrganTrigger addTrigger = box.AddComponent<AddOrganTrigger>();
            addTrigger.Actor = actor;
            addTrigger.Anchor = brt;

            // 流式布局容器：器官条目水平排列，换行
            GameObject flowGo = new GameObject("Flow", typeof(RectTransform));
            flowGo.transform.SetParent(box.transform, false);
            RectTransform flowRt = flowGo.GetComponent<RectTransform>();
            flowRt.anchorMin = new Vector2(0, 1);
            flowRt.anchorMax = new Vector2(1, 1);
            flowRt.pivot = new Vector2(0, 1);
            flowRt.anchoredPosition = Vector2.zero;
            flowRt.sizeDelta = new Vector2(0, 0);

            // 流式排版组件:短条目并排、过长条目独占整行换行;宽度变化或布局稳定后可重排
            BioFlowLayout flow = box.AddComponent<BioFlowLayout>();
            flow.Flow = flowRt;

            // 遍历每个器官，创建可点击的文本标签(位置与高度由 BioFlowLayout 统一排)
            foreach (OrganHealth oh in organs)
            {
                try
                {
                    string display = FormatOrgan(oh); // 显示文本（名称、血量、疾病）
                    string tip = OrganInfo.GetTooltip(actor, oh.Def.Id); // 悬停提示

                    GameObject el = new GameObject("Org", typeof(RectTransform));
                    el.transform.SetParent(flowRt, false);
                    RectTransform ert = el.GetComponent<RectTransform>();
                    ert.anchorMin = new Vector2(0, 1);
                    ert.anchorMax = new Vector2(0, 1);
                    ert.pivot = new Vector2(0, 1);

                    Text et = el.AddComponent<Text>();
                    et.font = LocalizedTextManager.current_font;
                    et.fontSize = 10;
                    et.color = ColorWhite;
                    et.alignment = TextAnchor.MiddleLeft;
                    et.horizontalOverflow = HorizontalWrapMode.Overflow;
                    et.verticalOverflow = VerticalWrapMode.Overflow;
                    et.text = display;
                    flow.AddItem(et);

                    // 使文本可点击，添加交互组件
                    et.raycastTarget = true;
                    OrganClickTrigger click = el.AddComponent<OrganClickTrigger>();
                    click.Actor = actor;
                    click.OrganId = oh.Def.Id;
                    click.Anchor = ert;

                    if (!string.IsNullOrEmpty(tip))
                    {
                        OrganTooltip ot = el.AddComponent<OrganTooltip>();
                        ot.TipTitle = oh.Def.LocalizedName;
                        ot.TipDescription = tip;
                    }
                }
                catch (Exception e)
                {
                    Main.LogError("生物学:单个器官渲染失败 " + e);
                }
            }

            flow.Relayout(FlowWidth());
        }

        // 器官内容容器的内宽(扣掉容器自身左右内边距)
        private static float InnerWidth()
        {
            return Mathf.Max(60f, _contentWidth - ContainerPadding * 2f);
        }

        // 黑框内部的可用排版宽度(再扣掉黑框自身左右内边距)
        private static float FlowWidth()
        {
            return Mathf.Max(40f, InnerWidth() - BoxPadding * 2f);
        }

        /// <summary> 宽度变化或布局稳定后重排所有器官黑框(高度随之重算,换行不会挤出框外) </summary>
        internal static void RelayoutFlows()
        {
            if (_content == null) return;
            try
            {
                float w = FlowWidth();
                BioFlowLayout[] flows = _content.GetComponentsInChildren<BioFlowLayout>(true);
                for (int i = 0; i < flows.Length; i++)
                {
                    if (flows[i] != null) flows[i].Relayout(w);
                }
            }
            catch (Exception e)
            {
                Main.LogError("生物学:重排器官流式布局失败 " + e);
            }
        }

        /// <summary> 估算文本宽度(供流式排版组件使用) </summary>
        internal static float EstimateTextWidth(string pText, int pFontSize)
        {
            return EstimateWidth(pText, pFontSize);
        }

        /// <summary>
        /// 估算给定文本在指定字号下的宽度（用于流式布局的换行计算）。
        /// </summary>
        // 富文本标签剥离用的正则:编译一次复用,避免流式布局每项/每帧重建正则的开销
        private static readonly System.Text.RegularExpressions.Regex _tagStrip =
            new System.Text.RegularExpressions.Regex("<[^>]+>", System.Text.RegularExpressions.RegexOptions.Compiled);

        private static float EstimateWidth(string pText, int pFontSize)
        {
            if (string.IsNullOrEmpty(pText)) return 0f;
            string plain = pText.IndexOf('<') < 0 ? pText : _tagStrip.Replace(pText, "");
            float w = 0f;
            foreach (char c in plain)
            {
                // 中文字符较宽，ASCII字符较窄，使用系数估算
                w += c > 255 ? pFontSize * 1.15f : pFontSize * 0.65f;
            }
            return w;
        }

        /// <summary>
        /// 格式化器官显示字符串：包含名称、血量百分比（带颜色）、以及附带的疾病信息。
        /// </summary>
        private static string FormatOrgan(OrganHealth pOrgan)
        {
            string hp;
            if (pOrgan.IsMissing)
            {
                hp = BioText.T("bio_ui_hp_missing", "<color=#999999>缺失</color>");
            }
            else if (pOrgan.Hp <= 0)
            {
                hp = BioText.T("bio_ui_hp_failed", "<color=#FF6666>0%</color>·<color=#FF6666>衰竭</color>");
            }
            else if (pOrgan.Hp > 100)
            {
                hp = "<color=#33CCFF>" + pOrgan.Hp + "%</color>";
            }
            else if (pOrgan.Hp >= 70)
            {
                hp = "<color=#66FF66>" + pOrgan.Hp + "%</color>";
            }
            else if (pOrgan.Hp >= 40)
            {
                hp = "<color=#FFD966>" + pOrgan.Hp + "%</color>";
            }
            else
            {
                hp = "<color=#FF6666>" + pOrgan.Hp + "%</color>";
            }
            string result = BioText.F("bio_ui_organ_hp", "{0}({1})", pOrgan.Def.LocalizedName, hp);
            foreach (DiseaseHit hit in pOrgan.Diseases)
            {
                if (hit.Severity <= 0) continue;
                result += BioText.F("bio_ui_disease_link", "·<color=#FF9F80>{0}→{1}%</color>", hit.Def.Name, hit.Severity);
                if (!string.IsNullOrEmpty(hit.SourceTrait))
                {
                    result += BioText.F("bio_ui_disease_source", "·<color=#A0A0A0>由[{0}]引发</color>", hit.SourceTrait);
                }
            }
            return result;
        }

        /// <summary>
        /// 向内容容器添加一行文本（用于标题、摘要等）。
        /// 行高按实际排版结果计算：文本含换行或在当前列宽下需要折行时，行高自动增加，
        /// 不会再被截断（分栏后列宽变窄，图例/提示这类长文本尤其需要）。
        /// </summary>
        private static Text AddRow(string pText, int pSize, Color pColor, FontStyle pStyle = FontStyle.Normal)
        {
            if (_content == null) return null;
            GameObject go = new GameObject("Row", typeof(RectTransform));
            go.transform.SetParent(_content, false);
            float width = InnerWidth();
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.sizeDelta = new Vector2(width, pSize + 6);   // 先定宽,preferredHeight 才按这个宽度折行

            Text text = go.AddComponent<Text>();
            text.font = LocalizedTextManager.current_font;
            text.fontSize = pSize;
            text.color = pColor;
            text.fontStyle = pStyle;
            text.alignment = TextAnchor.UpperLeft;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Overflow;
            text.text = pText;

            float height = pSize + 6;
            try
            {
                float pref = text.preferredHeight;
                if (pref > height) height = pref + 2f;
            }
            catch { }

            LayoutElement element = go.AddComponent<LayoutElement>();
            element.preferredHeight = height;
            element.minHeight = height;
            element.minWidth = width;
            element.preferredWidth = width;
            element.flexibleWidth = 0;
            return text;
        }

        // 名字行:横向排列 姓名文本 + 性别(文字/内联图标)。
        // 注意:⚥(U+26A5)字形在游戏 CJK 字体中缺失,会渲染为空白,所以双性用图标 sprite 替代字符。
        private static void AddNameRow(string pNameLine, int pGender)
        {
            if (_content == null) return;

            GameObject go = new GameObject("NameRow", typeof(RectTransform));
            go.transform.SetParent(_content, false);
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0, 1);
            rt.anchorMax = new Vector2(1, 1);
            rt.pivot = new Vector2(0, 1);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = new Vector2(0, 19);

            HorizontalLayoutGroup hlg = go.AddComponent<HorizontalLayoutGroup>();
            hlg.padding = new RectOffset(0, 0, 0, 0);
            hlg.spacing = 6f;
            hlg.childControlWidth = false;
            hlg.childControlHeight = true;
            hlg.childForceExpandWidth = false;
            hlg.childForceExpandHeight = false;
            hlg.childAlignment = TextAnchor.MiddleLeft;

            LayoutElement rowLe = go.AddComponent<LayoutElement>();
            rowLe.preferredHeight = 19;
            rowLe.minWidth = InnerWidth();
            rowLe.preferredWidth = InnerWidth();
            rowLe.flexibleWidth = 0;

            // 姓名文本
            GameObject nameGo = new GameObject("Name", typeof(RectTransform));
            nameGo.transform.SetParent(go.transform, false);
            Text nameText = nameGo.AddComponent<Text>();
            nameText.font = LocalizedTextManager.current_font;
            nameText.fontSize = 13;
            nameText.color = Color.white;
            nameText.fontStyle = FontStyle.Bold;
            nameText.alignment = TextAnchor.MiddleLeft;
            nameText.horizontalOverflow = HorizontalWrapMode.Overflow;
            nameText.verticalOverflow = VerticalWrapMode.Truncate;
            nameText.text = pNameLine;
            LayoutElement nameLe = nameGo.AddComponent<LayoutElement>();
            nameLe.preferredHeight = 19;
            nameLe.flexibleWidth = 0;
            ContentSizeFitter nameFitter = nameGo.AddComponent<ContentSizeFitter>();
            nameFitter.horizontalFit = ContentSizeFitter.FitMode.PreferredSize;
            nameFitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            // 性别标签
            // ♂(U+2642)/♀(U+2640)/◇(U+25C7) 字形在字体中都有;⚥(U+26A5)字形缺失,双性改用图标 sprite
            string genderText = null;
            Color genderColor = Color.white;
            Sprite genderIcon = null;
            if (pGender == 1)
            {
                genderText = "♂ " + BioText.T("bio_ui_gender_male", "男");
                genderColor = new Color(0.36f, 0.69f, 1f);
            }
            else if (pGender == 2)
            {
                genderText = "♀ " + BioText.T("bio_ui_gender_female", "女");
                genderColor = new Color(1f, 0.47f, 0.67f);
            }
            else if (pGender == 3)
            {
                genderText = BioText.T("bio_ui_gender_intersex", "扶他");
                genderColor = new Color(1f, 0.41f, 0.72f);
                // ⚥ 字形缺失,改用双性图标 sprite
                try { genderIcon = SexIconSync.ResolveHermaphSprite(); } catch { }
            }
            else
            {
                genderText = "◇ " + BioText.T("bio_ui_gender_neutral", "中性");
                genderColor = new Color(0.6f, 0.6f, 0.6f);
            }

            if (genderIcon != null)
            {
                GameObject iconGo = new GameObject("GenderIcon", typeof(RectTransform), typeof(Image));
                iconGo.transform.SetParent(go.transform, false);
                RectTransform irt = iconGo.GetComponent<RectTransform>();
                irt.sizeDelta = new Vector2(18, 18);
                Image img = iconGo.GetComponent<Image>();
                img.sprite = genderIcon;
                img.color = genderColor;
                img.raycastTarget = false;
                img.preserveAspect = true;
                LayoutElement ile = iconGo.AddComponent<LayoutElement>();
                ile.preferredWidth = 18;
                ile.preferredHeight = 18;
            }

            if (!string.IsNullOrEmpty(genderText))
            {
                GameObject gGo = new GameObject("Gender", typeof(RectTransform));
                gGo.transform.SetParent(go.transform, false);
                Text gText = gGo.AddComponent<Text>();
                gText.font = LocalizedTextManager.current_font;
                gText.fontSize = 13;
                gText.color = genderColor;
                gText.fontStyle = FontStyle.Bold;
                gText.alignment = TextAnchor.MiddleLeft;
                gText.horizontalOverflow = HorizontalWrapMode.Overflow;
                gText.verticalOverflow = VerticalWrapMode.Truncate;
                gText.text = genderText;
                LayoutElement gle = gGo.AddComponent<LayoutElement>();
                gle.preferredHeight = 19;
                gle.flexibleWidth = 0;
                ContentSizeFitter gFitter = gGo.AddComponent<ContentSizeFitter>();
                gFitter.horizontalFit = ContentSizeFitter.FitMode.PreferredSize;
                gFitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            }
        }

        /// <summary>
        /// 立即销毁指定Transform的所有子对象（用于清空重建）。
        /// </summary>
        private static void ClearChildren(Transform pParent)
        {
            if (pParent == null) return;
            List<GameObject> children = new List<GameObject>();
            for (int i = 0; i < pParent.childCount; i++)
            {
                children.Add(pParent.GetChild(i).gameObject);
            }
            foreach (GameObject child in children)
            {
                if (child != null) UnityEngine.Object.DestroyImmediate(child);
            }
        }

        /// <summary>
        /// 注册标签标题和描述的本地化字符串（防止丢失）。
        /// </summary>
        private static void RegisterTabLocales()
        {
            try
            {
                if (LocalizedTextManager.instance == null || LocalizedTextManager.instance._localized_text == null) return;
                if (!LocalizedTextManager.instance._localized_text.ContainsKey("bio_ui_tab_title"))
                {
                    LocalizedTextManager.instance._localized_text["bio_ui_tab_title"] = TabTitle;
                }
                if (!LocalizedTextManager.instance._localized_text.ContainsKey("bio_ui_tab_desc"))
                {
                    LocalizedTextManager.instance._localized_text["bio_ui_tab_desc"] = TabDesc;
                }
            }
            catch (Exception e)
            {
                Main.LogError("生物学:注册本地化失败 " + e);
            }
        }
    }
}
