using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace RimWorldMod {

    /// <summary>无可用双手时统一阻止手持工具、武器和资源搬运。</summary>
    public static class HandUseGuard {
        private static bool _patched;
        private static readonly object HiddenSync = new object();
        private static readonly Dictionary<long, List<Item>> HiddenWeapons =
            new Dictionary<long, List<Item>>();

        private static readonly FieldInfo CachedRendererField =
            AccessTools.Field(typeof(Actor), "_cached_hand_renderer_asset");
        private static readonly FieldInfo CachedSpriteField =
            AccessTools.Field(typeof(Actor), "_cached_sprite_item");
        private static readonly FieldInfo AnimatedItemField =
            AccessTools.Field(typeof(Actor), "_has_animated_item");
        private static readonly FieldInfo DirtyItemField =
            AccessTools.Field(typeof(Actor), "_dirty_sprite_item");

        public static void Ensure() {
            if (_patched) return;
            _patched = true;
            Harmony harmony = new Harmony("rimworld_health_hand_use_guard");
            int ok = 0;

            ok += Patch(harmony, typeof(ActorEquipment), "setItem",
                new Type[] { typeof(Item), typeof(Actor) }, typeof(void),
                nameof(EquipmentSetItemPrefix));
            ok += Patch(harmony, typeof(ActorEquipmentSlot), "setItem",
                new Type[] { typeof(Item), typeof(Actor) }, typeof(void),
                nameof(EquipmentSlotSetItemPrefix));
            ok += Patch(harmony, typeof(Actor), "createNewWeapon",
                new Type[] { typeof(string) }, typeof(bool), nameof(CreateWeaponPrefix));
            ok += Patch(harmony, typeof(Actor), "generateDefaultSpawnWeapons",
                new Type[] { typeof(bool) }, typeof(void), nameof(VoidActorPrefix));

            ok += Patch(harmony, typeof(Actor), "checkHasRenderedItem", Type.EmptyTypes,
                typeof(bool), nameof(RenderBoolPrefix));
            ok += Patch(harmony, typeof(Actor), "getHandRendererAsset", Type.EmptyTypes,
                typeof(IHandRenderer), nameof(RendererPrefix));
            ok += Patch(harmony, typeof(Actor), "getRenderedItemSprite", Type.EmptyTypes,
                typeof(Sprite), nameof(SpritePrefix));
            ok += Patch(harmony, typeof(Actor), "isItemInHandAnimated", Type.EmptyTypes,
                typeof(bool), nameof(RenderBoolPrefix));

            Main.LogInfo("生物学:无手武器与渲染守卫已启用,成功补丁 " + ok + " 个");
        }

        private static int Patch(Harmony pHarmony, Type pType, string pName, Type[] pArgs,
            Type pReturnType, string pPrefix) {
            MethodInfo method = AccessTools.Method(pType, pName, pArgs);
            return PatchResolved(pHarmony, method, pReturnType, pPrefix,
                pType.FullName + "." + pName);
        }

        private static int PatchResolved(Harmony pHarmony, MethodInfo pMethod,
            Type pReturnType, string pPrefix, string pLabel) {
            if (pMethod == null) {
                Main.LogError("生物学:无手守卫跳过,入口不存在 " + pLabel);
                return 0;
            }
            if (pMethod.ReturnType != pReturnType) {
                Main.LogError("生物学:无手守卫跳过,返回类型不安全 " + pLabel
                    + " 实际=" + pMethod.ReturnType.FullName);
                return 0;
            }
            MethodInfo prefix = AccessTools.Method(typeof(HandUseGuard), pPrefix);
            if (prefix == null) {
                Main.LogError("生物学:无手守卫跳过,Prefix不存在 " + pPrefix);
                return 0;
            }
            try {
                pHarmony.Patch(pMethod, prefix: new HarmonyMethod(prefix));
                Main.LogInfo("生物学:无手守卫已补丁 " + pLabel);
                return 1;
            } catch (Exception e) {
                Main.LogError("生物学:无手守卫单项补丁失败 " + pLabel + " " + e);
                return 0;
            }
        }

        private static bool HasNoHands(Actor pActor) {
            try { return pActor != null && !HealthSimulator.HasUsableHandsFast(pActor); }
            catch (Exception e) {
                Main.LogError("生物学:可用手判断失败,保留原版行为 " + e);
                return false;
            }
        }

        public static bool EquipmentSetItemPrefix(Item pItem, Actor pActor) {
            if (!HasNoHands(pActor) || !IsWeapon(pItem)) return true;
            PreserveRejectedWeapon(pActor, pItem);
            return false;
        }

        public static bool EquipmentSlotSetItemPrefix(ActorEquipmentSlot __instance,
            Item pItem, Actor pActor) {
            if (__instance == null || __instance.type != EquipmentType.Weapon
                || !HasNoHands(pActor)) return true;
            PreserveRejectedWeapon(pActor, pItem);
            return false;
        }

        public static bool CreateWeaponPrefix(Actor __instance, ref bool __result) {
            if (!HasNoHands(__instance)) return true;
            SyncActor(__instance);
            __result = false;
            return false;
        }

        public static bool VoidActorPrefix(Actor __instance) {
            if (!HasNoHands(__instance)) return true;
            SyncActor(__instance);
            return false;
        }

        public static bool RenderBoolPrefix(Actor __instance, ref bool __result) {
            if (!HasNoHands(__instance)) return true;
            ClearRenderCache(__instance);
            __result = false;
            return false;
        }

        public static bool RendererPrefix(Actor __instance, ref IHandRenderer __result) {
            if (!HasNoHands(__instance)) return true;
            ClearRenderCache(__instance);
            __result = null;
            return false;
        }

        public static bool SpritePrefix(Actor __instance, ref Sprite __result) {
            if (!HasNoHands(__instance)) return true;
            ClearRenderCache(__instance);
            __result = null;
            return false;
        }

        /// <summary>仅在手部可用状态真实变化后调用。</summary>
        public static void SyncActor(Actor pActor) {
            if (pActor == null) return;
            try {
                if (HealthSimulator.HasUsableHandsFast(pActor)) {
                    RestoreHiddenWeapons(pActor);
                    ClearRenderCache(pActor);
                    return;
                }
                UnequipWeaponOnly(pActor);
                ClearRenderCache(pActor);
                try { pActor.setStatsDirty(); } catch { }
            } catch (Exception e) {
                Main.LogError("生物学:无手单位同步失败 " + e);
            }
        }

        private static void UnequipWeaponOnly(Actor pActor) {
            if (pActor.equipment == null || pActor.equipment.weapon == null
                || pActor.equipment.weapon.isEmpty()) return;
            Item weapon = pActor.equipment.weapon.getItem();
            if (weapon == null) return;
            pActor.equipment.weapon.takeAwayItem();
            PreserveRejectedWeapon(pActor, weapon);
        }

        private static bool IsWeapon(Item pItem) {
            try {
                return pItem != null && pItem.getAsset() != null
                    && pItem.getAsset().equipment_type == EquipmentType.Weapon;
            } catch { return false; }
        }

        private static void PreserveRejectedWeapon(Actor pActor, Item pItem) {
            if (pItem == null) return;
            City city = GetAliveCity(pActor);
            if (city != null) {
                try {
                    city.data.equipment.addItem(city, pItem);
                    Main.LogInfo("生物学:无手单位武器已安全归还城市 id=" + pActor.getID());
                    return;
                } catch (Exception e) {
                    Main.LogError("生物学:武器归还城市失败,改为保留隐藏 " + e);
                }
            }
            try { pItem.clearUnit(); } catch { }
            long actorId;
            try { actorId = pActor.getID(); } catch { return; }
            lock (HiddenSync) {
                List<Item> items;
                if (!HiddenWeapons.TryGetValue(actorId, out items)) {
                    items = new List<Item>();
                    HiddenWeapons[actorId] = items;
                }
                if (!items.Contains(pItem)) items.Add(pItem);
            }
        }

        private static void RestoreHiddenWeapons(Actor pActor) {
            long actorId;
            try { actorId = pActor.getID(); } catch { return; }
            List<Item> items;
            lock (HiddenSync) {
                if (!HiddenWeapons.TryGetValue(actorId, out items) || items.Count == 0) return;
                HiddenWeapons.Remove(actorId);
                items = new List<Item>(items);
            }
            City city = GetAliveCity(pActor);
            for (int i = 0; i < items.Count; i++) {
                Item item = items[i];
                if (item == null) continue;
                try {
                    if (city != null) city.data.equipment.addItem(city, item);
                    else if (pActor.equipment != null && pActor.equipment.weapon.isEmpty())
                        pActor.equipment.weapon.setItem(item, pActor);
                    else PreserveRejectedWeapon(pActor, item);
                } catch (Exception e) {
                    Main.LogError("生物学:恢复隐藏武器失败 " + e);
                    PreserveRejectedWeapon(pActor, item);
                }
            }
        }

        private static City GetAliveCity(Actor pActor) {
            try {
                if (pActor != null && pActor.hasCity() && pActor.city != null
                    && pActor.city.isAlive()) return pActor.city;
            } catch { }
            return null;
        }

        private static void ClearRenderCache(Actor pActor) {
            if (pActor == null) return;
            try { if (CachedRendererField != null) CachedRendererField.SetValue(pActor, null); } catch { }
            try { if (CachedSpriteField != null) CachedSpriteField.SetValue(pActor, null); } catch { }
            try { if (AnimatedItemField != null) AnimatedItemField.SetValue(pActor, false); } catch { }
            try { if (DirtyItemField != null) DirtyItemField.SetValue(pActor, true); } catch { }
        }
    }
}
