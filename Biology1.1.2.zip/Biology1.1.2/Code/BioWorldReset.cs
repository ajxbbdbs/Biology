using System;

namespace RimWorldMod {

    /// <summary>
    /// 世界切换清理:本模组多处用"单位 id → 数据"的静态表(已故收藏、器官状态、寿命覆盖、血缘),
    /// 这些表只存在内存里、不随存档持久化。原版换世界/读档只清游戏自己的容器,不会动这些表,
    /// 于是上一个世界的数据会残留:收藏栏冒出别的世界的死者、id 复用后器官/父母张冠李戴。
    ///
    /// MapBox.on_world_loaded 是原版每次"世界加载完成"(新建地图或读档)都会触发的回调,
    /// 在这里把所有按 id 存的静态表统一清空,让每个世界从干净状态开始。
    /// </summary>
    public static class BioWorldReset {

        private static bool _installed;

        public static void Ensure() {
            if (_installed) return;
            _installed = true;
            try {
                MapBox.on_world_loaded = (Action)Delegate.Combine(
                    MapBox.on_world_loaded, new Action(OnWorldLoaded));
                Main.LogInfo("生物学:世界切换清理已启用");
            } catch (Exception e) {
                Main.LogError("生物学:世界切换清理启用失败 " + e);
            }
        }

        private static void OnWorldLoaded() {
            try { BioResurrect.ResetForNewWorld(); } catch (Exception e) { Main.LogError("生物学:清理已故收藏失败 " + e); }
            try { HealthSimulator.ResetForNewWorld(); } catch (Exception e) { Main.LogError("生物学:清理器官状态失败 " + e); }
            try { MortalityGuard.ResetForNewWorld(); } catch (Exception e) { Main.LogError("生物学:清理寿命覆盖表失败 " + e); }
            try { FamilyTracker.ResetForNewWorld(); } catch (Exception e) { Main.LogError("生物学:清理血缘表失败 " + e); }
        }
    }
}
