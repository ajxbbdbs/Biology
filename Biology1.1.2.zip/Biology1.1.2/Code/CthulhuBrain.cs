using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace RimWorldMod
{
    public static class CthulhuBrainContent
    {
        public const string Phase1Id = "cthulhu_brain_1";
        public const string Phase2Id = "cthulhu_brain_2";
        public const string MinionId = "cthulhu_minion";
        public const string Phase2MinionId = "cthulhu_minion_2";
        public const string GoldenBrainId = "golden_brain";

        public static ActorAsset Phase1;
        public static ActorAsset Phase2;
        public static ActorAsset Minion;
        public static ActorAsset Phase2Minion;
        public static Sprite Laser;

        private static bool _initialized;
        private static bool _initializing;
        private static readonly HashSet<string> CthulhuIds = new HashSet<string>(StringComparer.Ordinal) {
            Phase1Id, Phase2Id, MinionId, Phase2MinionId
        };

        public static bool IsCthulhuAsset(ActorAsset pAsset)
        {
            if (pAsset == null || pAsset.id == null) return false;
            return CthulhuIds.Contains(pAsset.id);
        }

        public static void TryInitializeIfWorldReady()
        {
            if (_initialized || _initializing) return;
            if (World.world == null || World.world.units == null) return;
            EnsureInitialized();
        }

        public static void EnsureInitialized()
        {
            if (_initialized || _initializing) return;
            _initializing = true;
            try
            {
                Laser = SpriteTextureLoader.getSprite("actors/species/other/cthulhu_brain_2/main/laser");

                Phase1 = CreateBrain(Phase1Id, 12000f, 120f, 8f, true);
                if (Phase1 != null) Phase1.immune_to_injuries = true;
                Phase2 = CreateBrain(Phase2Id, 24000f, 220f, 14f, true);
                if (Phase2 != null) Phase2.action_death = (WorldAction)((pTarget, pTile) =>
                {
                    CthulhuBrainRuntime.StopLaserFor(pTarget as Actor);
                    CthulhuBrainRuntime.OnPhase2Death();
                    return true;
                });
                Minion = CreateMinion();
                Phase2Minion = AssetManager.actor_library.clone(Phase2MinionId, MinionId);
                if (Phase2Minion != null)
                {
                    Phase2Minion.texture_id = Phase2MinionId;
                    Phase2Minion.name_locale = "cthulhu_minion";
                    Phase2Minion.base_stats["health"] = 1000f;
                    Phase2Minion.base_stats["damage"] = 100f;
                    Phase2Minion.base_stats["speed"] = 25f;
                    Phase2Minion.base_stats["scale"] = 0.05f;
                    Phase2Minion.traits = new List<string>();
                    ConfigureFlying(Phase2Minion);
                    Phase2Minion.addTrait("shield");
                    Phase2Minion.icon = "iconCthulhuBrain";
                    try
                    {
                        MethodInfo load = AssetManager.actor_library.GetType().GetMethod("loadTexturesAndSprites",
                            BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                        if (load != null) load.Invoke(AssetManager.actor_library, new object[] { Phase2Minion });
                    }
                    catch (Exception e)
                    {
                        Main.LogError("生物学[克苏鲁之脑] 二阶段小怪贴图加载失败 " + e);
                    }
                }

                Phase1.action_death = (WorldAction)((pTarget, pTile) =>
                {
                    SpawnPhase2(pTarget, pTile);
                    return true;
                });
                // 千万不要在这里把 Phase2.action_death 置空:
                // 上面刚挂上的“二阶段死亡回调”会被这一行整个抹掉,
                // 于是主脑死亡时不会停激光、不会清召唤兽、不会清修复目标,贴图就留在画面上。
                if (Minion != null) Minion.action_death = null;

                _initialized = true;
                Main.LogInfo("生物学[克苏鲁之脑] 单位资产已注册");
            }
            catch (Exception e)
            {
                Main.LogError("生物学[克苏鲁之脑] 初始化失败 " + e);
            }
            finally
            {
                _initializing = false;
            }
        }

        private static ActorAsset CreateBrain(string pId, float pHealth, float pDamage, float pSpeed, bool pFlying)
        {
            ActorAsset a = AssetManager.actor_library.clone(pId, "tumor_monster_unit");
            ConfigureCommon(a, pId);
            a.base_stats["health"] = pHealth;
            a.base_stats["damage"] = pDamage;
            a.base_stats["speed"] = pSpeed;
            a.base_stats["attack_speed"] = 18f;
            a.base_stats["scale"] = 0.1f;
            a.animation_walk = ActorAnimationSequences.walk_0_3;
            a.animation_idle = ActorAnimationSequences.walk_0_3;
            a.animation_swim = null;
            a.actor_size = ActorSize.S17_Dragon;
            a.name_locale = "cthulhu_brain";
            if (pFlying) ConfigureFlying(a); else ConfigureGround(a);
            a.skip_fight_logic = pId == Phase1Id;
            return a;
        }

        private static ActorAsset CreateMinion()
        {
            ActorAsset a = AssetManager.actor_library.clone(MinionId, "tumor_monster_unit");
            ConfigureCommon(a, MinionId);
            a.base_stats["health"] = 300f;
            a.base_stats["damage"] = 45f;
            a.base_stats["speed"] = 22f;
            a.base_stats["attack_speed"] = 25f;
            a.base_stats["scale"] = 0.05f;
            a.animation_walk = ActorAnimationSequences.walk_0_1;
            a.animation_idle = ActorAnimationSequences.walk_0_1;
            a.animation_swim = null;
            a.actor_size = ActorSize.S10_Dog;
            a.name_locale = "cthulhu_minion";
            ConfigureGround(a);
            return a;
        }

        private static void ConfigureGround(ActorAsset pAsset)
        {
            pAsset.flying = false;
            pAsset.very_high_flyer = false;
            pAsset.update_z = false;
            pAsset.default_height = 0.3f;
            pAsset.ignore_blocks = false;
            pAsset.ignore_tile_speed_multiplier = false;
            pAsset.die_on_blocks = true;
            pAsset.move_from_block = true;
            pAsset.run_to_water_when_on_fire = true;
            pAsset.disable_jump_animation = true;
        }

        private static void ConfigureFlying(ActorAsset pAsset)
        {
            pAsset.flying = true;
            pAsset.very_high_flyer = true;
            pAsset.update_z = false;
            pAsset.default_height = 6f;
            pAsset.ignore_blocks = true;
            pAsset.ignore_tile_speed_multiplier = true;
            pAsset.die_on_blocks = false;
            pAsset.move_from_block = false;
            pAsset.run_to_water_when_on_fire = false;
            pAsset.disable_jump_animation = true;
            pAsset.addTrait("weightless");
            pAsset.addSubspeciesTrait("hovering");
        }

        private static void ConfigureCommon(ActorAsset pAsset, string pId)
        {
            pAsset.id = pId;
            pAsset.texture_id = pId;
            pAsset.special = true;
            pAsset.unit_other = true;
            pAsset.civ = false;
            pAsset.default_animal = false;
            pAsset.kingdom_id_wild = "demon";
            pAsset.kingdom_id_civilization = string.Empty;
            pAsset.architecture_id = string.Empty;
            pAsset.banner_id = string.Empty;
            pAsset.build_order_template_id = string.Empty;
            pAsset.has_advanced_textures = false;
            pAsset.has_baby_form = false;
            pAsset.render_heads_for_babies = false;
            pAsset.is_humanoid = false;
            pAsset.body_separate_part_hands = false;
            pAsset.default_weapons = null;
            pAsset.default_attack = "base_attack";
            pAsset.use_items = false;
            pAsset.take_items = false;
            pAsset.can_edit_equipment = false;
            pAsset.use_phenotypes = false;
            pAsset.need_colored_sprite = false;
            pAsset.has_skin = false;
            pAsset.shadow = false;

            pAsset.disable_jump_animation = true;
            pAsset.can_flip = true;
            pAsset.can_be_moved_by_powers = true;
            pAsset.can_be_hurt_by_powers = true;
            pAsset.can_be_killed_by_stuff = true;
            pAsset.can_attack_buildings = true;
            pAsset.can_turn_into_zombie = false;
            pAsset.can_turn_into_mush = false;
            pAsset.can_turn_into_tumor = false;
            pAsset.can_turn_into_ice_one = false;
            pAsset.can_have_subspecies = true;
            pAsset.can_evolve_into_new_species = false;
            pAsset.zombie_auto_asset = false;
            pAsset.base_stats["lifespan"] = 999999f;
            pAsset.base_stats["mass_2"] = 99999f;
            pAsset.base_stats["size"] = 4f;
            pAsset.base_stats["targets"] = 20f;
            pAsset.base_stats["range"] = 1.5f;
            pAsset.base_stats["armor"] = 20f;
            pAsset.base_stats["stamina"] = 1000f;
            pAsset.traits = new List<string>();
            pAsset.default_subspecies_traits = new List<string>();

            pAsset.icon = "iconCthulhuBrain";
            pAsset.can_be_surprised = false;
            pAsset.texture_asset = null;
            pAsset.action_death = null;
            pAsset.action_click = null;
            pAsset.action_on_load = null;
            pAsset.check_flip = (BaseSimObject pObj, WorldTile pTile) => true;
            try
            {
                MethodInfo load = AssetManager.actor_library.GetType().GetMethod("loadTexturesAndSprites",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (load != null) load.Invoke(AssetManager.actor_library, new object[] { pAsset });
                else Main.LogError("生物学[克苏鲁之脑] 找不到贴图注册方法: " + pId);
            }
            catch (Exception e)
            {
                Main.LogError("生物学[克苏鲁之脑] 注册贴图失败 " + pId + " " + e);
            }
        }

        public static void SpawnPhase2(BaseSimObject pTarget, WorldTile pTile)
        {
            try
            {
                WorldTile tile = pTile;
                Actor actor = pTarget as Actor;
                if (tile == null && actor != null) tile = actor.current_tile;
                if (tile == null) return;
                EffectsLibrary.spawn("fx_spawn", tile);
                World.world.units.spawnNewUnit(Phase2Id, tile, pSpawnSound: true, pMiracleSpawn: true, pSpawnHeight: 0f);
                Main.LogInfo("生物学[克苏鲁之脑] 一阶段死亡，二阶段已出现");
                CthulhuBrainRuntime.ResetPhase2DeathAnnounced();
                CthulhuVoice.Play(CthulhuVoice.SndPhase2, 1f);
                CthulhuVoice.ShowTip("bio_cthulhu_tip_phase2",
                    "该死的蝼蚁，你将迎接神明的真正降临！", "#FF6A00", CthulhuVoice.TipSeconds);
            }
            catch (Exception e)
            {
                Main.LogError("生物学[克苏鲁之脑] 召唤二阶段失败 " + e);
            }
        }
    }

    public static class CthulhuBrainRuntime
    {
        private class BrainState
        {
            public bool InitialMinionsSpawned;
            public float NextSummonTime;
            public float NextTargetTime;
            public float NextVoiceTime;
            public float NextTeleportTime;
            public float NextDiveTime;
            public float DiveUntil;
            public float HoverPhase;
            public HashSet<long> Minions = new HashSet<long>();
            public bool InvincibleApplied;
            public int RepairPhase = -1;
            public int LastRepairPercent = -1;
            public bool Phase2InitialMinionsSpawned;
            public float NextPhase2SummonTime;
            public HashSet<long> Phase2Minions = new HashSet<long>();
            public int Phase2DeathCount;
            public float NextLaserTime;
            public float LaserEndTime = -1f;
            public float NextLaserDamageTime;
            public Actor LaserTarget;
            public GameObject LaserObject;
            public SpriteRenderer LaserRenderer;
            // 威胁检测(每 0.4 秒刷一次,避免每帧全表扫单位)
            public float NextEnemyCheckTime;
            public bool EnemyNearby;    // 16 格内有敌人 → 小怪先打架,不修废墟
            public bool ThreatNearby;   // 30 格内有敌人 → 显示头顶血条
        }

        private static readonly Dictionary<long, BrainState> _states = new Dictionary<long, BrainState>();
        private static readonly HashSet<Actor> _activeCthulhuActors = new HashSet<Actor>();
        private static readonly object _activeCthulhuLock = new object();
        private static volatile int _activeCthulhuActorCount;
        private static readonly HashSet<long> _handledGoldenBrains = new HashSet<long>();
        private static readonly HashSet<long> _countedPhase2Deaths = new HashSet<long>();
        private static int _lastWatchdogFrame = -1;

        public static Building RepairBuilding;
        public static long RepairBuildingId;
        public static float RepairProgress;
        public static Actor CurrentPhase2Boss;
        private const float RepairPerSecondPerMinion = 0.001f;
        // 距离一律用“世界坐标直线距离”算,不用 current_tile:
        // 这些单位在起降/被推挤时 current_tile 会一帧内在废墟旁和十几格外之间来回跳,
        // 用格子距离判定会变成 飞过去→立刻又飞回去 的逐帧抖动,进度永远攒不起来。
        private const float RepairRange2 = 9f;               // 距废墟 3 格以内 → 算“在场修复”
        private const float RepairFlyBackRange2 = 9f;        // 超出 → 飞回废墟
        // 二阶段:小怪要先清掉附近的敌人才回去修废墟(参考一阶段的作战优先级)
        private const float RepairCombatRadius = 16f;
        // 头顶血条:附近有敌人就显示,没有就隐藏
        private const float BossBarShowRadius = 30f;
        private const float BossBarWidth = 3.2f;
        private const float BossBarHeight = 0.34f;
        private const int BossBarOrder = 45;      // 在激光(40)之上、修复条(50)之下
        // 二阶段召唤:开局直接20只,之后每15秒补5只,总数不超过20;每召唤一只回5%血
        private const int Phase2InitialMinionCount = 20;
        private const int Phase2MinionCap = 20;
        private const int Phase2SummonBatch = 5;
        private const float Phase2SummonInterval = 15f;
        // 每死一只二阶段小怪,主脑掉 5% 最大生命(20 只全死正好把主脑从满血扣到 0)
        private const float Phase2MinionDeathDamageRatio = 0.05f;
        // 克苏鲁单位的“活动范围”:不管是一/二阶段主脑还是召唤兽,
        // 只要离黄金之脑废墟太远就自己往回走,甩得特别远的主脑直接闪现回巢。
        // 注意:第一阶段同样适用 —— 之前只限制二阶段,阶段一在主脑和小怪照样满地跑。
        private const float LeashRange2 = 64f;               // 8 格以内不管
        private const float LeashTeleportRange2 = 625f;      // 25 格外主脑直接闪现回巢
        private static float _nextLeashLogTime;
        private static float _nextRuinScanTime;
        // 修复进度条:必须挂到游戏自己的排序层上,否则会被地形/建筑压在下面看不见。
        // "MapOverlay" 就是原版血条用的层,一定在单位和地形之上。
        private const string RepairBarSortingLayer = "MapOverlay";
        private const int RepairBarOrder = 50;
        private static bool _sortingLayersLogged;

        // 激光从“眼睛”射出。下面是眼睛在 100x100 主贴图里的像素中心(原点在左下);
        // 以后换了贴图直接调这两个数即可。
        private const float EyePixelX = 52.5f;
        private const float EyePixelY = 61.5f;
        // 激光:持续 5 秒,结束后冷却 10 秒再放(原来是 25 秒,太久)。
        private const float LaserDuration = 5f;
        private const float LaserCooldown = 10f;
        // 和修复进度条同理,必须显式指定排序层,否则被地形挡住。
        private const string LaserSortingLayer = "MapOverlay";
        private const int LaserSortingOrder = 40;
        private const float LaserWidthScale = 0.25f;   // 光柱粗细(贴图 64x128,只取中间那几条像素)
        private const float LaserRange = 60f;          // 激光伤害范围(格)
        private const float LaserDamagePerSecond = 100f;  // 每秒伤害(每 1 秒结算一次)
        // 激光贴图里"可见光柱"占贴图高度的比例(从底边往上算)。
        // 实测 laser.png(64x128):光柱只画在底部 76 像素,上面 52 像素是透明的,
        // 所以不能按贴图中心摆,否则整条光柱会顺着朝向平移出去。换贴图时改这两个数。
        private const float LaserBeamBottom = 0f;
        private const float LaserBeamTop = 0.594f;
        private static GameObject _repairBar;
        private static Transform _repairFill;
        private static Sprite _whiteSprite;


        public static void OnActorAI(Actor pActor, float pElapsed)
        {
            if (pActor == null || pActor.asset == null) return;
            if (ActiveCthulhuCount == 0
                && pActor.asset != CthulhuBrainContent.Phase1
                && pActor.asset != CthulhuBrainContent.Phase2
                && pActor.asset != CthulhuBrainContent.Minion
                && pActor.asset != CthulhuBrainContent.Phase2Minion) return;
            try
            {
                bool cthulhu = CthulhuBrainContent.IsCthulhuAsset(pActor.asset);
                if (cthulhu && !pActor.isAlive())
                {
                    OnCthulhuActorDeath(pActor);
                    return;
                }
                RunWatchdogsOnce();
                if (!cthulhu) return;
                string assetId = pActor.asset.id;
                if (assetId == CthulhuBrainContent.Phase1Id) TickPhase1(pActor, pElapsed);
                else if (assetId == CthulhuBrainContent.Phase2Id) TickPhase2(pActor, pElapsed);
                else if (assetId == CthulhuBrainContent.MinionId) TickMinion(pActor, pElapsed);
                else if (assetId == CthulhuBrainContent.Phase2MinionId) TickPhase2Minion(pActor, pElapsed);
            }
            catch (Exception e)
            {
                Main.LogError("生物学[克苏鲁之脑] AI 更新失败 " + e);
            }
        }

        private static void RunWatchdogsOnce()
        {
            if (Time.frameCount == _lastWatchdogFrame) return;
            _lastWatchdogFrame = Time.frameCount;
            Phase2Watchdog();
            RepairWatchdog();
        }
        /// <summary>
        /// 二阶段主脑死亡兜底。原版只在“挨打致死”时才会调用资产上的 action_death,
        /// 被神力删除、蜕变等路径不会调用,所以这里再兜一层,保证一定会清理。
        /// </summary>
        private static void Phase2Watchdog()
        {
            Actor boss = CurrentPhase2Boss;
            if (boss == null || boss.isAlive()) return;
            Main.LogInfo("生物学[克苏鲁之脑] 看门狗:二阶段主脑已消失,执行清理");
            OnPhase2Death();
        }

        private static float _nextRepairWatchdogTime;

        /// <summary>
        /// 修复目标 / 进度条看门狗(每 0.5 秒一次,和有没有小怪在修无关)。
        /// 以前只有"二阶段小怪跑 PrepareRepair"那条路会调 ClearRepairTarget,
        /// 所以玩家把黄金之脑废墟彻底清掉、或者换成别的建筑时,
        /// 没人去清目标,修复条就永远留在画面上。
        /// </summary>
        private static void RepairWatchdog()
        {
            if (Time.time < _nextRepairWatchdogTime) return;
            _nextRepairWatchdogTime = Time.time + 0.5f;
            // 只要还挂着修复条,而目标已经不是那座废墟了(被清掉 / 被换成别的建筑 /
            // 世界重载后建筑对象失效),就把目标和条子一起收掉。
            if (_repairBar != null && (RepairBuilding == null || !IsRepairBuildingValid()))
            {
                Main.LogInfo("生物学[克苏鲁之脑] 看门狗:修复目标已不存在，清除修复目标与进度条");
                ClearRepairTarget();
            }
            // 血条只跟着活着的那个主脑
            if (_bossBarOwner != null && (!_bossBarOwner.isAlive() || _bossBarOwner.isRekt()))
            {
                HideBossBar();
                _bossBarOwner = null;
            }
        }

        /// <summary>回收某个单位身上的激光和状态。</summary>
        private static void CleanupState(Actor pActor)
        {
            if (pActor == null) return;
            UntrackActiveCthulhu(pActor);
            BrainState st;
            if (!_states.TryGetValue(pActor.getID(), out st)) return;
            if (st.LaserObject != null) UnityEngine.Object.Destroy(st.LaserObject);
            _states.Remove(pActor.getID());
        }

        private static void TrackActiveCthulhu(Actor pActor)
        {
            if (pActor == null) return;
            lock (_activeCthulhuLock)
            {
                if (_activeCthulhuActors.Add(pActor))
                    _activeCthulhuActorCount = _activeCthulhuActors.Count;
            }
        }

        private static void UntrackActiveCthulhu(Actor pActor)
        {
            if (pActor == null) return;
            lock (_activeCthulhuLock)
            {
                if (_activeCthulhuActors.Remove(pActor))
                    _activeCthulhuActorCount = _activeCthulhuActors.Count;
            }
        }

        internal static int ActiveCthulhuCount
        {
            get { return _activeCthulhuActorCount; }
        }

        internal static Actor FindCthulhuNear(Vector2 pPos, float pRadius)
        {
            Actor found = null;
            float best = pRadius * pRadius;
            lock (_activeCthulhuLock)
            {
                foreach (Actor a in _activeCthulhuActors)
                {
                    if (a == null || !a.isAlive() || a.asset == null) continue;
                    if (!CthulhuBrainContent.IsCthulhuAsset(a.asset)) continue;
                    if (!a.asset.can_be_inspected || a.isInsideSomething()) continue;
                    if (a.current_tile == null) continue;
                    Vector2 p = a.current_position;
                    p.y += GetActorHeight(a);
                    float d = (p - pPos).sqrMagnitude;
                    if (d <= best)
                    {
                        best = d;
                        found = a;
                    }
                }
            }
            return found;
        }
        /// <summary>
        /// 克苏鲁单位死亡处理。
        /// 关键点:这些单位是飞行单位并关掉了 update_z,永远不会调用 updateFall(),
        /// 于是 position_height 一直不为 0,而原版 updateDeadAnimation 里
        /// “if (!isFalling()) updateDeadBlackAnimation()” 就会永远被跳过 ——
        /// 尸体既不淡出也不销毁,贴图就永久留在画面上。这里强制落地把它救回来。
        /// </summary>
        private static void OnCthulhuActorDeath(Actor pActor)
        {
            if (GetActorHeight(pActor) != 0f) SetActorHeight(pActor, 0f);
            if (pActor.move_jump_offset.y != 0f)
                pActor.move_jump_offset = new Vector2(pActor.move_jump_offset.x, 0f);
            bool isPhase2 = pActor.asset != null && pActor.asset.id == CthulhuBrainContent.Phase2Id;
            bool isBoss = pActor.asset != null && (isPhase2
                || pActor.asset.id == CthulhuBrainContent.Phase1Id);
            bool isPhase2Minion = pActor.asset != null && pActor.asset.id == CthulhuBrainContent.Phase2MinionId;
            CleanupState(pActor);
            if (isBoss) HideBossBar();
            if (isPhase2Minion) DamagePhase2BossFromMinionDeath(pActor);
            if (isPhase2) OnPhase2Death();
        }

        /// <summary>
        /// 二阶段小怪死亡 → 主脑掉血。不再直接调 getHit,
        /// 改为累计死亡数,由 UpdatePhase2Health 每帧按死亡数设置血量。
        /// </summary>
        private static void DamagePhase2BossFromMinionDeath(Actor pMinion)
        {
            try
            {
                long minionId = pMinion.getID();
                if (_countedPhase2Deaths.Contains(minionId)) return;
                _countedPhase2Deaths.Add(minionId);
                Actor boss = CurrentPhase2Boss;
                if (boss == null || !boss.isAlive()) return;
                BrainState st;
                if (!_states.TryGetValue(boss.getID(), out st)) return;
                st.Phase2DeathCount++;
                int maxHp = boss.getMaxHealth();
                int hp = Mathf.Clamp(maxHp - Mathf.RoundToInt(maxHp * Phase2MinionDeathDamageRatio * st.Phase2DeathCount), 0, maxHp);
                int percent = Mathf.RoundToInt((float)hp / Mathf.Max(1, maxHp) * 100f);
                Main.LogInfo("生物学[克苏鲁之脑] 二阶段召唤兽 " + pMinion.getID()
                    + " 死亡，主脑剩余 " + hp + "/" + maxHp + " (" + percent + "%)");
            }
            catch (Exception e)
            {
                Main.LogError("生物学[克苏鲁之脑] 小怪死亡扣主脑生命失败 " + e);
            }
        }


        private static BrainState GetState(Actor pActor)
        {
            TrackActiveCthulhu(pActor);
            long id = pActor.getID();
            BrainState st;
            if (!_states.TryGetValue(id, out st))
            {
                st = new BrainState();
                st.NextTargetTime = Time.time;
                st.NextSummonTime = Time.time + UnityEngine.Random.Range(3f, 6f);
                st.NextTeleportTime = Time.time + UnityEngine.Random.Range(5f, 9f);
                st.NextDiveTime = Time.time + UnityEngine.Random.Range(2f, 5f);
                st.HoverPhase = UnityEngine.Random.Range(0f, 6.28318f);
                st.NextPhase2SummonTime = Time.time + 15f;
                st.NextLaserTime = Time.time + UnityEngine.Random.Range(6f, 10f);
                _states[id] = st;
            }
            return st;
        }

        private static void TickPhase1(Actor pActor, float pElapsed)
        {
            BrainState st = GetState(pActor);
            if (!st.InitialMinionsSpawned)
            {
                st.InitialMinionsSpawned = true;
                SummonMinions(pActor, st, 10);
                st.NextSummonTime = Time.time + 25f;
                Main.LogInfo("生物学[克苏鲁之脑] 一阶段开始，首次召唤 10 只召唤兽");
            }
            if (UpdatePhase1Health(pActor, st)) return;
            if (Time.time >= st.NextSummonTime)
            {
                if (CountLinkedMinions(st) < 7)
                {
                    SummonMinions(pActor, st, 3);
                    if (UpdatePhase1Health(pActor, st)) return;
                }
                st.NextSummonTime = Time.time + 25f;
            }
            TickFlight(pActor, st);
            TickLeash(pActor);
            RefreshThreat(pActor, st);
            UpdateBossBar(pActor, st);
        }

        private static void TeleportActor(Actor pActor, WorldTile pTile)
        {
            try
            {
                MethodInfo spawnOn = typeof(Actor).GetMethod("spawnOn",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (spawnOn != null) spawnOn.Invoke(pActor, new object[] { pTile, 0f });
            }
            catch (Exception e)
            {
                Main.LogError("生物学[克苏鲁之脑] 传送方法调用失败 " + e);
            }
        }

        private static void TickPhase2(Actor pActor, float pElapsed)
        {
            BrainState st = GetState(pActor);
            CurrentPhase2Boss = pActor;
            if (UpdatePhase2Health(pActor, st)) return;
            if (!st.Phase2InitialMinionsSpawned)
            {
                st.Phase2InitialMinionsSpawned = true;
                SummonPhase2Minions(pActor, st, Phase2InitialMinionCount);
                st.NextPhase2SummonTime = Time.time + Phase2SummonInterval;
                Main.LogInfo("生物学[克苏鲁之脑] 二阶段开始，首次召唤 " + Phase2InitialMinionCount + " 只二阶段召唤兽");
            }
            if (Time.time >= st.NextPhase2SummonTime)
            {
                // 每次补 5 只,补到上限 20 为止(差几只就补几只,不超上限)
                int alive = CountPhase2Minions(st);
                int room = Phase2MinionCap - alive;
                if (room > 0) SummonPhase2Minions(pActor, st, Math.Min(Phase2SummonBatch, room));
                st.NextPhase2SummonTime = Time.time + Phase2SummonInterval;
            }
            MaintainTarget(pActor, st, 320f);
            TickFlight(pActor, st);
            TickLeash(pActor);
            TickLaser(pActor, st);
            RefreshThreat(pActor, st);
            UpdateBossBar(pActor, st);
            if (Time.time >= st.NextTeleportTime)
            {
                Actor target = FindNearestEnemy(pActor, 80f);
                if (target != null && target.current_tile != null)
                {
                    WorldTile tile = Toolbox.getRandomTileWithinDistance(target.current_tile, 8);
                    if (tile != null)
                    {
                        try
                        {
                            ActionLibrary.teleportEffect(pActor, tile);
                            pActor.cancelAllBeh();
                            TeleportActor(pActor, tile);
                            pActor.startFightingWith(target);
                        }
                        catch (Exception e)
                        {
                            Main.LogError("生物学[克苏鲁之脑] 二阶段传送失败 " + e);
                        }
                    }
                }
                st.NextTeleportTime = Time.time + UnityEngine.Random.Range(5f, 9f);
            }
        }

        private static FieldInfo _heightField;

        public static float GetActorHeight(Actor pActor)
        {
            try
            {
                if (_heightField == null)
                    _heightField = typeof(BaseSimObject).GetField("position_height",
                        BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy);
                return _heightField != null ? (float)_heightField.GetValue(pActor) : 0f;
            }
            catch
            {
                return 0f;
            }
        }

        private static void SetActorHeight(Actor pActor, float pHeight)
        {
            try
            {
                if (_heightField == null)
                    _heightField = typeof(BaseSimObject).GetField("position_height",
                        BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy);
                if (_heightField != null) _heightField.SetValue(pActor, pHeight);
            }
            catch
            {
            }
        }

        private static void TickFlight(Actor pActor, BrainState pState)
        {
            if (pActor == null || pActor.asset == null) return;
            bool isBoss = pActor.asset.id == CthulhuBrainContent.Phase1Id
                || pActor.asset.id == CthulhuBrainContent.Phase2Id;
            float baseHeight = isBoss ? 7f : 4.5f;
            float targetHeight;
            if (Time.time < pState.DiveUntil) targetHeight = 0.3f;
            else targetHeight = baseHeight + Mathf.Sin(Time.time * 1.8f + pState.HoverPhase) * (isBoss ? 1.8f : 1.1f);
            float current = GetActorHeight(pActor);
            SetActorHeight(pActor, Mathf.Lerp(current, targetHeight, 0.25f));
            if (Time.time >= pState.NextDiveTime)
            {
                Actor target = FindNearestEnemy(pActor, isBoss ? 18f : 12f);
                if (target != null)
                {
                    pState.DiveUntil = Time.time + 0.5f;
                    pState.NextDiveTime = Time.time + UnityEngine.Random.Range(isBoss ? 4f : 3f, isBoss ? 7f : 5f);
                }
            }
        }

        private static void TickMinion(Actor pActor, float pElapsed)
        {
            BrainState st = GetState(pActor);
            MaintainTarget(pActor, st, 150f);
            TickLeash(pActor);
        }

        private static void TickPhase2Minion(Actor pActor, float pElapsed)
        {
            if (PrepareRepair(pActor, pElapsed)) return;
            if (pActor.asset != null && pActor.asset.flying) pActor.setFlying(true);
            BrainState st = GetState(pActor);
            MaintainTarget(pActor, st, 180f);
            TickFlight(pActor, st);
            TickLeash(pActor);
        }

        private static MethodInfo _getHitMethod;

        private static void DamageActor(Actor pAttacker, Actor pTarget, float pDamage)
        {
            try
            {
                if (_getHitMethod == null)
                    _getHitMethod = typeof(BaseSimObject).GetMethod("getHit",
                        BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic,
                        null,
                        new[] { typeof(float), typeof(bool), typeof(AttackType), typeof(BaseSimObject), typeof(bool), typeof(bool), typeof(bool) },
                        null);
                if (_getHitMethod != null)
                    _getHitMethod.Invoke(pTarget, new object[] { pDamage, true, AttackType.Other, pAttacker, false, false, false });
            }
            catch (Exception e)
            {
                Main.LogError("生物学[克苏鲁之脑] 激光伤害调用失败 " + e);
            }
        }

        private static void DamageEnemiesInCone(Actor pAttacker, Vector3 pStart, Vector3 pDir, float pRange, float pDamage)
        {
            if (World.world == null || World.world.units == null) return;
            Vector3 normalized = pDir.sqrMagnitude < 0.0001f ? Vector3.up : pDir.normalized;
            float range2 = pRange * pRange;
            foreach (Actor other in World.world.units)
            {
                if (other == null || other == pAttacker || !other.isAlive() || other.asset == null) continue;
                if (CthulhuBrainContent.IsCthulhuAsset(other.asset)) continue;
                if (other.kingdom != null && pAttacker.kingdom != null && other.kingdom == pAttacker.kingdom) continue;
                if (other.current_tile == null) continue;
                Vector3 to = new Vector3(other.current_position.x - pStart.x, other.current_position.y - pStart.y, 0f);
                if (to.sqrMagnitude > range2) continue;
                if (to.sqrMagnitude < 0.0001f) { DamageActor(pAttacker, other, pDamage); continue; }
                float dot = Vector3.Dot(normalized, to.normalized);
                if (dot >= 0f) DamageActor(pAttacker, other, pDamage);
            }
        }

        private static void TickLaser(Actor pActor, BrainState pState)
        {
            if (pActor == null || pState == null) return;
            if (Time.time < pState.LaserEndTime)
            {
                UpdateLaser(pActor, pState);
                return;
            }
            if (pState.LaserObject != null) StopLaser(pState);
            if (Time.time < pState.NextLaserTime) return;
            if (CthulhuBrainContent.Laser == null)
            {
                pState.NextLaserTime = Time.time + 5f;
                return;
            }
            Actor target = FindNearestEnemy(pActor, 60f);
            if (target == null)
            {
                // 没目标就 2 秒后再看一次,别每帧全表扫单位。
                pState.NextLaserTime = Time.time + 2f;
                return;
            }
            pState.LaserTarget = target;
            pState.LaserEndTime = Time.time + LaserDuration;
            pState.NextLaserDamageTime = Time.time;
            pState.NextLaserTime = pState.LaserEndTime + LaserCooldown;
            GameObject go = new GameObject("CthulhuBrainLaser");
            SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = CthulhuBrainContent.Laser;
            // 和进度条一样:不设排序层的话会落在最底下的 Default 层,被地形挡掉。
            sr.sortingLayerID = SortingLayer.NameToID(LaserSortingLayer);
            sr.sortingOrder = LaserSortingOrder;
            pState.LaserObject = go;
            pState.LaserRenderer = sr;
            UpdateLaser(pActor, pState);
            Main.LogInfo("生物学[克苏鲁之脑] 二阶段激光启动(冷却 " + LaserCooldown + " 秒)");
            CthulhuVoice.Play(CthulhuVoice.SndLaser, 0.8f);
        }

        private static void UpdateLaser(Actor pActor, BrainState pState)
        {
            if (pActor == null || pState == null || pState.LaserObject == null) return;
            Actor target = pState.LaserTarget;
            if (target == null || !target.isAlive()) target = FindNearestEnemy(pActor, 60f);
            if (target == null) return;
            pState.LaserTarget = target;
            // 从眼睛射出去
            Vector3 start = GetEyeWorldPosition(pActor);
            Vector3 end = new Vector3(target.current_position.x, target.current_position.y + 0.5f, 0f);
            Vector3 dir = end - start;
            float dist = dir.magnitude;
            if (dist < 0.1f) dist = 0.1f;
            Vector3 norm = dir / dist;
            float length = Mathf.Max(dist, 15f);
            float angle = Mathf.Atan2(norm.y, norm.x) * Mathf.Rad2Deg - 90f;

            // 摆放方式:按贴图“可见光柱”的实际范围 + 精灵 pivot 反推。
            // 让可见段底端正好压在被眼睛位置,并把可见段长度缩放到 length。
            Sprite sprite = CthulhuBrainContent.Laser;
            float spriteW = 1f, spriteH = 1f, pivotFx = 0.5f, pivotFy = 0.5f;
            if (sprite != null)
            {
                spriteW = Mathf.Max(0.001f, sprite.bounds.size.x);
                spriteH = Mathf.Max(0.001f, sprite.bounds.size.y);
                if (sprite.rect.width > 0f) pivotFx = sprite.pivot.x / sprite.rect.width;
                if (sprite.rect.height > 0f) pivotFy = sprite.pivot.y / sprite.rect.height;
            }
            float beamFrac = Mathf.Max(0.05f, LaserBeamTop - LaserBeamBottom);
            float scaleY = length / (beamFrac * spriteH);
            float worldH = spriteH * scaleY;
            float worldW = spriteW * LaserWidthScale;
            Vector3 localX = new Vector3(norm.y, -norm.x, 0f);   // 精灵局部 +X 在世界中的方向
            Vector3 pos = start
                + norm * ((pivotFy - LaserBeamBottom) * worldH)
                + localX * ((pivotFx - 0.5f) * worldW);

            pState.LaserObject.transform.position = new Vector3(pos.x, pos.y, -1f);
            pState.LaserObject.transform.rotation = Quaternion.Euler(0f, 0f, angle);
            pState.LaserObject.transform.localScale = new Vector3(LaserWidthScale, scaleY, 1f);
            if (Time.time >= pState.NextLaserDamageTime)
            {
                pState.NextLaserDamageTime = Time.time + 1f;
                try { DamageEnemiesInCone(pActor, start, norm, LaserRange, LaserDamagePerSecond); }
                catch (Exception e) { Main.LogError("生物学[克苏鲁之脑] 激光伤害失败 " + e); }
            }
        }

        /// <summary>
        /// 克苏鲁单位当前帧“眼睛”的世界坐标。单位本体是 QuantumSprite 批渲染
        /// (localPosition = current_position + position_height, localScale = current_scale),
        /// 精灵以自身 pivot 对齐该点,所以用贴图内的像素位置反推偏移。
        /// </summary>
        private static Vector3 GetEyeWorldPosition(Actor pActor)
        {
            Vector3 pos = pActor.current_position;
            pos.y += GetActorHeight(pActor);
            Sprite main = null;
            try { main = pActor.calculateMainSprite(); }
            catch { }
            if (main == null) return new Vector3(pos.x, pos.y, 0f);
            float w = main.rect.width > 0f ? main.rect.width : 100f;
            float h = main.rect.height > 0f ? main.rect.height : 100f;
            float scale = pActor.current_scale.x;
            Vector2 size = main.bounds.size;      // 世界尺寸(已含 pixelsPerUnit)
            float nx = (EyePixelX - main.pivot.x) / w;
            float ny = (EyePixelY - main.pivot.y) / h;
            return new Vector3(pos.x + nx * size.x * scale, pos.y + ny * size.y * scale, 0f);
        }

        private static void StopLaser(BrainState pState)
        {
            if (pState == null) return;
            if (pState.LaserObject != null) UnityEngine.Object.Destroy(pState.LaserObject);
            pState.LaserObject = null;
            pState.LaserRenderer = null;
            pState.LaserTarget = null;
            pState.LaserEndTime = -1f;
        }

        private static void KillPhase2Minions()
        {
            try
            {
                List<Actor> toKill = new List<Actor>();
                foreach (Actor a in World.world.units)
                {
                    if (a == null || !a.isAlive() || a.asset == null) continue;
                    if (a.asset.id == CthulhuBrainContent.Phase2MinionId) toKill.Add(a);
                }
                foreach (Actor a in toKill)
                {
                    CleanupState(a);
                    try { a.dieAndDestroy(AttackType.None); } catch { }
                }
            }
            catch (Exception e)
            {
                Main.LogError("生物学[克苏鲁之脑] 清除二阶段召唤兽失败 " + e);
            }
        }

        public static void SetRepairTarget(Building pBuilding)
        {
            RepairBuilding = pBuilding;
            RepairBuildingId = pBuilding != null ? pBuilding.getID() : -1L;
            RepairProgress = 0f;
            CreateRepairBar();
            UpdateRepairBar();
            WorldTile repairTile = pBuilding != null ? pBuilding.current_tile : null;
            Main.LogInfo("生物学[克苏鲁之脑] 设置修复目标 id=" + RepairBuildingId
                + " tile=" + (repairTile != null ? (repairTile.x + "," + repairTile.y) : "<null>"));
        }

        public static void ClearRepairTarget()
        {
            if (RepairBuilding != null) Main.LogInfo("生物学[克苏鲁之脑] 清除修复目标 id=" + RepairBuildingId);
            RepairBuilding = null;
            RepairBuildingId = -1L;
            RepairProgress = 0f;
            if (_repairBar != null) UnityEngine.Object.Destroy(_repairBar);
            _repairBar = null;
            _repairFill = null;
        }

        public static void OnPhase2Death()
        {
            // 死亡回调 + 看门狗可能都会走到这里,保证只播一次音、只弹一次台词。
            if (_phase2DeathAnnounced) return;
            _phase2DeathAnnounced = true;
            Main.LogInfo("生物学[克苏鲁之脑] 二阶段死亡，清理二阶段召唤兽与修复目标");
            CthulhuVoice.Play(CthulhuVoice.SndDeath, 1f);
            CthulhuVoice.ShowTip("bio_cthulhu_tip_death",
                "这不该！我不会就此……", "#B26BFF", CthulhuVoice.TipSeconds);
            KillPhase2Minions();
            CurrentPhase2Boss = null;
            ClearRepairTarget();
            HideBossBar();
        }

        private static bool _phase2DeathAnnounced;

        public static void ResetPhase2DeathAnnounced()
        {
            _phase2DeathAnnounced = false;
            _countedPhase2Deaths.Clear();
        }

        /// <summary>二阶段已经"了结"(被修好或已播报过死亡),不再重复弹死亡台词/音效。</summary>
        public static void MarkPhase2Resolved()
        {
            _phase2DeathAnnounced = true;
        }

        private static bool IsRepairBuildingValid()
        {
            return RepairBuilding != null
                && RepairBuilding.current_tile != null
                && RepairBuilding.current_tile.building == RepairBuilding;
        }

        private static bool PrepareRepair(Actor pActor, float pElapsed)
        {
            if (pActor == null || pActor.asset == null || pActor.current_tile == null) return false;
            if (pActor.asset.id != CthulhuBrainContent.Phase2MinionId) return false;
            BrainState st = GetState(pActor);
            if (CurrentPhase2Boss == null || !CurrentPhase2Boss.isAlive())
            {
                if (st.RepairPhase != -1)
                {
                    Main.LogInfo("生物学[克苏鲁之脑] 二阶段召唤兽 " + pActor.getID() + " 退出修复：二阶段主脑不存在");
                    st.RepairPhase = -1;
                    st.LastRepairPercent = -1;
                }
                return false;
            }
            if (!IsRepairBuildingValid())
            {
                // 读档、神力拆除等情况下 startMakingRuins 补丁可能没触发过,
                // 静态目标会是空的 —— 这时自己去世界里认领一座黄金之脑废墟。
                if (RepairBuilding == null) TryAdoptGoldenBrainRuin();
                if (!IsRepairBuildingValid())
                {
                    Main.LogError("生物学[克苏鲁之脑] 修复目标已失效，清除修复目标");
                    ClearRepairTarget();
                    st.RepairPhase = -1;
                    st.LastRepairPercent = -1;
                    return false;
                }
            }
            WorldTile tile = RepairBuilding.current_tile;
            if (tile == null) return false;
            // 有敌人在附近就先打架,别去修废墟(参考一阶段的作战优先级)。
            // RefreshThreat 自带 0.4 秒节流,每帧调也没关系。
            RefreshThreat(pActor, st);
            if (st.EnemyNearby) return false;
            try
            {
                float d2 = WorldDist2(pActor, tile);
                // 纯几何判定,不写任何相位状态:
                //   离废墟近 → 就地修复(钉住位置 + 推进进度)
                //   太远     → 飞回废墟
                if (d2 > RepairFlyBackRange2)
                {
                    pActor.setFlying(true);
                    pActor.goTo(tile);
                    return true;
                }
                return DoRepair(pActor, st, pElapsed);
            }
            catch (Exception e)
            {
                Main.LogError("生物学[克苏鲁之脑] 修复行为失败 " + e);
                return false;
            }
        }

        /// <summary>
        /// 兜底认领修复目标:世界上只要还存在一座黄金之脑废墟,就把它设为修复目标。
        /// 每 5 秒最多扫一次,且仅在当前没有有效目标时调用。
        /// </summary>
        private static void TryAdoptGoldenBrainRuin()
        {
            try
            {
                if (World.world == null || World.world.buildings == null) return;
                if (Time.time < _nextRuinScanTime) return;
                _nextRuinScanTime = Time.time + 5f;
                foreach (Building b in World.world.buildings)
                {
                    if (b == null || b.current_tile == null) continue;
                    if (!b.isRuin()) continue;
                    if (CthulhuBrainPatches.GetBuildingAssetId(b) != CthulhuBrainContent.GoldenBrainId) continue;
                    SetRepairTarget(b);
                    Main.LogInfo("生物学[克苏鲁之脑] 自动接管黄金之脑废墟 id=" + b.getID());
                    return;
                }
            }
            catch (Exception e)
            {
                Main.LogError("生物学[克苏鲁之脑] 搜索黄金之脑废墟失败 " + e);
            }
        }

        /// <summary>单位与某个格子的世界坐标距离平方(不受 current_tile 抖动影响)。</summary>
        private static float WorldDist2(Actor pActor, WorldTile pTile)
        {
            if (pActor == null || pTile == null) return float.MaxValue;
            Vector3 t = pTile.posV3;
            Vector2 p = pActor.current_position;
            float dx = p.x - t.x;
            float dy = p.y - t.y;
            return dx * dx + dy * dy;
        }

        /// <summary>就地修复:钉住位置并推进全局修复进度。</summary>
        private static bool DoRepair(Actor pActor, BrainState pState, float pElapsed)
        {
            pActor.setFlying(false);
            SetActorHeight(pActor, 0f);
            pActor.stopMovement();
            pActor.cancelAllBeh();
            // 帧长封顶,避免卡帧时一帧涨一大截。
            float step = Mathf.Clamp(pElapsed, 0.01f, 0.1f);
            RepairProgress = Mathf.Clamp01(RepairProgress + RepairPerSecondPerMinion * step);
            int percent = Mathf.FloorToInt(RepairProgress * 100f);
            if (percent >= pState.LastRepairPercent + 10)
            {
                pState.LastRepairPercent = percent;
                Main.LogInfo("生物学[克苏鲁之脑] 修复进度 " + percent + "%（在场修复兽 "
                    + CountRepairingMinions() + " 只）");
            }
            UpdateRepairBar();
            if (RepairProgress >= 1f)
            {
                Main.LogInfo("生物学[克苏鲁之脑] 修复进度 100%，开始重建黄金之脑");
                CompleteRepair();
            }
            return true;
        }

        /// <summary>当前贴在废墟旁边修复的召唤兽数量(只用于日志)。</summary>
        private static int CountRepairingMinions()
        {
            if (!IsRepairBuildingValid()) return 0;
            WorldTile tile = RepairBuilding.current_tile;
            if (tile == null || World.world == null || World.world.units == null) return 0;
            int count = 0;
            foreach (Actor a in World.world.units)
            {
                if (a == null || !a.isAlive() || a.asset == null || a.current_tile == null) continue;
                if (a.asset.id != CthulhuBrainContent.Phase2MinionId) continue;
                if (WorldDist2(a, tile) <= RepairRange2) count++;
            }
            return count;
        }

        private static void CompleteRepair()
        {
            Building ruin = RepairBuilding;
            WorldTile tile = ruin != null ? ruin.current_tile : null;
            Actor boss = CurrentPhase2Boss;
            // 修复完成也会让主脑死亡,但这是"被修好"而不是"被打死":
            // 先把死亡播报标记掉,否则下一帧 OnCthulhuActorDeath 会再弹一次死亡台词,
            // 把"僭越者终将归于尘土"顶掉。
            MarkPhase2Resolved();
            ClearRepairTarget();
            HideBossBar();
            CurrentPhase2Boss = null;
            try
            {
                if (boss != null && boss.isAlive())
                {
                    StopLaserFor(boss);
                    boss.dieAndDestroy(AttackType.None);
                    CleanupState(boss);
                }
            }
            catch (Exception e)
            {
                Main.LogError("生物学[克苏鲁之脑] 二阶段自动死亡失败 " + e);
            }
            if (tile != null)
            {
                if (ruin != null) RemoveBuilding(ruin);
                AddGoldenBrain(tile);
                KillPhase2Minions();
                CthulhuVoice.ShowTip("bio_cthulhu_tip_repaired",
                    "僭越者终将归于尘土", "#FFD84D", CthulhuVoice.TipSeconds);
                Main.LogInfo("生物学[克苏鲁之脑] 修复完成，二阶段主脑死亡，黄金之脑已重建"
                    + " boss=" + (boss != null ? boss.getID().ToString() : "<null>")
                    + " ruinTile=" + (tile != null ? (tile.x + "," + tile.y) : "<null>"));
            }
        }

        private static void RemoveBuilding(Building pBuilding)
        {
            try
            {
                MethodInfo remove = typeof(Building).GetMethod("removeBuildingFinal",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (remove != null) remove.Invoke(pBuilding, null);
            }
            catch (Exception e)
            {
                Main.LogError("生物学[克苏鲁之脑] 清除破损黄金之脑失败 " + e);
            }
        }

        private static void AddGoldenBrain(WorldTile pTile)
        {
            try
            {
                MethodInfo add = typeof(BuildingManager).GetMethod("addBuilding",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic,
                    null,
                    new[] { typeof(string), typeof(WorldTile), typeof(bool), typeof(bool), typeof(BuildPlacingType) },
                    null);
                if (add != null)
                    add.Invoke(World.world.buildings,
                        new object[] { CthulhuBrainContent.GoldenBrainId, pTile, false, true, BuildPlacingType.New });
            }
            catch (Exception e)
            {
                Main.LogError("生物学[克苏鲁之脑] 重建黄金之脑失败 " + e);
            }
        }

        /// <summary>
        /// 创建悬浮在废墟上方的修复进度条。
        /// 关键点:必须显式设置排序层。WorldBox 的单位精灵在 "Objects" 层、
        /// 原版血条在 "MapOverlay" 层,而 new GameObject 默认落在最底下的 "Default" 层,
        /// 结果就是进度条被地形/建筑压在下面,肉眼完全看不到(这就是之前"进度条不出现"的原因)。
        /// </summary>
        private static void CreateRepairBar()
        {
            if (_repairBar != null || !IsRepairBuildingValid()) return;
            if (_whiteSprite == null) _whiteSprite = CreateWhiteSprite();
            if (_whiteSprite == null) return;
            LogSortingLayersOnce();
            int layer = SortingLayer.NameToID(RepairBarSortingLayer);
            _repairBar = new GameObject("CthulhuRepairBar");
            AddBarPart(_repairBar, "outline", layer, RepairBarOrder, new Vector3(2.34f, 0.46f, 1f),
                new Color(0f, 0f, 0f, 0.85f), Vector3.zero);
            AddBarPart(_repairBar, "bg", layer, RepairBarOrder + 1, new Vector3(2.1f, 0.3f, 1f),
                new Color(0.08f, 0.08f, 0.08f, 0.95f), Vector3.zero);
            GameObject fill = AddBarPart(_repairBar, "fill", layer, RepairBarOrder + 2, new Vector3(0.001f, 0.24f, 1f),
                new Color(0.25f, 1f, 0.3f, 1f), new Vector3(-1f, 0f, 0f));
            _repairFill = fill.transform;
            UpdateRepairBar();
            Main.LogInfo("生物学[克苏鲁之脑] 修复进度条已创建 layer=" + RepairBarSortingLayer
                + "(id=" + layer + ")");
        }

        private static GameObject AddBarPart(GameObject pParent, string pName, int pLayer, int pOrder,
            Vector3 pScale, Color pColor, Vector3 pLocalPos)
        {
            GameObject go = new GameObject(pName);
            go.transform.SetParent(pParent.transform, false);
            go.transform.localPosition = pLocalPos;
            go.transform.localScale = pScale;
            SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = _whiteSprite;
            sr.color = pColor;
            sr.sortingLayerID = pLayer;
            sr.sortingOrder = pOrder;
            return go;
        }

        /// <summary>把游戏里实际存在的排序层名打一次日志,方便需要时换层。</summary>
        private static void LogSortingLayersOnce()
        {
            if (_sortingLayersLogged) return;
            _sortingLayersLogged = true;
            try
            {
                string names = "";
                SortingLayer[] layers = SortingLayer.layers;
                for (int i = 0; i < layers.Length; i++)
                {
                    if (i > 0) names += " , ";
                    names += layers[i].name;
                }
                Main.LogInfo("生物学[克苏鲁之脑] 可用排序层: " + names);
            }
            catch
            {
            }
        }

        private static void UpdateRepairBar()
        {
            if (!IsRepairBuildingValid())
            {
                // 目标已经没了(被玩家清掉 / 换成别的建筑),条子不能留在画面上
                if (_repairBar != null) ClearRepairTarget();
                return;
            }
            // 兜底:如果创建时机不巧没建成(或世界重载把它销毁了),
            // 这里补建一次,避免"进度在涨但条子永远不出现"。
            if (_repairBar == null)
            {
                CreateRepairBar();
                if (_repairBar == null) return;
            }
            Vector3 pos = RepairBuilding.current_tile.posV3;
            pos.y += 3.5f;
            pos.z = -1f;   // 正交相机下 z 越小越靠近镜头,同层同序时排最后绘制
            _repairBar.transform.position = pos;
            if (_repairFill != null)
            {
                float p = Mathf.Clamp01(RepairProgress);
                // 底槽宽 2.1、内缩 0.05;填充从左边开始长出来
                _repairFill.localPosition = new Vector3(-1f + p, 0f, 0f);
                _repairFill.localScale = new Vector3(Mathf.Max(0.001f, 2f * p), 0.24f, 1f);
            }
        }

        private static Sprite CreateWhiteSprite()
        {
            Texture2D tex = new Texture2D(1, 1, TextureFormat.RGBA32, false);
            tex.SetPixel(0, 0, Color.white);
            tex.Apply();
            return Sprite.Create(tex, new Rect(0f, 0f, 1f, 1f), new Vector2(0.5f, 0.5f), 1f);
        }

        public static void StopLaserFor(Actor pActor)
        {
            if (pActor == null) return;
            BrainState st;
            if (_states.TryGetValue(pActor.getID(), out st)) StopLaser(st);
        }

        // ------------------------------------------------------------------ 威胁检测

        /// <summary>
        /// 每 0.4 秒算一次周围有没有敌人(一次扫描同时得到两个半径的结论,别每帧全表扫单位)。
        /// EnemyNearby:16 格内有敌人 → 二阶段小怪先打架;ThreatNearby:30 格内有敌人 → 显示血条。
        /// </summary>
        private static void RefreshThreat(Actor pActor, BrainState pState)
        {
            if (pActor == null || pState == null) return;
            if (Time.time < pState.NextEnemyCheckTime) return;
            pState.NextEnemyCheckTime = Time.time + 0.4f;
            Actor near = FindNearestEnemy(pActor, BossBarShowRadius);
            pState.ThreatNearby = near != null;
            if (near == null || pActor.current_tile == null || near.current_tile == null)
            {
                pState.EnemyNearby = false;
                return;
            }
            pState.EnemyNearby =
                Toolbox.SquaredDistTile(pActor.current_tile, near.current_tile)
                <= RepairCombatRadius * RepairCombatRadius;
        }

        // ------------------------------------------------------------------ 头顶血条

        private static GameObject _bossBar;
        private static Transform _bossBarFill;
        private static bool _bossBarVisible;
        private static Actor _bossBarOwner;

        /// <summary>在主脑头顶画一条血条:附近有敌人时显示,没有敌人就隐藏。</summary>
        private static void UpdateBossBar(Actor pActor, BrainState pState)
        {
            if (pActor == null || pState == null) return;
            _bossBarOwner = pActor;
            bool show = pState.ThreatNearby;
            if (_bossBar == null)
            {
                if (!show) return;          // 没敌人就不急着建
                CreateBossBar();
                if (_bossBar == null) return;
            }
            if (_bossBarVisible != show)
            {
                _bossBarVisible = show;
                _bossBar.SetActive(show);
            }
            if (!show) return;

            float topY = 3f;
            try
            {
                Sprite main = pActor.calculateMainSprite();
                if (main != null && main.rect.height > 0f)
                {
                    float pivotFy = main.pivot.y / main.rect.height;
                    topY = (1f - pivotFy) * main.bounds.size.y * pActor.current_scale.x + 0.8f;
                }
            }
            catch { }
            Vector3 pos = pActor.current_position;
            pos.y += GetActorHeight(pActor) + topY;
            pos.z = -1f;
            _bossBar.transform.position = pos;

            int maxHp = Mathf.Max(1, pActor.getMaxHealth());
            float ratio = Mathf.Clamp01((float)pActor.getHealth() / maxHp);
            if (_bossBarFill != null)
            {
                float w = Mathf.Max(0.001f, BossBarWidth * ratio);
                _bossBarFill.localPosition = new Vector3(-BossBarWidth * 0.5f + w * 0.5f, 0f, 0f);
                _bossBarFill.localScale = new Vector3(w, BossBarHeight * 0.68f, 1f);
            }
        }

        private static void CreateBossBar()
        {
            if (_bossBar != null) return;
            if (_whiteSprite == null) _whiteSprite = CreateWhiteSprite();
            if (_whiteSprite == null) return;
            int layer = SortingLayer.NameToID(RepairBarSortingLayer);
            _bossBar = new GameObject("CthulhuBossHealthBar");
            AddBarPart(_bossBar, "outline", layer, BossBarOrder, new Vector3(BossBarWidth + 0.14f, BossBarHeight + 0.12f, 1f),
                new Color(0f, 0f, 0f, 0.85f), Vector3.zero);
            AddBarPart(_bossBar, "bg", layer, BossBarOrder + 1, new Vector3(BossBarWidth, BossBarHeight, 1f),
                new Color(0.12f, 0.04f, 0.06f, 0.95f), Vector3.zero);
            GameObject fill = AddBarPart(_bossBar, "fill", layer, BossBarOrder + 2, new Vector3(BossBarWidth, BossBarHeight * 0.68f, 1f),
                new Color(0.9f, 0.15f, 0.2f, 1f), Vector3.zero);
            _bossBarFill = fill != null ? fill.transform : null;
            _bossBarVisible = true;
            Main.LogInfo("生物学[克苏鲁之脑] 头顶血条已创建 layer=" + RepairBarSortingLayer + "(id=" + layer + ")");
        }

        public static void HideBossBar()
        {
            if (_bossBar != null) _bossBar.SetActive(false);
            _bossBarVisible = false;
            _bossBarOwner = null;
        }

        private static void MaintainTarget(Actor pActor, BrainState pState, float pRange)
        {
            if (Time.time < pState.NextTargetTime) return;
            pState.NextTargetTime = Time.time + 0.5f;
            Actor target = FindNearestEnemy(pActor, pRange);
            if (target == null) return;
            pActor.startFightingWith(target);
            TryMinionAttackVoice(pActor, pState, target);
        }

        private static float _nextMinionVoiceGlobal;

        /// <summary>
        /// 小怪攻击时的叫声:只在一阶段/二阶段的召唤兽贴到目标附近时叫,
        /// 每只自己一个冷却,再加一个全局冷却,免得十几只一起叫成噪音。
        /// </summary>
        private static void TryMinionAttackVoice(Actor pActor, BrainState pState, Actor pTarget)
        {
            if (pActor == null || pState == null || pTarget == null || pActor.asset == null) return;
            string id = pActor.asset.id;
            if (id != CthulhuBrainContent.MinionId && id != CthulhuBrainContent.Phase2MinionId) return;
            if (pActor.current_tile == null || pTarget.current_tile == null) return;
            if (Toolbox.SquaredDistTile(pActor.current_tile, pTarget.current_tile) > 100f) return;   // 10 格内
            if (Time.time < pState.NextVoiceTime || Time.time < _nextMinionVoiceGlobal) return;
            pState.NextVoiceTime = Time.time + UnityEngine.Random.Range(1.6f, 3.6f);
            _nextMinionVoiceGlobal = Time.time + 0.45f;
            CthulhuVoice.Play(CthulhuVoice.SndMinionAttack, 0.45f, CthulhuVoice.MinionAttackPitch);
        }

        private static Actor FindNearestEnemy(Actor pSelf, float pRange)
        {
            if (pSelf == null || pSelf.current_tile == null || World.world == null || World.world.units == null) return null;
            Actor best = null;
            float bestDist = pRange * pRange;
            foreach (Actor other in World.world.units)
            {
                if (other == null || other == pSelf || !other.isAlive()) continue;
                if (other.asset == null || CthulhuBrainContent.IsCthulhuAsset(other.asset)) continue;
                if (other.kingdom != null && pSelf.kingdom != null && other.kingdom == pSelf.kingdom) continue;
                if (other.current_tile == null) continue;
                float d = Toolbox.SquaredDistTile(pSelf.current_tile, other.current_tile);
                if (d < bestDist)
                {
                    bestDist = d;
                    best = other;
                }
            }
            return best;
        }

        private static MethodInfo _addStatusMethod;

        private static void ApplyInvincible(Actor pActor)
        {
            try
            {
                if (_addStatusMethod == null)
                    _addStatusMethod = typeof(BaseSimObject).GetMethod("addStatusEffect",
                        BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic,
                        null, new[] { typeof(string), typeof(float), typeof(bool) }, null);
                if (_addStatusMethod != null)
                    _addStatusMethod.Invoke(pActor, new object[] { "invincible", 99999f, false });
            }
            catch
            {
            }
        }

        private static void KillPhase1(Actor pActor)
        {
            if (pActor == null || !pActor.isAlive()) return;
            Main.LogInfo("生物学[克苏鲁之脑] 一阶段死亡，触发二阶段并清除一阶段尸体");
            try
            {
                pActor.setHealth(0, false);
                if (pActor.asset != null && pActor.asset.action_death != null)
                    pActor.asset.action_death(pActor, pActor.current_tile);
            }
            catch (Exception e)
            {
                Main.LogError("生物学[克苏鲁之脑] 一阶段死亡回调失败 " + e);
            }
            pActor.dieAndDestroy(AttackType.None);
        }

        private static bool UpdatePhase1Health(Actor pActor, BrainState pState)
        {
            if (pActor == null || !pActor.isAlive()) return true;
            if (!pState.InvincibleApplied)
            {
                ApplyInvincible(pActor);
                pState.InvincibleApplied = true;
            }
            int count = CountLinkedMinions(pState);
            int maxHp = pActor.getMaxHealth();
            int hp = Mathf.Clamp(Mathf.RoundToInt(maxHp * 0.1f * count), 0, maxHp);
            if (hp <= 0)
            {
                KillPhase1(pActor);
                return true;
            }
            pActor.setHealth(hp, true);
            return false;
        }

        private static bool UpdatePhase2Health(Actor pActor, BrainState pState)
        {
            if (pActor == null || !pActor.isAlive()) return true;
            if (!pState.InvincibleApplied)
            {
                ApplyInvincible(pActor);
                pState.InvincibleApplied = true;
            }
            int maxHp = pActor.getMaxHealth();
            int hp = Mathf.Clamp(maxHp - Mathf.RoundToInt(maxHp * Phase2MinionDeathDamageRatio * pState.Phase2DeathCount), 0, maxHp);
            if (hp <= 0)
            {
                pActor.setHealth(0, false);
                if (pActor.asset != null && pActor.asset.action_death != null)
                    pActor.asset.action_death(pActor, pActor.current_tile);
                pActor.dieAndDestroy(AttackType.None);
                return true;
            }
            pActor.setHealth(hp, true);
            return false;
        }

        private static void SummonMinions(Actor pActor, BrainState pState, int pCount)
        {
            if (pActor == null || pActor.current_tile == null || pState == null) return;
            int summoned = 0;
            for (int i = 0; i < pCount; i++)
            {
                WorldTile tile = Toolbox.getRandomTileWithinDistance(pActor.current_tile, 4);
                if (tile == null || tile.Type == null || !tile.Type.ground) tile = pActor.current_tile;
                if (tile == null) continue;
                Actor minion = World.world.units.spawnNewUnit(CthulhuBrainContent.MinionId, tile,
                    pSpawnSound: false, pMiracleSpawn: true, pSpawnHeight: 0f);
                if (minion != null)
                {
                    pState.Minions.Add(minion.getID());
                    summoned++;
                }
            }
            Main.LogInfo("生物学[克苏鲁之脑] 一阶段召唤兽 +" + summoned
                + "，当前绑定存活=" + CountLinkedMinions(pState));
        }

        private static void SummonPhase2Minions(Actor pActor, BrainState pState, int pCount)
        {
            if (pActor == null || pActor.current_tile == null || pState == null) return;
            int summoned = 0;
            for (int i = 0; i < pCount; i++)
            {
                WorldTile tile = Toolbox.getRandomTileWithinDistance(pActor.current_tile, 5);
                if (tile == null) tile = pActor.current_tile;
                if (tile == null) continue;
                Actor minion = World.world.units.spawnNewUnit(CthulhuBrainContent.Phase2MinionId, tile,
                    pSpawnSound: false, pMiracleSpawn: true, pSpawnHeight: 4.5f);
                if (minion != null)
                {
                    pState.Phase2Minions.Add(minion.getID());
                    summoned++;
                    pState.Phase2DeathCount = Mathf.Max(0, pState.Phase2DeathCount - 1);
                }
            }
            Main.LogInfo("生物学[克苏鲁之脑] 二阶段召唤兽 +" + summoned
                + "，当前存活=" + CountPhase2Minions(pState));
        }

        private static int CountPhase2Minions(BrainState pState)
        {
            if (pState == null || pState.Phase2Minions.Count == 0) return 0;
            if (World.world == null || World.world.units == null) return 0;
            int count = 0;
            List<long> dead = null;
            foreach (long id in pState.Phase2Minions)
            {
                Actor minion = World.world.units.get(id);
                if (minion == null || !minion.isAlive() || minion.asset == null
                    || minion.asset.id != CthulhuBrainContent.Phase2MinionId)
                {
                    if (dead == null) dead = new List<long>();
                    dead.Add(id);
                }
                else count++;
            }
            if (dead != null)
            {
                foreach (long id in dead) pState.Phase2Minions.Remove(id);
            }
            return count;
        }

        private static int CountLinkedMinions(BrainState pState)
        {
            if (pState == null || pState.Minions.Count == 0) return 0;
            if (World.world == null || World.world.units == null) return 0;
            int count = 0;
            List<long> dead = null;
            foreach (long id in pState.Minions)
            {
                Actor minion = World.world.units.get(id);
                if (minion == null || !minion.isAlive() || minion.asset == null
                    || minion.asset.id != CthulhuBrainContent.MinionId)
                {
                    if (dead == null) dead = new List<long>();
                    dead.Add(id);
                }
                else count++;
            }
            if (dead != null)
            {
                foreach (long id in dead) pState.Minions.Remove(id);
            }
            return count;
        }

        /// <summary>
        /// 归巢:克苏鲁单位离黄金之脑废墟太远就往回走,主脑甩得特别远直接闪现回巢。
        /// 对一阶段、二阶段的主脑和召唤兽一律生效;场上没有废墟时不做任何限制。
        /// 飞行单位调用 goTo 只是把目标压进 current_path,不做 A* 寻路,可以每帧调用。
        /// </summary>
        private static void TickLeash(Actor pActor)
        {
            if (pActor == null || pActor.asset == null || pActor.current_tile == null) return;
            if (!IsRepairBuildingValid())
            {
                // 一阶段就走不到修复逻辑,这里也要能自己认领废墟,否则限制等于没开。
                if (RepairBuilding == null) TryAdoptGoldenBrainRuin();
                if (!IsRepairBuildingValid()) return;
            }
            WorldTile home = RepairBuilding.current_tile;
            if (home == null) return;
            float d2 = WorldDist2(pActor, home);
            if (d2 <= LeashRange2) return;

            bool isBoss = pActor.asset.id == CthulhuBrainContent.Phase1Id
                || pActor.asset.id == CthulhuBrainContent.Phase2Id;
            if (d2 > LeashTeleportRange2)
            {
                // 跑得太离谱:先打断当前行为(否则它会一直追着远处的敌人),
                // 主脑再额外闪现回巢。
                pActor.cancelAllBeh();
                if (isBoss)
                {
                    WorldTile spot = Toolbox.getRandomTileWithinDistance(home, 6);
                    if (spot != null)
                    {
                        try
                        {
                            ActionLibrary.teleportEffect(pActor, spot);
                            TeleportActor(pActor, spot);
                            return;
                        }
                        catch (Exception e)
                        {
                            Main.LogError("生物学[克苏鲁之脑] 主脑回巢失败 " + e);
                        }
                    }
                }
            }
            // 飞行单位 goTo 只是把目标压进 current_path,零寻路开销,可以每帧叫;
            // 地面单位(一阶段召唤兽)走 A*,只在它站住不动时重新下令,避免每帧寻路卡顿。
            // 注意不要为了省事去改 flying 标志:那会把受击判定高度顶到 8,近战可能打不到它们。
            if (pActor.asset.flying) pActor.goTo(home);
            else if (!pActor.is_moving) pActor.goTo(home);
            if (Time.time >= _nextLeashLogTime)
            {
                _nextLeashLogTime = Time.time + 5f;
                Main.LogInfo("生物学[克苏鲁之脑] 单位 " + pActor.getID()
                    + "(" + pActor.asset.id + ") 离废墟太远,返回废墟");
            }
        }

        public static bool WasGoldenBrainHandled(Building pBuilding)
        {
            return pBuilding != null && _handledGoldenBrains.Contains(pBuilding.getID());
        }

        public static void MarkGoldenBrainHandled(Building pBuilding)
        {
            if (pBuilding != null) _handledGoldenBrains.Add(pBuilding.getID());
        }
    }

    public static class CthulhuBrainPatches
    {
        private static bool _patched;

        public static void Ensure()
        {
            if (_patched) return;
            _patched = true;
            Harmony harmony = new Harmony("rimworld_health_cthulhu_brain");
            int ok = 0;
            ok += Patch(harmony, AccessTools.Method(typeof(Actor), "b6_updateAI", new[] { typeof(float) }),
                null, nameof(ActorAIPostfix), null, "克苏鲁之脑 AI");
            ok += Patch(harmony, AccessTools.Method(typeof(Building), "startMakingRuins"),
                null, nameof(BuildingRuinsPostfix), null, "金脑破坏召唤");
            ok += Patch(harmony, AccessTools.Method(typeof(Actor), "makeSleep", new[] { typeof(float) }),
                nameof(ActorMakeSleepPrefix), null, null, "禁用睡眠");
            ok += Patch(harmony, AccessTools.Method(typeof(ActionLibrary), "getActorNearPos", new[] { typeof(Vector2) }),
                null, nameof(GetActorNearPosPostfix), null, "高飞单位点击命中");
            Main.LogInfo("生物学:克苏鲁之脑补丁 " + ok + "/4 装上了");
        }

        private static int Patch(Harmony pHarmony, MethodInfo pTarget, string pPrefix,
            string pPostfix, string pFinalizer, string pWhat)
        {
            try
            {
                if (pTarget == null)
                {
                    Main.LogError("生物学:找不到克苏鲁目标方法  " + pWhat);
                    return 0;
                }
                pHarmony.Patch(pTarget,
                    prefix: pPrefix == null ? null : new HarmonyMethod(AccessTools.Method(typeof(CthulhuBrainPatches), pPrefix)),
                    postfix: pPostfix == null ? null : new HarmonyMethod(AccessTools.Method(typeof(CthulhuBrainPatches), pPostfix)),
                    finalizer: pFinalizer == null ? null : new HarmonyMethod(AccessTools.Method(typeof(CthulhuBrainPatches), pFinalizer)));
                return 1;
            }
            catch (Exception e)
            {
                Main.LogError("生物学:克苏鲁补丁失败 " + pWhat + " " + e);
                return 0;
            }
        }


        public static bool ActorMakeSleepPrefix(Actor __instance)
        {
            if (__instance == null || __instance.asset == null) return true;
            if (CthulhuBrainRuntime.ActiveCthulhuCount == 0
                && __instance.asset != CthulhuBrainContent.Phase1
                && __instance.asset != CthulhuBrainContent.Phase2
                && __instance.asset != CthulhuBrainContent.Minion
                && __instance.asset != CthulhuBrainContent.Phase2Minion) return true;
            return !CthulhuBrainContent.IsCthulhuAsset(__instance.asset);
        }

        public static void ActorAIPostfix(Actor __instance, float pElapsed)
        {
            CthulhuBrainRuntime.OnActorAI(__instance, pElapsed);
        }

        private static int _lastPickFrame = -1;
        private static Vector2 _lastPickPos = new Vector2(-99999f, -99999f);
        private static Actor _lastPickFound;

        /// <summary>
        /// 点击命中兜底。原版 getActorNearPos 只拿 actor.current_position 和光标比距离
        /// (命中半径 √3 ≈ 1.7 格),而克苏鲁单位悬停在 4.5~7 格高空:
        /// 精灵画在上面、判定点却留在地面,所以怎么点都点不到。
        /// 这里只在原版没找到目标时,按“精灵实际画在哪”再找一次,不影响原版行为。
        /// </summary>
        public static void GetActorNearPosPostfix(Vector2 pPos, ref Actor __result)
        {
            if (__result != null) return;
            try
            {
                if (World.world == null || World.world.units == null) return;
                // 没有活跃克苏鲁单位时,不要让原版每次鼠标查询都触发全单位扫描。
                if (CthulhuBrainRuntime.ActiveCthulhuCount == 0) return;
                // 同一帧同一光标位置只扫一次,顺便复用上一轮结果。
                if (Time.frameCount == _lastPickFrame && (pPos - _lastPickPos).sqrMagnitude < 0.0001f)
                {
                    if (_lastPickFound != null && _lastPickFound.isAlive()) __result = _lastPickFound;
                    return;
                }
                _lastPickFrame = Time.frameCount;
                _lastPickPos = pPos;
                _lastPickFound = null;
                Actor found = CthulhuBrainRuntime.FindCthulhuNear(pPos, 2.6f);
                _lastPickFound = found;
                if (found != null) __result = found;
            }
            catch (Exception e)
            {
                Main.LogError("生物学:高飞单位点击兜底失败 " + e);
            }
        }

        // 反射句柄缓存:本方法会在"遍历所有建筑"的循环里被调用,每次都 GetField 很浪费。
        private static FieldInfo _buildingAssetField;
        private static FieldInfo _assetIdField;
        public static string GetBuildingAssetId(Building pBuilding)
        {
            try
            {
                if (_buildingAssetField == null)
                    _buildingAssetField = typeof(Building).GetField("asset",
                        BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                object asset = _buildingAssetField != null ? _buildingAssetField.GetValue(pBuilding) : null;
                if (asset == null) return null;
                if (_assetIdField == null)
                    _assetIdField = asset.GetType().GetField("id",
                        BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                return _assetIdField != null ? _assetIdField.GetValue(asset) as string : null;
            }
            catch
            {
                return null;
            }
        }

        public static void BuildingRuinsPostfix(Building __instance)
        {
            try
            {
                if (__instance == null) return;
                if (GetBuildingAssetId(__instance) != CthulhuBrainContent.GoldenBrainId) return;
                if (CthulhuBrainRuntime.WasGoldenBrainHandled(__instance)) return;
                CthulhuBrainRuntime.MarkGoldenBrainHandled(__instance);
                CthulhuBrainContent.EnsureInitialized();
                CthulhuBrainRuntime.SetRepairTarget(__instance);
                if (CthulhuBrainContent.Phase1 == null || World.world == null) return;
                WorldTile tile = __instance.current_tile;
                if (tile == null) return;
                EffectsLibrary.spawn("fx_spawn", tile);
                World.world.units.spawnNewUnit(CthulhuBrainContent.Phase1Id, tile,
                    pSpawnSound: true, pMiracleSpawn: true, pSpawnHeight: 0f);
                Main.LogInfo("生物学[克苏鲁之脑] 黄金之脑被破坏，一阶段已出现");
                CthulhuVoice.Play(CthulhuVoice.SndShellBreak, 0.9f);
                CthulhuVoice.Play(CthulhuVoice.SndAwaken, 1f);
                CthulhuVoice.ShowTip("bio_cthulhu_tip_awaken",
                    "躯壳被打破！克苏鲁之脑已从沉睡中苏醒，祂感觉震怒！", "#FF3B3B", CthulhuVoice.TipSeconds);
            }
            catch (Exception e)
            {
                Main.LogError("生物学[克苏鲁之脑] 黄金之脑破坏处理失败 " + e);
            }
        }
    }
}
