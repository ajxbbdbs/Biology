using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace RimWorldMod {

    // 悬停弹窗数据:只有值得好奇的器官才提供,其余返回 null
    public static class OrganInfo {

        public static string GetTooltip(Actor pActor, string pOrganId) {
            if (pActor == null || string.IsNullOrEmpty(pOrganId)) return null;
            int seed = pActor.getID().GetHashCode() ^ pOrganId.GetHashCode();
            System.Random rng = new System.Random(seed);
            switch (pOrganId) {
                case "chest":
                    return GetChestInfo(pActor, rng);
                case "penis":
                    return GetPenisInfo(pActor, rng, HasSterile(pActor), GetSizeBonus(pActor));
                case "vagina":
                    return GetVaginaInfo(pActor, GetSizeBonus(pActor),
                        OrganEditorUI.GetViolationCount(pActor, "vagina"));
                case "anus":
                    return GetAnusInfo(pActor, rng,
                        OrganEditorUI.GetViolationCount(pActor, "anus"));
                case "brain":
                    return GetBrainInfo(pActor, rng);
                case "heart":
                    return BioText.F("bio_tip_heart", "静息心率: {0} 次/分\n心脏重量: {1} g",
                        rng.Next(55, 96), rng.Next(280, 360));
                case "blood":
                    return GetBloodType(rng);
                case "lung":
                    return BioText.F("bio_tip_lung", "肺活量: {0} ml", rng.Next(3200, 6200));
                case "eye_l":
                case "eye_r":
                    return BioText.F("bio_tip_eye", "视力: {0}", GetVision(rng));
                case "ear":
                    return BioText.F("bio_tip_ear", "听力阈值: {0} dB", rng.Next(10, 36));
                case "liver":
                    return BioText.F("bio_tip_liver", "肝脏重量: {0} kg", (1.2 + rng.Next(0, 6) / 10.0).ToString("0.0"));
                case "stomach":
                    return BioText.F("bio_tip_stomach", "胃容量: {0} ml", rng.Next(1000, 1800));
                case "skin":
                    return GetSkinInfo(pActor, rng);
                case "beak":
                    return BioText.F("bio_tip_beak", "喙长: {0} cm\n用于啄食、梳理羽毛与防御", rng.Next(3, 15));
                case "horn":
                    return BioText.F("bio_tip_horn", "角长: {0} cm\n用于防御与求偶", rng.Next(15, 60));
                case "cloaca":
                    return BioText.T("bio_tip_cloaca", "泄殖腔\n兼有排泄与生殖功能(禽类/鱼类/爬行类)");
                case "gills":
                    return BioText.T("bio_tip_gills", "鳃\n在水中呼吸的器官,离开水无法呼吸");
                case "wing_l":
                case "wing_r":
                    return BioText.F("bio_tip_wing", "翼展: {0} cm\n用于飞行与平衡", rng.Next(60, 300));
            }
            return null;
        }

        // 胸围与罩杯:男性固定A罩杯;肥胖升B/C;巨大只加胸围;小孩A/B;成年随机
        private static string GetChestInfo(Actor pActor, System.Random pRng) {
            string[] cups = { "A", "B", "C", "D", "E", "F", "G" };
            int cupIdx = 0; // 默认 A
            int underbust = 70 + pRng.Next(0, 15);
            float diff = 10f + cupIdx * 2.5f;

            // 用 mod 的器官组合判定性别(1=男,2=女,3=双性,0=中性)
            int gender = 0;
            try { gender = HealthSimulator.GetGender(pActor); } catch { }
            bool male = gender == 1 || gender == 0; // 男性或中性:固定 A
            bool child = false;
            try { child = !pActor.isAdult(); } catch { }
            bool fat = HasTrait(pActor, "fat", new[] { "肥胖", "Fat" });
            bool giant = HasTrait(pActor, "giant", new[] { "巨大", "Giant" });
            bool tiny = HasTrait(pActor, "tiny", new[] { "渺小", "侏儒", "Tiny" });
            bool animal = false;
            string speciesId = "?";
            try { animal = pActor.isAnimal(); } catch { }
            if (animal) {
                try { if (pActor.asset != null && !string.IsNullOrEmpty(pActor.asset.id)) speciesId = pActor.asset.id; } catch { }
            }

            if (male) {
                // 男性:罩杯固定 A
                cupIdx = 0;
            } else if (child) {
                // 小孩:A 或 B
                cupIdx = pRng.Next(0, 2);
            } else if (animal) {
                // 动物:哺乳动物按体型分罩杯(小型A~B,大型D~G,中型A~D)
                int size = OrganData.GetMammalSize(speciesId);
                if (size == 0) cupIdx = pRng.Next(0, 2);
                else if (size == 2) cupIdx = pRng.Next(3, 7);
                else cupIdx = pRng.Next(0, 4);
            } else {
                // 成年女性/双性:随机分配
                cupIdx = pRng.Next(0, cups.Length);
            }
            // 肥胖:罩杯升到 B/C(仅女性/双性),并增加胸围
            if (fat && !male) {
                cupIdx = Mathf.Max(cupIdx, pRng.Next(1, 3)); // B 或 C
            }
            diff = 10f + cupIdx * 2.5f;
            // 巨大体型:只增加胸围,罩杯不变
            if (giant) {
                underbust += 15;
            }
            // 渺小体型:减小胸围
            if (tiny) {
                underbust -= 10;
            }
            int bust = underbust + (int)diff;
            Main.LogInfo("生物学:[胸围] 性别码=" + gender + " male=" + male + " child=" + child
                + " animal=" + animal + " 物种=" + speciesId + " 体型="
                + (animal ? OrganData.GetMammalSize(speciesId).ToString() : "-")
                + " fat=" + fat + " giant=" + giant + " tiny=" + tiny
                + " cupIdx=" + cupIdx + " 罩杯=" + cups[cupIdx]);
            return BioText.F("bio_tip_chest", "胸围: {0} cm\n下胸围: {1} cm\n罩杯: {2} 罩杯",
                bust, underbust, cups[cupIdx]);
        }

        private static string GetPenisInfo(Actor pActor, System.Random pRng, bool pSterile, int pBonus) 
        {
            int flaccid, erect;
            RollPenisSize(pRng, pSterile, pBonus, out flaccid, out erect);
            string bonusStr = pBonus > 0 ? BioText.F("bio_tip_bonus", "\n特质加成: +{0} cm", pBonus) : "";
            string note = pSterile ? BioText.T("bio_tip_sterile_note", "\n(生殖困难:尺寸明显偏小)") : "";
            // 撸管/射精记录:撸管次数 + 射精次数(撸管射精与生育均计入)
            string mastStr = "";
            int mast = OrganEditorUI.GetMasturbationCount(pActor);
            int ejac = OrganEditorUI.GetEjaculationCount(pActor);
            if (mast > 0 || ejac > 0) {
                mastStr = BioText.F("bio_tip_mast", "\n撸管次数: {0} 次\n射精次数: {1} 次", mast, ejac);
            }
            // 性伴侣:被神撸管(玩家在阴茎上点"撸管")即被神碰过,god 计入伴侣;
            // 再加他生下的孩子的母亲们和恋人;全都没有才显示"无"
            List<string> partners = new List<string>();
            if (mast > 0) {
                partners.Add("<color=#FFD700>god</color>");
            }
            List<string> mothers = FamilyTracker.GetChildMotherNames(pActor);
            foreach (string m in mothers) {
                partners.Add(m);
            }
            // 恋人也算伴侣(若有)
            if (pActor.lover != null && !pActor.lover.isRekt()) {
                partners.Add(pActor.lover.getName());
            }
            partners = DedupList(partners);
            string partnerStr = partners.Count > 0
                ? BioText.F("bio_tip_partner", "\n性伴侣: {0}", string.Join("、", partners))
                : BioText.T("bio_tip_partner_none", "\n性伴侣: 无");
            return BioText.F("bio_tip_penis", "尺寸(疲软): {0} cm\n尺寸(勃起): {1} cm", flaccid, erect)
                 + bonusStr + note + mastStr + partnerStr;
        }

        /// <summary>
        /// 阴茎尺寸(cm)。立绘要按尺寸挑贴图,所以把这一段单独拿出来给外面调。
        /// 种子和 GetTooltip 一样是「单位id ^ 器官id」,抽取顺序也一样(先疲软再勃起),
        /// 因此立绘挑中的那张贴图必然和悬停弹窗写的尺寸对得上。
        /// </summary>
        public static void GetPenisSize(Actor pActor, out int pFlaccid, out int pErect) {
            pFlaccid = 0;
            pErect = 0;
            if (pActor == null) return;
            System.Random rng = new System.Random(pActor.getID().GetHashCode() ^ "penis".GetHashCode());
            RollPenisSize(rng, HasSterile(pActor), GetSizeBonus(pActor), out pFlaccid, out pErect);
        }

        private static void RollPenisSize(System.Random pRng, bool pSterile, int pBonus,
            out int pFlaccid, out int pErect) {
            if (pSterile) {
                pFlaccid = 1 + pRng.Next(0, 4);
                pErect = 6 + pRng.Next(0, 4);
            } else {
                pFlaccid = 6 + pRng.Next(0, 3);
                pErect = 12 + pRng.Next(0, 6);
            }
            pFlaccid += pBonus;
            pErect += pBonus;
        }

        private static string GetVaginaInfo(Actor pActor, int pBonus, int pViolations) {
            int depth = GetVaginaDepth(pActor); // 固定深度,不受侵犯/强化影响,最大 20cm
            int level = GetVaginaLevel(pActor);  // 强化+、弱化-
            int children = 0;
            try { children = pActor.current_children_count; } catch { }

            // 弹性:基础 60,强化每级 +12,弱化每级 -12,生孩子每个 -3
            int elasticity = Mathf.Clamp(60 + level * 12 - children * 3, 0, 100);
            // 敏感度:基础 70,强化每级 +12(紧致=敏感),弱化每级 -12(松弛=迟钝)
            int sensitivity = Mathf.Clamp(70 + level * 12, 0, 100);

            string bonusStr = pBonus > 0 ? BioText.F("bio_tip_bonus", "\n特质加成: +{0} cm", pBonus) : "";
            string violStr = "";
            if (pViolations > 0) {
                violStr = BioText.F("bio_tip_violated", "\n<color=#FF69B4>⚠ 被神侵犯过 {0} 次</color>", pViolations);
            }
            // 怀着神之子:状态条上只看得到"怀孕"和剩余时间,看不出怀的是谁的,所以在这儿点明
            string divineStr = HasDivinePregnancy(pActor)
                ? BioText.T("bio_tip_divine_pregnancy", "\n<color=#FFD700>★ 怀着神的孩子</color>") : "";
            // 性交伴侣:她怀孕生下的孩子的父亲的名字(去重)
            List<string> fathers = DedupList(FamilyTracker.GetChildFatherNames(pActor));
            string partnerStr = fathers.Count > 0
                ? BioText.F("bio_tip_sex_partner", "\n性交伴侣: {0}", string.Join("、", fathers)) : "";
            string orgasmStr = BioText.F("bio_tip_orgasm", "\n高潮次数: {0} 次", GetOrgasmCount(pActor));
            return BioText.F("bio_tip_vagina", "深度: {0} cm(最大 20cm)\n弹性: {1}({2})\n敏感度: {3}({4})",
                depth, elasticity, ElasticityDesc(elasticity), sensitivity, SensitivityDesc(sensitivity))
                 + bonusStr + violStr + divineStr + partnerStr + orgasmStr;
        }

        // 这一胎是不是神之侵犯致孕的
        private static bool HasDivinePregnancy(Actor pActor) {
            if (pActor == null) return false;
            try {
                ActorWoundState state;
                return HealthSimulator.TryGetState(pActor.getID(), out state)
                    && state != null && state.Mods != null && state.Mods.DivinePregnancy;
            } catch {
                return false;
            }
        }

        // 该单位累计高潮次数
        public static int GetOrgasmCount(Actor pActor) {
            if (pActor == null) return 0;
            try {
                ActorWoundState state = HealthSimulator.GetState(pActor.getID());
                return state.Mods.OrgasmCount;
            } catch {
                return 0;
            }
        }

        // 该单位肛门实际扩张次数(概率性,非每次侵犯都扩张)
        public static int GetAnalExpansionCount(Actor pActor) {
            if (pActor == null) return 0;
            try {
                ActorWoundState state = HealthSimulator.GetState(pActor.getID());
                return state.Mods.AnalExpansionCount;
            } catch {
                return 0;
            }
        }

        // 阴道深度:同一单位固定,8~20cm
        private static int GetVaginaDepth(Actor pActor) {
            int seed = pActor.getID().GetHashCode() ^ "vagina_depth".GetHashCode();
            return 8 + new System.Random(seed).Next(0, 13); // 8..20
        }

        // 阴道强化/弱化等级:强化 +10/级,弱化 -10/次(无上限,可无限强化)
        private static int GetVaginaLevel(Actor pActor) {
            try {
                ActorWoundState state = HealthSimulator.GetState(pActor.getID());
                int cur = 0;
                state.Mods.HpMods.TryGetValue("vagina", out cur);
                return Mathf.Clamp(cur / 10, -100, 100);
            } catch {
                return 0;
            }
        }

        private static string ElasticityDesc(int pE) {            if (pE >= 85) return BioText.T("bio_elast_tight", "紧致");
            if (pE >= 65) return BioText.T("bio_elast_normal", "正常");
            if (pE >= 40) return BioText.T("bio_elast_loose", "松弛");
            return BioText.T("bio_elast_extreme", "极度松弛");
        }

        private static string SensitivityDesc(int pS) {
            if (pS >= 85) return BioText.T("bio_sens_extreme", "极度敏感");
            if (pS >= 65) return BioText.T("bio_sens_sensitive", "敏感");
            if (pS >= 40) return BioText.T("bio_sens_normal", "正常");
            return BioText.T("bio_sens_dull", "迟钝");
        }

        // 去重:保留顺序,相同名字只显示一次
        private static List<string> DedupList(List<string> pList) {
            List<string> result = new List<string>();
            if (pList == null) return result;
            HashSet<string> seen = new HashSet<string>();
            foreach (string s in pList) {
                if (string.IsNullOrEmpty(s) || seen.Contains(s)) continue;
                seen.Add(s);
                result.Add(s);
            }
            return result;
        }

        private static string GetAnusInfo(Actor pActor, System.Random pRng, int pViolations) {
            int children = pActor.current_children_count;
            int orientRoll = pRng.Next(0, 100);
            bool gay = orientRoll < 8;
            bool bi = orientRoll >= 8 && orientRoll < 16;

            // 历史肛交(孩子/取向随机,代表被神碰之前的经历)
            int history = 0;
            for (int i = 0; i < children; i++) {
                if (pRng.NextDouble() < 0.3) history++;
            }
            if (gay) history += pRng.Next(2, 6);
            else if (bi) history += pRng.Next(1, 4);
            // 肛门实际扩张次数(概率性,非每次侵犯都撑开)
            int expansions = GetAnalExpansionCount(pActor);
            // 肛交次数 = 历史 + 每次被神侵犯都算一次(即便没撑开也算发生过)
            int n = history + pViolations;
            // 物理松弛只由历史 + 实际扩张决定(没撑开就不会变松)
            int loose = history + expansions;

            string relax;
            if (loose <= 0) relax = BioText.T("bio_relax_tight", "紧致");
            else if (loose <= 2) relax = BioText.T("bio_relax_stight", "较紧致");
            else if (loose <= 4) relax = BioText.T("bio_relax_loose", "松弛");
            else if (loose <= 8) relax = BioText.T("bio_relax_sloose", "较松弛");
            else relax = BioText.T("bio_relax_severe", "重度松弛");

            float maxDil = Mathf.Min(20f, 2.5f + loose * 1.4f) + (float)pRng.NextDouble() * 0.5f;
            // 强化=紧缩:每级降低扩张,最小 2cm
            int tighten = OrganEditorUI.GetStrengthenLevel(pActor, "anus");
            if (tighten > 0) {
                maxDil = Mathf.Max(2f, maxDil - tighten * 2.5f);
            }
            maxDil = Mathf.Clamp(maxDil, 2f, 20f);
            // 敏感度:基础 70,强化每级 +12(紧致=敏感),弱化每级 -12(松弛=迟钝)
            int anusSensitivity = Mathf.Clamp(70 + tighten * 12, 0, 100);
            string orientStr = gay ? BioText.T("bio_orient_gay", "同性恋")
                : (bi ? BioText.T("bio_orient_bi", "双性恋") : BioText.T("bio_orient_straight", "异性恋"));

            List<string> partners = new List<string>();
            // 神之侵犯:每次侵犯的伴侣是 god
            for (int i = 0; i < pViolations; i++) {
                partners.Add("<color=#FFD700>god</color>");
            }
            // 真实伴侣:她怀孕生下的孩子的父亲的名字(而非随机名字)
            List<string> fathers = FamilyTracker.GetChildFatherNames(pActor);
            foreach (string f in fathers) {
                partners.Add(f);
            }
            // 不足的再补恋人(若有),其余不再随机生成
            if (pActor.lover != null && !pActor.lover.isRekt()) {
                partners.Add(pActor.lover.getName());
            }
            // 去重:相同名字只显示一次
            partners = DedupList(partners);

            StringBuilder sb = new StringBuilder();
            sb.Append(BioText.F("bio_anus_relax", "松弛程度: {0}", relax)).Append('\n');
            sb.Append(BioText.F("bio_anus_dilate", "最大扩张: {0} cm", maxDil.ToString("0.0"))).Append('\n');
            sb.Append(BioText.F("bio_anus_sensitivity", "敏感度: {0}({1})", anusSensitivity, SensitivityDesc(anusSensitivity))).Append('\n');
            if (pViolations > 0) {
                sb.Append(BioText.F("bio_anus_violated",
                    "<color=#FF69B4>⚠ 被神侵犯过 {0} 次,实际扩张 {1} 次(+{2} cm)</color>",
                    pViolations, expansions, (expansions * 1.4f).ToString("0.0"))).Append('\n');
            }
            sb.Append(BioText.F("bio_anus_orient", "性取向: {0}", orientStr)).Append('\n');
            sb.Append(BioText.F("bio_anus_count", "肛交次数: {0} 次", n)).Append('\n');
            if (n > 0) {
                if (partners.Count > 0) {
                    sb.Append(BioText.F("bio_anus_partner", "肛交伴侣: {0}", string.Join("、", partners))).Append('\n');
                } else {
                    sb.Append(BioText.T("bio_anus_partner_god", "肛交伴侣: <color=#FFD700>god</color>")).Append('\n');
                }
            } else {
                sb.Append(BioText.T("bio_anus_partner_none", "肛交伴侣: 无")).Append('\n');
            }
            sb.Append(BioText.F("bio_anus_orgasms", "高潮次数: {0} 次", GetOrgasmCount(pActor)));
            return sb.ToString();
        }

        private static int GetSizeBonus(Actor pActor) {
            int bonus = 0;
            if (HasTrait(pActor, "fertile", new[] { "兴旺", "多产", "Fertile" })) bonus += 5;
            if (HasTrait(pActor, "strong", new[] { "强壮", "Strong" })) bonus += 5;
            if (HasTrait(pActor, "giant", new[] { "巨大", "Giant" })) bonus += 15;
            return bonus;
        }

        private static bool HasTrait(Actor pActor, string pId, string[] pNames) {
            if (pActor.traits == null) return false;
            foreach (ActorTrait t in pActor.traits) {
                if (t == null) continue;
                if (!string.IsNullOrEmpty(t.id) && t.id == pId) return true;
                string n = t.getTranslatedName();
                if (!string.IsNullOrEmpty(n)) {
                    foreach (string name in pNames) {
                        if (n.Contains(name)) return true;
                    }
                }
            }
            return false;
        }

        private static string GetBloodType(System.Random pRng) {
            string[] abo = { BioText.T("bio_abo_a", "A型"), BioText.T("bio_abo_b", "B型"),
                BioText.T("bio_abo_ab", "AB型"), BioText.T("bio_abo_o", "O型") };
            string t = abo[pRng.Next(0, abo.Length)];
            string rh = pRng.Next(0, 6) == 0 ? BioText.T("bio_rh_neg", "Rh阴性") : BioText.T("bio_rh_pos", "Rh阳性");
            return BioText.F("bio_blood_type", "血型: {0} ({1})", t, rh);
        }

        // 大脑:法力值与大脑健康挂钩(法力上限 × 大脑百分比)
        private static string GetBrainInfo(Actor pActor, System.Random pRng) {
            float brainPct = 1f;
            try {
                BodyHealth body = HealthSimulator.Simulate(pActor);
                foreach (OrganHealth oh in body.Organs) {
                    if (oh.Def.Id == "brain") {
                        brainPct = Mathf.Clamp01(oh.Hp / 100f);
                        break;
                    }
                }
            } catch {
            }
            float maxMana = 0f;
            try { maxMana = pActor.getMaxMana(); } catch { }
            float effectiveMana = maxMana * brainPct;
            int iq = 85 + pRng.Next(0, 61);
            return BioText.F("bio_brain", "智商: {0}\n脑容量: {1} ml\n法力: {2} / {3}({4}%)",
                iq, rng2(1250, 1500, pRng), Mathf.RoundToInt(effectiveMana), Mathf.RoundToInt(maxMana),
                Mathf.RoundToInt(brainPct * 100f));
        }

        // 皮肤:显示体温,炽热/燃烧之血等特质会拉高体温,寒冷特质降低体温
        private static string GetSkinInfo(Actor pActor, System.Random pRng) {
            float temp = 36.5f;
            bool hot = HasTrait(pActor, "fire_blood", new[] { "燃烧之血", "Fire Blood" })
                || HasTrait(pActor, "burning_feet", new[] { "炽热", "Hot Feet", "Burning Feet" })
                || HasTrait(pActor, "acid_blood", new[] { "蚀骨之血", "Acid Blood" })
                || HasTrait(pActor, "poisonous", new[] { "剧毒", "Poisonous" });
            if (hot) {
                temp += 2f + pRng.Next(0, 3); // 炽热特质:体温 +2~4℃
            }
            bool cold = HasTrait(pActor, "cold_aura", new[] { "寒冷", "Cold Aura", "寒冰" });
            if (cold) {
                temp -= 2f + pRng.Next(0, 3); // 寒冷特质:体温 -2~4℃
            }
            bool fever = HasTrait(pActor, "infected", new[] { "感染", "Infected", "丧尸化" });
            if (fever) temp += 1f + (float)pRng.NextDouble();
            return BioText.F("bio_skin", "体温: {0} ℃\n肤质评分: {1}/100", temp.ToString("0.0"), pRng.Next(60, 100));
        }

        private static int rng2(int pMin, int pMax, System.Random pRng) {
            return pRng.Next(pMin, pMax);
        }

        private static string GetVision(System.Random pRng) {
            int v = 45 + pRng.Next(0, 9);
            return (v / 10.0).ToString("0.0");
        }

        private static bool HasSterile(Actor pActor) {
            if (pActor.traits == null) return false;
            foreach (ActorTrait t in pActor.traits) {
                if (t == null) continue;
                if (!string.IsNullOrEmpty(t.id) && (t.id == "sterile" || t.id == "infertile")) return true;
                string n = t.getTranslatedName();
                if (!string.IsNullOrEmpty(n) &&
                    (n.Contains("不孕") || n.Contains("绝后") || n.Contains("Sterile") || n.Contains("Infertile"))) {
                    return true;
                }
            }
            return false;
        }
    }
}
