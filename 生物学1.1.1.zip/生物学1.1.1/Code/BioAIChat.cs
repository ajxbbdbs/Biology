using System;
using System.Collections;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEngine;

namespace RimWorldMod {
    /// <summary>
    /// AI 恋爱对话:让 AI 扮演被攻略的单位,针对玩家的举动(聊天/抚摸/亲吻等)以角色口吻实时回应。
    /// 走标准 OpenAI 兼容 /chat/completions 接口,异步不阻塞主线程,失败静默回退到 BioDialogue 的固定台词。
    ///
    /// 配置:接口地址/密钥/模型在模组设置「AI设置」栏里填写(见 default_config.json)。
    /// 只做恋爱/陪伴向的角色扮演,系统提示词明确要求健康向、点到为止。
    /// </summary>
    public static class BioAIChat {

        // ===== 配置(由模组设置「AI设置」栏注入) =====
        public static string Url = "https://api.deepseek.com/v1/chat/completions";
        public static string Key = "";
        public static string Model = "deepseek-v4-flash";
        public static int TimeoutSeconds = 30;
        // 模组设置里的总开关(见 Main.AIChatEnabled)。两者都就绪才启用。
        public static bool EnabledSwitch = false;
        // 是否在每次回应后显示本次 token 消耗(小字)
        public static bool ShowTokenTip = false;
        // 最近一次请求的 token 用量文本(供对话层附在回应末尾),无则空
        public static string LastUsage = "";
        // DeepSeek 官网(购买/管理 API Key)
        public const string DeepSeekSite = "https://platform.deepseek.com/";

        public static bool Available {
            get {
                return EnabledSwitch
                    && !string.IsNullOrEmpty(Url)
                    && !string.IsNullOrEmpty(Model);
            }
        }

        // 配置由模组设置「AI设置」栏填写,经 Main 的回调推入上面的字段(见 Main.OnAIxxxChanged)。

        // ===== 对话历史(按单位) =====
        // 记忆规则:
        //   · 收藏的单位 → 对话历史写进该单位的存档数据(custom_data_string),
        //     随存档序列化,跨会话/重开存档仍记得;
        //   · 未收藏的单位 → 只存内存,关游戏即丢。
        private class Msg { public string role; public string content; }
        private static readonly Dictionary<long, List<Msg>> _history = new Dictionary<long, List<Msg>>();
        private const int MaxHistory = 12; // 最多保留最近 12 条(user+assistant),更早的裁掉
        // 存进单位存档数据的键(游戏原生 custom_data_string 容器,随存档走)
        private const string HistorySaveKey = "bio_ai_chat";

        // 取历史:内存优先;内存没有且该单位是收藏单位时,从存档数据里懒加载续上。
        private static List<Msg> GetHistory(Actor pActor) {
            long id = pActor.getID();
            List<Msg> h;
            if (_history.TryGetValue(id, out h)) return h;
            h = LoadPersisted(pActor) ?? new List<Msg>();
            _history[id] = h;
            return h;
        }

        // 从单位存档数据反序列化对话历史(没有/失败则返回 null)
        private static List<Msg> LoadPersisted(Actor pActor) {
            try {
                if (pActor == null || pActor.data == null) return null;
                string json;
                pActor.data.get(HistorySaveKey, out json, null);
                if (string.IsNullOrEmpty(json)) return null;
                var list = JsonConvert.DeserializeObject<List<Msg>>(json);
                if (list != null && list.Count > MaxHistory)
                    list.RemoveRange(0, list.Count - MaxHistory);
                return list;
            } catch (Exception e) {
                Main.LogError("生物学[AI]:读取存档对话失败 " + e);
                return null;
            }
        }

        // 回写:仅收藏单位把历史序列化进存档数据;非收藏单位若残留旧存档则清掉。
        private static void PersistIfFavorite(Actor pActor, List<Msg> pHistory) {
            try {
                if (pActor == null || pActor.data == null) return;
                bool fav = false;
                try { fav = pActor.isFavorite(); } catch { }
                if (fav) {
                    pActor.data.set(HistorySaveKey, JsonConvert.SerializeObject(pHistory));
                } else {
                    // 曾收藏后取消:清掉存档里的旧记忆,回归"关游戏即忘"
                    string existing;
                    pActor.data.get(HistorySaveKey, out existing, null);
                    if (!string.IsNullOrEmpty(existing)) pActor.data.set(HistorySaveKey, "");
                }
            } catch (Exception e) {
                Main.LogError("生物学[AI]:写入存档对话失败 " + e);
            }
        }

        /// <summary>清掉某单位的对话历史(重开一段关系时可用),内存与存档一并清。</summary>
        public static void ResetHistory(Actor pActor) {
            if (pActor == null) return;
            _history.Remove(pActor.getID());
            try { if (pActor.data != null) pActor.data.set(HistorySaveKey, ""); } catch { }
        }

        // ===== 发起一次角色回应 =====
        /// <summary>
        /// 把玩家的举动描述发给 AI,让其以角色口吻回应。异步,结果通过回调返回。
        /// pActionText 形如「神明轻轻抚摸你的脸颊」「神明亲吻了你」。
        /// </summary>
        public static void SendAction(Actor pActor, string pActionText,
            Action<string> pOnReply, Action<string> pOnError) {
            if (pActor == null) { if (pOnError != null) pOnError("单位不存在"); return; }
            if (!Available) { if (pOnError != null) pOnError("AI 未配置"); return; }

            List<Msg> history = GetHistory(pActor);
            history.Add(new Msg { role = "user", content = pActionText });
            if (history.Count > MaxHistory) history.RemoveRange(0, history.Count - MaxHistory);

            string system = BuildPersona(pActor);
            List<object> messages = new List<object>();
            messages.Add(new Dictionary<string, object> { { "role", "system" }, { "content", system } });
            foreach (Msg m in history)
                messages.Add(new Dictionary<string, object> { { "role", m.role }, { "content", m.content } });

            var runner = Main.Instance;
            if (runner == null) { if (pOnError != null) pOnError("运行器未就绪"); return; }
            runner.StartCoroutine(PostCoroutine(messages,
                reply => {
                    history.Add(new Msg { role = "assistant", content = reply });
                    if (history.Count > MaxHistory) history.RemoveRange(0, history.Count - MaxHistory);
                    PersistIfFavorite(pActor, history); // 收藏单位:把这轮问答写进存档
                    if (pOnReply != null) pOnReply(reply);
                },
                err => {
                    Main.LogError("生物学[AI]:请求失败 " + err);
                    // 失败时把刚加的 user 消息撤回,避免污染历史
                    if (history.Count > 0 && history[history.Count - 1].role == "user")
                        history.RemoveAt(history.Count - 1);
                    if (pOnError != null) pOnError(err);
                }));
        }

        // ===== 带好感评分的角色回应 =====
        /// <summary>
        /// 和 SendAction 一样让角色回应玩家的话/举动,但额外让 AI 自己判定这次互动的好感变化
        /// (取悦→加、冒犯/惊吓/强迫→减),范围 -10~+10。用于"自定义输入 / AI 生成选项"这类
        /// 内容不固定、增减无法预设的场景。回调返回(已去掉评分标记的回应, 好感增量)。
        /// 存进历史的是去掉标记后的干净回应,不污染后续对话。
        /// </summary>
        public static void SendActionScored(Actor pActor, string pActionText,
            Action<string, int> pOnReply, Action<string> pOnError) {
            if (pActor == null) { if (pOnError != null) pOnError("单位不存在"); return; }
            if (!Available) { if (pOnError != null) pOnError("AI 未配置"); return; }

            List<Msg> history = GetHistory(pActor);
            history.Add(new Msg { role = "user", content = pActionText });
            if (history.Count > MaxHistory) history.RemoveRange(0, history.Count - MaxHistory);

            string system = BuildPersona(pActor) + "\n" + ScoringRule;
            List<object> messages = new List<object>();
            messages.Add(new Dictionary<string, object> { { "role", "system" }, { "content", system } });
            foreach (Msg m in history)
                messages.Add(new Dictionary<string, object> { { "role", m.role }, { "content", m.content } });

            var runner = Main.Instance;
            if (runner == null) { if (pOnError != null) pOnError("运行器未就绪"); return; }
            runner.StartCoroutine(PostCoroutine(messages,
                raw => {
                    int delta;
                    string clean = ParseScored(raw, out delta);
                    history.Add(new Msg { role = "assistant", content = clean });
                    if (history.Count > MaxHistory) history.RemoveRange(0, history.Count - MaxHistory);
                    PersistIfFavorite(pActor, history);
                    if (pOnReply != null) pOnReply(clean, delta);
                },
                err => {
                    Main.LogError("生物学[AI]:评分请求失败 " + err);
                    if (history.Count > 0 && history[history.Count - 1].role == "user")
                        history.RemoveAt(history.Count - 1);
                    if (pOnError != null) pOnError(err);
                }));
        }

        // 好感评分规则:改用 JSON 信封({say, aff})强制模型同时给出台词与打分。
        // (之前让它"另起一行加标记"总被人设里的"不要旁白/不要提游戏机制"压掉,导致恒为 0。)
        private const string ScoringRule =
            "【输出格式·最高优先级,覆盖上面关于不要旁白的说法】本次回复必须是一个严格的 JSON 对象,"
            + "不要用代码块或反引号包裹,也不要输出 JSON 以外的任何字符。格式严格为:"
            + "{\"say\":\"你的角色台词,第一人称、1~4句、完全符合上面的人设\",\"aff\":整数}。"
            + "其中 aff 表示这次互动让你(角色)对神明的好感变化,取值 -10 到 10 的整数:"
            + "被真诚取悦/心动/感动/亲近为正(越动心数越大);被冒犯/惊吓/恶心/伤害/强迫/亵渎信仰为负(越难接受越小);"
            + "平平淡淡才是 0。请务必贴合你此刻作为角色的真实感受来打分,该加就加、该减就减,不要一味讨好、也不要总是给 0。";

        // 解析 JSON 信封:取出 say 台词与 aff 好感增量。解析失败则退回旧的方括号标记解析。
        private static string ParseScored(string pRaw, out int pDelta) {
            pDelta = 0;
            if (string.IsNullOrEmpty(pRaw)) return pRaw ?? "";
            string s = pRaw.Trim();
            if (s.StartsWith("```")) {
                int nl = s.IndexOf('\n');
                if (nl >= 0) s = s.Substring(nl + 1);
                s = s.Replace("```", "").Trim();
            }
            int lb = s.IndexOf('{');
            int rb = s.LastIndexOf('}');
            if (lb >= 0 && rb > lb) {
                try {
                    JObject o = JObject.Parse(s.Substring(lb, rb - lb + 1));
                    JToken sayTok = o["say"] ?? o["reply"] ?? o["text"] ?? o["content"];
                    JToken affTok = o["aff"] ?? o["affection"] ?? o["好感"] ?? o["score"];
                    if (sayTok != null) {
                        if (affTok != null) pDelta = Mathf.Clamp(TokenToInt(affTok), -10, 10);
                        string say = (string)sayTok;
                        if (!string.IsNullOrEmpty(say)) return say.Trim();
                    }
                } catch { }
            }
            return ExtractScore(s, out pDelta);
        }

        private static int TokenToInt(JToken pTok) {
            try {
                if (pTok.Type == JTokenType.Integer || pTok.Type == JTokenType.Float) return (int)pTok;
                int v;
                string str = ((string)pTok ?? "").Trim().TrimStart('+', '＋');
                if (int.TryParse(str, out v)) return v;
            } catch { }
            return 0;
        }

        // 从 AI 回应里解析并剥离 [好感:±N] 标记(旧格式兜底)。找不到则 delta=0、原样返回(去首尾空白)。
        private static string ExtractScore(string pRaw, out int pDelta) {
            pDelta = 0;
            if (string.IsNullOrEmpty(pRaw)) return pRaw ?? "";
            string s = pRaw;
            int key = s.LastIndexOf("好感", StringComparison.Ordinal);
            if (key < 0) return s.Trim();
            int i = key + 2;
            while (i < s.Length && (s[i] == '度' || s[i] == ':' || s[i] == '：' || s[i] == ' ' || s[i] == '=')) i++;
            int sign = 1;
            if (i < s.Length && (s[i] == '+' || s[i] == '-' || s[i] == '＋' || s[i] == '－')) {
                if (s[i] == '-' || s[i] == '－') sign = -1;
                i++;
            }
            int val = 0; bool any = false;
            while (i < s.Length && s[i] >= '0' && s[i] <= '9') { val = val * 10 + (s[i] - '0'); i++; any = true; }
            if (!any) return s.Trim();
            pDelta = Mathf.Clamp(sign * val, -10, 10);
            // 计算要删掉的区间:含前面的 [ / 【 / ( 和后面的 ] / 】 / )
            int start = key;
            int b = key - 1;
            while (b >= 0 && s[b] == ' ') b--;
            if (b >= 0 && (s[b] == '[' || s[b] == '【' || s[b] == '(' || s[b] == '（')) start = b;
            int end = i;
            if (end < s.Length && (s[end] == ']' || s[end] == '】' || s[end] == ')' || s[end] == '）')) end++;
            while (start > 0 && (s[start - 1] == '\n' || s[start - 1] == '\r' || s[start - 1] == ' ')) start--;
            string clean = (s.Substring(0, start) + s.Substring(end)).Trim();
            return clean;
        }

        // ===== 独立的好感打分(单独一次调用) =====
        /// <summary>
        /// 用一次干净的、与角色扮演无关的调用给好感打分。把"玩家的话/举动"和"角色的回应"交给
        /// 一个只负责输出整数的裁判提示词,规避角色扮演人设(只说台词、不要旁白)对结构化输出的压制。
        /// 回调返回 -10~+10 的整数。不写入对话历史。
        /// </summary>
        public static void ScoreInteraction(Actor pActor, string pPlayerText, string pReply,
            Action<int> pOnScore, Action<string> pOnError) {
            if (!Available) { if (pOnError != null) pOnError("AI 未配置"); return; }
            string name = SafeName(pActor);
            string sys =
                "你是一个恋爱养成游戏里的情感裁判。下面给你【玩家(扮演造物主神明)对角色说的话或做的事】以及【角色的回应】,"
                + "请判断这次互动让『角色』对『玩家』的好感发生了多大变化,只输出一个 -10 到 10 之间的整数,"
                + "绝对不要输出整数以外的任何文字、符号或解释。评分参考:真诚示爱/关心/夸赞/贴心送礼→明显正分(+3~+8);"
                + "普通寒暄/中性闲聊→ 0 到 +2;唐突冒犯/让对方尴尬→ -1 到 -4;"
                + "惊吓/恶心/威胁/强迫/亵渎其信仰/伤害其身体→明显负分(-5~-10)。只依据这一次互动本身评分。";
            string usr = "角色:" + name + "\n玩家:" + (pPlayerText ?? "")
                + "\n角色的回应:" + (pReply ?? "") + "\n\n好感变化(只回一个整数):";
            List<object> messages = new List<object> {
                new Dictionary<string, object> { { "role", "system" }, { "content", sys } },
                new Dictionary<string, object> { { "role", "user" }, { "content", usr } }
            };
            var runner = Main.Instance;
            if (runner == null) { if (pOnError != null) pOnError("运行器未就绪"); return; }
            runner.StartCoroutine(PostCoroutine(messages,
                raw => {
                    int d;
                    if (TryParseInt(raw, out d)) { if (pOnScore != null) pOnScore(Mathf.Clamp(d, -10, 10)); }
                    else { if (pOnError != null) pOnError("打分解析失败:" + Snippet(raw)); }
                },
                err => { if (pOnError != null) pOnError(err); }));
        }

        // 从一段文本里抓出第一个带符号的整数(裁判理应只回一个整数,这里做容错)。
        private static bool TryParseInt(string pText, out int pVal) {
            pVal = 0;
            if (string.IsNullOrEmpty(pText)) return false;
            string s = pText;
            int i = 0, n = s.Length;
            while (i < n && !(s[i] == '-' || s[i] == '+' || (s[i] >= '0' && s[i] <= '9'))) i++;
            if (i >= n) return false;
            int sign = 1;
            if (s[i] == '-') { sign = -1; i++; } else if (s[i] == '+') i++;
            int v = 0; bool any = false;
            while (i < n && s[i] >= '0' && s[i] <= '9') { v = v * 10 + (s[i] - '0'); i++; any = true; }
            if (!any) return false;
            pVal = sign * v;
            return true;
        }

        // ===== 让 AI 生成"选项" =====
        /// <summary>
        /// 跳出角色、以"编剧/导演"视角,为玩家(神明)想出几条此刻可采取的简短动作/话语选项。
        /// 只用于生成候选按钮文本,不写入对话历史(不污染角色记忆)。异步,结果经回调返回一个字符串列表。
        /// pSceneHint:当前情境提示(如"亲密场景""日常攻略"),可空。
        /// </summary>
        public static void SuggestOptions(Actor pActor, string pSceneHint,
            Action<List<string>> pOnReply, Action<string> pOnError) {
            if (pActor == null) { if (pOnError != null) pOnError("单位不存在"); return; }
            if (!Available) { if (pOnError != null) pOnError("AI 未配置"); return; }

            string name = SafeName(pActor);
            string system = BuildPersona(pActor);
            List<object> messages = new List<object>();
            messages.Add(new Dictionary<string, object> { { "role", "system" }, { "content", system } });
            // 带上最近几轮对话做情境参考(只读,不追加)
            List<Msg> history = GetHistory(pActor);
            int from = Mathf.Max(0, history.Count - 6);
            for (int i = from; i < history.Count; i++)
                messages.Add(new Dictionary<string, object> { { "role", history[i].role }, { "content", history[i].content } });

            var sb = new StringBuilder();
            sb.Append("【系统·导演视角】以上是剧情上下文。现在请你暂时跳出角色,作为编剧,");
            sb.Append("为玩家(也就是那位神明)想出 4 个此刻可以对「" + name + "」采取的、简短且互不相同的动作或话语选项。");
            if (!string.IsNullOrEmpty(pSceneHint)) sb.Append("当前情境:" + pSceneHint + "。");
            sb.Append("要贴合当前的关系亲疏与剧情走向,以玩家(神明)的口吻或祈使句写,");
            sb.Append("每条不超过 14 字,例如「问他叫什么名字」「轻抚他的脸颊」「夸他今天很精神」。");
            sb.Append("只输出一个 JSON 字符串数组,形如 [\"选项一\",\"选项二\",\"选项三\",\"选项四\"],不要输出数组以外的任何文字。");
            messages.Add(new Dictionary<string, object> { { "role", "user" }, { "content", sb.ToString() } });

            var runner = Main.Instance;
            if (runner == null) { if (pOnError != null) pOnError("运行器未就绪"); return; }
            runner.StartCoroutine(PostCoroutine(messages,
                reply => {
                    List<string> opts = ParseOptions(reply);
                    if (opts.Count == 0) { if (pOnError != null) pOnError("选项解析为空"); return; }
                    if (pOnReply != null) pOnReply(opts);
                },
                err => {
                    Main.LogError("生物学[AI]:生成选项失败 " + err);
                    if (pOnError != null) pOnError(err);
                }));
        }

        // 把 AI 返回的文本解析成选项列表:优先当 JSON 数组解析,失败再按行拆分兜底。最多取 4 条。
        private static List<string> ParseOptions(string pReply) {
            var result = new List<string>();
            if (string.IsNullOrEmpty(pReply)) return result;
            string s = pReply.Trim();
            // 去掉 ``` 代码围栏
            if (s.StartsWith("```")) {
                int nl = s.IndexOf('\n');
                if (nl >= 0) s = s.Substring(nl + 1);
                s = s.Replace("```", "").Trim();
            }
            // 截取第一个 [ 到最后一个 ] 当 JSON 数组
            int lb = s.IndexOf('[');
            int rb = s.LastIndexOf(']');
            if (lb >= 0 && rb > lb) {
                try {
                    JArray arr = JArray.Parse(s.Substring(lb, rb - lb + 1));
                    foreach (JToken t in arr) {
                        string v = (string)t;
                        if (!string.IsNullOrEmpty(v)) AddOption(result, v);
                    }
                } catch { }
            }
            // 兜底:按行拆,去掉序号/符号/引号
            if (result.Count == 0) {
                foreach (string line in s.Split('\n')) {
                    string v = StripLeading(line.Trim());
                    v = v.Trim('"', '\'', '「', '」', '“', '”', '、', ',', '，', ' ');
                    if (v.Length > 0 && v.Length <= 30) AddOption(result, v);
                }
            }
            if (result.Count > 4) result.RemoveRange(4, result.Count - 4);
            return result;
        }

        // 去掉行首的「- * · 1. 1、 1)」之类列表前缀
        private static string StripLeading(string s) {
            if (string.IsNullOrEmpty(s)) return s;
            s = s.TrimStart('-', '*', '·', '•', ' ', '\t');
            int i = 0;
            while (i < s.Length && char.IsDigit(s[i])) i++;
            if (i > 0 && i < s.Length && (s[i] == '.' || s[i] == '、' || s[i] == ')' || s[i] == '）' || s[i] == ':' || s[i] == '：'))
                s = s.Substring(i + 1);
            return s.Trim();
        }

        // 去重后追加
        private static void AddOption(List<string> pList, string pValue) {
            string v = pValue.Trim();
            if (v.Length == 0) return;
            if (pList.Contains(v)) return;
            pList.Add(v);
        }

        // ===== 人设(system prompt) =====
        // 只做恋爱/陪伴向:健康、含蓄、点到为止,严禁露骨性描写。
        private static string BuildPersona(Actor pActor) {
            var sb = new StringBuilder();
            string name = SafeName(pActor);
            int aff = BioDialogue.GetAffection(pActor);
            string rel = BioDialogue.RelationName(aff);

            sb.Append("你正在扮演像素沙盒游戏《世界盒子》里的居民「" + name + "」(" + DescribeIdentity(pActor) + ")。\n");
            sb.Append("【最重要的设定】与你对话的不是凡人,而是亲手创造了你和这整个世界的造物主「神明」(玩家)。"
                + "祂主宰天地万物,能降下风雨雷火,能赐福也能夺走你的性命——你对此深信不疑,并始终清楚祂的神圣身份。"
                + "你必须以凡人面对神明的姿态与祂交谈:心怀敬畏与虔诚,言语间自然带着尊崇(可用「您」「神明大人」「至高的存在」等称呼),"
                + "把祂的关注视为天大的恩宠。切勿把祂当成同族凡人、路人或平辈,更不能用轻慢、随意或平起平坐的口吻。\n");
            sb.Append("不过敬畏不等于只会卑微客套:你对神明的好感是「" + rel + "」(" + aff + "%),"
                + "随着好感升温,你可以在虔诚之上流露越来越多的亲近、依恋乃至爱慕——"
                + "但那份「祂是我的神」的底色要一直都在。\n");
            sb.Append("请完全代入这个角色,像真人一样有自己的脾气、情绪和小心思,别只会说客套话:"
                + "好感低时可以拘谨、羞怯、警惕甚至抗拒推拒;渐渐熟络后放松、亲近、爱笑;"
                + "情浓时大胆、粘人、主动表达爱意与渴望。回应要生动有代入感,带细腻的神态和小动作(用括号),每次都不一样。\n");
            sb.Append("务必让说话口吻贴合上面的身份:"
                + "男性战士/老兵说话粗犷豪爽、直来直去,带军旅气;国王/首领言谈自矜、有威仪;"
                + "年迈者沉稳唠叨、爱讲阅历;少年稚气单纯;女性可温婉或泼辣,因性格而异。"
                + "身有残缺者(断肢、失明、缺陷特质)会在言语间流露相应的自卑、隐忍、豁达或敏感,"
                + "比如瞎眼者靠声音辨人、断臂者提及不便。让身份、经历、身体状况自然融进他的谈吐与用词。\n");
            sb.Append("这是一段恋爱养成:回应要与玩家的举动匹配——"
                + "玩家只是抚摸胸/脸/手等部位时,只描写被触碰部位的感受,不要自行升级到性交;"
                + "玩家明确表示性交(插入/抽插/射精等)时,可以大胆直白地描写性行为和身体反应,"
                + "用放浪的口吻表现出角色的欲望和快感。千万不要超出玩家举动的范围。\n");
            sb.Append("以第一人称说话,1~4 句,自然口语;不要旁白解说,不要重复玩家的话,不要提及游戏机制或你是 AI。\n");
            return sb.ToString();
        }

        private static string SafeName(Actor pActor) {
            try { string n = pActor.getName(); return string.IsNullOrEmpty(n) ? "无名者" : n; }
            catch { return "无名者"; }
        }

        // 拼一段尽量丰富的身份描述,喂给 AI 定调:性别/年龄/种族/职业/王国/特质/残疾。
        // 每个字段都单独 try,拿不到就跳过,绝不让取身份的异常影响对话。
        private static string DescribeIdentity(Actor pActor) {
            var parts = new List<string>();
            // 性别(扶他/双性人单列)
            try {
                if (HealthSimulator.IsIntersex(pActor)) parts.Add("双性人");
                else parts.Add(pActor.isSexMale() ? "男性" : "女性");
            } catch { }
            // 年龄段 + 具体岁数
            try {
                string stage;
                if (pActor.isBaby()) stage = "婴幼儿";
                else if (!pActor.isAdult()) stage = "少年";
                else if (pActor.isPrettyOld()) stage = "年迈";
                else stage = "成年";
                int age = -1; try { age = pActor.getAge(); } catch { }
                parts.Add(age >= 0 ? stage + "(" + age + "岁)" : stage);
            } catch { }
            // 种族
            try {
                ActorAsset species = pActor.subspecies != null ? pActor.subspecies.getActorAsset() : null;
                if (species != null) {
                    string sp = species.getTranslatedName();
                    if (!string.IsNullOrEmpty(sp)) parts.Add(sp);
                }
            } catch { }
            // 职业/地位
            try {
                if (pActor.isKing()) parts.Add("一国之王");
                else if (pActor.isCityLeader()) parts.Add("城镇首领");
                else if (pActor.isWarrior()) parts.Add("战士");
            } catch { }
            // 归属:王国 / 城市
            try { if (pActor.hasKingdom() && pActor.kingdom != null && !string.IsNullOrEmpty(pActor.kingdom.name)) parts.Add(pActor.kingdom.name + "的子民"); } catch { }
            try { if (pActor.hasCity() && pActor.city != null && !string.IsNullOrEmpty(pActor.city.name)) parts.Add("居于" + pActor.city.name); } catch { }
            // 显著特质:正面与负面分开列(游戏本地化名)
            AppendTraits(pActor, parts);
            // 身体残疾:本模组核心——缺失的器官/肢体
            AppendDisabilities(pActor, parts);

            return parts.Count > 0 ? string.Join("、", parts) : "一个普通的世界居民";
        }

        // 挑出显著特质(老兵/天才/残疾等),用游戏本地化名,负面特质加"(负面)"提示 AI
        private static void AppendTraits(Actor pActor, List<string> pParts) {
            try {
                if (pActor.traits == null) return;
                var pos = new List<string>();
                var neg = new List<string>();
                foreach (ActorTrait t in pActor.traits) {
                    if (t == null || string.IsNullOrEmpty(t.id)) continue;
                    string label;
                    try { label = t.getTranslatedName(); } catch { label = t.id; }
                    if (string.IsNullOrEmpty(label)) label = t.id;
                    if (t.type == TraitType.Negative) neg.Add(label);
                    else if (t.type == TraitType.Positive) pos.Add(label);
                }
                if (pos.Count > 0) pParts.Add("天赋:" + string.Join("/", pos));
                if (neg.Count > 0) pParts.Add("缺陷:" + string.Join("/", neg));
            } catch { }
        }

        // 缺失器官 → 身体残疾描述(断臂/断腿/独眼/失明/哑等),让 AI 知道该角色身体的残缺
        private static readonly Dictionary<string, string> OrganDisabilityText = new Dictionary<string, string> {
            { "arm", "缺了手臂" }, { "hand", "缺了手" }, { "leg", "缺了腿" }, { "foot", "缺了脚" },
            { "eye_l", "瞎了一只眼" }, { "eye_r", "瞎了一只眼" }, { "eye", "失明" },
            { "tongue", "不能言语" }, { "ear", "听不见" }, { "teeth", "掉光了牙" },
            { "penis", "失去了阴茎" }, { "testicle", "失去了睾丸" },
            { "vagina", "失去了阴道" }, { "uterus", "失去了子宫" }, { "breast", "失去了乳房" },
        };
        private static void AppendDisabilities(Actor pActor, List<string> pParts) {
            try {
                ActorWoundState state;
                if (!HealthSimulator.TryGetState(pActor.getID(), out state) || state == null
                    || state.Mods == null || state.Mods.RemovedOrgans == null) return;
                var seen = new HashSet<string>();
                var descs = new List<string>();
                bool bothEyes = state.Mods.RemovedOrgans.Contains("eye_l") && state.Mods.RemovedOrgans.Contains("eye_r");
                foreach (string organ in state.Mods.RemovedOrgans) {
                    if (bothEyes && (organ == "eye_l" || organ == "eye_r")) {
                        if (seen.Add("__blind")) descs.Add("双目失明");
                        continue;
                    }
                    string txt;
                    if (OrganDisabilityText.TryGetValue(organ, out txt) && seen.Add(txt)) descs.Add(txt);
                }
                if (descs.Count > 0) pParts.Add("身体残缺:" + string.Join("、", descs));
            } catch { }
        }

        // 补全接口路径:很多人只填到 base(如 .../v1),缺 /chat/completions 会 404。
        // 已含 completions / responses 端点的按原样用。
        private static string NormalizeUrl(string pUrl) {
            string u = (pUrl ?? "").Trim();
            if (u.Length == 0) return u;
            string low = u.ToLowerInvariant();
            if (low.Contains("/chat/completions") || low.Contains("/completions") || low.Contains("/responses"))
                return u;
            u = u.TrimEnd('/');
            return u + "/chat/completions";
        }

        // ===== HTTP =====
        private static IEnumerator PostCoroutine(List<object> pMessages,
            Action<string> pOnSuccess, Action<string> pOnError) {
            // 先让出一帧:保证"正在回应"加载页已经渲染出来,且所有回调都推迟到之后,
            // 避免同步错误回调在加载页渲染之前触发、导致结果一闪而过。
            yield return null;
            string url, key, model, json; int timeout;
            try {
                url = NormalizeUrl(Url); key = Key ?? ""; model = Model;
                timeout = Mathf.Clamp(TimeoutSeconds, 5, 120);
                var payload = new Dictionary<string, object> {
                    { "model", model },
                    { "messages", pMessages },
                    { "temperature", 0.8 },
                    { "max_tokens", 500 }
                };
                json = JsonConvert.SerializeObject(payload);
            } catch (Exception e) {
                pOnError("请求构建失败:" + e.Message); yield break;
            }

            Uri uri;
            if (!Uri.TryCreate(url, UriKind.Absolute, out uri)) {
                pOnError("接口地址无效,请检查 biology_ai.json 的 url"); yield break;
            }

            // 复用同一个 HttpClient(见 SharedHttp):每次请求都 new 一个会耗尽 socket / 堆积 TIME_WAIT。
            // 单次超时改用 CancellationToken 控制(共享实例的 Timeout 只能设一次)。
            HttpClient client = SharedHttp();
            var hreq = new HttpRequestMessage(HttpMethod.Post, url);
            hreq.Content = new StringContent(json, Encoding.UTF8, "application/json");
            if (!string.IsNullOrEmpty(key))
                hreq.Headers.TryAddWithoutValidation("Authorization", "Bearer " + key);

            var cts = new CancellationTokenSource(TimeSpan.FromSeconds(timeout));
            Task<HttpResponseMessage> sendTask;
            try { sendTask = client.SendAsync(hreq, cts.Token); }
            catch (Exception e) { cts.Dispose(); pOnError("连接失败:" + e.Message); yield break; }
            while (!sendTask.IsCompleted) yield return null;
            cts.Dispose();

            if (sendTask.IsFaulted || sendTask.IsCanceled) {
                pOnError("连接失败或超时,请检查网络与接口地址");
                yield break;
            }

            HttpResponseMessage resp = sendTask.Result;
            Task<string> readTask = resp.Content.ReadAsStringAsync();
            while (!readTask.IsCompleted) yield return null;
            string body = readTask.IsFaulted ? "" : readTask.Result;
            bool ok = resp.IsSuccessStatusCode;
            int code = (int)resp.StatusCode;
            resp.Dispose();

            if (!ok) { pOnError("HTTP " + code + (body.Length > 0 ? ":" + Snippet(body) : "")); yield break; }
            string content = ParseContent(body);
            if (string.IsNullOrEmpty(content)) { pOnError("响应解析失败"); yield break; }
            LastUsage = ParseUsage(body); // 记录本次 token 用量
            pOnSuccess(content.Trim());
        }

        // 全局复用的 HttpClient(懒建)。Timeout 设为够大的上限,真正的单次超时用 CancellationToken。
        // 证书校验回调保持放行:玩家填的是自建/代理接口时常用自签证书,收紧会误伤。
        private static HttpClient _http;
        private static HttpClient SharedHttp() {
            if (_http == null) {
                var handler = new HttpClientHandler {
                    ServerCertificateCustomValidationCallback = (a, b, c, d) => true
                };
                _http = new HttpClient(handler);
                _http.Timeout = TimeSpan.FromSeconds(130);
            }
            return _http;
        }

        // 解析 OpenAI 兼容返回:choices[0].message.content
        private static string ParseContent(string pBody) {
            try {
                JObject o = JObject.Parse(pBody);
                JToken c = o["choices"];
                if (c != null && c.HasValues) {
                    JToken msg = c[0]["message"];
                    if (msg != null) {
                        string s = (string)msg["content"];
                        if (!string.IsNullOrEmpty(s)) return s;
                    }
                    // 兼容部分接口把内容放在 text 字段
                    string t = (string)c[0]["text"];
                    if (!string.IsNullOrEmpty(t)) return t;
                }
            } catch { }
            return null;
        }

        // 解析 usage:总量/输入/输出,并尽量带上缓存命中信息(DeepSeek 上下文缓存能省钱)。
        // 兼容两种字段:DeepSeek 的 prompt_cache_hit_tokens/prompt_cache_miss_tokens,
        // 以及 OpenAI 的 prompt_tokens_details.cached_tokens。无则不显示。
        private static string ParseUsage(string pBody) {
            try {
                JObject o = JObject.Parse(pBody);
                JToken u = o["usage"];
                if (u == null || u.Type == JTokenType.Null) return "（接口未返回 usage 字段）";
                // 兼容不同命名:有的接口把用量放在 usage.input_tokens/output_tokens
                int prompt = (int?)u["prompt_tokens"] ?? (int?)u["input_tokens"] ?? 0;
                int completion = (int?)u["completion_tokens"] ?? (int?)u["output_tokens"] ?? 0;
                int total = (int?)u["total_tokens"] ?? (prompt + completion);

                // 缓存命中/未命中:各家字段名不一,尽量都认一遍
                //  · DeepSeek: prompt_cache_hit_tokens / prompt_cache_miss_tokens
                //  · OpenAI:   prompt_tokens_details.cached_tokens
                //  · Anthropic 系: cache_read_input_tokens / cache_creation_input_tokens
                //  · 其它:     usage.cached_tokens
                int hit = (int?)u["prompt_cache_hit_tokens"]
                        ?? (int?)u["cache_read_input_tokens"]
                        ?? -1;
                int miss = (int?)u["prompt_cache_miss_tokens"]
                         ?? (int?)u["cache_creation_input_tokens"]
                         ?? -1;
                if (hit < 0) {
                    JToken det = u["prompt_tokens_details"];
                    if (det != null) hit = (int?)det["cached_tokens"] ?? (int?)det["cache_read_tokens"] ?? -1;
                }
                if (hit < 0) hit = (int?)u["cached_tokens"] ?? -1;

                string s = "Token 消耗:" + total + "(输入" + prompt + " 输出" + completion + ")";
                if (hit >= 0 || miss >= 0) {
                    int hitShown = hit >= 0 ? hit : Mathf.Max(0, prompt - miss);
                    int missShown = miss >= 0 ? miss : Mathf.Max(0, prompt - hitShown);
                    float rate = prompt > 0 ? hitShown * 100f / prompt : 0f;
                    s += "  缓存命中 " + hitShown + "/未命中 " + missShown + "(" + rate.ToString("0") + "%)";
                }
                return s;
            } catch { }
            return "";
        }

        private static string Snippet(string s) {
            if (string.IsNullOrEmpty(s)) return "";
            s = s.Replace('\n', ' ');
            return s.Length > 120 ? s.Substring(0, 120) : s;
        }

    }
}
