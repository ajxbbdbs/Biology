using System.Collections.Concurrent;
using System.Collections.Generic;
using UnityEngine;

namespace RimWorldMod {

    public class DiseaseHit {
        public Disease Def;
        public int Severity;
        public string SourceTrait;
    }

    public class OrganHealth {
        public Organ Def;
        public int Hp;
        public List<DiseaseHit> Diseases = new List<DiseaseHit>();
        public bool IsMissing;
    }

    public class BodyHealth {
        public List<OrganHealth> Organs = new List<OrganHealth>();
        public List<string> Legend = new List<string>();
        public int TotalDiseases;
        public int HealthPercent;
    }

    // 特质引发的"伤口":持久存在、随时间缓缓恢复、特质被移除后立即痊愈(恢复100%)
    public class OrganWound {
        public string TraitKey;
        public string TraitName;
        public Disease Disease;
        public string OrganId;
        public int HpAtDamage;
        public double DamageTime;
        public int RegenPerMonth = 1;
    }

    // 器官编辑器对单位器官的持久修改
    public class ActorMods {
        public HashSet<string> RemovedOrgans = new HashSet<string>();
        public HashSet<string> AddedOrgans = new HashSet<string>();
        public Dictionary<string, int> HpMods = new Dictionary<string, int>();
        // 手术/弱化附加的持久疾病:器官id → 疾病id
        public Dictionary<string, string> ModDiseases = new Dictionary<string, string>();
        // 被侵犯次数:器官id → 次数(仅阴道/肛门等可侵犯器官)
        public Dictionary<string, int> Violations = new Dictionary<string, int>();
        // 肛门实际扩张次数(概率性,非每次侵犯都扩张)
        public int AnalExpansionCount = 0;
        // 高潮次数:被神侵犯或生孩子时有概率增加
        public int OrgasmCount = 0;
        // 撸管次数:男性自慰操作计数(仅阴茎)
        public int MasturbationCount = 0;
        // 射精次数:撸管有概率触发,生孩子必定 +1
        public int EjaculationCount = 0;
        // 好感度(0-100,默认30)
        public int Affection = 30;
        // 神之侵犯致孕:这一胎怀的是神的孩子。真正分娩(原版怀孕状态走完)时才结算,
        // 那一胎走神之子流程 —— 取神名、授特质、加入收藏,见 OrganEditorUI.BirthDivineChild
        public bool DivinePregnancy;
        // 特质导致的全局/器官属性降低百分比:type → 数值 (body=全身, organId=指定器官)
        public Dictionary<string, int> StatPenalties = new Dictionary<string, int>();
        // 弱化到衰竭时已结算过“等同摘除”一次性代价的器官。
        public HashSet<string> FailedOrgans = new HashSet<string>();
        // 当前最终功能为 0 的器官；与一次性后果门闩分离，器官 Hp 恢复后立即清除。
        public HashSet<string> FunctionallyFailedOrgans = new HashSet<string>();
        // 发色档位(小人与立绘共用):-1=未指定(按单位 id 在六色里定死一个)
        // 0=黑 1=暗红 2=黄 3=绿 4=蓝 5=白
        public int HairColor = -1;
        // 关节骨↔体型特质的反向回填做过没有(只做一次,见 OrganEditorUI.SyncBoneTrait)
        public bool BoneSynced;
    }

    public class ActorWoundState {
        public Dictionary<string, OrganWound> Wounds = new Dictionary<string, OrganWound>();
        public ActorMods Mods = new ActorMods();
        public int LastRecalcVersion;
        // 死亡检查节流:世界单位自然死亡检查可能每帧调用,避免重复完整模拟
        public float NextDeathCheck;
    }

    public static class HealthSimulator {

        private const int WoundMaxCount = 4000;

        // 线程安全:原版 precalcMovementSpeed / updateStats 是并行 Job(worker 线程)里调的,
        // 本模组的钩子会在那些线程上读写这张表,普通 Dictionary 并发结构性写会损坏(卡死/异常)。
        // 每个单位只被某一个 worker 线程处理,所以只有"容器本身"需要并发安全,用 ConcurrentDictionary 即可。
        private static readonly ConcurrentDictionary<long, ActorWoundState> _states = new ConcurrentDictionary<long, ActorWoundState>();
        private static readonly string[] HandChain = { "shoulder", "arm", "hand" };
        private static readonly string[] LegChain = { "leg", "foot" };

        // HasAnyState 被大量每单位/每帧的钩子调用(走路/自然死亡/属性/营养…)。
        // 千万不能用 ConcurrentDictionary.Count —— 它会锁住所有分段,几万次/秒从并行线程调会直接锁爆(实测每帧上百 ms)。
        // 用一个只增不减的标志代替:只要加过状态就为 true;整表清空时置 false。本表没有单条移除路径,所以精确。
        private static volatile bool _hasAnyState;
        public static bool HasAnyState { get { return _hasAnyState; } }

        /// <summary>
        /// 该单位是否启用器官系统。模组设置里"启用动物器官"关闭时,只有非动物单位
        /// (人类/精灵/矮人/兽人等文明种族)参与器官模拟,动物一律跳过。
        /// </summary>
        public static bool IsOrganSupported(Actor pActor) {
            if (pActor == null) return false;
            if (Main.AnimalOrgans) return true;
            try { return !pActor.isAnimal(); } catch { return true; }
        }

        /// <summary>
        /// 原版 Actor.isPrettyOld() 内部直接解引用 subspecies,
        /// 对没有亚种的单位(模组自建单位等)每帧都会抛 NullReferenceException:
        /// 日志被刷爆(实测一次游戏 5500+ 条)、整段器官模拟被异常打断。这里加一层保护。
        /// </summary>
        private static bool IsPrettyOldSafe(Actor pActor) {
            try {
                if (pActor == null || !pActor.hasSubspecies()) return false;
                return pActor.isPrettyOld();
            } catch {
                return false;
            }
        }

        public static BodyHealth Simulate(Actor pActor) {
            BodyHealth body = new BodyHealth();
            if (pActor == null) {
                body.HealthPercent = 100;
                return body;
            }
            // 动物器官未启用:不构建任何器官数据(面板会显示提示)
            if (!IsOrganSupported(pActor)) {
                body.HealthPercent = 100;
                return body;
            }

            long actorId = pActor.getID();
            ActorWoundState state = GetOrCreateState(actorId);
            BuildOrgans(pActor, state, body, out Dictionary<string, OrganHealth> byId);

            System.Random rng = new System.Random(pActor.GetHashCode());
            System.Random traitRng = new System.Random(pActor.GetHashCode() ^ 0x5F3759DF);
            float healthRatio = Mathf.Clamp01(pActor.getHealthRatio());
            // 肺/肾摘除:呼吸衰竭/尿毒症 → 整体健康大幅下降
            bool hasRespFailure = false, hasUremia = false, hasParalysis = false;
            string tmpCur;
            if (state.Mods.ModDiseases.TryGetValue("chest", out tmpCur) && tmpCur == "respiratory_failure") hasRespFailure = true;
            if (state.Mods.ModDiseases.TryGetValue("blood", out tmpCur) && tmpCur == "uremia") hasUremia = true;
            if (state.Mods.ModDiseases.TryGetValue("spine", out tmpCur) && tmpCur == "paralysis") hasParalysis = true;
            if (hasRespFailure) healthRatio = Mathf.Min(healthRatio, 0.25f);
            if (hasUremia) healthRatio = Mathf.Min(healthRatio, 0.35f);
            if (hasParalysis) healthRatio = Mathf.Min(healthRatio, 0.45f);
            body.HealthPercent = (int)(healthRatio * 100f);

            HashSet<string> available = new HashSet<string>();
            foreach (KeyValuePair<string, OrganHealth> kv in byId) {
                if (kv.Value != null && !kv.Value.IsMissing) available.Add(kv.Key);
            }
            double curTime = GetWorldTime();

            // ===== 0. 增益特质 → 器官强化(可超过100%) =====
            Dictionary<string, int> boosts = CollectBoosts(pActor, available);

            // ===== 0.5 负面特质 → 属性/器官降低百分比 =====
            Dictionary<string, int> penalties = CollectPenalties(pActor, available);

            // ===== 1. 负面特质 → 绑定疾病(随机器官、持久伤口、随时间恢复) =====
            ApplyTraitWounds(pActor, byId, state, traitRng, curTime, body);

            // ===== 2. 年龄与整体健康带来的随机疾病(临时) =====
            Dictionary<string, List<DiseaseHit>> transient = new Dictionary<string, List<DiseaseHit>>();
            float chance = 0.45f * (1f - healthRatio);
            if (IsPrettyOldSafe(pActor)) chance += 0.25f;
            for (int i = 0; i < 3; i++) {
                if ((float)rng.NextDouble() > chance) continue;
                Disease d = DiseaseLibrary.PickRandomGeneral(rng, available);
                if (d == null) continue;
                // 动物免疫创伤后应激障碍
                if (d.Id == "ptsd" && pActor.isAnimal()) continue;
                ApplyTransient(byId, transient, d, rng.Next(10, 31));
            }

            // ===== 3. 战斗/饥饿造成的通用损伤 + 汇总 =====
            float missing = (1f - healthRatio) * 100f;
            foreach (OrganHealth oh in body.Organs) {
                // 摘除器官保留在显示模型中,但不参与伤口/疾病/强化计算。
                // IsMissing 是唯一的“缺失”判据;存在但 Hp=0 的器官仍是衰竭状态。
                if (oh.IsMissing) {
                    oh.Hp = 0;
                    continue;
                }
                OrganWound w;
                bool hasWound = state.Wounds.TryGetValue(oh.Def.Id, out w);
                int woundHp = hasWound ? GetWoundHp(w, curTime) : 100;

                List<DiseaseHit> tlist;
                transient.TryGetValue(oh.Def.Id, out tlist);

                int tSev = 0;
                if (tlist != null) {
                    foreach (DiseaseHit h in tlist) tSev += h.Severity;
                }

                int boost = 0;
                boosts.TryGetValue(oh.Def.Id, out boost);
                int penalty = 0;
                penalties.TryGetValue(oh.Def.Id, out penalty);
                int hpMod = 0;
                state.Mods.HpMods.TryGetValue(oh.Def.Id, out hpMod);
                float extra = Mathf.Max(0f, missing - tSev) * (0.35f + 0.65f * (float)rng.NextDouble());
                oh.Hp = Mathf.Clamp(woundHp - tSev - (int)extra + boost + hpMod - penalty, 0, 999);

                if (hasWound) {
                    oh.Diseases.Add(new DiseaseHit {
                        Def = w.Disease,
                        Severity = Mathf.Max(0, 100 - woundHp),
                        SourceTrait = w.TraitName
                    });
                }
                if (tlist != null) {
                    oh.Diseases.AddRange(tlist);
                }
            }

            // 最终 Hp 已全部算完后统一同步功能失效。Removed、编辑修正≤-100、最终 Hp≤0
            // 任一命中即失效；最终 Hp 恢复到正数且不存在前两项时自动清除。
            SyncFunctionalFailures(state, body);

            // ===== 4. 手术/弱化附加的持久疾病 =====
            foreach (KeyValuePair<string, string> kv in state.Mods.ModDiseases) {
                OrganHealth oh;
                if (!byId.TryGetValue(kv.Key, out oh) || oh == null || oh.IsMissing) continue;
                // 侵犯类器官的疾病随受损阶段升级(如肛门:失禁→肛裂→烂屁眼)
                string effDisease = ApplyStageDisease(pActor, kv.Key, kv.Value, oh.Hp);
                Disease d = DiseaseLibrary.Find(effDisease);
                if (d == null) continue;
                // 阴道上的疾病来自性交,肛门上的来自肛交,其余为手术/弱化
                string source = kv.Key == "vagina" ? BioText.T("bio_src_sex", "性交")
                    : (kv.Key == "anus" ? BioText.T("bio_src_anal", "肛交") : BioText.T("bio_src_surgery", "手术"));
                oh.Diseases.Add(new DiseaseHit { Def = d, Severity = 50, SourceTrait = source });
            }

            // 关节骨功能衰竭是独立状态，不占用 ModDiseases 的器官槽。
            OrganHealth bone;
            if (state.Mods.FunctionallyFailedOrgans.Contains("bone")
                && byId.TryGetValue("bone", out bone) && bone != null && !bone.IsMissing) {
                Disease failure = DiseaseLibrary.Find("joint_bone_failure");
                if (failure != null) {
                    bone.Diseases.Add(new DiseaseHit {
                        Def = failure,
                        Severity = 100,
                        SourceTrait = BioText.T("bio_src_organ_failure", "器官衰竭")
                    });
                }
            }

            // ===== 统计 =====
            HashSet<string> diseaseNames = new HashSet<string>();
            foreach (OrganHealth oh in body.Organs) {
                foreach (DiseaseHit hit in oh.Diseases) {
                    diseaseNames.Add(hit.Def.Name);
                }
            }
            body.TotalDiseases = diseaseNames.Count;

            // ===== 根据现有器官同步性别(支持性别转换与双性人) =====
            SyncSexByOrgans(pActor, byId);

            return body;
        }

        private static void SyncFunctionalFailures(ActorWoundState pState, BodyHealth pBody) {
            if (pState == null || pState.Mods == null || pBody == null) return;
            ActorMods mods = pState.Mods;
            if (mods.FunctionallyFailedOrgans == null)
                mods.FunctionallyFailedOrgans = new HashSet<string>();
            HashSet<string> current = new HashSet<string>();
            foreach (OrganHealth oh in pBody.Organs) {
                if (oh == null || oh.Def == null) continue;
                string id = oh.Def.Id;
                int hpMod = 0;
                bool editedToZero = mods.HpMods != null
                    && mods.HpMods.TryGetValue(id, out hpMod) && hpMod <= -100;
                bool removed = oh.IsMissing || (mods.RemovedOrgans != null
                    && mods.RemovedOrgans.Contains(id));
                if (removed || editedToZero || oh.Hp <= 0) current.Add(id);
            }
            mods.FunctionallyFailedOrgans.Clear();
            foreach (string id in current) mods.FunctionallyFailedOrgans.Add(id);
        }

        // 疾病随受损阶段升级:根据器官 Hp 由轻到重选择疾病
        // 例:肛门 100~70% 失禁 / 70~40% 肛裂 / <40% 烂屁眼
        // 阴道:生孩子也会导致松弛,孩子数计入松弛因子
        private static string ApplyStageDisease(Actor pActor, string pOrganId, string pDiseaseId, int pHp) {
            if (pHp >= 100) return pDiseaseId;
            if (pOrganId == "anus" && pDiseaseId == "incontinence") {
                if (pHp >= 70) return "incontinence";
                if (pHp >= 40) return "anal_tear";
                return "rotten_anus";
            }
            if (pOrganId == "vagina" && pDiseaseId == "hormone_imbalance") {
                // 生孩子导致松弛:每个孩子视作额外的松弛负担
                int childPenalty = 0;
                try {
                    if (pActor != null) childPenalty = pActor.current_children_count * 3;
                } catch {
                    childPenalty = 0;
                }
                int eff = pHp - childPenalty;
                if (eff >= 95) return "vagina_frequent_sex";
                if (eff >= 40) return "vagina_loose";
                return "loose_pussy";
            }
            return pDiseaseId;
        }

        // 按当前(含增删的)器官集合构建器官表
        private static void BuildOrgans(Actor pActor, ActorWoundState pState, BodyHealth pBody,
            out Dictionary<string, OrganHealth> pById) {
            LimbDependency.NormalizeState(pState);
            pById = new Dictionary<string, OrganHealth>();
            bool animal = pActor.isAnimal();
            List<OrganGroup> groups = OrganData.GetPlan(animal);

            // 性器官组合判定:原生性别 + 增删器官
            bool nativeFemale = pActor.isSexFemale();
            HashSet<string> removed = pState.Mods.RemovedOrgans;
            bool maleExists = !removed.Contains("testicle") || !removed.Contains("penis") || !removed.Contains("prostate");
            bool femaleExists = !removed.Contains("uterus") || !removed.Contains("ovary") || !removed.Contains("vagina");
            bool hasM = (!nativeFemale && maleExists)
                || pState.Mods.AddedOrgans.Contains("testicle")
                || pState.Mods.AddedOrgans.Contains("penis")
                || pState.Mods.AddedOrgans.Contains("prostate");
            bool hasF = (nativeFemale && femaleExists)
                || pState.Mods.AddedOrgans.Contains("uterus")
                || pState.Mods.AddedOrgans.Contains("ovary")
                || pState.Mods.AddedOrgans.Contains("vagina");
            bool showMale = hasM;
            bool showFemale = hasF;

            // 毒牙特质:用毒牙替代牙齿(二者不共存)
            bool hasFangTrait = HasTraitId(pActor, "venomous", "poisonous");

            // 动物:按物种调整皮肤器官(鱼→鳞片,鸟→羽毛,哺乳→皮毛)
            string animalSkin = null;
            string speciesId = "?";
            if (animal) {
                try { if (pActor.asset != null && !string.IsNullOrEmpty(pActor.asset.id)) speciesId = pActor.asset.id; } catch { }
                animalSkin = OrganData.GetAnimalSkin(speciesId);
                Main.LogInfo("生物学:[皮肤] 动物物种=" + speciesId + " → 皮肤=" + animalSkin
                    + " 类别=" + OrganData.GetAnimalKind(speciesId));
            }
            // 非哺乳动物(鱼/禽/爬行):无乳房、用泄殖腔
            bool hasBreast = !animal || OrganData.HasBreast(speciesId);
            bool usesCloaca = animal && OrganData.UsesCloaca(speciesId);
            // 类别细分:鸟无牙齿/鼻(用喙),鱼无牙齿/鼻/肺(用鳃),腿按物种命名(爪/鳍/腿),角仅部分哺乳
            string kind = animal ? OrganData.GetAnimalKind(speciesId) : "";
            bool isBird = kind == "bird";
            bool isFish = kind == "fish";
            bool hasHorn = animal && OrganData.HasHorn(speciesId);
            bool hasLegs = animal && OrganData.HasLegs(speciesId);
            bool hasWings = animal && OrganData.HasWings(speciesId);
            bool hasGills = animal && OrganData.HasGills(speciesId);
            bool usesBeak = animal && OrganData.UsesBeak(speciesId);
            bool usesShell = animal && OrganData.UsesShell(speciesId);

            foreach (OrganGroup g in groups) {
                foreach (string oid in g.OrganIds) {
                    bool isMissing = removed.Contains(oid);
                    if (!showFemale && (oid == "uterus" || oid == "ovary" || oid == "vagina") && !isMissing) continue;
                    if (!showMale && (oid == "testicle" || oid == "prostate" || oid == "penis") && !isMissing) continue;
                    // 毒牙特质:用毒牙替代牙齿,不显示普通牙齿
                    if (oid == "teeth" && hasFangTrait) continue;
                    // 动物皮肤:只保留该物种对应的皮肤器官(鳞片/羽毛/皮毛),其余不添加
                    if (animal && (oid == "fur" || oid == "scale" || oid == "feather") && oid != animalSkin) continue;
                    // 非哺乳动物:没有乳房(胸部)
                    if (oid == "chest" && !hasBreast) continue;
                    // 泄殖腔物种:用泄殖腔替代肛门/阴茎/阴道等器官
                    if (usesCloaca && (oid == "anus" || oid == "uterus" || oid == "ovary" || oid == "vagina"
                        || oid == "testicle" || oid == "prostate" || oid == "penis")) continue;
                    // 泄殖腔:仅泄殖腔物种(哺乳动物/人类没有)
                    if (oid == "cloaca" && !usesCloaca) continue;
                    // 鸟/龟:没有牙齿(用喙)
                    if (oid == "teeth" && usesBeak) continue;
                    // 鸟/鱼:没有鼻(鸟用喙,鱼无外鼻)
                    if ((isBird || isFish) && oid == "nose") continue;
                    // 喙:仅鸟/龟
                    if (oid == "beak" && !usesBeak) continue;
                    // 角:仅长角物种
                    if (oid == "horn" && !hasHorn) continue;
                    // 鳃:仅鱼类;鱼类无肺(用鳃呼吸)
                    if (oid == "gills" && !hasGills) continue;
                    if (oid == "lung" && hasGills) continue;
                    // 翅膀:仅鸟类
                    if ((oid == "wing_l" || oid == "wing_r") && !hasWings) continue;
                    // 腿:无腿动物物种(蛇/蠕虫)不显示;人类始终有腿
                    if (animal && oid == "leg" && !hasLegs) continue;
                    Organ def;
                    if (oid == "tail" && animal) {
                        // 尾巴按物种命名:鱼→鱼尾,鸟→尾羽,其余→尾巴
                        def = new Organ("tail", OrganData.GetTailName(speciesId));
                    } else if (oid == "leg" && animal) {
                        // 腿部按物种命名:鸟→双爪,鱼→双鳍,其余→双腿
                        def = new Organ(oid, OrganData.GetLegName(speciesId));
                    } else if (oid == "spine" && usesShell) {
                        // 龟类:脊椎与肋骨融合成龟壳骨盔,显示为"龟背"(bio_dyn_* 键)
                        def = new Organ("spine", "龟背(骨盔)");
                    } else if (!OrganData.OrganName.TryGetValue(oid, out def)) {
                        continue;
                    }
                    OrganHealth oh = new OrganHealth { Def = def, Hp = isMissing ? 0 : 100, IsMissing = isMissing };
                    pBody.Organs.Add(oh);
                    pById[oid] = oh;
                }
            }

            // 用户手动添加的器官(不受性别限制,上限为每个器官只允许一个)
            foreach (string oid in pState.Mods.AddedOrgans) {
                if (pById.ContainsKey(oid)) continue;
                Organ def;
                if (!OrganData.OrganName.TryGetValue(oid, out def)) continue;
                OrganHealth oh = new OrganHealth { Def = def, Hp = 100 };
                pBody.Organs.Add(oh);
                pById[oid] = oh;
            }

            // 毒牙:毒牙特质时,头部已用毒牙替代牙齿
            if ((hasFangTrait || removed.Contains("fang")) && !pById.ContainsKey("fang")) {
                Organ fdef;
                if (OrganData.OrganName.TryGetValue("fang", out fdef)) {
                    bool fangMissing = removed.Contains("fang");
                    OrganHealth foh = new OrganHealth { Def = fdef, Hp = fangMissing ? 0 : 100, IsMissing = fangMissing };
                    pBody.Organs.Add(foh);
                    pById["fang"] = foh;
                }
            }
        }

        // 检查单位是否具有指定特质 id(可多个,任一命中即返回 true)
        private static bool HasTraitId(Actor pActor, string pId1, string pId2) {
            if (pActor == null || pActor.traits == null) return false;
            foreach (ActorTrait t in pActor.traits) {
                if (t == null || string.IsNullOrEmpty(t.id)) continue;
                if (string.Equals(t.id, pId1, System.StringComparison.OrdinalIgnoreCase)
                    || string.Equals(t.id, pId2, System.StringComparison.OrdinalIgnoreCase)) return true;
            }
            return false;
        }

        private static void SyncSexByOrgans(Actor pActor, Dictionary<string, OrganHealth> pById) {
            if (pActor.data.sex == ActorSex.None) return;
            bool hasM = IsPresent(pById, "testicle") || IsPresent(pById, "penis") || IsPresent(pById, "prostate");
            bool hasF = IsPresent(pById, "uterus") || IsPresent(pById, "ovary") || IsPresent(pById, "vagina");
            ActorSex newSex = pActor.data.sex;
            // 混合(⚥):保持当前性别字段,由 UI 显示双性图标
            if (hasM && !hasF) newSex = ActorSex.Male;
            else if (hasF && !hasM) newSex = ActorSex.Female;
            if (newSex != pActor.data.sex) {
                pActor.data.sex = newSex;
            }
        }

        private static bool IsPresent(Dictionary<string, OrganHealth> pById, string pOrganId) {
            OrganHealth organ;
            return pById != null && pById.TryGetValue(pOrganId, out organ)
                && organ != null && !organ.IsMissing;
        }

        // 游戏原生性别(未启用器官系统的单位直接用它)
        private static int NativeGender(Actor pActor) {
            if (pActor == null) return 0;
            try { if (pActor.isSexFemale()) return 2; } catch { }
            try { if (pActor.isSexMale()) return 1; } catch { }
            return 0;
        }

        // 性别判定:0=中性(无性器官) 1=♂ 2=♀ 3=⚥(混合)
        public static int GetGender(Actor pActor) {
            // 显示/UI 用:复用 Fast 版本,避免 GetCurrentOrgans -> BuildOrgans 的完整构建和状态创建。
            return GetGenderFast(pActor);
        }

        public static int GetGenderFast(Actor pActor) {
            if (pActor == null) return 0;
            if (!HasAnyState) return NativeGender(pActor);
            // 未启用器官的单位:用原生性别(不受历史器官改动影响)
            if (!IsOrganSupported(pActor)) return NativeGender(pActor);
            ActorWoundState state;
            bool hasState = TryGetState(pActor.getID(), out state) && state.Mods != null;
            bool nativeFemale = false;
            try { nativeFemale = pActor.isSexFemale(); } catch { }

            ActorMods mods = hasState ? state.Mods : null;
            bool removedTesticle = mods != null && mods.RemovedOrgans != null && mods.RemovedOrgans.Contains("testicle");
            bool removedPenis = mods != null && mods.RemovedOrgans != null && mods.RemovedOrgans.Contains("penis");
            bool removedProstate = mods != null && mods.RemovedOrgans != null && mods.RemovedOrgans.Contains("prostate");
            bool removedUterus = mods != null && mods.RemovedOrgans != null && mods.RemovedOrgans.Contains("uterus");
            bool removedOvary = mods != null && mods.RemovedOrgans != null && mods.RemovedOrgans.Contains("ovary");
            bool removedVagina = mods != null && mods.RemovedOrgans != null && mods.RemovedOrgans.Contains("vagina");
            bool addedTesticle = mods != null && mods.AddedOrgans != null && mods.AddedOrgans.Contains("testicle");
            bool addedPenis = mods != null && mods.AddedOrgans != null && mods.AddedOrgans.Contains("penis");
            bool addedProstate = mods != null && mods.AddedOrgans != null && mods.AddedOrgans.Contains("prostate");
            bool addedUterus = mods != null && mods.AddedOrgans != null && mods.AddedOrgans.Contains("uterus");
            bool addedOvary = mods != null && mods.AddedOrgans != null && mods.AddedOrgans.Contains("ovary");
            bool addedVagina = mods != null && mods.AddedOrgans != null && mods.AddedOrgans.Contains("vagina");

            // 与 BuildOrgans 一致:原生性别器官只要三者之一未移除即视为存在
            bool maleExists = !removedTesticle || !removedPenis || !removedProstate;
            bool femaleExists = !removedUterus || !removedOvary || !removedVagina;
            bool hasM = (!nativeFemale && maleExists) || addedTesticle || addedPenis || addedProstate;
            bool hasF = (nativeFemale && femaleExists) || addedUterus || addedOvary || addedVagina;

            if (hasM && hasF) return 3;
            if (hasM) return 1;
            if (hasF) return 2;

            // 无性器官:泄殖腔动物回退原生性别
            bool animal = false;
            try { animal = pActor.isAnimal(); } catch { }
            if (animal) {
                string sid = "?";
                try { if (pActor.asset != null && !string.IsNullOrEmpty(pActor.asset.id)) sid = pActor.asset.id; } catch { }
                if (OrganData.UsesCloaca(sid)) {
                    try { if (pActor.isSexFemale()) return 2; } catch { }
                    try { if (pActor.isSexMale()) return 1; } catch { }
                }
            }
            return 0;
        }

        public static ActorWoundState GetState(long pActorId) {
            return GetOrCreateState(pActorId);
        }

        // 只读取已有状态,不新建(供高频检测使用,避免为无关单位创建状态)
        public static bool TryGetState(long pActorId, out ActorWoundState pState) {
            return _states.TryGetValue(pActorId, out pState);
        }

        /// <summary> 整条状态放回某个 id 名下(复活时把死前那份器官/伤情原样搬回来) </summary>
        public static void PutState(long pActorId, ActorWoundState pState) {
            if (pState == null) return;
            LimbDependency.NormalizeState(pState);
            _states[pActorId] = pState;
            _hasAnyState = true;
        }

        /// <summary>
        /// 无分配快速检查双手是否可用。只读 Simulate 同步的功能失效集合；
        /// shoulder/arm/hand 任一最终功能为 0 即不可用，无状态默认为可用。
        /// </summary>
        public static bool HasUsableHandsFast(Actor pActor) {
            return HasFunctionalChainFast(pActor, HandChain);
        }

        /// <summary>双腿或双脚任一最终功能为 0 时禁止移动。</summary>
        public static bool HasUsableLegsFast(Actor pActor) {
            return HasFunctionalChainFast(pActor, LegChain);
        }

        private static bool HasFunctionalChainFast(Actor pActor, string[] pOrganIds) {
            if (pActor == null || !HasAnyState) return true;
            ActorWoundState state;
            if (!TryGetState(pActor.getID(), out state) || state == null || state.Mods == null) return true;
            if (!IsOrganSupported(pActor)) return true;
            ActorMods mods = state.Mods;
            for (int i = 0; i < pOrganIds.Length; i++) {
                string id = pOrganIds[i];
                if (mods.FunctionallyFailedOrgans != null
                    && mods.FunctionallyFailedOrgans.Contains(id)) return false;
                if (mods.RemovedOrgans != null && mods.RemovedOrgans.Contains(id)) return false;
                int hpMod;
                if (mods.HpMods != null && mods.HpMods.TryGetValue(id, out hpMod)
                    && hpMod <= -100) return false;
            }
            return true;
        }

        // 是否有正常工作的胃:未摘除且未弱化到衰竭。返回 false 表示无法消化食物(饱食度强制归零)
        public static bool HasStomach(Actor pActor) {
            if (pActor == null || !HasAnyState) return true;
            if (!IsOrganSupported(pActor)) return true;   // 动物器官未启用:按有胃处理
            ActorWoundState state;
            if (!TryGetState(pActor.getID(), out state) || state.Mods == null) return true;
            if (state.Mods.RemovedOrgans != null && state.Mods.RemovedOrgans.Contains("stomach")) return false;
            int hm = 0;
            if (state.Mods.HpMods != null) state.Mods.HpMods.TryGetValue("stomach", out hm);
            return hm > -100;
        }

        // 当前饱食度存储上限:基础上限 × 胃的强化/弱化百分比(无胃或弱化到衰竭 → 0)
        // 注意:这里不修改游戏原版的 getMaxNutrition()(它保持基础值,供 UI 显示相对百分比),
        // 而是让 setNutrition/addNutritionFromEating 的 clamp 使用本值,实现"存储扩容、显示按基础算"。
        public static int GetScaledMaxNutrition(Actor pActor) {
            if (pActor == null) return 0;
            int baseMax = 0;
            try { baseMax = pActor.getMaxNutrition(); } catch { return 0; }
            if (!HasAnyState) return baseMax;
            ActorWoundState state;
            if (!TryGetState(pActor.getID(), out state) || state.Mods == null) return baseMax;
            if (state.Mods.RemovedOrgans != null && state.Mods.RemovedOrgans.Contains("stomach")) return 0;
            int hm = 0;
            if (state.Mods.HpMods != null) state.Mods.HpMods.TryGetValue("stomach", out hm);
            if (hm <= -100) return 0;
            float mult = (100f + hm) / 100f;
            return System.Math.Max(1, (int)(baseMax * mult));
        }

        public static HashSet<string> GetCurrentOrgans(Actor pActor) {
            HashSet<string> result = new HashSet<string>();
            if (pActor == null) return result;
            // 未启用器官的单位:返回空集,也不为其创建器官状态(避免动物挤占状态缓存)
            if (!IsOrganSupported(pActor)) return result;
            ActorWoundState state = GetOrCreateState(pActor.getID());
            BodyHealth tmp = new BodyHealth();
            Dictionary<string, OrganHealth> byId;
            BuildOrgans(pActor, state, tmp, out byId);
            foreach (KeyValuePair<string, OrganHealth> kv in byId) {
                if (kv.Value != null && !kv.Value.IsMissing) result.Add(kv.Key);
            }
            return result;
        }

        public static bool IsIntersex(Actor pActor) {
            if (pActor == null) return false;
            HashSet<string> organs = GetCurrentOrgans(pActor);
            bool hasM = organs.Contains("testicle") || organs.Contains("penis");
            bool hasF = organs.Contains("uterus") || organs.Contains("ovary") || organs.Contains("vagina");
            return hasM && hasF;
        }

        private static Dictionary<string, int> CollectBoosts(Actor pActor, HashSet<string> pAvailable) {
            Dictionary<string, int> boosts = new Dictionary<string, int>();
            if (pActor.traits == null) return boosts;
            foreach (ActorTrait t in pActor.traits) {
                if (t == null) continue;
                TraitBinding b = DiseaseLibrary.FindBinding(t.id, t.getTranslatedName());
                if (b == null) continue;
                if (b.Boosts != null && b.Boosts.Count > 0) {
                    foreach (KeyValuePair<string, int> kv in b.Boosts) {
                        if (!pAvailable.Contains(kv.Key)) continue;
                        int cur;
                        boosts.TryGetValue(kv.Key, out cur);
                        boosts[kv.Key] = cur + kv.Value;
                    }
                }
                if (b.BoostAll) {
                    foreach (string oid in pAvailable) {
                        int cur;
                        boosts.TryGetValue(oid, out cur);
                        boosts[oid] = cur + b.BoostAllAmount;
                    }
                }
            }
            return boosts;
        }

        // 收集特质导致的属性/器官降低百分比(penalties)。"body" 表示全身
        private static Dictionary<string, int> CollectPenalties(Actor pActor, HashSet<string> pAvailable) {
            Dictionary<string, int> penalties = new Dictionary<string, int>();
            if (pActor.traits == null) return penalties;
            System.Random rngSeed = new System.Random(pActor.getID().GetHashCode());
            foreach (ActorTrait t in pActor.traits) {
                if (t == null) continue;
                TraitBinding b = DiseaseLibrary.FindBinding(t.id, t.getTranslatedName());
                if (b == null || b.Penalties == null || b.Penalties.Count == 0) continue;
                foreach (KeyValuePair<string, int> kv in b.Penalties) {
                    if (kv.Key == "body") {
                        // 全身:应用到所有可用器官
                        foreach (string oid in pAvailable) {
                            int cur;
                            penalties.TryGetValue(oid, out cur);
                            penalties[oid] = cur + kv.Value;
                        }
                    } else if (kv.Key == "eye_random") {
                        // 随机一只眼
                        string eye = (rngSeed.Next(2) == 0) ? "eye_l" : "eye_r";
                        if (pAvailable.Contains(eye)) {
                            int cur;
                            penalties.TryGetValue(eye, out cur);
                            penalties[eye] = cur + kv.Value;
                        }
                    } else if (kv.Key == "bone_random") {
                        // 随机一处骨骼部位(脊椎/关节骨/四肢)
                        string[] bones = { "spine", "bone", "arm", "leg" };
                        string bone = bones[rngSeed.Next(bones.Length)];
                        if (pAvailable.Contains(bone)) {
                            int cur;
                            penalties.TryGetValue(bone, out cur);
                            penalties[bone] = cur + kv.Value;
                        }
                    } else if (kv.Key == "face") {
                        // 面部相关:鼻/嘴巴/牙齿
                        string[] faces = { "nose", "mouth", "teeth" };
                        foreach (string fid in faces) {
                            if (!pAvailable.Contains(fid)) continue;
                            int cur;
                            penalties.TryGetValue(fid, out cur);
                            penalties[fid] = cur + kv.Value;
                        }
                    } else if (kv.Key == "cancer_random") {
                        // 随机一个易癌变器官
                        string[] cancers = { "lung", "liver", "stomach", "intestine", "brain", "skin", "bone", "kidney", "chest", "uterus" };
                        string cid = cancers[rngSeed.Next(cancers.Length)];
                        if (pAvailable.Contains(cid)) {
                            int cur;
                            penalties.TryGetValue(cid, out cur);
                            penalties[cid] = cur + kv.Value;
                        }
                    } else if (pAvailable.Contains(kv.Key)) {
                        int cur;
                        penalties.TryGetValue(kv.Key, out cur);
                        penalties[kv.Key] = cur + kv.Value;
                    }
                }
            }
            return penalties;
        }

        private static string BuildLegend(string pTraitName, TraitBinding pBinding, HashSet<string> pPlanOrgans,
            ActorWoundState pState, string pTraitKey) {
            if (pBinding == null) return null;
            if (pBinding.BoostAll || (pBinding.Boosts != null && pBinding.Boosts.Count > 0)) {
                return pTraitName + " → " + BuildBuffSummary(pBinding, pPlanOrgans);
            }
            // 纯心理特质(无疾病无惩罚):只标注心理状态
            if ((pBinding.DiseaseHits == null || pBinding.DiseaseHits.Count == 0)
                && (pBinding.Penalties == null || pBinding.Penalties.Count == 0)) {
                return pTraitName + " → <color=#AAAAAA>" + BioText.T("bio_legend_mental", "心理状态") + "</color>";
            }
            string baseLine = pTraitName + " → " + BuildDebuffSummary(pBinding, pPlanOrgans, pState, pTraitKey);
            // 追加属性降低信息
            if (pBinding.Penalties != null && pBinding.Penalties.Count > 0) {
                List<string> pl = new List<string>();
                foreach (KeyValuePair<string, int> kv in pBinding.Penalties) {
                    if (kv.Key == "body") {
                        pl.Add(BioText.F("bio_fmt_pen_whole", "全身<color=#FF6666>(-{0}%)</color>", kv.Value));
                    } else if (kv.Key == "face") {
                        pl.Add(BioText.F("bio_fmt_pen_face", "面部<color=#FF6666>(-{0}%)</color>", kv.Value));
                    } else if (kv.Key == "eye_random") {
                        pl.Add(BioText.T("bio_fmt_pen_eye", "随机单眼<color=#FF6666>(0%)</color>"));
                    } else if (kv.Key == "bone_random") {
                        pl.Add(BioText.F("bio_fmt_pen_bone", "随机骨骼<color=#FF6666>(-{0}%)</color>", kv.Value));
                    } else if (kv.Key == "cancer_random") {
                        pl.Add(BioText.F("bio_fmt_pen_cancer", "随机癌变<color=#FF6666>(-{0}%)</color>", kv.Value));
                    } else if (pPlanOrgans.Contains(kv.Key)) {
                        Organ o;
                        pl.Add(BioText.F("bio_fmt_organ_pen",
                            "{0}<color=#FF6666>(-{1}%)</color>",
                            (OrganData.OrganName.TryGetValue(kv.Key, out o) ? o.LocalizedName : kv.Key), kv.Value));
                    }
                }
                if (pl.Count > 0) {
                    baseLine += " · " + string.Join("、", pl);
                }
            }
            return baseLine;
        }

        private static string BuildBuffSummary(TraitBinding pBinding, HashSet<string> pPlanOrgans) {
            List<string> lines = new List<string>();
            if (pBinding.BoostAll) {
                lines.Add(BioText.F("bio_fmt_buff_whole", "全身<color=#66FF66>(+{0}%)</color>", pBinding.BoostAllAmount));
            }
            if (pBinding.Boosts != null && pBinding.Boosts.Count > 0) {
                Dictionary<int, List<string>> byAmount = new Dictionary<int, List<string>>();
                foreach (KeyValuePair<string, int> kv in pBinding.Boosts) {
                    if (!pPlanOrgans.Contains(kv.Key)) continue;
                    List<string> list;
                    if (!byAmount.TryGetValue(kv.Value, out list)) {
                        list = new List<string>();
                        byAmount[kv.Value] = list;
                    }
                    list.Add(kv.Key);
                }
                foreach (KeyValuePair<int, List<string>> kv in byAmount) {
                    lines.Add(DescribeOrganSet(kv.Value) + "<color=#66FF66>(+" + kv.Key + "%)</color>");
                }
            }
            return lines.Count > 0 ? string.Join("、", lines)
                : BioText.T("bio_fmt_buff_unknown", "全身<color=#66FF66>(+?)</color>");
        }

        private static string BuildDebuffSummary(TraitBinding pBinding, HashSet<string> pPlanOrgans,
            ActorWoundState pState, string pTraitKey) {
            if (pBinding.Kind == BindingKind.RandomInfectious) {
                return "<color=#FF6666>" + BioText.T("bio_legend_infectious", "随机传染病(对应器官受损)") + "</color>";
            }
            if (pBinding.Kind == BindingKind.RandomCancer) {
                return "<color=#FF6666>" + BioText.T("bio_legend_cancer", "对应器官癌变") + "</color>";
            }
            if (pBinding.Kind == BindingKind.RandomInfection) {
                return "<color=#FF6666>" + BioText.T("bio_legend_infection", "随机感染(对应器官受损)") + "</color>";
            }
            if (pBinding.Kind == BindingKind.Curse) {
                return "<color=#FF6666>" + BioText.T("bio_legend_curse", "全身衰减·百病缠身") + "</color>";
            }
            List<string> lines = new List<string>();
            if (pBinding.DiseaseHits != null) {
                foreach (KeyValuePair<Disease, int> hit in pBinding.DiseaseHits) {
                    if (hit.Key == null) continue;
                    // 只列"实际受影响"的器官:该疾病在本单位已落地的伤口 + 已摘除的对应器官,
                    // 而不是疾病可能影响的全部候选(否则删个腿会连手臂一起显示)
                    List<string> actualIds = new List<string>();
                    HashSet<string> missingIds = new HashSet<string>();
                    if (pState != null) {
                        if (pState.Wounds != null) {
                            foreach (OrganWound w in pState.Wounds.Values) {
                                if (w == null || w.Disease == null || w.Disease.Id != hit.Key.Id) continue;
                                if (w.TraitKey != pTraitKey) continue;
                                if (!hit.Key.Organs.Contains(w.OrganId)) continue;
                                if (actualIds.Contains(w.OrganId)) continue;
                                actualIds.Add(w.OrganId);
                                if (pState.Mods != null && pState.Mods.RemovedOrgans != null
                                    && pState.Mods.RemovedOrgans.Contains(w.OrganId)) {
                                    missingIds.Add(w.OrganId);
                                }
                            }
                        }
                        // 已摘除但尚无伤口记录的(如先天无器官):直接按缺失标注
                        if (pState.Mods != null && pState.Mods.RemovedOrgans != null) {
                            foreach (string oid in hit.Key.Organs) {
                                if (pState.Mods.RemovedOrgans.Contains(oid)
                                    && !actualIds.Contains(oid)) {
                                    actualIds.Add(oid);
                                    missingIds.Add(oid);
                                }
                            }
                        }
                    }
                    if (actualIds.Count == 0) {
                        // 兜底:疾病还没落地伤口时,才按候选器官列(天生残疾等)
                        foreach (string oid in hit.Key.Organs) {
                            if (pPlanOrgans.Contains(oid)) actualIds.Add(oid);
                        }
                    }
                    if (actualIds.Count == 0) continue;
                    List<string> presentIds = new List<string>();
                    List<string> missingParts = new List<string>();
                    foreach (string oid in actualIds) {
                        if (missingIds.Contains(oid)) {
                            Organ o;
                            missingParts.Add(BioText.F("bio_fmt_organ_missing",
                                "{0}<color=#FF6666>(缺失)</color>",
                                (OrganData.OrganName.TryGetValue(oid, out o) ? o.LocalizedName : oid)));
                        } else {
                            presentIds.Add(oid);
                        }
                    }
                    string desc = presentIds.Count > 0 ? DescribeOrganSet(presentIds) : "";
                    if (missingParts.Count > 0) {
                        if (desc.Length > 0) desc += "·";
                        desc += string.Join("·", missingParts);
                    }
                    if (hit.Value > 0) {
                        lines.Add(BioText.F("bio_fmt_organ_pen",
                            "{0}<color=#FF6666>(-{1}%)</color>", desc, hit.Value));
                    } else {
                        lines.Add(BioText.F("bio_fmt_organ_damaged",
                            "{0}<color=#FF6666>(受损)</color>", desc));
                    }
                }
            }
            return lines.Count > 0 ? string.Join("、", lines)
                : "<color=#FF6666>" + BioText.T("bio_legend_wholedamaged", "全身受损") + "</color>";
        }

        private static string DescribeOrganSet(List<string> pIds) {
            if (pIds == null || pIds.Count == 0) return BioText.T("bio_tag_whole", "全身");
            HashSet<string> set = new HashSet<string>(pIds);
            List<string> parts = new List<string>();
            AddPair(parts, set, "eye_l", "eye_r", BioText.T("bio_pair_eyes", "双眼"));
            foreach (string oid in pIds) {
                if (set.Contains(oid)) {
                    Organ o;
                    parts.Add(OrganData.OrganName.TryGetValue(oid, out o) ? o.LocalizedName : oid);
                    set.Remove(oid);
                }
            }
            return string.Join("·", parts);
        }

        private static void AddPair(List<string> pParts, HashSet<string> pSet, string pL, string pR, string pLabel) {
            if (pSet.Contains(pL) && pSet.Contains(pR)) {
                pParts.Add(pLabel);
                pSet.Remove(pL);
                pSet.Remove(pR);
            }
        }

        private static void ApplyTraitWounds(Actor pActor, Dictionary<string, OrganHealth> pById,
            ActorWoundState pState, System.Random pRng, double pCurTime, BodyHealth pBody) {
            if (pActor.traits == null) return;

            // 动物免疫创伤后应激障碍(嗜血/屠龙者等精神类负面病症)
            bool animalImmune = false;
            try { animalImmune = pActor.isAnimal(); } catch { }

            HashSet<string> present = new HashSet<string>();
            List<ActorTrait> presentTraits = new List<ActorTrait>();
            HashSet<string> planOrgans = new HashSet<string>();
            foreach (KeyValuePair<string, OrganHealth> kv in pById) {
                if (kv.Value != null && !kv.Value.IsMissing) planOrgans.Add(kv.Key);
            }
            foreach (ActorTrait t in pActor.traits) {
                if (t == null) continue;
                string id = t.id;
                string name = t.getTranslatedName();
                TraitBinding binding = DiseaseLibrary.FindBinding(id, name);
                if (binding == null) continue;
                present.Add(GetTraitKey(t));
                presentTraits.Add(t);
                string legend = BuildLegend(name, binding, planOrgans, pState, GetTraitKey(t));
                if (legend != null && !pBody.Legend.Contains(legend)) pBody.Legend.Add(legend);
            }

            // 特质被移除 → 伤口立即痊愈(从状态中删除,恢复100%)
            List<string> toRemove = new List<string>();
            foreach (KeyValuePair<string, OrganWound> kv in pState.Wounds) {
                if (!present.Contains(kv.Value.TraitKey)) toRemove.Add(kv.Key);
            }
            foreach (string oid in toRemove) {
                pState.Wounds.Remove(oid);
            }

            foreach (ActorTrait t in presentTraits) {
                string id = t.id;
                string name = t.getTranslatedName();
                TraitBinding binding = DiseaseLibrary.FindBinding(id, name);
                if (binding == null) continue;
                string traitKey = GetTraitKey(t);

                switch (binding.Kind) {
                    case BindingKind.Direct:
                        foreach (KeyValuePair<Disease, int> pair in binding.DiseaseHits) {
                            // 动物豁免创伤后应激障碍
                            if (animalImmune && pair.Key != null && pair.Key.Id == "ptsd") continue;
                            EnsureWound(pState, pById, pRng, pCurTime, traitKey, name, pair.Key, true);
                        }
                        break;
                    case BindingKind.RandomInfectious: {
                        Disease d = DiseaseLibrary.PickRandomInfectious(pRng);
                        if (d != null) EnsureWound(pState, pById, pRng, pCurTime, traitKey, name, d, false);
                        break;
                    }
                    case BindingKind.RandomCancer: {
                        Disease d = DiseaseLibrary.PickRandomCancer(pRng);
                        if (d != null) EnsureWound(pState, pById, pRng, pCurTime, traitKey, name, d, false);
                        break;
                    }
                    case BindingKind.RandomInfection: {
                        Disease d = DiseaseLibrary.PickRandomInfection(pRng);
                        if (d != null) EnsureWound(pState, pById, pRng, pCurTime, traitKey, name, d, false);
                        break;
                    }
                    case BindingKind.DeathMark: {
                        // 脑血栓 + 急性心脏病 + 随机癌症 → 离死不远
                        Disease thromb = DiseaseLibrary.Find("cerebral_thrombosis");
                        Disease heart = DiseaseLibrary.Find("heart_attack");
                        if (thromb != null) EnsureWound(pState, pById, pRng, pCurTime, traitKey, name, thromb, true);
                        if (heart != null) EnsureWound(pState, pById, pRng, pCurTime, traitKey, name, heart, true);
                        Disease cancer = DiseaseLibrary.PickRandomCancer(pRng);
                        if (cancer != null) EnsureWound(pState, pById, pRng, pCurTime, traitKey, name, cancer, true);
                        break;
                    }
                    case BindingKind.Curse: {
                        // 全身大范围衰减:所有可显示器官随机衰减到 50~80%
                        Disease curseDisease = DiseaseLibrary.Find("curse_affliction");
                        if (curseDisease != null) {
                            List<string> allIds = new List<string>();
                            foreach (KeyValuePair<string, OrganHealth> kv in pById) {
                                if (kv.Value != null && !kv.Value.IsMissing) allIds.Add(kv.Key);
                            }
                            foreach (string oid in allIds) {
                                if (pState.Wounds.ContainsKey(oid)) continue;
                                pState.Wounds[oid] = MakeWound(traitKey, name, curseDisease, oid, pRng.Next(50, 81), pCurTime);
                            }
                        }
                        // 百病缠身:随机施加若干疾病伤口
                        HashSet<string> availableSet = new HashSet<string>();
                        foreach (KeyValuePair<string, OrganHealth> kv in pById) {
                            if (kv.Value != null && !kv.Value.IsMissing) availableSet.Add(kv.Key);
                        }
                        for (int i = 0; i < 6; i++) {
                            Disease d = DiseaseLibrary.PickRandomGeneral(pRng, availableSet);
                            if (d == null) continue;
                            // 动物豁免创伤后应激障碍
                            if (animalImmune && d.Id == "ptsd") continue;
                            EnsureWound(pState, pById, pRng, pCurTime, traitKey, name, d, true);
                        }
                        break;
                    }
                }
            }
        }

        private static void EnsureWound(ActorWoundState pState, Dictionary<string, OrganHealth> pById,
            System.Random pRng, double pCurTime, string pTraitKey, string pTraitName, Disease pDisease, bool pPerDisease) {
            if (HasWoundFor(pState, pTraitKey, pPerDisease ? pDisease.Id : null)) return;

            string organId = PickRandomOrgan(pDisease, pById, pState, pRng);
            if (organId == null) return;

            int hp = pRng.Next(0, 2) == 0 ? 80 : 50;
            pState.Wounds[organId] = MakeWound(pTraitKey, pTraitName, pDisease, organId, hp, pCurTime);

            // 眼/耳/肾/肺等左右对称器官应同时受影响(如糖尿病伤双眼),四肢保持随机单侧
            string pair = GetSymmetricPair(organId);
            OrganHealth pairOrgan;
            if (pair != null && pById.TryGetValue(pair, out pairOrgan) && pairOrgan != null
                && !pairOrgan.IsMissing && !pState.Wounds.ContainsKey(pair)) {
                pState.Wounds[pair] = MakeWound(pTraitKey, pTraitName, pDisease, pair, hp, pCurTime);
            }
        }

        private static OrganWound MakeWound(string pTraitKey, string pTraitName, Disease pDisease,
            string pOrganId, int pHp, double pCurTime) {
            return new OrganWound {
                TraitKey = pTraitKey,
                TraitName = pTraitName,
                Disease = pDisease,
                OrganId = pOrganId,
                HpAtDamage = pHp,
                DamageTime = pCurTime,
                RegenPerMonth = 1
            };
        }

        // 摘除授予"残疾"的器官(肢体/脊椎/关节骨)时,把残疾伤钉在被摘除的器官上:
        // 让 HasWoundFor 短路,避免 trait 系统随后随机把病挂到其他(完好的)肢体上
        public static void PinCrippledFracture(Actor pActor, string pOrganId) {
            try {
                if (pActor == null || string.IsNullOrEmpty(pOrganId)) return;
                // 与 ApplyTraitWounds 使用同一套 trait key(id 优先,否则名称),确保能命中占位伤
                string traitKey = "";
                string traitName = BioText.T("bio_src_crippled", "残疾");
                if (pActor.traits != null) {
                    foreach (ActorTrait t in pActor.traits) {
                        if (t == null || string.IsNullOrEmpty(t.id) || t.id != "crippled") continue;
                        traitKey = GetTraitKey(t);
                        traitName = t.getTranslatedName();
                        break;
                    }
                }
                if (string.IsNullOrEmpty(traitKey)) traitKey = "id:crippled";
                ActorWoundState state = GetOrCreateState(pActor.getID());
                Disease d = DiseaseLibrary.Find("fracture");
                if (d == null) return;
                state.Wounds[pOrganId] = MakeWound(traitKey, traitName, d, pOrganId, 0, GetWorldTime());
            } catch (System.Exception e) {
                Main.LogError("生物学:钉住残疾伤失败 " + e);
            }
        }

        // 仍保留左右之分的器官(眼睛/翅膀);肺/肾/耳等已合并成单个器官,不再成对
        private static string GetSymmetricPair(string pOrganId) {
            switch (pOrganId) {
                case "eye_l": return "eye_r";
                case "eye_r": return "eye_l";
                case "wing_l": return "wing_r";
                case "wing_r": return "wing_l";
            }
            return null;
        }

        private static bool HasWoundFor(ActorWoundState pState, string pTraitKey, string pDiseaseId) {
            foreach (OrganWound w in pState.Wounds.Values) {
                if (w.TraitKey != pTraitKey) continue;
                if (pDiseaseId == null || w.Disease.Id == pDiseaseId) return true;
            }
            return false;
        }

        private static string PickRandomOrgan(Disease pDisease, Dictionary<string, OrganHealth> pById,
            ActorWoundState pState, System.Random pRng) {
            List<string> free = new List<string>();
            List<string> all = new List<string>();
            foreach (string oid in pDisease.Organs) {
                    OrganHealth oh;
                    if (!pById.TryGetValue(oid, out oh) || oh == null || oh.IsMissing) continue;
                    all.Add(oid);
                if (!pState.Wounds.ContainsKey(oid)) free.Add(oid);
            }
            List<string> pool = free.Count > 0 ? free : all;
            if (pool.Count == 0) return null;
            return pool[pRng.Next(pool.Count)];
        }

        private static void ApplyTransient(Dictionary<string, OrganHealth> pByOrgan,
            Dictionary<string, List<DiseaseHit>> pHits, Disease pDisease, int pSeverity) {
            foreach (string oid in pDisease.Organs) {
                OrganHealth organ;
                if (!pByOrgan.TryGetValue(oid, out organ) || organ == null || organ.IsMissing) continue;
                List<DiseaseHit> list;
                if (!pHits.TryGetValue(oid, out list)) {
                    list = new List<DiseaseHit>();
                    pHits[oid] = list;
                }
                DiseaseHit found = null;
                foreach (DiseaseHit h in list) {
                    if (h.Def.Id == pDisease.Id) {
                        found = h;
                        break;
                    }
                }
                if (found != null) {
                    found.Severity = Mathf.Min(100, found.Severity + pSeverity);
                } else {
                    list.Add(new DiseaseHit { Def = pDisease, Severity = pSeverity });
                }
            }
        }

        private static int GetWoundHp(OrganWound pWound, double pCurTime) {
            if (pWound.RegenPerMonth <= 0) return pWound.HpAtDamage;
            double months = (pCurTime - pWound.DamageTime) / 5.0;
            if (months < 0) months = 0;
            int hp = pWound.HpAtDamage + (int)(months * pWound.RegenPerMonth);
            return Mathf.Clamp(hp, 0, 100);
        }

        private static double GetWorldTime() {
            try {
                MapBox mb = MapBox.instance;
                if (mb == null) return 0;
                return mb.getCurWorldTime();
            } catch {
                return 0;
            }
        }

        private static string GetTraitKey(ActorTrait pTrait) {
            if (pTrait == null) return "";
            if (!string.IsNullOrEmpty(pTrait.id)) return "id:" + pTrait.id;
            string name = pTrait.getTranslatedName();
            return string.IsNullOrEmpty(name) ? "" : "n:" + name;
        }

        private static ActorWoundState GetOrCreateState(long pActorId) {
            ActorWoundState state;
            if (!_states.TryGetValue(pActorId, out state)) {
                if (_states.Count >= WoundMaxCount) {
                    _states.Clear();
                }
                state = new ActorWoundState();
                _states[pActorId] = state;
                _hasAnyState = true;
            }
            return state;
        }
    }
}
