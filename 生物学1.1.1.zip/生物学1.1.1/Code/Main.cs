using NeoModLoader.api;
using NeoModLoader.General;
using UnityEngine;

namespace RimWorldMod {
    public class Main : BasicMod<Main> {
        // 添加器官/操纵器官菜单的等比缩放倍率(由模组设置"窗口设置>菜单缩放"控制)
        public static float MenuScale = 1f;
        // 添加器官/操纵器官菜单的基准面板宽度(px,由模组设置"窗口设置>面板宽度"控制)
        public static int MenuWidth = 280;
        // 器官面板(生物学标签)的加宽倍率:1=不加宽,2=宽度翻倍(向右扩展)
        public static float PanelWidthFactor = 2f;
        // 攻略/亲密对话框的整体大小倍率(由模组设置"窗口设置>对话框大小"控制,1=默认)
        public static float DialogScale = 1f;
        // 是否启用 AI 对话(让 AI 扮演单位实时回应玩家的攻略举动)
        public static bool AIChatEnabled = false;
        // 模组是否已加载完成:用于拦截 NML 启动时应用配置就触发的"伪按钮"回调
        private static bool _ready = false;
        // 是否为动物启用器官系统:关闭时只有人类/精灵/矮人/兽人等文明种族有器官面板
        public static bool AnimalOrgans = false;
        // 调试用:单位窗口内点击时把光标下的 UI 节点打进日志(默认关闭,避免刷日志)
        public static bool ClickProbe = false;
        // 自动初始化/刷新诊断是否允许在游戏画面显示 WorldTip；旧配置缺少此键时必须安全关闭。
        public static bool ScreenDebugEnabled = false;
        // 立绘是否用裸体那套图层。女性/扶他换成 body_Nude/body_NudeTorso,
        // 男性换成 male_TorsoNude 并额外挂上睾丸/阴毛/阴茎(阴茎按器官尺寸挑贴图)
        public static bool NudeDoll = false;
        // 器官磨损:打架/生孩子/走路会慢慢磨低对应器官的百分比(见 BioExperience)。
        // 大世界里嫌吵或者嫌费性能可以关掉,关掉后只剩玩家手动强化/弱化
        public static bool OrganWear = true;
        // 矮人贴图:开着的时候世界里和头像框里的矮人换成重绘的那一套,
        // 并且按装备决定穿什么(皮革甲/精金甲/六种金属的变色甲)、头上戴什么(见 BioDwarfSkin)
        public static bool DwarfSkin = false;
        // 人类贴图:开着的时候世界里和头像框里的人类换成 Human_Unpacked 重绘的那一套,
        // 按装备决定穿什么(皮革甲/精金甲/六种金属的变色甲)、头上戴什么(见 BioHumanSkin)。
        public static bool HumanSkin = true;
        // 隐藏服装:BodyDoll 始终裸体；矮人重绘仅隐藏服装/头饰，不删除真实装备或武器。
        public static bool HideClothing = false;
        private float _powerTabRetry;

        internal static ModConfigItem GetFeatureItem(string pId) {
            try {
                ModConfig config = Instance != null ? Instance.GetConfig() : null;
                if (config != null && config["功能开关"].ContainsKey(pId))
                    return config["功能开关"][pId];
            } catch (System.Exception e) {
                LogError("生物学:读取功能开关 " + pId + " 失败 " + e.Message);
            }
            return null;
        }

        internal static ModConfigItem GetDiagnosticItem(string pId) {
            try {
                ModConfig config = Instance != null ? Instance.GetConfig() : null;
                if (config != null && config["诊断设置"].ContainsKey(pId))
                    return config["诊断设置"][pId];
            } catch (System.Exception e) {
                LogError("生物学:读取诊断设置 " + pId + " 失败 " + e.Message);
            }
            return null;
        }

        public static bool ReadDiagnosticSwitch(string pId) {
            ModConfigItem item = GetDiagnosticItem(pId);
            return item != null && item.BoolVal;
        }

        public static bool ReadFeatureSwitch(string pId, bool pFallback) {
            ModConfigItem item = GetFeatureItem(pId);
            return item != null ? item.BoolVal : pFallback;
        }

        // 自动诊断专用屏幕提示。普通 LogInfo/LogError 始终保留到 Player.log。
        public static void ShowDebugTip(string pMessage) {
            if (!ScreenDebugEnabled || string.IsNullOrEmpty(pMessage)) return;
            try {
                WorldTip.showNow(pMessage, false, "top");
            } catch (System.Exception e) {
                LogError("生物学:显示屏幕调试提示失败 " + e);
            }
        }

        // 高频玩法日志(磨损/持续扣血/生育等)专用:只有开了「屏幕调试提示」开关才写进 Player.log,
        // 平时关着就不刷屏、也不费性能。LogError 依旧始终保留。
        public static void LogDebug(string pMessage) {
            if (!ScreenDebugEnabled) return;
            LogInfo(pMessage);
        }

        public static void SyncFeatureSwitchesFromConfig() {
            bool dwarf = ReadFeatureSwitch("矮人贴图", DwarfSkin);
            bool human = ReadFeatureSwitch("人类贴图", HumanSkin);
            bool hide = ReadFeatureSwitch("隐藏服装", HideClothing);
            if (dwarf != DwarfSkin) OnDwarfSkinChanged(dwarf);
            if (human != HumanSkin) OnHumanSkinChanged(human);
            if (hide != HideClothing) OnHideClothingChanged(hide);
        }

        private static void SetFeatureSwitch(string pId, bool pEnabled,
            System.Action<bool> pFallbackCallback, bool pSave) {
            ModConfigItem item = GetFeatureItem(pId);
            if (item != null) {
                // NML 的第二参数是 pSkipCallback；false 才会触发配置中的回调。
                // 值没有变化时不再次触发 callback，确保按钮一次点击只刷新一次。
                if (item.BoolVal != pEnabled) item.SetValue(pEnabled, false);
                else if ((pId == "矮人贴图" && DwarfSkin != pEnabled)
                    || (pId == "人类贴图" && HumanSkin != pEnabled)
                    || (pId == "隐藏服装" && HideClothing != pEnabled))
                    pFallbackCallback(pEnabled);
            } else if (pFallbackCallback != null) {
                pFallbackCallback(pEnabled);
            }
            if (pSave && Instance != null && Instance.GetConfig() != null)
                Instance.GetConfig().Save();
            BiologyPowerTab.RefreshState();
        }

        public static void SetDwarfSkinEnabled(bool pEnabled) {
            SetFeatureSwitch("矮人贴图", pEnabled, OnDwarfSkinChanged, true);
        }

        public static void SetHideClothingEnabled(bool pEnabled) {
            SetFeatureSwitch("隐藏服装", pEnabled, OnHideClothingChanged, true);
        }

        public static void SetHumanSkinEnabled(bool pEnabled) {
            SetFeatureSwitch("人类贴图", pEnabled, OnHumanSkinChanged, true);
        }

        // 兼容已创建的 PowerTab 调用点；开关逻辑仍统一经过同一个配置 API。
        public static void SetDwarfSkin(bool pEnabled, bool pSave) {
            SetFeatureSwitch("矮人贴图", pEnabled, OnDwarfSkinChanged, pSave);
        }

        public static void SetHideClothing(bool pEnabled, bool pSave) {
            SetFeatureSwitch("隐藏服装", pEnabled, OnHideClothingChanged, pSave);
        }

        public static void SetHumanSkin(bool pEnabled, bool pSave) {
            SetFeatureSwitch("人类贴图", pEnabled, OnHumanSkinChanged, pSave);
        }

        public static void OnHideClothingChanged(bool pEnabled) {
            HideClothing = pEnabled;
            ModConfigItem item = GetFeatureItem("隐藏服装");
            LogInfo("生物学:隐藏服装callback value=" + pEnabled
                + " config=" + (item != null ? item.BoolVal.ToString() : "<missing>"));
            BioBodyDoll.ResetBuild();
            BioDwarfSkin.OnSwitchChanged();
            BioHumanSkin.OnSwitchChanged();
            UnitHealthTab.RefreshAfterEdit();
            BioGraveTab.RefreshIfOpen();
            BiologyPowerTab.RefreshState();
        }

        // 模组设置回调:矮人贴图开关(改完立即让世界里的矮人重取贴图)
        public static void OnDwarfSkinChanged(bool pEnabled) {
            DwarfSkin = pEnabled;
            Main.LogInfo("生物学:矮人贴图已" + (pEnabled ? "启用" : "关闭"));
            BioDwarfSkin.OnSwitchChanged();
            BioBodyDoll.ResetBuild();
            UnitHealthTab.RefreshAfterEdit();
            BioGraveTab.RefreshIfOpen();
            BiologyPowerTab.RefreshState();
        }

        // 模组设置回调:人类贴图开关(改完立即让世界里的人类重取贴图)
        public static void OnHumanSkinChanged(bool pEnabled) {
            HumanSkin = pEnabled;
            Main.LogInfo("生物学:人类贴图已" + (pEnabled ? "启用" : "关闭"));
            BioHumanSkin.OnSwitchChanged();
            BioBodyDoll.ResetBuild();
            UnitHealthTab.RefreshAfterEdit();
            BioGraveTab.RefreshIfOpen();
            BiologyPowerTab.RefreshState();
        }

        // 模组设置回调:器官磨损开关
        public static void OnOrganWearChanged(bool pEnabled) {
            OrganWear = pEnabled;
            Main.LogInfo("生物学:器官磨损已" + (pEnabled ? "启用" : "关闭"));
        }

        // 模组设置回调:裸体立绘开关(改完立即重搭立绘)
        public static void OnNudeDollChanged(bool pEnabled) {
            NudeDoll = pEnabled;
            Main.LogInfo("生物学:裸体立绘已" + (pEnabled ? "启用" : "关闭"));
            try {
                BioBodyDoll.ResetBuild();
                UnitHealthTab.RefreshAfterEdit();
            } catch (System.Exception e) {
                LogError("生物学:切换裸体立绘后刷新面板失败 " + e);
            }
        }

        // 模组设置回调:屏幕调试提示总开关；不影响 Player.log 或玩家主动操作反馈。
        public static void OnScreenDebugChanged(bool pEnabled) {
            ScreenDebugEnabled = pEnabled;
            Main.LogInfo("生物学:屏幕调试提示已" + (pEnabled ? "启用" : "关闭"));
        }

        // 模组设置回调:点击探针开关
        public static void OnClickProbeChanged(bool pEnabled) {
            ClickProbe = pEnabled;
            if (pEnabled) BioClickProbe.Ensure();
            Main.LogInfo("生物学:点击探针已" + (pEnabled ? "启用" : "关闭"));
        }

        // 模组设置回调:动物器官开关(改完立即刷新已打开的器官面板)
        public static void OnAnimalOrgansChanged(bool pEnabled) {
            AnimalOrgans = pEnabled;
            Main.LogInfo("生物学:动物器官已" + (pEnabled ? "启用" : "关闭"));
            try {
                UnitHealthTab.RefreshAfterEdit();
            } catch (System.Exception e) {
                LogError("生物学:切换动物器官后刷新面板失败 " + e);
            }
        }

        // 模组设置回调:器官面板加宽倍率
        public static void OnPanelWidthFactorChanged(float pFactor) {
            PanelWidthFactor = Mathf.Clamp(pFactor, 1f, 3f);
            Main.LogInfo("生物学:器官面板加宽倍率已更新为 " + PanelWidthFactor);
        }

        // 模组设置回调:对话框大小
        public static void OnDialogScaleChanged(float pScale) {
            DialogScale = Mathf.Clamp(pScale, 0.6f, 2f);
            Main.LogInfo("生物学:对话框大小已更新为 " + DialogScale);
        }

        // 模组设置回调:AI 设置栏(总开关 + 接口地址/密钥/模型/超时)
        public static void OnAIChatChanged(bool pEnabled) {
            AIChatEnabled = pEnabled;
            BioAIChat.EnabledSwitch = pEnabled;
            Main.LogInfo("生物学:AI 对话已" + (pEnabled ? "启用" : "关闭"));
        }

        public static void OnAIUrlChanged(string pUrl) {
            BioAIChat.Url = (pUrl ?? "").Trim();
            Main.LogInfo("生物学:AI 接口地址已更新 " + (string.IsNullOrEmpty(BioAIChat.Url) ? "<空>" : BioAIChat.Url));
        }

        public static void OnAIKeyChanged(string pKey) {
            BioAIChat.Key = pKey ?? "";
            Main.LogInfo("生物学:AI 密钥已更新 " + (string.IsNullOrEmpty(BioAIChat.Key) ? "<空>" : "已填"));
        }

        public static void OnAIModelChanged(string pModel) {
            BioAIChat.Model = (pModel ?? "").Trim();
            Main.LogInfo("生物学:AI 模型已更新 " + (string.IsNullOrEmpty(BioAIChat.Model) ? "<空>" : BioAIChat.Model));
        }

        public static void OnAITimeoutChanged(int pSeconds) {
            BioAIChat.TimeoutSeconds = Mathf.Clamp(pSeconds, 5, 120);
            Main.LogInfo("生物学:AI 超时秒数已更新为 " + BioAIChat.TimeoutSeconds);
        }

        public static void OnAITokenTipChanged(bool pEnabled) {
            BioAIChat.ShowTokenTip = pEnabled;
            Main.LogInfo("生物学:Token 消耗提示已" + (pEnabled ? "启用" : "关闭"));
        }

        // 这是个"伪按钮":拨到"开"才打开 DeepSeek 官网(购买/管理 API Key)。
        // 只在模组加载完成后、且开关被拨到 true 时才跳转,避免游戏启动时 NML 应用配置就自动打开。
        public static void OnOpenDeepSeekSite(bool pEnabled) {
            if (!_ready || !pEnabled) return;
            try {
                Application.OpenURL(BioAIChat.DeepSeekSite);
                Main.LogInfo("生物学:已打开 DeepSeek 官网 " + BioAIChat.DeepSeekSite);
            } catch (System.Exception e) {
                Main.LogError("生物学:打开 DeepSeek 官网失败 " + e);
            }
        }

        // 模组设置回调:关闭设置窗口后生效
        public static void OnMenuScaleChanged(float pScale) {
            MenuScale = Mathf.Max(0.3f, pScale);
            Main.LogInfo("生物学:菜单缩放已更新为 " + MenuScale);
        }

        // 模组设置回调:面板宽度变化时按比例缩放(等比缩放)
        public static void OnMenuWidthChanged(int pWidth) {
            MenuWidth = Mathf.Clamp(pWidth, 100, 600);
            Main.LogInfo("生物学:面板宽度已更新为 " + MenuWidth);
        }

        protected override void OnModLoad() {
            // 读取模组设置中的菜单缩放/面板宽度
            try {
                var scaleItem = GetConfig()["窗口设置"]["菜单缩放"];
                if (scaleItem != null) MenuScale = Mathf.Max(0.3f, scaleItem.FloatVal);
                var widthItem = GetConfig()["窗口设置"]["面板宽度"];
                if (widthItem != null) MenuWidth = Mathf.Clamp(widthItem.IntVal, 100, 600);
                var factorItem = GetConfig()["窗口设置"]["器官面板加宽倍数"];
                if (factorItem != null) PanelWidthFactor = Mathf.Clamp(factorItem.FloatVal, 1f, 3f);
                var dlgItem = GetConfig()["窗口设置"]["对话框大小"];
                if (dlgItem != null) DialogScale = Mathf.Clamp(dlgItem.FloatVal, 0.6f, 2f);
            } catch (System.Exception e) {
                LogError("生物学:读取菜单缩放配置失败 " + e);
            }
            // 功能开关:动物器官(默认关闭,只支持文明种族)+ 点击探针(调试)
            try {
                var animalItem = GetConfig()["功能开关"]["启用动物器官"];
                if (animalItem != null) AnimalOrgans = animalItem.BoolVal;
                var probeItem = GetConfig()["功能开关"]["点击探针"];
                if (probeItem != null) ClickProbe = probeItem.BoolVal;
                // 使用严格缺键回退，确保旧玩家配置不会意外开启屏幕诊断。
                ScreenDebugEnabled = ReadDiagnosticSwitch("屏幕调试提示");
                var nudeItem = GetConfig()["功能开关"]["裸体立绘"];
                if (nudeItem != null) NudeDoll = nudeItem.BoolVal;
                var wearItem = GetConfig()["功能开关"]["器官磨损"];
                if (wearItem != null) OrganWear = wearItem.BoolVal;
                var dwarfItem = GetConfig()["功能开关"]["矮人贴图"];
                if (dwarfItem != null) DwarfSkin = dwarfItem.BoolVal;
                var humanItem = GetFeatureItem("人类贴图");
                if (humanItem != null) HumanSkin = humanItem.BoolVal;
                var hideItem = GetConfig()["功能开关"]["隐藏服装"];
                if (hideItem != null) HideClothing = hideItem.BoolVal;
                LogInfo("生物学:动物器官=" + (AnimalOrgans ? "启用" : "关闭")
                    + " 点击探针=" + (ClickProbe ? "启用" : "关闭")
                    + " 屏幕调试提示=" + (ScreenDebugEnabled ? "启用" : "关闭")
                    + " 裸体立绘=" + (NudeDoll ? "启用" : "关闭")
                    + " 器官磨损=" + (OrganWear ? "启用" : "关闭")
                    + " 矮人贴图=" + (DwarfSkin ? "启用" : "关闭")
                    + " 人类贴图=" + (HumanSkin ? "启用" : "关闭")
                    + " 隐藏服装=" + (HideClothing ? "启用" : "关闭"));
            } catch (System.Exception e) {
                LogError("生物学:读取功能开关失败 " + e);
            }
            // AI 对话:从「AI设置」栏读取总开关与接口配置,推入 BioAIChat
            try {
                ModConfig cfg = GetConfig();
                if (cfg != null) {
                    var ai = cfg["AI设置"];
                    if (ai.ContainsKey("启用AI对话")) AIChatEnabled = ai["启用AI对话"].BoolVal;
                    if (ai.ContainsKey("AI接口地址")) BioAIChat.Url = (ai["AI接口地址"].TextVal ?? "").Trim();
                    if (ai.ContainsKey("AI密钥")) BioAIChat.Key = ai["AI密钥"].TextVal ?? "";
                    if (ai.ContainsKey("AI模型")) BioAIChat.Model = (ai["AI模型"].TextVal ?? "").Trim();
                    if (ai.ContainsKey("AI超时秒数")) BioAIChat.TimeoutSeconds = Mathf.Clamp(ai["AI超时秒数"].IntVal, 5, 120);
                    if (ai.ContainsKey("显示Token消耗")) BioAIChat.ShowTokenTip = ai["显示Token消耗"].BoolVal;
                }
                BioAIChat.EnabledSwitch = AIChatEnabled;
                LogInfo("生物学:AI 对话=" + (AIChatEnabled ? "启用" : "关闭")
                    + " 地址=" + (string.IsNullOrEmpty(BioAIChat.Url) ? "<空>" : BioAIChat.Url)
                    + " 模型=" + (string.IsNullOrEmpty(BioAIChat.Model) ? "<空>" : BioAIChat.Model)
                    + " 密钥=" + (string.IsNullOrEmpty(BioAIChat.Key) ? "<空>" : "已填"));
            } catch (System.Exception e) {
                LogError("生物学:读取 AI 设置失败 " + e);
            }
            UnitHealthTab.Ensure();
            // 小人头发:接管重绘的头部贴图 + 按单位发色换色(和立绘同色)
            BioHeadHair.Ensure();
            // 矮人整套换图 + 按装备换服饰(由「功能开关 → 矮人贴图」控制)
            BioDwarfSkin.Ensure();
            // 人类整套换图(由「功能开关  人类贴图」控制,默认开启)
            BioHumanSkin.Ensure();
            // 克苏鲁之脑:黄金之脑被破坏后召唤 Boss(单位资产首次使用时再惰性注册)
            CthulhuBrainPatches.Ensure();
            // 器官面板加宽动画驱动(左锚点固定,只向右扩展)
            BioPanelWidth.Ensure();
            // 调试用点击探针；组件可常驻，但只有“功能开关>点击探针”明确开启时才输出。
            BioClickProbe.Ensure();
            FamilyTracker.Ensure();
            // 神之侵犯致孕的那一胎:孕期走完时接管分娩,换成神之子
            OrganEditorUI.EnsureDivineBirthPatch();
            // 打架/生孩子/走路 → 器官磨损;另外双腿被摘掉时真的走不动(原版有移速保底 1)
            BioExperience.Ensure();
            // 收藏的单位死了先把家底抄一份,留着以后复活(见 BioResurrect)
            BioResurrect.Ensure();
            // PowerTab 等待 Canvas/PowerTabs 就绪后由 Update 重试并仅创建一次。
            BiologyPowerTab.Ensure();
            // 主线程统一死亡入口:寿命到点、致命器官缺失/衰竭均直接调用原版 die
            MortalityGuard.Ensure();
            // 胃被摘除 → 无法消化,饱食度强制归零
            NutritionGuard.Ensure();
            // 无可用双手:卸下并保全武器,停止手工具任务/搬运,隐藏所有手持渲染
            HandUseGuard.Ensure();
            // 大脑强化:取消法力上限 + 增加智力;弱化反之
            BrainStat.Ensure();
            // 常驻行为:选中单位时持续执行致命状态扣血(呼吸衰竭/尿毒症/内出血等)
            try {
                GameObject go = new GameObject("RimWorldHealthDrain");
                go.AddComponent<HealthDrainBehaviour>();
                UnityEngine.Object.DontDestroyOnLoad(go);
            } catch (System.Exception e) {
                LogError("生物学:创建持续扣血行为失败 " + e);
            }
            // 常驻守卫:双性人单位窗口性别图标每帧廉价覆盖(UnitStatsElement._icon_sex)
            try {
                GameObject go2 = new GameObject("RimWorldSexIconGuard");
                go2.AddComponent<SexIconGuardBehaviour>();
                UnityEngine.Object.DontDestroyOnLoad(go2);
            } catch (System.Exception e) {
                LogError("生物学:创建性别图标守卫失败 " + e);
            }
            // 加载完成:此后"打开官网"伪按钮才允许真正跳转
            _ready = true;
        }

        private void Update() {
            _powerTabRetry -= Time.unscaledDeltaTime;
            if (_powerTabRetry > 0f) return;
            _powerTabRetry = 1f;
            BiologyPowerTab.Ensure();
        }
    }
}
