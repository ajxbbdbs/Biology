using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace RimWorldMod {

    // 双击器官 → 打开器官操作菜单
    public class OrganClickTrigger : MonoBehaviour, IPointerClickHandler {
        public Actor Actor;
        public string OrganId;
        public RectTransform Anchor;

        public void OnPointerClick(PointerEventData pEvent) {
            OrganEditorUI.OpenOrganMenu(Actor, OrganId, Anchor, pEvent.position);
        }
    }

    // 点击黑框空白区域 → 打开"添加器官"菜单
    public class AddOrganTrigger : MonoBehaviour, IPointerClickHandler {
        public Actor Actor;
        public RectTransform Anchor;

        public void OnPointerClick(PointerEventData pEvent) {
            OrganEditorUI.OpenAddMenu(Actor, Anchor, pEvent.position);
        }
    }

    // 模态遮挡,点击菜单外区域关闭
    public class MenuBlocker : MonoBehaviour, IPointerClickHandler {
        public void OnPointerClick(PointerEventData pEvent) {
            OrganEditorUI.CloseMenu();
        }
    }

    public static class OrganEditorUI {

        // 等比缩放:面板宽度(基准280px)与菜单缩放共同决定整体倍率,所有尺寸按此比例放大/缩小
        private static float EffScale { get { return Main.MenuScale * (Main.MenuWidth / 280f); } }
        private static float S(float v) { return v * EffScale; }
        private static int F(int v) { return Mathf.Max(8, Mathf.RoundToInt(v * EffScale)); }

        private static GameObject _menu;
        private static GameObject _blocker;
        private static Canvas _menuCanvas;
        private static readonly System.Random _rng = new System.Random();

        // 器官 id → 强化后授予的特质 id(全部器官均可强化;anus 特殊:强化=紧缩,不授特质)
        // 腿/脚强化:授予轻盈(weightless)+敏捷(agile),并提升移动速度
        private static readonly Dictionary<string, string[]> StrengthenTrait = new Dictionary<string, string[]> {
            { "eye_l",   new[] { "eagle_eyed" } }, { "eye_r", new[] { "eagle_eyed" } },
            { "ear",     new[] { "lucky" } },
            { "nose",    new[] { "lucky" } },
            { "mouth",   new[] { "strong", "lucky" } },   // 嘴巴 = 原下颌(强壮) + 舌头(幸运)
            { "teeth",   new[] { "golden_tooth" } },
            { "head",    new[] { "strong_minded" } },
            // 大脑可强化,但天才特质不在这里给:改由 SyncBrainTraits 按显示血量管理
            // (>100% 去脑震荡与愚蠢,≥150% 给天才)。和肌肉走的是同一套路子。
            { "brain",   new string[0] },
            { "neck",    new[] { "strong_minded" } },
            { "chest",   new[] { "attractive" } },
            { "abdomen", new[] { "tough" } },
            { "spine",   new[] { "battle_reflexes" } },
            { "stomach", new[] { "energized" } },
            { "heart",   new[] { "heart_of_wizard" } },
            { "lung",    new[] { "titan_lungs" } },
            { "kidney",  new[] { "long_liver" } },
            { "liver",   new[] { "long_liver" } },
            { "intestine",new[] { "lucky" } },
            { "anus",    new string[0] },
            { "bladder", new[] { "energized" } },
            // 关节骨 = 原 骨骼(坚韧) + 关节(敏捷) + 骨髓(超级健康)
            { "bone",    new[] { "tough", "agile", "super_health" } },
            { "muscle",  new string[0] }, // 肌肉可强化,特质由 SyncMuscleTrait 按等级管理(150%健壮/弱化80%瘦小)
            { "blood",   new[] { "boosted_vitality" } },
            { "skin",    new[] { "hard_skin" } },
            { "hair",    new[] { "attractive" } },
            { "fur",     new[] { "tough" } },
            { "scale",   new[] { "hard_skin" } },
            { "feather", new[] { "weightless" } },
            { "tail",    new[] { "agile" } },
            { "shoulder",new[] { "strong" } },
            { "arm",     new[] { "strong" } },
            { "hand",    new[] { "strong" } },
            { "leg",     new[] { "agile", "weightless" } },
            { "foot",    new[] { "agile", "weightless" } },
            { "uterus",  new[] { "fertile" } }, { "ovary", new[] { "fertile" } }, { "vagina", new[] { "fertile" } },
            { "testicle",new[] { "fertile" } }, { "prostate", new[] { "fertile" } }, { "penis", new[] { "fertile" } },
        };

        public static void OpenOrganMenu(Actor pActor, string pOrganId, RectTransform pAnchor, Vector2 pClickPos) {
            CloseMenu();
            if (pActor == null || string.IsNullOrEmpty(pOrganId)) return;
            Main.LogInfo("生物学:打开器官操作菜单 " + pOrganId);
            RectTransform menu = CreateMenu(pAnchor, BioText.T("bio_menu_op", "器官操作"), 250f, pClickPos);
            if (menu == null) return;
            _menu = menu.gameObject;

            // 毒牙(特质器官):不可删除/强化/弱化,只有取消
            if (pOrganId == "fang") {
                AddFitButton(menu, BioText.T("bio_fang_note", "毒牙是天生特质器官,不可手术"), null);
                FinalizeMenu(menu);
                LayoutEditor.BindMenu(menu, "op");
                return;
            }

            // 2×3 网格(2列,按按钮数自动成行):按钮等大等宽,不超出窗口
            GameObject grid = new GameObject("OpGrid", typeof(RectTransform),
                typeof(GridLayoutGroup), typeof(ContentSizeFitter));
            grid.transform.SetParent(menu, false);
            RectTransform grt = grid.GetComponent<RectTransform>();
            grt.sizeDelta = new Vector2(0, 0);
            grt.pivot = new Vector2(0f, 1f); // 左上角锚点:单元格行距精确,无偏移
            GridLayoutGroup glg = grid.GetComponent<GridLayoutGroup>();
            glg.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
            glg.constraintCount = 2;
            glg.cellSize = new Vector2(S(112f), S(30f));
            glg.spacing = new Vector2(S(6f), S(15f));
            glg.childAlignment = TextAnchor.UpperLeft;
            ContentSizeFitter fitter = grid.GetComponent<ContentSizeFitter>();
            fitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            // 行1: 强化 | 弱化
            if (StrengthenTrait.ContainsKey(pOrganId)) {
                string lbl = pOrganId == "anus" ? BioText.T("bio_btn_tighten", "紧缩") : BioText.T("bio_btn_strengthen", "强化");
                AddGridButton(grid.transform, lbl, () => { StrengthenOrgan(pActor, pOrganId); CloseMenu(); }, 13);
            }
            AddGridButton(grid.transform, BioText.T("bio_btn_weaken", "弱化"), () => { WeakenOrgan(pActor, pOrganId); CloseMenu(); }, 13);
            // 行2: 强化*10 | 弱化*10
            if (StrengthenTrait.ContainsKey(pOrganId)) {
                AddGridButton(grid.transform, BioText.T("bio_btn_strengthen10", "强化*10"), () => { StrengthenOrganX10(pActor, pOrganId); CloseMenu(); }, 13);
            }
            AddGridButton(grid.transform, BioText.T("bio_btn_weaken10", "弱化*10"), () => { WeakenOrganX10(pActor, pOrganId); CloseMenu(); }, 13);
            // 行3: 删除 | 互动(若有)
            AddGridButton(grid.transform, BioText.T("bio_btn_remove", "删除"), () => { DeleteOrgan(pActor, pOrganId); CloseMenu(); }, 13);
            // 体表器官(脸/手/嘴/亲密器官等,内脏除外):打开攻略对话。
            // 亲密器官走"更进一步"(需好感达标),嘴唇走亲吻,其它体表走抚摸。
            if (BioDialogue.IsTouchable(pOrganId)) {
                AddGridButton(grid.transform, BioText.T("bio_btn_interact", "互动"), () => {
                    CloseMenu();
                    BioDialogue.OpenRelation(pActor, pOrganId);
                }, 13);
            }
            // 发色不在这里改了:器官菜单只留手术类操作,换发色改成点头像框上的头发弹色板
            // (见 OpenHairColorMenu),点脸/肩膀之类的皮肤则弹肤色板(OpenSkinColorMenu)。

            FinalizeMenu(menu);
            LayoutEditor.BindMenu(menu, "op");
        }

        /// <summary>
        /// 发色板:点头像框里的头发弹出。只有色块,没有强化/弱化那些手术操作。
        /// 当前档位的格子套一圈绿边(和亚种修改器里选中色块一个样)。
        /// </summary>
        public static void OpenHairColorMenu(Actor pActor, RectTransform pAnchor, Vector2 pClickPos) {
            CloseMenu();
            if (pActor == null) return;
            Main.LogInfo("生物学:打开发色板");
            RectTransform menu = CreateMenu(pAnchor, BioText.T("bio_menu_hair_color", "发色"),
                SwatchMenuWidth(BioHairColor.Count), pClickPos);
            if (menu == null) return;
            _menu = menu.gameObject;

            Transform grid = AddSwatchGrid(menu, BioHairColor.Count);
            int cur = BioHairColor.GetIndex(pActor);
            for (int i = 0; i < BioHairColor.Count; i++) {
                int idx = i;
                AddSwatch(grid, BioHairColor.ColorOf(idx), idx == cur, BioHairColor.NameOf(idx),
                    () => { SetHairColor(pActor, idx); CloseMenu(); });
            }

            FinalizeMenu(menu);
            LayoutEditor.BindMenu(menu, "haircolor");
        }

        /// <summary>
        /// 肤色板:点头像框里的脸/肩膀等皮肤部位弹出。格子取自游戏的表型库,
        /// 每个表型铺 4 个明暗档,和亚种修改器里那排色块同源。
        /// 列数按格子总数算,铺成横着的一片,不会堆成一根细长条。
        /// </summary>
        public static void OpenSkinColorMenu(Actor pActor, RectTransform pAnchor, Vector2 pClickPos) {
            CloseMenu();
            if (pActor == null) return;
            Main.LogInfo("生物学:打开肤色板");
            List<BioSkinColor.Swatch> all = BioSkinColor.All();
            int cols = SwatchColumns(all.Count);
            RectTransform menu = CreateMenu(pAnchor, BioText.T("bio_menu_skin_color", "肤色"),
                SwatchMenuWidth(cols), pClickPos);
            if (menu == null) return;
            _menu = menu.gameObject;

            if (all.Count == 0) {
                AddFitButton(menu, BioText.T("bio_skin_none", "读不到表型色板"), null);
            } else {
                Transform grid = AddSwatchGrid(menu, cols);
                for (int i = 0; i < all.Count; i++) {
                    BioSkinColor.Swatch sw = all[i];
                    AddSwatch(grid, sw.Color, BioSkinColor.IsCurrent(pActor, sw), null,
                        () => { SetSkinColor(pActor, sw); CloseMenu(); });
                }
            }

            FinalizeMenu(menu);
            LayoutEditor.BindMenu(menu, "skincolor");
        }

        private const float SwatchCell = 22f;    // 格子边长(未缩放)
        private const float SwatchSpace = 3f;    // 格子间距
        private const float SwatchEdge = 2f;     // 选中绿边的粗细
        private const int SwatchColsMax = 20;    // 一行最多几格
        private const float SwatchMenuPad = 22f; // 窗口左右内边距合计(与 CreateMenu 的 padding 对齐)

        // 列数:目标是宽高比 2.5:1 上下,横着铺开。格子少的时候就一行放完
        private static int SwatchColumns(int pCount) {
            if (pCount <= 0) return 6;
            if (pCount <= 8) return pCount;
            return Mathf.Clamp(Mathf.CeilToInt(Mathf.Sqrt(pCount * 2.5f)), 6, SwatchColsMax);
        }

        // 窗口宽度按列数反推,正好包住网格(标题带红叉,所以给个下限)
        private static float SwatchMenuWidth(int pColumns) {
            int cols = Mathf.Max(1, pColumns);
            return Mathf.Max(140f, cols * SwatchCell + (cols - 1) * SwatchSpace + SwatchMenuPad);
        }

        // 色块网格容器:列数按需给,行数由格子数自动决定
        private static Transform AddSwatchGrid(RectTransform pMenu, int pColumns) {
            GameObject grid = new GameObject("SwatchGrid", typeof(RectTransform),
                typeof(GridLayoutGroup), typeof(ContentSizeFitter));
            grid.transform.SetParent(pMenu, false);
            RectTransform grt = grid.GetComponent<RectTransform>();
            grt.sizeDelta = new Vector2(0, 0);
            grt.pivot = new Vector2(0f, 1f);
            GridLayoutGroup glg = grid.GetComponent<GridLayoutGroup>();
            glg.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
            glg.constraintCount = Mathf.Max(1, pColumns);
            glg.cellSize = new Vector2(S(SwatchCell), S(SwatchCell));
            glg.spacing = new Vector2(S(SwatchSpace), S(SwatchSpace));
            glg.childAlignment = TextAnchor.UpperLeft;
            glg.padding = new RectOffset(0, 0, 0, 0);
            ContentSizeFitter fitter = grid.GetComponent<ContentSizeFitter>();
            fitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            return grid.transform;
        }

        /// <summary>
        /// 一个色块:外层是边框(选中时绿色,否则深色),里面一格纯色。
        /// pTip 给悬停提示用,没有就不挂。
        /// </summary>
        private static void AddSwatch(Transform pParent, Color32 pColor, bool pCurrent, string pTip, Action pAction) {
            GameObject go = new GameObject("Swatch", typeof(RectTransform), typeof(Image), typeof(Button));
            go.transform.SetParent(pParent, false);
            Image edge = go.GetComponent<Image>();
            edge.color = pCurrent ? new Color(0.45f, 0.95f, 0.45f, 1f) : new Color(0.12f, 0.13f, 0.16f, 1f);
            edge.raycastTarget = true;

            GameObject fillGo = new GameObject("Fill", typeof(RectTransform), typeof(Image));
            fillGo.transform.SetParent(go.transform, false);
            RectTransform frt = fillGo.GetComponent<RectTransform>();
            frt.anchorMin = Vector2.zero;
            frt.anchorMax = Vector2.one;
            frt.offsetMin = new Vector2(S(SwatchEdge), S(SwatchEdge));
            frt.offsetMax = new Vector2(-S(SwatchEdge), -S(SwatchEdge));
            Image fill = fillGo.GetComponent<Image>();
            fill.color = pColor;
            fill.raycastTarget = false;

            Button btn = go.GetComponent<Button>();
            btn.targetGraphic = edge;
            btn.transition = Selectable.Transition.None;
            if (pAction != null) btn.onClick.AddListener(() => pAction());

            if (!string.IsNullOrEmpty(pTip)) {
                OrganTooltip ot = go.AddComponent<OrganTooltip>();
                ot.TipTitle = pTip;
                ot.TipDescription = "";
            }
        }

        /// <summary> 换肤色:写回表型数据后重搭立绘并重绘面板 </summary>
        public static void SetSkinColor(Actor pActor, BioSkinColor.Swatch pSwatch) {
            if (pActor == null || pSwatch == null) return;
            BioSkinColor.Apply(pActor, pSwatch);
            try {
                BioBodyDoll.ResetBuild();
                // 头像框里那个小人的动画帧是 load 时就烘好存下来的,不重新 load 一次不会变色
                BioHeadHair.RefreshAvatars(pActor);
                UnitHealthTab.RefreshAfterEdit();
            } catch (Exception e) {
                Main.LogError("生物学:改肤色后刷新面板失败 " + e);
            }
        }

        // 自适应文字宽度的按钮(深色底+白字,贴合文字)
        private static void AddFitButton(Transform pParent, string pText, Action pAction) {
            float w = EstimateTextWidth(pText, F(13)) + S(22f);
            GameObject go = new GameObject("FitBtn", typeof(RectTransform), typeof(Image), typeof(Button),
                typeof(LayoutElement));
            go.transform.SetParent(pParent, false);
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.sizeDelta = new Vector2(w, S(28));
            LayoutElement le = go.GetComponent<LayoutElement>();
            le.minWidth = w;
            le.preferredWidth = w;
            le.flexibleWidth = 0f;
            le.minHeight = S(28);
            le.preferredHeight = S(28);
            le.flexibleHeight = 0f;
            Image img = go.GetComponent<Image>();
            Sprite spr = SpriteTextureLoader.getSprite("ui/special/button");
            if (spr != null) {
                img.sprite = spr;
                img.type = Image.Type.Sliced;
            }
            img.color = new Color(0.22f, 0.30f, 0.42f, 1f);
            img.raycastTarget = true;
            Text txt = AttachText(go.transform, pText, 13, Color.white);
            Button btn = go.GetComponent<Button>();
            btn.targetGraphic = img;
            btn.transition = Selectable.Transition.None;
            if (pAction != null) {
                btn.onClick.AddListener(() => pAction());
            } else {
                btn.interactable = false;
                txt.color = new Color(0.6f, 0.6f, 0.6f);
            }
        }

        // 估算文本渲染宽度:中文按字宽,ASCII 较窄
        private static float EstimateTextWidth(string pText, int pFontSize) {
            if (string.IsNullOrEmpty(pText)) return 0f;
            float w = 0f;
            foreach (char c in pText) {
                w += c > 255 ? pFontSize * 1.0f : pFontSize * 0.58f;
            }
            return w;
        }

        /// <summary>
        /// 改发色:立绘的毛发层和世界里那个小人的头发一起换色,面板随即重绘。
        /// 入口只有一个 —— 点头像框里的头发开出的发色板。
        /// </summary>
        public static void SetHairColor(Actor pActor, int pIndex) {
            if (pActor == null) return;
            BioHairColor.SetIndex(pActor, pIndex);
            Main.LogInfo("生物学:发色已改为 " + BioHairColor.NameOf(pIndex));
            try {
                // 立绘那套换色贴图按发色指纹缓存,指纹变了要丢掉重烘
                BioDollSkin.Invalidate();
                // 小人贴图重取头 + 重烘,站着不动的单位也会立刻变色
                BioHeadHair.RefreshActor(pActor);
                UnitHealthTab.RefreshAfterEdit();
            } catch (Exception e) {
                Main.LogError("生物学:改发色后刷新面板失败 " + e);
            }
        }

        /// <summary>
        /// 点击人物立绘的某个部位时,列出该部位下现有的器官,选一个再进操作菜单。
        /// 部位只挂着一个器官时调用方会直接开 OpenOrganMenu,不会走到这里。
        /// </summary>
        public static void OpenPartMenu(Actor pActor, string pTitle, List<string> pOrganIds,
            RectTransform pAnchor, Vector2 pClickPos) {
            CloseMenu();
            if (pActor == null || pOrganIds == null || pOrganIds.Count == 0) return;
            string title = string.IsNullOrEmpty(pTitle) ? BioText.T("bio_menu_part", "身体部位") : pTitle;
            Main.LogInfo("生物学:打开立绘部位菜单 " + title + " 器官数=" + pOrganIds.Count);
            RectTransform menu = CreateMenu(pAnchor, title, 250f, pClickPos);
            if (menu == null) return;
            _menu = menu.gameObject;

            // 2×n 网格(与添加/操纵器官菜单一致)
            GameObject grid = new GameObject("PartGrid", typeof(RectTransform),
                typeof(GridLayoutGroup), typeof(ContentSizeFitter));
            grid.transform.SetParent(menu, false);
            RectTransform grt = grid.GetComponent<RectTransform>();
            grt.sizeDelta = new Vector2(0, 0);
            grt.pivot = new Vector2(0f, 1f);
            GridLayoutGroup glg = grid.GetComponent<GridLayoutGroup>();
            glg.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
            glg.constraintCount = 2;
            glg.cellSize = new Vector2(S(112f), S(30f));
            glg.spacing = new Vector2(S(6f), S(15f));
            glg.childAlignment = TextAnchor.UpperLeft;
            glg.padding = new RectOffset(0, 0, 0, 0);
            ContentSizeFitter fitter = grid.GetComponent<ContentSizeFitter>();
            fitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            RectTransform anchor = pAnchor;
            Vector2 clickPos = pClickPos;
            for (int i = 0; i < pOrganIds.Count; i++) {
                string oid = pOrganIds[i];
                Organ o;
                string name = OrganData.OrganName.TryGetValue(oid, out o) ? o.LocalizedName : oid;
                AddGridButton(grid.transform, name, () => OpenOrganMenu(pActor, oid, anchor, clickPos), 13);
            }

            FinalizeMenu(menu);
            LayoutEditor.BindMenu(menu, "part");
        }

        public static void OpenAddMenu(Actor pActor, RectTransform pAnchor, Vector2 pClickPos) {
            CloseMenu();
            if (pActor == null) return;
            Main.LogInfo("生物学:打开添加器官菜单");
            List<string> addable;
            try {
                addable = GetAddableOrgans(pActor);
            } catch (Exception e) {
                Main.LogError("生物学:获取可添加器官失败 " + e);
                return;
            }
            RectTransform menu = CreateMenu(pAnchor, BioText.T("bio_menu_add", "添加器官"), 250f, pClickPos);
            if (menu == null) return;
            _menu = menu.gameObject;
            if (addable.Count == 0) {
                AddFitButton(menu, BioText.T("bio_add_none", "没有可添加的器官"), null);
            } else {
                // 2×n 网格布局(与操纵器官窗口一致):每行 2 个,后续器官自动往下加
                GameObject grid = new GameObject("AddGrid", typeof(RectTransform),
                    typeof(GridLayoutGroup), typeof(ContentSizeFitter));
                grid.transform.SetParent(menu, false);
                RectTransform grt = grid.GetComponent<RectTransform>();
                grt.sizeDelta = new Vector2(0, 0);
                grt.pivot = new Vector2(0f, 1f); // 左上角锚点:单元格行距精确,无偏移
                GridLayoutGroup glg = grid.GetComponent<GridLayoutGroup>();
                glg.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
                glg.constraintCount = 2;
                glg.cellSize = new Vector2(S(112f), S(30f));
                glg.spacing = new Vector2(S(6f), S(15f));
                glg.childAlignment = TextAnchor.UpperLeft;
                glg.padding = new RectOffset(0, 0, 0, 0);
                ContentSizeFitter fitter = grid.GetComponent<ContentSizeFitter>();
                fitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
                fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

                for (int i = 0; i < addable.Count; i++) {
                    string oid = addable[i];
                    Organ o;
                    string name = OrganData.OrganName.TryGetValue(oid, out o) ? o.LocalizedName : oid;
                    string captured = oid;
                    AddGridButton(grid.transform, name, () => { AddOrgan(pActor, captured); CloseMenu(); }, 13);
                }
            }
            FinalizeMenu(menu);
            LayoutEditor.BindMenu(menu, "add");
        }

        private static List<string> GetAddableOrgans(Actor pActor) {
            HashSet<string> current = HealthSimulator.GetCurrentOrgans(pActor);
            // 只列出该种族计划内存在的器官(人类不会出现鳞片/羽毛/关节/骨骼/血液等无用项)
            HashSet<string> planOrgans = new HashSet<string>();
            foreach (OrganGroup g in OrganData.GetPlan(pActor.isAnimal())) {
                foreach (string oid in g.OrganIds) {
                    planOrgans.Add(oid);
                }
            }
            // 动物:只保留该物种对应的皮肤器官
            string animalSkin = null;
            string animalKind = null;
            string sid = "?";
            if (pActor.isAnimal()) {
                try { if (pActor.asset != null && !string.IsNullOrEmpty(pActor.asset.id)) sid = pActor.asset.id; } catch { }
                animalSkin = OrganData.GetAnimalSkin(sid);
                animalKind = OrganData.GetAnimalKind(sid);
            }
            bool isMammal = animalKind == "mammal";
            bool usesCloaca = animalKind == "fish" || animalKind == "bird" || animalKind == "reptile";
            bool isBird = animalKind == "bird";
            bool isFish = animalKind == "fish";
            bool hasHorn = isMammal && OrganData.HasHorn(sid);
            bool hasLegs = pActor.isAnimal() && OrganData.HasLegs(sid);
            bool hasWings = pActor.isAnimal() && OrganData.HasWings(sid);
            bool hasGills = pActor.isAnimal() && OrganData.HasGills(sid);
            bool usesBeak = pActor.isAnimal() && OrganData.UsesBeak(sid);
            List<string> result = new List<string>();
            foreach (string oid in planOrgans) {
                if (current.Contains(oid)) continue;
                // 下游器官只能在其直接父级存在时添加；父级菜单项会同步恢复整条下游链。
                if (!LimbDependency.HasPresentParent(oid, current)) continue;
                if (pActor.isAnimal() && (oid == "fur" || oid == "scale" || oid == "feather") && oid != animalSkin) continue;
                // 非哺乳动物(鱼/禽/爬行):不可添加肛门/乳房/阴茎/阴道等器官(用泄殖腔)
                if (usesCloaca && (oid == "anus" || oid == "chest" || oid == "uterus" || oid == "ovary" || oid == "vagina"
                    || oid == "testicle" || oid == "prostate" || oid == "penis")) continue;
                // 哺乳动物:不可添加泄殖腔
                if (isMammal && oid == "cloaca") continue;
                // 鸟/龟:不可添加牙齿(用喙)
                if (usesBeak && oid == "teeth") continue;
                // 鸟/鱼:不可添加鼻(鸟用喙,鱼无外鼻)
                if ((isBird || isFish) && oid == "nose") continue;
                // 喙:仅鸟/龟
                if (oid == "beak" && !usesBeak) continue;
                // 角:仅长角物种
                if (oid == "horn" && !hasHorn) continue;
                // 鳃:仅鱼类;鱼类不可添加肺
                if (oid == "gills" && !hasGills) continue;
                if (oid == "lung" && hasGills) continue;
                // 翅膀:仅鸟类
                if ((oid == "wing_l" || oid == "wing_r") && !hasWings) continue;
                // 腿:无腿动物物种(蛇/蠕虫)不可添加;人类始终有腿
                if (pActor.isAnimal() && oid == "leg" && !hasLegs) continue;
                result.Add(oid);
            }
            return result;
        }

        // 摘除后授予的特质(使用模组已验证存在的特质 id)
        private static readonly Dictionary<string, string> RemoveTrait = new Dictionary<string, string> {
            { "eye_l", "eyepatch" }, { "eye_r", "eyepatch" },
            { "arm", "crippled" },
            { "hand", "crippled" },
            { "leg", "crippled" },
            { "foot", "crippled" },
            { "shoulder", "crippled" },
            { "spine", "crippled" },
            { "bone", "crippled" },
            { "muscle", "crippled" },
            { "mouth", "mute" },
            { "hair", "ugly" },
            { "testicle", "infertile" }, { "penis", "infertile" }, { "prostate", "infertile" },
            { "uterus", "infertile" }, { "ovary", "infertile" }, { "vagina", "infertile" },
        };

        private static void DeleteOrgan(Actor pActor, string pOrganId) {
            ActorWoundState state = HealthSimulator.GetState(pActor.getID());
            bool handsBefore = HealthSimulator.HasUsableHandsFast(pActor);
            // 根器官结算一次后果；依赖 API 递归清理全部下游状态与伤口，下游不重复即时伤害。
            LimbDependency.RemoveWithDownstream(state, pOrganId);
            ApplyRemoveConsequence(pActor, pOrganId);
            SyncMuscleTrait(pActor);
            Refresh(pActor, handsBefore);
            // 摘除器官是重操作:弹一次反应对话(好感度大跌)。单位已死则跳过。
            BioDialogue.ShowReaction(pActor, pOrganId, "摘除器官", -25, BioDialogue.RemoveReply);
        }

        // 摘除器官 → 附加的持久疾病:器官id → [疾病id, 宿主器官id]
        // 无特质对应的器官用"削属性"体现:给该器官挂匹配疾病或通用虚弱
        private static readonly Dictionary<string, string[]> RemoveDisease = new Dictionary<string, string[]> {
            { "lung",     new[] { "stamina_loss", "blood" } },
            { "kidney",   new[] { "stamina_loss", "blood" } },
            { "stomach",  new[] { "malnutrition", "intestine" } },
            { "liver",    new[] { "poison_susceptibility", "blood" } },
            { "testicle", new[] { "hormone_imbalance", "blood" } },
            { "ovary",    new[] { "hormone_imbalance", "blood" } },
            { "uterus",   new[] { "hormone_imbalance", "blood" } },
            { "intestine",new[] { "malnutrition", "blood" } },
            { "muscle",   new[] { "muscle_atrophy", "blood" } },
            // 关节骨:原 骨髓(贫血) / 关节(关节炎) / 骨骼(骨质疏松) 三者合一,取骨质疏松为代表
            { "bone",     new[] { "osteoporosis", "blood" } },
            { "bladder",  new[] { "incontinence", "blood" } },
            { "anus",     new[] { "anal_blockage", "intestine" } },
            { "chest",    new[] { "breast_cancer", "blood" } },
            { "ear",      new[] { "deafness", "head" } },
            { "nose",     new[] { "rhinitis", "head" } },
            { "teeth",    new[] { "malnutrition", "intestine" } },
            // 嘴巴:原 下颌(营养不良) + 舌头(失语),取失语为代表
            { "mouth",    new[] { "mutism", "head" } },
            { "skin",     new[] { "dermatitis", "blood" } },
            { "hair",     new[] { "hair_loss", "skin" } },
            { "fur",      new[] { "fur_loss", "skin" } },
            { "scale",    new[] { "scale_loss", "skin" } },
            { "feather",  new[] { "feather_loss", "skin" } },
            { "tail",     new[] { "tail_loss", "spine" } },
            { "abdomen",  new[] { "malnutrition", "intestine" } },
            { "leg",      new[] { "fracture_leg", "leg" } },
            { "foot",     new[] { "fracture_foot", "leg" } },
        };

        private static void ApplyRemoveDisease(Actor pActor, string pOrganId) {
            ActorWoundState state = HealthSimulator.GetState(pActor.getID());
            // 眼:单眼→独眼(特质);双眼都没→失明(疾病挂头部)
            if (pOrganId == "eye_l" || pOrganId == "eye_r") {
                string other = pOrganId == "eye_l" ? "eye_r" : "eye_l";
                if (IsInactive(state, other)) {
                    state.Mods.ModDiseases["head"] = "blindness";
                }
                return;
            }
            string[] info;
            if (!RemoveDisease.TryGetValue(pOrganId, out info)) return;
            state.Mods.ModDiseases[info[1]] = info[0];
        }

        // 器官是否已失效:被摘除,或弱化到衰竭(≤-100,HP归零)。两者代价等同。
        private static bool IsInactive(ActorWoundState pState, string pOrganId) {
            if (pState == null || pState.Mods == null) return false;
            if (pState.Mods.RemovedOrgans != null && pState.Mods.RemovedOrgans.Contains(pOrganId)) return true;
            int hm = 0;
            if (pState.Mods.HpMods != null && pState.Mods.HpMods.TryGetValue(pOrganId, out hm) && hm <= -100) return true;
            return false;
        }

        // 弱化到衰竭(≤-100,器官Hp归零) → 代价与摘除等价:
        // 致命器官即死,其余器官照搬摘除后果(特质/疾病/成对后果/生命损伤)。
        // FailedOrgans 记录已结算的器官,避免连续点击弱化时重复扣血/重复授特质。
        private static void CheckWeakenedToZero(Actor pActor, string pOrganId) {
            try {
                if (pActor == null || string.IsNullOrEmpty(pOrganId)) return;
                ActorWoundState state = HealthSimulator.GetState(pActor.getID());
                int hm = 0;
                state.Mods.HpMods.TryGetValue(pOrganId, out hm);
                if (hm > -100) return; // 尚未弱化到 0%,无代价
                if (pOrganId == "bone") {
                    ApplyBoneFailureConsequences(pActor, state);
                    return;
                }
                if (state.Mods.FailedOrgans.Contains(pOrganId)) return; // 已结算过,跳过
                state.Mods.FailedOrgans.Add(pOrganId);
                ApplyRemoveConsequence(pActor, pOrganId);
                Main.LogInfo("生物学:器官弱化到衰竭(等同摘除代价) " + pOrganId);
            } catch (Exception e) {
                Main.LogError("生物学:弱化衰竭代价结算失败 " + e);
            }
        }

        public static void ApplyBoneFailureConsequences(Actor pActor, ActorWoundState pState) {
            if (pState.Mods.FailedOrgans.Contains("bone")) return;
            pState.Mods.FailedOrgans.Add("bone");
            TryAddTrait(pActor, "crippled");
            HealthSimulator.PinCrippledFracture(pActor, "bone");
            if (!pState.Mods.ModDiseases.ContainsKey("bone"))
                pState.Mods.ModDiseases["bone"] = "osteoporosis";
            try {
                pActor.getHit(pActor.getHealth() * 0.40f, false, AttackType.Divine,
                    null, false, false, false);
            } catch (Exception e) {
                Main.LogError("生物学:关节骨衰竭首次损伤失败 " + e);
            }
        }

        private static void ApplyRemoveConsequence(Actor pActor, string pOrganId) {
            // 即时编辑也只走统一入口;该入口按现有状态判定致命器官缺失/最终 Hp<=0。
            MortalityGuard.ProcessExistingState(pActor);
            if (pActor == null || !pActor.isAlive()) return;
            ActorWoundState state = HealthSimulator.GetState(pActor.getID());
            // 每个器官摘除都有对应后果:有特定特质给特质,有特定疾病给疾病,否则通用虚弱
            bool hasTrait = RemoveTrait.ContainsKey(pOrganId);
            bool hasDisease = RemoveDisease.ContainsKey(pOrganId) || pOrganId == "eye_l" || pOrganId == "eye_r";
            if (hasTrait) {
                TryAddTrait(pActor, RemoveTrait[pOrganId]);
                // 仅“弱化至衰竭”保留占位伤；真正摘除必须保持器官状态已清空。
                // ApplyTraitWounds 会识别缺失肢体，不会把残疾伤重新随机分配给完好肢体。
                if (RemoveTrait[pOrganId] == "crippled"
                    && !state.Mods.RemovedOrgans.Contains(pOrganId)) {
                    HealthSimulator.PinCrippledFracture(pActor, pOrganId);
                }
            }
            ApplyRemoveDisease(pActor, pOrganId);
            // 无特质无疾病对应的器官:通用削属性(虚弱 + 生命损伤),确保每个器官摘除都有反应
            if (!hasTrait && !hasDisease) {
                TryAddTrait(pActor, "weak");
            }
            // 关键器官摘除:致命后果(肺=窒息、肾=肾衰、双眼=失明已在疾病)
            CheckPairRemoval(pActor, pOrganId);
            // 其余器官:健康损伤,按器官重要性区分(关节/肌肉等重要部位扣血更多)
            float damageRatio = GetRemoveDamageRatio(pOrganId);
            try {
                pActor.getHit(pActor.getHealth() * damageRatio, false, AttackType.Divine, null, false, false, false);
            } catch (Exception e) {
                Main.LogError("生物学:删除器官损伤失败 " + e);
            }
        }

        // 摘除器官的生命损伤比例(重要活动器官扣血更多)
        private static float GetRemoveDamageRatio(string pOrganId) {
            switch (pOrganId) {
                case "bone": case "muscle": case "spine":
                    return 0.40f; // 重要承重/活动器官:扣 40%
                case "stomach": case "liver": case "intestine":
                case "lung": case "kidney":
                    return 0.30f; // 关键内脏:扣 30%
                case "arm": case "hand": case "leg": case "foot": case "shoulder":
                    return 0.25f; // 四肢:扣 25%
                default:
                    return 0.15f; // 其余:扣 15%
            }
        }

        // 关键器官摘除 → 严重惩罚与持续扣血(弱化到衰竭的器官按摘除同等对待)
        private static void CheckPairRemoval(Actor pActor, string pOrganId) {
            ActorWoundState state = HealthSimulator.GetState(pActor.getID());
            // 肺:窒息
            if (IsInactive(state, "lung")) {
                state.Mods.ModDiseases["chest"] = "respiratory_failure";
                ApplyDrain(pActor, 0.06f, "肺摘除·窒息");
            }
            // 肾:肾衰竭
            if (IsInactive(state, "kidney")) {
                state.Mods.ModDiseases["blood"] = "uremia";
                ApplyDrain(pActor, 0.04f, "肾摘除·肾衰竭");
            }
            // 双臂/双手/双腿/双脚:活动不能 → 全身健康下降
            if (IsInactive(state, "arm") || IsInactive(state, "hand")
                || IsInactive(state, "leg") || IsInactive(state, "foot")) {
                ApplyDrain(pActor, 0.03f, "四肢缺失");
            }
            // 脊椎:瘫痪,持续扣血 + 行动不能 + 耐力归零
            if (IsInactive(state, "spine")) {
                state.Mods.ModDiseases["spine"] = "paralysis";
                state.Mods.ModDiseases["blood"] = "stamina_loss";
                ApplyDrain(pActor, 0.03f, "瘫痪卧床");
            }
            // 腹部:内脏暴露、大出血 → 持续扣血
            if (IsInactive(state, "abdomen")) {
                state.Mods.ModDiseases["blood"] = "internal_bleeding";
                ApplyDrain(pActor, 0.05f, "腹部暴露·大出血");
            }
            // 胃:消化功能丧失 → 持续扣血(无法进食)
            if (IsInactive(state, "stomach")) {
                state.Mods.ModDiseases["intestine"] = "no_stomach";
                ApplyDrain(pActor, 0.04f, "胃摘除·无法消化");
            }
            // 肛门:改为肛门堵塞(不是失禁)→ 持续扣血
            if (IsInactive(state, "anus")) {
                state.Mods.ModDiseases["intestine"] = "anal_blockage";
                ApplyDrain(pActor, 0.02f, "肛门堵塞");
            }
        }

        // 持续扣血:pRatio 为每次结算扣血比例(模拟按世界时间 tick 触发)
        private static void ApplyDrain(Actor pActor, float pRatio, string pReason) {
            try {
                // 首次扣血 + 标记持续扣血(通过 ModDiseases 的 respiratory_failure 等体现)
                pActor.getHit(pActor.getHealth() * pRatio, false, AttackType.Divine, null, false, false, false);
                Main.LogInfo("生物学:持续扣血 " + pReason);
            } catch (Exception e) {
                Main.LogError("生物学:持续扣血失败 " + e);
            }
        }

        /// <summary> 加特质。返回加完之后身上到底有没有这个特质(原版会因为对立特质等原因拒掉) </summary>
        private static bool TryAddTrait(Actor pActor, string pTraitId) {
            try {
                if (string.IsNullOrEmpty(pTraitId)) return false;
                if (HasTrait(pActor, pTraitId)) return true;
                pActor.addTrait(pTraitId, false);
                return HasTrait(pActor, pTraitId);
            } catch (Exception e) {
                Main.LogError("生物学:授予特质失败 " + pTraitId + " " + e);
                return false;
            }
        }

        private static bool HasTrait(Actor pActor, string pTraitId) {
            if (pActor.traits == null) return false;
            foreach (ActorTrait t in pActor.traits) {
                if (t == null) continue;
                if (!string.IsNullOrEmpty(t.id) && t.id == pTraitId) return true;
            }
            return false;
        }

        // 肌肉 → 体质特质联动:强化≥150%授予健壮(strong),弱化≤-80%授予瘦小(weak),两者互斥;
        // 中间态(80~150)移除健壮;天生携带健壮的单位,肌肉自动同步为150%(单位生成即生效)。
        public static void SyncMuscleTrait(Actor pActor) {
            if (pActor == null) return;
            try {
                ActorWoundState state = HealthSimulator.GetState(pActor.getID());
                if (state == null || state.Mods == null) return;
                // 肌肉被摘除:视作极限弱化(瘦小),覆盖一切强化等级
                if (state.Mods.RemovedOrgans != null && state.Mods.RemovedOrgans.Contains("muscle")) {
                    state.Mods.HpMods.Remove("muscle");
                    TryAddTrait(pActor, "weak");
                    if (HasTrait(pActor, "strong")) RemoveTraitFromActor(pActor, "strong");
                    return;
                }
                int hm = 0;
                if (!state.Mods.HpMods.TryGetValue("muscle", out hm)) hm = 0;
                // 天生健壮(strong)且肌肉从未被强化(未到150) → 初始化为150%,与特质一致
                if (hm < 150 && HasTrait(pActor, "strong")) {
                    state.Mods.HpMods["muscle"] = 150;
                    hm = 150;
                }
                bool hasStrong = HasTrait(pActor, "strong");
                bool hasWeak = HasTrait(pActor, "weak");
                if (hm >= 150) {
                    // 达到健壮线:授予健壮,移除瘦小
                    if (hasWeak) RemoveTraitFromActor(pActor, "weak");
                    if (!hasStrong) TryAddTrait(pActor, "strong");
                } else if (hm <= -80) {
                    // 弱化到80%以下:授予瘦小,移除健壮
                    if (hasStrong) RemoveTraitFromActor(pActor, "strong");
                    if (!hasWeak) TryAddTrait(pActor, "weak");
                } else {
                    // 中间态(80<hm<150):移除健壮,也不保留瘦小
                    if (hasStrong) RemoveTraitFromActor(pActor, "strong");
                    if (hasWeak) RemoveTraitFromActor(pActor, "weak");
                }
            } catch (Exception e) {
                Main.LogError("生物学:同步肌肉特质失败 " + e);
            }
        }

        // 大脑 → 智力特质联动(按显示血量,不是按强化等级)。三条线:
        //   ≤70%  → 获得愚蠢,并摘掉天才(两者语义相反)。70 这个数不是随手定的:愚蠢那条绑定
        //           TraitBinding("脑震荡(大脑70%)", "stupid", "dumb").Give(concussion, 70) 本身就是
        //           把大脑压到 70%,所以拿 70% 当"蠢到该有这个特质"的线,和数据自洽。
        //   >100% → 摘掉脑震荡和愚蠢。顺序很重要:脑震荡不是独立挂上去的病,而是上面那条绑定从愚蠢
        //           推出来的,只删病不删特质,下一次 Simulate 会连伤带病一起原样打回来。
        //   ≥150% → 授予天才。
        // 天才不会因为掉到 150% 以下就被剥夺(那是很多单位的天生特质,打开面板看一眼就摘掉太粗暴),
        // 只有掉到 ≤70% 才摘 —— 脑子都成那样了,不算天才也说得过去。
        private const int BrainStupidHp = 70;    // 显示血量 ≤ 此值 → 愚蠢
        private const int BrainGeniusHp = 150;   // 显示血量 ≥ 此值 → 天才
        private const int BrainGeniusMods = 30;  // 天生天才的大脑初始强化等级(3 级)

        // 愚蠢的 id 在不同版本/整合包里不一样(TraitBinding 里同时登记了 stupid 和 dumb),
        // 所以挨个试、挂上了就停,而不是硬编码一个可能在当前版本根本不存在的 id
        private static readonly string[] StupidTraitIds = { "dumb", "stupid" };

        /// <summary>
        /// 天生天才 → 大脑一开始就是强化过的。只在大脑从来没被动过(HpMods 里没有 brain 这个键)时
        /// 初始化一次,之后玩家怎么调都不再干预。
        /// 肌肉那边用的是"值 &lt;150 就重置"的写法,结果天生健壮的单位肌肉永远弱化不下去,这里不抄那个坑。
        /// 天才自带 Boost("brain", 25),所以 30 级之后显示血量是 100+25+30=155%。
        /// 必须在 Simulate 之前调,否则这一帧算出来的血量还是旧的。
        /// </summary>
        public static void PrimeBrainMods(Actor pActor) {
            if (pActor == null) return;
            try {
                if (!HasTrait(pActor, "genius")) return;
                ActorWoundState state = HealthSimulator.GetState(pActor.getID());
                if (state == null || state.Mods == null || state.Mods.HpMods == null) return;
                if (state.Mods.HpMods.ContainsKey("brain")) return;
                state.Mods.HpMods["brain"] = BrainGeniusMods;
            } catch (Exception e) {
                Main.LogError("生物学:初始化天才大脑失败 " + e);
            }
        }

        public static void SyncBrainTraits(Actor pActor, BodyHealth pBody) {
            if (pActor == null || pBody == null) return;
            try {
                int hp = -1;
                foreach (OrganHealth oh in pBody.Organs) {
                    if (oh != null && oh.Def != null && oh.Def.Id == "brain") {
                        hp = oh.Hp;
                        break;
                    }
                }
                if (hp < 0) return;   // 这个单位没有大脑这个器官
                ActorWoundState state = HealthSimulator.GetState(pActor.getID());
                if (state == null || state.Mods == null) return;

                if (hp <= BrainStupidHp) {
                    if (HasTrait(pActor, "genius")) RemoveTraitFromActor(pActor, "genius");
                    AddStupidTrait(pActor);
                } else if (hp > 100) {
                    // 先摘特质,再摘病
                    foreach (string id in StupidTraitIds) RemoveTraitFromActor(pActor, id);
                    string cur;
                    if (state.Mods.ModDiseases.TryGetValue("brain", out cur) && cur == "concussion") {
                        state.Mods.ModDiseases.Remove("brain");
                    }
                }
                if (hp >= BrainGeniusHp) TryAddTrait(pActor, "genius");
            } catch (Exception e) {
                Main.LogError("生物学:同步大脑特质失败 " + e);
            }
        }

        // 逐个 id 尝试授予愚蠢,已经有了就什么都不做
        private static void AddStupidTrait(Actor pActor) {
            foreach (string id in StupidTraitIds) {
                if (HasTrait(pActor, id)) return;
            }
            foreach (string id in StupidTraitIds) {
                TryAddTrait(pActor, id);
                if (HasTrait(pActor, id)) return;
            }
            Main.LogInfo("生物学:未能授予愚蠢特质,当前版本里 dumb/stupid 都不存在");
        }

        // 器官恢复满血(100%)后,自动移除摘除该器官时获得的负面特质/疾病
        public static void SyncRestoredTraits(Actor pActor, BodyHealth pBody) {
            if (pActor == null || pBody == null) return;
            try {
                ActorWoundState state = HealthSimulator.GetState(pActor.getID());
                Dictionary<string, int> hpById = new Dictionary<string, int>();
                foreach (OrganHealth oh in pBody.Organs) {
                    hpById[oh.Def.Id] = oh.Hp;
                }
                // 特质:该特质对应的所有器官都满血 → 移除该特质
                // (如:缺任一肢体则保留残疾;所有肢体恢复才移除残疾)
                Dictionary<string, List<string>> traitGroups = new Dictionary<string, List<string>>();
                foreach (KeyValuePair<string, string> kv in RemoveTrait) {
                    List<string> list;
                    if (!traitGroups.TryGetValue(kv.Value, out list)) {
                        list = new List<string>();
                        traitGroups[kv.Value] = list;
                    }
                    if (!list.Contains(kv.Key)) list.Add(kv.Key);
                }
                foreach (KeyValuePair<string, List<string>> kv in traitGroups) {
                    if (GroupAllRestored(kv.Value, state.Mods.RemovedOrgans, hpById)) {
                        RemoveTraitFromActor(pActor, kv.Key);
                    }
                }
                // 疾病:该疾病对应的所有器官都满血 → 移除该疾病
                Dictionary<string, List<string>> diseaseGroups = new Dictionary<string, List<string>>();
                Dictionary<string, string> diseaseHost = new Dictionary<string, string>();
                foreach (KeyValuePair<string, string[]> kv in RemoveDisease) {
                    string diseaseId = kv.Value[0];
                    string host = kv.Value[1];
                    List<string> list;
                    if (!diseaseGroups.TryGetValue(diseaseId, out list)) {
                        list = new List<string>();
                        diseaseGroups[diseaseId] = list;
                    }
                    if (!list.Contains(kv.Key)) list.Add(kv.Key);
                    diseaseHost[diseaseId] = host;
                }
                foreach (KeyValuePair<string, List<string>> kv in diseaseGroups) {
                    if (!GroupAllRestored(kv.Value, state.Mods.RemovedOrgans, hpById)) continue;
                    string host;
                    if (!diseaseHost.TryGetValue(kv.Key, out host)) continue;
                    string cur;
                    if (state.Mods.ModDiseases.TryGetValue(host, out cur) && cur == kv.Key) {
                        state.Mods.ModDiseases.Remove(host);
                    }
                }
                // 眼睛:双眼都恢复满血 → 移除失明(盲眼疾病挂头部)
                if (hpById.ContainsKey("eye_l") && hpById["eye_l"] >= 100 &&
                    hpById.ContainsKey("eye_r") && hpById["eye_r"] >= 100) {
                    string cur;
                    if (state.Mods.ModDiseases.TryGetValue("head", out cur) && cur == "blindness") {
                        state.Mods.ModDiseases.Remove("head");
                    }
                }
                // 可侵犯器官(肛门/阴道):自身满血(紧缩/复原) → 移除侵犯造成的疾病(失禁/激素失衡)
                RemoveViolationDiseaseIfRestored(state, hpById, "anus", "incontinence");
                RemoveViolationDiseaseIfRestored(state, hpById, "vagina", "hormone_imbalance");
            } catch (Exception e) {
                Main.LogError("生物学:特质恢复同步失败 " + e);
            }
        }

        // 某器官组是否全部满血(存在且 Hp>=100);因性别/种族本就不存在的器官视为满足
        private static bool GroupAllRestored(List<string> pOrgans, HashSet<string> pRemoved,
            Dictionary<string, int> pHpById) {
            foreach (string oid in pOrgans) {
                if (pRemoved.Contains(oid)) return false;
                int hp;
                if (pHpById.TryGetValue(oid, out hp)) {
                    if (hp < 100) return false;
                }
            }
            return true;
        }

        // 可侵犯器官自身满血 → 移除该器官上由侵犯造成的疾病(紧缩后不再失禁)
        private static void RemoveViolationDiseaseIfRestored(ActorWoundState pState,
            Dictionary<string, int> pHpById, string pOrganId, string pDiseaseId) {
            int hp;
            if (!pHpById.TryGetValue(pOrganId, out hp) || hp < 100) return;
            string cur;
            if (pState.Mods.ModDiseases.TryGetValue(pOrganId, out cur) && cur == pDiseaseId) {
                pState.Mods.ModDiseases.Remove(pOrganId);
            }
        }

        private static void RemoveTraitFromActor(Actor pActor, string pTraitId) {
            if (pActor.traits == null || string.IsNullOrEmpty(pTraitId)) return;
            try {
                List<ActorTrait> toRemove = new List<ActorTrait>();
                foreach (ActorTrait t in pActor.traits) {
                    if (t != null && !string.IsNullOrEmpty(t.id) && t.id == pTraitId) {
                        toRemove.Add(t);
                    }
                }
                foreach (ActorTrait t in toRemove) {
                    pActor.removeTrait(t);
                }
            } catch (Exception e) {
                Main.LogError("生物学:移除恢复特质失败 " + e);
            }
        }

        // 强化等级:每级 +10,无上限(无限强化)
        public static int GetStrengthenLevel(Actor pActor, string pOrganId) {
            ActorWoundState state = HealthSimulator.GetState(pActor.getID());
            int cur = 0;
            state.Mods.HpMods.TryGetValue(pOrganId, out cur);
            return cur / 10;
        }

        // 强化一次:+10,无上限;第 3 级(≥30)时授予对应特质
        /// <summary>
        /// 关节骨 → 体型特质联动:
        ///   面板显示 ≥ BoneGiantHp% → 巨大,并摘掉渺小
        ///   面板显示 ≤ BoneTinyHp%  → 渺小,并摘掉巨大
        ///   中间                    → 两个都摘掉
        /// 巨大和渺小在原版里互为对立特质,所以永远只留一个;加之前必须先把另一个摘掉,
        /// 否则 addTrait 会被拒(TryAddTrait 现在会回读确认,不信它的返回值)。
        ///
        /// ⚠ 阈值用的是**面板上那个百分比**,不是 HpMods。第一版拿 HpMods 当阈值是错的:
        /// HpMods 是纯修正量(强化一次 +10、强化*10 +100),150 对应面板上 250% 左右,
        /// 玩家强化到面板 150% 时 HpMods 才 50,当然什么都不会发生。SyncBrainTraits 早就
        /// 是按显示血量判的,这里跟它对齐。
        ///
        /// 天生带巨大/渺小的单位,第一次看到时反过来把关节骨顶到对应区间(只做一次,见 BoneSynced)
        /// —— 不这么做的话一打开面板就会把它们天生的体型特质当成"中间态"摘掉。
        /// 身高那边(BioHeight)读的是特质,所以这条链走通之后,强化关节骨会把人撑高,弱化会压矮。
        /// </summary>
        public const int BoneGiantHp = 150;
        public const int BoneTinyHp = 80;

        public static void SyncBoneTrait(Actor pActor, BodyHealth pBody) {
            if (pActor == null || pBody == null) return;
            try {
                ActorWoundState state = HealthSimulator.GetState(pActor.getID());
                if (state == null || state.Mods == null) return;
                // 关节骨被摘掉:视作极限弱化(渺小),覆盖一切强化等级
                if (state.Mods.RemovedOrgans != null && state.Mods.RemovedOrgans.Contains("bone")) {
                    state.Mods.HpMods.Remove("bone");
                    if (HasTrait(pActor, "giant")) RemoveTraitFromActor(pActor, "giant");
                    TryAddTrait(pActor, "tiny");
                    return;
                }
                // 面板上那个百分比:阈值就是按它判的
                int hp = 100;
                bool found = false;
                foreach (OrganHealth oh in pBody.Organs) {
                    if (oh != null && oh.Def != null && oh.Def.Id == "bone") {
                        hp = oh.Hp;
                        found = true;
                        break;
                    }
                }
                if (!found) return;   // 这个物种没有关节骨,不参与体型联动
                bool hasGiant = HasTrait(pActor, "giant");
                bool hasTiny = HasTrait(pActor, "tiny");
                // 反向回填只在第一次看这个单位时做一次 —— 那时候身上的特质才是"天生带的"。
                // 每次都回填的话,自己刚授出去的渺小会把玩家后续的强化一次次按回去:
                // 弱化到渺小之后就再也强化不上去,也永远到不了巨大那一档。
                if (!state.Mods.BoneSynced) {
                    state.Mods.BoneSynced = true;
                    // 顶到对应区间内。巨大自带 Boost("bone",25)、渺小自带 Penalty("bone",25),
                    // 所以这里给的修正量再加上那一份,面板值就落在阈值该在的那一侧
                    if (hasGiant && hp < BoneGiantHp) {
                        state.Mods.HpMods["bone"] = BoneGiantHp - 100;
                        return;   // 改了修正量,这一帧的 hp 已经过期,下一次 Rebuild 再判
                    }
                    if (hasTiny && hp > BoneTinyHp) {
                        state.Mods.HpMods["bone"] = BoneTinyHp - 100 - 20;
                        return;
                    }
                }
                if (hp >= BoneGiantHp) {
                    // 巨大和渺小在原版里是对立特质,身上还挂着渺小的话 addTrait("giant") 会被拒,
                    // 所以必须先摘掉渺小再加。加完回读一次确认 —— 不确认的话拒了也照样打
                    // "已获得巨大"的日志,查起来完全看不出问题在哪。
                    if (hasTiny) RemoveTraitFromActor(pActor, "tiny");
                    if (!hasGiant) {
                        bool ok = TryAddTrait(pActor, "giant");
                        if (!ok && HasTrait(pActor, "tiny")) {
                            RemoveTraitFromActor(pActor, "tiny");
                            ok = TryAddTrait(pActor, "giant");
                        }
                        Main.LogInfo("生物学:关节骨到 " + hp + "% → 加巨大"
                            + (ok ? "成功" : "失败(仍带渺小=" + HasTrait(pActor, "tiny") + ")"));
                    }
                } else if (hp <= BoneTinyHp) {
                    if (hasGiant) RemoveTraitFromActor(pActor, "giant");
                    if (!hasTiny) {
                        bool ok = TryAddTrait(pActor, "tiny");
                        if (!ok && HasTrait(pActor, "giant")) {
                            RemoveTraitFromActor(pActor, "giant");
                            ok = TryAddTrait(pActor, "tiny");
                        }
                        Main.LogInfo("生物学:关节骨到 " + hp + "% → 加渺小"
                            + (ok ? "成功" : "失败"));
                    }
                } else {
                    if (hasGiant) RemoveTraitFromActor(pActor, "giant");
                    if (hasTiny) RemoveTraitFromActor(pActor, "tiny");
                }
            } catch (Exception e) {
                Main.LogError("生物学:同步关节骨体型特质失败 " + e);
            }
        }

        private static void StrengthenOrgan(Actor pActor, string pOrganId) {
            ActorWoundState state = HealthSimulator.GetState(pActor.getID());
            int cur = 0;
            state.Mods.HpMods.TryGetValue(pOrganId, out cur);
            int next = cur + 10;
            state.Mods.HpMods[pOrganId] = next;
            // 恢复超过衰竭线(-100) → 解除已结算标记,后续再弱化到 0% 时重新结算
            if (next > -100) {
                state.Mods.FailedOrgans.Remove(pOrganId);
                state.Mods.FunctionallyFailedOrgans.Remove(pOrganId);
            }
            if (next >= 30 && cur < 30) {
                string[] traitIds;
                if (StrengthenTrait.TryGetValue(pOrganId, out traitIds) && traitIds != null) {
                    foreach (string traitId in traitIds) TryAddTrait(pActor, traitId);
                }
            }
            RefreshLimbTraits(pActor);
            SyncMuscleTrait(pActor);
            Refresh(pActor);
            BioDialogue.ShowReaction(pActor, pOrganId, "强化器官", 2, BioDialogue.StrengthenReply);
        }

        // 强化×10:+100,一次提升十级
        private static void StrengthenOrganX10(Actor pActor, string pOrganId) {
            ActorWoundState state = HealthSimulator.GetState(pActor.getID());
            int cur = 0;
            state.Mods.HpMods.TryGetValue(pOrganId, out cur);
            int next = cur + 100;
            state.Mods.HpMods[pOrganId] = next;
            // 恢复超过衰竭线(-100) → 解除已结算标记
            if (next > -100) {
                state.Mods.FailedOrgans.Remove(pOrganId);
                state.Mods.FunctionallyFailedOrgans.Remove(pOrganId);
            }
            if (next >= 30 && cur < 30) {
                string[] traitIds;
                if (StrengthenTrait.TryGetValue(pOrganId, out traitIds) && traitIds != null) {
                    foreach (string traitId in traitIds) TryAddTrait(pActor, traitId);
                }
            }
            RefreshLimbTraits(pActor);
            SyncMuscleTrait(pActor);
            Refresh(pActor);
            BioDialogue.ShowReaction(pActor, pOrganId, "强化器官", 5, BioDialogue.StrengthenReply);
        }

        // 腿/脚强化 → 轻盈+敏捷特质联动:双腿或双脚任一强化 ≥3 级就补 轻盈/敏捷,否则剥除
        private static readonly string[] LegFootIds = { "leg", "foot" };
        private static void RefreshLimbTraits(Actor pActor) {
            try {
                ActorWoundState state = HealthSimulator.GetState(pActor.getID());
                if (state == null || state.Mods == null) return;
                bool anyStrongLeg = false;
                foreach (string oid in LegFootIds) {
                    int lvl = 0;
                    state.Mods.HpMods.TryGetValue(oid, out lvl);
                    if (lvl >= 30) { anyStrongLeg = true; break; }
                }
                // 无强化腿脚:剥除 轻盈/敏捷;有:确保存在
                if (anyStrongLeg) {
                    TryAddTrait(pActor, "agile");
                    TryAddTrait(pActor, "weightless");
                } else {
                    RemoveTraitFromActor(pActor, "agile");
                    RemoveTraitFromActor(pActor, "weightless");
                }
            } catch (Exception e) {
                Main.LogError("生物学:腿脚特质联动失败 " + e);
            }
        }

        // 弱化时可能附加的疾病:器官id → 候选疾病id列表
        private static readonly Dictionary<string, string[]> WeakenDiseases = new Dictionary<string, string[]> {
            { "eye_l", new[] { "cataract", "glaucoma" } }, { "eye_r", new[] { "cataract", "glaucoma" } },
            { "lung", new[] { "asthma", "bronchitis" } },
            { "kidney", new[] { "nephritis", "kidney_stone" } },
            { "heart", new[] { "arrhythmia", "angina" } },
            { "brain", new[] { "migraine", "epilepsy" } },
            { "stomach", new[] { "gastritis", "gastric_ulcer" } },
            { "liver", new[] { "hepatitis", "fatty_liver" } },
            { "blood", new[] { "anemia" } },
            { "skin", new[] { "dermatitis", "eczema" } },
            // 关节骨 = 原 骨骼(骨质疏松) + 关节(关节炎/痛风) + 骨髓(骨髓炎)
            { "bone", new[] { "osteoporosis", "arthritis", "gout", "osteomyelitis" } },
            { "muscle", new[] { "muscle_atrophy" } },
            { "intestine", new[] { "enteritis", "parasite" } },
            { "spine", new[] { "disc_herniation" } },
            { "uterus", new[] { "uterine_fibroid" } },
            { "ovary", new[] { "ovarian_cyst" } },
            { "testicle", new[] { "orchitis" } },
            { "prostate", new[] { "prostatitis" } },
            { "penis", new[] { "impotence" } },
            { "chest", new[] { "pleurisy" } },
            { "ear", new[] { "otitis", "tinnitus" } },
            { "nose", new[] { "rhinitis" } },
            { "teeth", new[] { "dental_caries" } },
            { "mouth", new[] { "periodontitis", "mutism" } },
            { "bladder", new[] { "cystitis" } },
            { "anus", new[] { "hemorrhoid" } },
        };

        // 弱化一次:-10,可一直弱化到器官衰竭(≈-1000,Hp归零)
        private static void WeakenOrgan(Actor pActor, string pOrganId) {
            ActorWoundState state = HealthSimulator.GetState(pActor.getID());
            int cur = 0;
            state.Mods.HpMods.TryGetValue(pOrganId, out cur);
            state.Mods.HpMods[pOrganId] = Mathf.Max(cur - 10, -1000);
            if (state.Mods.HpMods[pOrganId] <= -100)
                state.Mods.FunctionallyFailedOrgans.Add(pOrganId);
            // 弱化到 0%(衰竭) → 等同摘除代价(致命器官即死等)
            CheckWeakenedToZero(pActor, pOrganId);
            // 弱化时可能附加一种符合的疾病(约一半概率)
            if (_rng.Next(2) == 0) {
                string[] pool;
                if (WeakenDiseases.TryGetValue(pOrganId, out pool) && pool != null && pool.Length > 0) {
                    string diseaseId = pool[_rng.Next(pool.Length)];
                    if (!state.Mods.ModDiseases.ContainsKey(pOrganId)) {
                        state.Mods.ModDiseases[pOrganId] = diseaseId;
                    }
                }
            }
            RefreshLimbTraits(pActor);
            SyncMuscleTrait(pActor);
            Refresh(pActor);
            BioDialogue.ShowReaction(pActor, pOrganId, "弱化器官", -4, BioDialogue.WeakenReply);
        }

        // 弱化×10:-100,一次弱化十级(可迅速弱到器官衰竭)
        private static void WeakenOrganX10(Actor pActor, string pOrganId) {
            ActorWoundState state = HealthSimulator.GetState(pActor.getID());
            int cur = 0;
            state.Mods.HpMods.TryGetValue(pOrganId, out cur);
            state.Mods.HpMods[pOrganId] = Mathf.Max(cur - 100, -1000);
            if (state.Mods.HpMods[pOrganId] <= -100)
                state.Mods.FunctionallyFailedOrgans.Add(pOrganId);
            // 弱化到 0%(衰竭) → 等同摘除代价(致命器官即死等)
            CheckWeakenedToZero(pActor, pOrganId);
            string[] pool;
            if (WeakenDiseases.TryGetValue(pOrganId, out pool) && pool != null && pool.Length > 0) {
                string diseaseId = pool[_rng.Next(pool.Length)];
                if (!state.Mods.ModDiseases.ContainsKey(pOrganId)) {
                    state.Mods.ModDiseases[pOrganId] = diseaseId;
                }
            }
            RefreshLimbTraits(pActor);
            SyncMuscleTrait(pActor);
            Refresh(pActor);
            BioDialogue.ShowReaction(pActor, pOrganId, "弱化器官", -12, BioDialogue.WeakenReply);
        }

        private static void AddOrgan(Actor pActor, string pOrganId) {
            ActorWoundState state = HealthSimulator.GetState(pActor.getID());
            bool handsBefore = HealthSimulator.HasUsableHandsFast(pActor);
            // 父级恢复整条下游链并清伤；若祖先仍缺失，API 拒绝直接添加下游。
            if (!LimbDependency.AddWithDownstream(state, pOrganId)) return;
            Refresh(pActor, handsBefore);
        }

        // 神之子名字池:神之侵犯致孕时从中随机取名(显示走 bio_name_<i> 键)
        private static readonly string[] DivineChildNames = {
            "耶稣", "洪秀全", "赫拉克勒斯", "后稷", "聂赤赞普", "天赤七王",
            "亚历山大", "奥古斯都", "提比略", "汉谟拉比", "阿育王",
            "雅威·本·雅威", "黑耶稣塔里", "戴维·艾克"
        };

        // 神之子特质/祝福池:随机抽取一批授予(强化、祝福、神性)
        private static readonly string[] DivineChildTraits = {
            "blessed", "sunblessed", "chosen_one", "immortal", "strong",
            "giant", "genius", "wise", "strong_minded", "titan_lungs",
            "battle_reflexes", "immune", "regeneration", "agile", "tough",
            "energized", "super_health", "attractive", "long_liver", "boosted_vitality"
        };

        // 亲密"继续"一步:按器官分派到对应机制(纯逻辑,不弹对话,由对话层调用)
        internal static void ApplyIntimateAct(Actor pActor, string pOrganId) {
            if (pActor == null) return;
            if (pOrganId == "vagina" || pOrganId == "anus") ApplyViolation(pActor, pOrganId);
            else if (pOrganId == "penis") ApplyMasturbate(pActor);
            Refresh(pActor);
        }

        // 口/指爱抚(舔阴蒂/舔尿道/舔肛/手指插入):只按概率引发高潮,累加高潮次数;
        // 不是插入性交,所以不扩张、不挂病、更不会受孕。阴蒂刺激最容易高潮,肛门/尿道次之。
        internal static void ApplyOralOrgasm(Actor pActor, string pAction) {
            if (pActor == null) return;
            // 概率触发,不是必定;舔阴蒂相对最容易,肛门/尿道次之
            int chance;
            switch (pAction) {
                case "clit_lick": chance = 40; break;   // 舔阴蒂:最易高潮
                case "finger_insert": chance = 30; break; // 手指(勾 G 点)
                case "urethra_lick": chance = 20; break;
                case "anus_lick": chance = 15; break;
                default: chance = 25; break;
            }
            if (_rng.Next(100) < chance) {
                try {
                    ActorWoundState state = HealthSimulator.GetState(pActor.getID());
                    if (state != null && state.Mods != null) state.Mods.OrgasmCount++;
                } catch { }
            }
            Refresh(pActor);
        }

        // 亲密机制(阴道/肛门):扩张/受损/疾病/受孕。原"侵犯"逻辑,好感度改由对话层统一加。
        private static void ApplyViolation(Actor pActor, string pOrganId) {
            if (pOrganId != "vagina" && pOrganId != "anus") return;
            ActorWoundState state = HealthSimulator.GetState(pActor.getID());
            int n = 0;
            state.Mods.Violations.TryGetValue(pOrganId, out n);
            state.Mods.Violations[pOrganId] = n + 1;
            int newCount = n + 1;
            // 器官受损:降低该器官百分比,并挂上对应疾病(失禁/激素失衡)
            int cur = 0;
            state.Mods.HpMods.TryGetValue(pOrganId, out cur);
            // 肛门:概率性扩张(首次20%,第二次10%,第三次6.67%...),每5次保底一次
            // 阴道:每次都扩张
            bool expand = true;
            if (pOrganId == "anus") {
                if (newCount % 5 == 0) {
                    expand = true; // 每5次保底
                } else {
                    float prob = 20f / newCount;
                    expand = _rng.Next(10000) < (int)(prob * 100);
                }
            }
            if (expand) {
                state.Mods.HpMods[pOrganId] = Mathf.Max(cur - 15, -100);
                if (pOrganId == "anus") state.Mods.AnalExpansionCount++;
            }
            state.Mods.ModDiseases[pOrganId] = pOrganId == "anus" ? "incontinence" : "hormone_imbalance";
            // 侵犯到 0%(衰竭) → 等同摘除代价
            CheckWeakenedToZero(pActor, pOrganId);
            // 神之侵犯:约 1/3 概率引发高潮
            if (_rng.Next(3) == 0) {
                state.Mods.OrgasmCount++;
            }
            string log = "生物学:神之侵犯 " + pOrganId + " x" + newCount;
            if (pOrganId == "anus") log += expand ? "(扩张)" : "(未扩张)";
            Main.LogInfo(log);
            // 神之侵犯(阴道):约 40% 概率受孕(平均侵犯 2~3 次怀上)。受孕只是让她进入怀孕状态,
            // 孩子要等孕期走完才落地
            if (pOrganId == "vagina" && Randy.randomChance(0.4f)) {
                ConceiveDivineChild(pActor);
            }
            // 对话与刷新由调用方(ApplyIntimateAct/对话层)统一处理
        }

        // 原版怀孕状态的 id。孕期走完由 StatusLibrary.actionPregnancyFinish 触发
        // BabyMaker.makeBabyFromPregnancy,我们在那儿截住这一胎(见 EnsureDivineBirthPatch)
        private const string PregnantStatus = "pregnant";

        /// <summary>
        /// 神之侵犯致孕:让她怀上,而不是当场把孩子塞出来。
        ///
        /// 走的是原版那套怀孕:加 pregnant 状态(时长取该物种的成熟时间,和原版有性生殖
        /// BehCheckForBabiesFromSexualReproduction 用的是同一个值),孕期条走完原版会调
        /// BabyMaker.makeBabyFromPregnancy,我们在那里把这一胎换成神之子。
        ///
        /// 以前"每 15 天只能生一个"那道闸不需要了 —— 怀着的时候再侵犯本来就不该二次受孕,
        /// 怀孕状态自己就是那道闸,而且玩家能直接从状态条上看到还剩多久。
        /// </summary>
        private static void ConceiveDivineChild(Actor pMother) {
            try {
                if (pMother == null) return;
                if (pMother.hasStatus(PregnantStatus)) {
                    Main.LogInfo("生物学:她已经怀着了,本次侵犯未致孕");
                    try {
                        new WorldLogMessage(WorldLogLibrary.auto_tester,
                            BioText.F("bio_log_gestation", "{0} 已在孕期中,本次侵犯未致孕",
                                pMother.getName())).add();
                    } catch { }
                    return;
                }
                ActorWoundState st = HealthSimulator.GetState(pMother.getID());
                // 卵生/直接产子的物种没有孕期可进(原版按 ReproductiveStrategy 分的就是这三条路),
                // 那就照旧当场生一个,否则这些物种被侵犯永远不会有结果
                if (!UsesPregnancy(pMother)) {
                    st.Mods.DivinePregnancy = false;
                    Main.LogInfo("生物学:该物种不经孕期(卵生/直接产子),神之子当场降生");
                    BirthDivineChild(pMother);
                    return;
                }
                st.Mods.DivinePregnancy = true;
                float term = pMother.getMaturationTimeSeconds();
                BabyHelper.babyMakingStart(pMother);
                // 状态可能被原版拒掉(canAddStatus 里那几道判定)。真被拒了就不能把标记留在那儿等一个
                // 永远不会来的分娩,当场生掉
                if (!pMother.addStatusEffect(PregnantStatus, term, true)) {
                    st.Mods.DivinePregnancy = false;
                    Main.LogInfo("生物学:怀孕状态挂不上,神之子当场降生");
                    BirthDivineChild(pMother);
                    return;
                }
                Main.LogInfo("生物学:神之侵犯致孕!" + pMother.getName()
                    + " 进入怀孕状态,孕期约 " + term.ToString("F0") + " 秒");
                try {
                    new WorldLogMessage(WorldLogLibrary.auto_tester,
                        BioText.F("bio_log_conceive", "神之侵犯致孕!{0} 怀上了神的孩子", pMother.getName())).add();
                } catch { }
            } catch (Exception e) {
                Main.LogError("生物学:神之致孕失败 " + e);
            }
        }

        // 该物种是不是"怀孕生产"型(而非卵生/直接产子)
        private static bool UsesPregnancy(Actor pMother) {
            try {
                return pMother.subspecies != null
                    && pMother.subspecies.getReproductionStrategy() == ReproductiveStrategy.Pregnancy;
            } catch (Exception e) {
                Main.LogInfo("生物学:读取生殖策略失败,按不经孕期处理 " + e.Message);
                return false;
            }
        }

        /// <summary> 分娩时取走"这一胎是神之子"的标记(只结算一次) </summary>
        public static bool ConsumeDivinePregnancy(Actor pMother) {
            try {
                if (pMother == null) return false;
                ActorWoundState st;
                if (!HealthSimulator.TryGetState(pMother.getID(), out st)) return false;
                if (st == null || st.Mods == null || !st.Mods.DivinePregnancy) return false;
                st.Mods.DivinePregnancy = false;
                return true;
            } catch {
                return false;
            }
        }

        // ===== 多胞胎 =====
        //
        // 原版的连生判定(BabyMaker.makeBabyFromPregnancy)是"第一个必生,之后按 birth_rate 再试
        // 几次,首次 50%、每多生一个 ×0.85 递减"。50% 这个数是写死在代码里的,而且递减很快 ——
        // 算下来期望额外胎数只有 0.82 个,而且把 birth_rate 从 5 抬到 8 几乎没有任何区别
        // (第 5 个之后的概率加起来不到 0.01)。
        //
        // 所以"强化子宫 → 多胞胎"不能只靠抬 birth_rate 上限,起始概率也得跟着抬:
        //     起始概率 = 0.5 + 子宫强化等级/100 × 0.4,夹在 0.05~0.95
        // 强化一档(+100)时起始概率 0.9,期望胎数从 1.82 升到 3.47,这才叫多胞胎;此时 birth_rate
        // 那个上限也终于开始起作用了,两个数是配合着用的。弱化方向同一条公式:弱化一档起始概率
        // 只剩 0.1,期望胎数 1.11,基本只会单胎。
        private const float TwinBaseChance = 0.5f;
        private const float TwinDecay = 0.85f;
        private const float TwinBoostPerLevel = 0.4f;
        private const float TwinChanceMin = 0.05f;
        private const float TwinChanceMax = 0.95f;

        /// <summary> 这一胎的连生起始概率。只读已有状态,没被动过的单位一律是原版那 50% </summary>
        private static float TwinChanceOf(Actor pMother) {
            float chance = TwinBaseChance;
            try {
                ActorWoundState st;
                if (HealthSimulator.TryGetState(pMother.getID(), out st)
                    && st != null && st.Mods != null) {
                    int lvl;
                    st.Mods.HpMods.TryGetValue("uterus", out lvl);
                    if (lvl != 0) chance += lvl / 100f * TwinBoostPerLevel;
                }
            } catch { }
            return Mathf.Clamp(chance, TwinChanceMin, TwinChanceMax);
        }

        // 按 birth_rate 上限和递减概率再多生几个,返回额外胎数
        private static int MakeExtraBabies(Actor pMother, Func<Actor> pMake) {
            int extras = 0;
            try {
                int limit = (int)pMother.stats["birth_rate"];
                float chance = TwinChanceOf(pMother);
                for (int i = 0; i < limit; i++) {
                    if (!Randy.randomChance(chance)) break;
                    if (pMake() == null) break;
                    extras++;
                    chance *= TwinDecay;
                }
            } catch (Exception e) {
                Main.LogInfo("生物学:多胞胎判定失败 " + e.Message);
            }
            return extras;
        }

        /// <summary>
        /// 子宫被动过的普通分娩:形状照原版 makeBabyFromPregnancy 抄,只是连生概率按强化/弱化
        /// 等级换过。子宫没被动过的孕妇不会走到这里,原样交回原版处理。
        /// </summary>
        private static void BirthWithUterusMod(Actor pMother) {
            Actor father = null;
            try {
                pMother.hasLover();      // 原版在这儿先问一次,照抄以免漏掉它的副作用
                father = pMother.lover;
            } catch { }
            try { pMother.birthEvent(null, null); }
            catch (Exception e) { Main.LogInfo("生物学:母亲分娩事件失败 " + e.Message); }
            Actor dad = father;
            Func<Actor> make = () => BabyMaker.makeBaby(pMother, dad, ActorSex.None, false, 0, null, true, false);
            if (make() == null) {
                Main.LogError("生物学:分娩失败——makeBaby 返回 null");
                return;
            }
            int extras = MakeExtraBabies(pMother, make);
            Main.LogInfo("生物学:子宫已被改动,本胎共 " + (extras + 1) + " 个(连生起始概率 "
                + TwinChanceOf(pMother).ToString("P0") + ")");
        }

        /// <summary>
        /// 神之侵犯致孕:分娩时诞下神之子(自动加入收藏、赐予特质与祝福、取神名)。
        /// 胎数和普通分娩同一套算法,所以强化子宫在神之子身上一样能生出多胞胎。
        /// </summary>
        public static void BirthDivineChild(Actor pMother) {
            try {
                if (pMother == null || World.world == null) return;
                Actor first = MakeDivineChild(pMother);
                if (first == null) {
                    Main.LogError("生物学:神之子降生失败——makeBaby 返回 null(该生物类型无法繁衍?)");
                    return;
                }
                // 母亲照原版分娩走一遍:掉饱食度、短暂僵直、心情加成
                try { pMother.birthEvent(null, null); }
                catch (Exception e) { Main.LogInfo("生物学:母亲分娩事件失败 " + e.Message); }

                int extras = MakeExtraBabies(pMother, () => MakeDivineChild(pMother));
                if (extras > 0) {
                    Main.LogInfo("生物学:神之子多胞胎,本胎共 " + (extras + 1) + " 个");
                }
                // 玩家可见通知:镜头跟随头一个新生儿(每个孩子自己会写一条世界日志)
                try {
                    World.world.locateAndFollow(first, null, null);
                } catch { }
            } catch (Exception e) {
                Main.LogError("生物学:神之子降生失败 " + e);
            }
        }

        // 生一个神之子:取神名、抽特质、加入收藏,并写一条世界日志
        private static Actor MakeDivineChild(Actor pMother) {
            Actor baby = BabyMaker.makeBaby(pMother, null, ActorSex.None, false, 0, null, false, false);
            if (baby == null) return null;
            // 自动加入玩家收藏
            baby.data.favorite = true;
            // 随机抽取 3~6 个特质/祝福授予
            string[] pool = DivineChildTraits;
            int count = 3 + _rng.Next(4); // 3..6
            List<string> picked = new List<string>(pool);
            for (int i = 0; i < count && picked.Count > 0; i++) {
                int idx = _rng.Next(picked.Count);
                string tid = picked[idx];
                picked.RemoveAt(idx);
                try { baby.addTrait(tid, false); } catch { }
            }
            // 神之子名字:从名册随机取一个;标记为自定义名,防止被中文名模组覆盖
            int nameIdx = _rng.Next(DivineChildNames.Length);
            string name = BioText.T("bio_name_" + nameIdx, DivineChildNames[nameIdx]);
            try {
                baby.data.custom_name = true;
                baby.setName(name, false);
            } catch { }
            Main.LogInfo("生物学:神之子降生 <" + name + ">,特质x" + count + ",已加入收藏");
            try {
                new WorldLogMessage(WorldLogLibrary.auto_tester,
                    BioText.F("bio_log_birth", "神之子降生!{0}(特质x{1}),已加入收藏",
                        name, count)).add();
            } catch { }
            return baby;
        }


        /// <summary>
        /// 截住分娩。
        ///
        /// 原版孕期条走完 → StatusLibrary.actionPregnancyFinish → BabyMaker.makeBabyFromPregnancy。
        /// 两种情况要接手:
        ///   神之子那一胎  —— 原版会拿 actor.lover 当爹、按 birth_rate 连生;神之子只该有一个
        ///                    凡人母亲、没有凡人父亲,所以整段换成 BirthDivineChild
        ///   子宫被强化/弱化过 —— 原版那个连生起始概率 50% 是写死的,想让强化子宫真的生多胞胎
        ///                    只能自己重走一遍(见 BirthWithUterusMod)
        /// 其余的普通怀孕原样放过,不碰原版行为。
        /// </summary>
        public static void EnsureDivineBirthPatch() {
            if (_divineBirthPatched) return;
            _divineBirthPatched = true;
            try {
                Harmony harmony = new Harmony("rimworld_health_divine_birth");
                harmony.Patch(
                    AccessTools.Method(typeof(BabyMaker), "makeBabyFromPregnancy"),
                    prefix: new HarmonyMethod(AccessTools.Method(typeof(OrganEditorUI), nameof(OnPregnancyFinish)))
                );
                Main.LogInfo("生物学:神之子分娩接管已启用");
            } catch (Exception e) {
                Main.LogError("生物学:神之子分娩接管启用失败 " + e);
            }
        }

        private static bool _divineBirthPatched;

        // 返回 false = 跳过原版分娩,由我们自己生
        public static bool OnPregnancyFinish(Actor pActor) {
            try {
                if (pActor == null) return true;
                if (ConsumeDivinePregnancy(pActor)) {
                    BirthDivineChild(pActor);
                    return false;
                }
                // 子宫没被动过的孕妇一律交回原版,连生概率一点不动
                if (Mathf.Abs(TwinChanceOf(pActor) - TwinBaseChance) > 0.001f) {
                    BirthWithUterusMod(pActor);
                    return false;
                }
                return true;
            } catch (Exception e) {
                Main.LogError("生物学:接管分娩失败,交回原版 " + e);
                return true;
            }
        }

        public static int GetViolationCount(Actor pActor, string pOrganId) {
            if (pActor == null) return 0;
            try {
                ActorWoundState state = HealthSimulator.GetState(pActor.getID());
                int n = 0;
                return state.Mods.Violations.TryGetValue(pOrganId, out n) ? n : 0;
            } catch {
                return 0;
            }
        }

        // 亲密机制(阴茎):次数+1,射精有概率(早泄疾病提升概率)。好感度由对话层统一加。
        private static void ApplyMasturbate(Actor pActor) {
            if (pActor == null) return;
            ActorWoundState state = HealthSimulator.GetState(pActor.getID());
            state.Mods.MasturbationCount++;
            // 基础 40% 射精概率;早泄疾病 → 提高到 70%
            int chance = HasPremature(pActor) ? 70 : 40;
            bool ejaculated = _rng.Next(100) < chance;
            if (ejaculated) {
                state.Mods.EjaculationCount++;
                Main.LogInfo("生物学:亲密(阴茎) x" + state.Mods.MasturbationCount + " → 射精,累计 " + state.Mods.EjaculationCount + " 次");
            } else {
                Main.LogInfo("生物学:亲密(阴茎) x" + state.Mods.MasturbationCount + " → 未射精");
            }
            // 对话与刷新由调用方统一处理
        }

        // 是否患有早泄(存在于器官伤口中的 premature 疾病)
        private static bool HasPremature(Actor pActor) {
            if (pActor == null) return false;
            try {
                ActorWoundState state = HealthSimulator.GetState(pActor.getID());
                foreach (OrganWound w in state.Wounds.Values) {
                    if (w != null && w.Disease != null && w.Disease.Id == "premature") return true;
                }
            } catch { }
            return false;
        }

        // 射精次数(累计,含撸管射精与生育)
        public static int GetEjaculationCount(Actor pActor) {
            if (pActor == null) return 0;
            try {
                return HealthSimulator.GetState(pActor.getID()).Mods.EjaculationCount;
            } catch {
                return 0;
            }
        }

        // 撸管次数
        public static int GetMasturbationCount(Actor pActor) {
            if (pActor == null) return 0;
            try {
                return HealthSimulator.GetState(pActor.getID()).Mods.MasturbationCount;
            } catch {
                return 0;
            }
        }

        internal static void Refresh(Actor pActor, bool? pHandsBefore = null) {
            try {
                UnitHealthTab.RefreshAfterEdit();
                if (pHandsBefore.HasValue
                    && pHandsBefore.Value != HealthSimulator.HasUsableHandsFast(pActor)) {
                    HandUseGuard.SyncActor(pActor);
                }
            } catch (Exception e) {
                Main.LogError("生物学:编辑后刷新失败 " + e);
            }
        }

        public static void CloseMenu() {
            // 若处于布局编辑模式,先保存再销毁
            try {
                LayoutEditor.OnMenuClose();
            } catch (Exception e) {
                Main.LogError("生物学:关闭菜单保存布局失败 " + e);
            }
            if (_menu != null) {
                UnityEngine.Object.Destroy(_menu);
                _menu = null;
            }
            if (_blocker != null) {
                UnityEngine.Object.Destroy(_blocker);
                _blocker = null;
            }
            // 兜底:按名字清理画布上可能残留的菜单/遮挡
            try {
                if (_menuCanvas != null) {
                    Transform menuT = _menuCanvas.transform.Find("OrganEditMenu");
                    if (menuT != null) UnityEngine.Object.Destroy(menuT.gameObject);
                    Transform blockT = _menuCanvas.transform.Find("MenuBlocker");
                    if (blockT != null) UnityEngine.Object.Destroy(blockT.gameObject);
                }
            } catch (Exception e) {
                Main.LogError("生物学:清理菜单残留失败 " + e);
            }
        }

        private static RectTransform CreateMenu(RectTransform pAnchor, string pTitle, float pWidth = 300f, Vector2 pClickPos = default(Vector2)) {
            try {
            Canvas c = pAnchor != null ? pAnchor.GetComponentInParent<Canvas>() : null;
            if (c == null && CanvasMain.instance != null) c = CanvasMain.instance.canvas_windows;

            // 模态遮挡
            if (c != null) {
                GameObject blocker = new GameObject("MenuBlocker", typeof(RectTransform), typeof(Image));
                blocker.transform.SetParent(c.transform, false);
                RectTransform brt = blocker.GetComponent<RectTransform>();
                brt.anchorMin = Vector2.zero;
                brt.anchorMax = Vector2.one;
                brt.offsetMin = Vector2.zero;
                brt.offsetMax = Vector2.zero;
                Image bimg = blocker.GetComponent<Image>();
                bimg.color = new Color(0f, 0f, 0f, 0.001f);
                bimg.raycastTarget = true;
                blocker.AddComponent<MenuBlocker>();
                _blocker = blocker;
            }

            GameObject go = new GameObject("OrganEditMenu", typeof(RectTransform), typeof(Image),
                typeof(VerticalLayoutGroup), typeof(ContentSizeFitter));
            go.transform.SetParent(c != null ? c.transform : null, false);
            // 立刻登记菜单对象,避免后续任何异常导致窗口无法关闭
            _menu = go;
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.pivot = new Vector2(0.5f, 1f);
            rt.sizeDelta = new Vector2(S(pWidth), 0);
            Image img = go.GetComponent<Image>();
            Sprite windowSpr = SpriteTextureLoader.getSprite("ui/special/windowInnerSliced");
            if (windowSpr != null) {
                img.sprite = windowSpr;
                img.type = Image.Type.Sliced;
            }
            // 保留贴图原色(浅色窗口),不染色
            img.color = Color.white;
            img.raycastTarget = false;
            VerticalLayoutGroup vlg = go.GetComponent<VerticalLayoutGroup>();
            vlg.padding = new RectOffset(Mathf.RoundToInt(S(10f)), Mathf.RoundToInt(S(10f)),
                Mathf.RoundToInt(S(10f)), Mathf.RoundToInt(S(10f)));
            vlg.spacing = 0f;
            vlg.childControlWidth = true;
            vlg.childForceExpandWidth = true;
            // 控制子元素高度=各自偏好高度(网格按真实行数计算),避免长列表时底部按钮错位重叠
            vlg.childControlHeight = true;
            vlg.childForceExpandHeight = false;
            vlg.childAlignment = TextAnchor.UpperLeft;
            ContentSizeFitter fitter = go.GetComponent<ContentSizeFitter>();
            fitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            // 标题行(标题 + 右上角红叉)
            GameObject titleRow = new GameObject("TitleRow", typeof(RectTransform), typeof(HorizontalLayoutGroup));
            titleRow.transform.SetParent(rt, false);
            RectTransform trt = titleRow.GetComponent<RectTransform>();
            trt.sizeDelta = new Vector2(0, Mathf.Max(S(24), 20f));
            LayoutElement titleRowLe = titleRow.AddComponent<LayoutElement>();
            titleRowLe.preferredHeight = Mathf.Max(S(24), 20f);
            titleRowLe.minHeight = Mathf.Max(S(24), 20f);
            HorizontalLayoutGroup hlg = titleRow.GetComponent<HorizontalLayoutGroup>();
            hlg.childControlWidth = true;
            hlg.childForceExpandWidth = true;
            hlg.childControlHeight = true;
            hlg.childForceExpandHeight = false;
            hlg.spacing = S(4f);
            hlg.padding = new RectOffset(Mathf.RoundToInt(S(2f)), Mathf.RoundToInt(S(2f)), 0, 0);

            GameObject titleText = new GameObject("Title", typeof(RectTransform));
            titleText.transform.SetParent(titleRow.transform, false);
            LayoutElement tle = titleText.AddComponent<LayoutElement>();
            tle.minWidth = S(20f);
            tle.preferredWidth = S(20f);
            tle.flexibleWidth = 1f;
            Text tt = titleText.AddComponent<Text>();
            tt.font = LocalizedTextManager.current_font;
            tt.fontSize = F(13);
            tt.color = Color.white;
            tt.alignment = TextAnchor.MiddleCenter;
            tt.raycastTarget = true;
            tt.text = pTitle;

            // 右上角红叉关闭按钮:直接钉在窗口右上角,不受布局组影响;使用原版关闭按钮贴图
            GameObject closeBtn = new GameObject("CloseX", typeof(RectTransform), typeof(Image), typeof(Button));
            closeBtn.transform.SetParent(rt, false);
            RectTransform crt = closeBtn.GetComponent<RectTransform>();
            crt.anchorMin = new Vector2(1f, 1f);
            crt.anchorMax = new Vector2(1f, 1f);
            crt.pivot = new Vector2(1f, 1f);
            crt.anchoredPosition = new Vector2(S(-3f), S(-3f));
            crt.sizeDelta = new Vector2(S(28f), S(28f));
            LayoutElement cle = closeBtn.AddComponent<LayoutElement>();
            cle.ignoreLayout = true;
            Image cimg = closeBtn.GetComponent<Image>();
            cimg.sprite = SpriteTextureLoader.getSprite("ui/icons/iconClose");
            if (cimg.sprite != null) cimg.preserveAspect = true;
            cimg.color = Color.white;
            cimg.raycastTarget = true;

            Button cbtn = closeBtn.GetComponent<Button>();
            cbtn.targetGraphic = cimg;
            cbtn.transition = Selectable.Transition.None;
            cbtn.onClick.AddListener(() => CloseMenu());

            _menuCanvas = c;
            // 定位:优先在鼠标点击处弹出(屏幕坐标转世界坐标),再右下移一点避免遮住点击位置;
            // 仅在缺少有效点击位置时退回锚点(黑框)位置
            bool positioned = false;
            if (pClickPos != default(Vector2)) {
                RectTransform canvasRt = c != null ? c.transform as RectTransform : null;
                if (canvasRt != null) {
                    Vector3 world;
                    if (RectTransformUtility.ScreenPointToWorldPointInRectangle(canvasRt, pClickPos, c != null ? c.worldCamera : null, out world)) {
                        rt.position = world + new Vector3(0f, -12f, 0f);
                        positioned = true;
                    }
                }
            }
            if (!positioned && pAnchor != null) {
                rt.position = pAnchor.position + new Vector3(0f, 12f, 0f);
            }
            return rt;
            } catch (Exception e) {
                Main.LogError("生物学:创建菜单失败 " + e);
                CloseMenu();
                return null;
            }
        }

        private static void FinalizeMenu(RectTransform pMenu) {
            try {
                LayoutRebuilder.ForceRebuildLayoutImmediate(pMenu);
                // 第二次重建:网格内容高度生效后再排一次,避免底部按钮与网格重叠
                LayoutRebuilder.ForceRebuildLayoutImmediate(pMenu);
                // 手动计算内容总高度并套用,确保多行网格等所有内容都被窗口包住
                float contentH = ComputeContentHeight(pMenu);
                if (contentH > 20f && Mathf.Abs(contentH - pMenu.rect.height) > 1f) {
                    pMenu.sizeDelta = new Vector2(pMenu.sizeDelta.x, contentH);
                    LayoutRebuilder.ForceRebuildLayoutImmediate(pMenu);
                }
                ClampMenuToScreen(pMenu, _menuCanvas);
            } catch (Exception e) {
                Main.LogError("生物学:菜单布局/夹取失败 " + e);
            }
        }

        // 计算垂直布局全部子元素的实际总高度(忽略 ignoreLayout 的关闭按钮)
        private static float ComputeContentHeight(RectTransform pMenu) {
            VerticalLayoutGroup vlg = pMenu.GetComponent<VerticalLayoutGroup>();
            if (vlg == null) return pMenu.rect.height;
            float h = vlg.padding.top + vlg.padding.bottom;
            int count = 0;
            for (int i = 0; i < pMenu.childCount; i++) {
                RectTransform child = pMenu.GetChild(i) as RectTransform;
                if (child == null) continue;
                LayoutElement le = child.GetComponent<LayoutElement>();
                if (le != null && le.ignoreLayout) continue;
                h += child.rect.height;
                if (count > 0) h += vlg.spacing;
                count++;
            }
            return h;
        }

        private static void ClampMenuToScreen(RectTransform pMenu, Canvas pCanvas) {
            if (pMenu == null) return;
            RectTransform canvasRt = pCanvas != null ? pCanvas.transform as RectTransform : null;
            if (canvasRt == null) return;
            Vector2 size = pMenu.rect.size;
            Vector3 pos = pMenu.position;
            Vector3 center = canvasRt.position;
            Vector2 canvasSize = canvasRt.rect.size;
            float halfW = canvasSize.x * 0.5f;
            float halfH = canvasSize.y * 0.5f;
            pos.x = Mathf.Clamp(pos.x, center.x - halfW + size.x * 0.5f, center.x + halfW - size.x * 0.5f);
            float top = center.y + halfH;
            float bottom = center.y - halfH;
            pos.y = Mathf.Clamp(pos.y, bottom + size.y, top);
            pMenu.position = pos;
        }

        // 网格按钮:由 GridLayoutGroup 控制大小;pFontSize 默认 12
        private static void AddGridButton(Transform pParent, string pText, Action pAction, int pFontSize = 12) {
            GameObject go = new GameObject("GridBtn", typeof(RectTransform), typeof(Image), typeof(Button));
            go.transform.SetParent(pParent, false);
            Image img = go.GetComponent<Image>();
            Sprite spr = SpriteTextureLoader.getSprite("ui/special/button");
            if (spr != null) {
                img.sprite = spr;
                img.type = Image.Type.Sliced;
            }
            img.color = new Color(0.25f, 0.30f, 0.40f, 0.98f);
            img.raycastTarget = true;
            Text txt = AttachText(go.transform, pText, pFontSize, Color.white);
            Button btn = go.GetComponent<Button>();
            btn.targetGraphic = img;
            btn.transition = Selectable.Transition.None;
            if (pAction != null) {
                btn.onClick.AddListener(() => pAction());
            } else {
                btn.interactable = false;
                txt.color = Color.gray;
            }
        }

        // 在按钮内创建铺满全按钮的文字子物体,避免文字与背景同层导致不可见
        private static Text AttachText(Transform pParent, string pText, int pFontSize, Color pColor) {
            GameObject label = new GameObject("Label", typeof(RectTransform));
            label.transform.SetParent(pParent, false);
            RectTransform lrt = label.GetComponent<RectTransform>();
            lrt.anchorMin = Vector2.zero;
            lrt.anchorMax = Vector2.one;
            lrt.offsetMin = Vector2.zero;
            lrt.offsetMax = Vector2.zero;
            Text txt = label.AddComponent<Text>();
            txt.font = LocalizedTextManager.current_font;
            txt.fontSize = F(pFontSize);
            txt.color = pColor;
            txt.alignment = TextAnchor.MiddleCenter;
            txt.horizontalOverflow = HorizontalWrapMode.Overflow;
            txt.verticalOverflow = VerticalWrapMode.Overflow;
            txt.raycastTarget = false;
            txt.text = pText;
            return txt;
        }
    }
}
