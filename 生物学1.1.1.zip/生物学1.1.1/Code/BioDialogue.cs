using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace RimWorldMod {
    /// <summary>
    /// 攻略/亲密/器官反馈的对话系统。所有台词文本、分支流程、窗口渲染都集中在这里,
    /// 方便单独编辑。机制部分(扩张/受孕/强化数值等)仍在 OrganEditor.cs,本类只在
    /// 玩家点「继续」时回调 OrganEditorUI.ApplyIntimateAct 触发。
    ///
    /// ┌─ 想改台词 → 直接改下面「对话文本池」区域的字符串数组
    /// ├─ 想改好感度门槛/增减值 → 改「可调参数」区域
    /// └─ 想加/改分支 → 改「对话流程」区域的 Build* 方法
    /// </summary>
    public static class BioDialogue {

        // ============================================================
        //  可调参数
        // ============================================================
        // 亲密互动的好感度门槛:低于此值只能交谈培养,达到后才解锁亲密选项
        public const int IntimacyThreshold = 50;
        // 各类交谈的好感度增加值
        public const int GainGreet = 1;   // 寒暄
        public const int GainPraise = 1;  // 赞美
        public const int GainComfort = 2; // 安抚
        public const int GainGift = 5;    // 送礼物
        public const int GainListen = 1;  // 倾听心事
        public const int GainBless = 6;   // 赐予祝福
        public const int GainIntimateContinue = 2; // 亲密-继续
        public const int GainIntimateTender = 1;    // 亲密-温柔/亲吻
        public const int GainIntimateChat = 1;      // 亲密-聊天
        public const int GainCaress = 1;            // 抚摸体表部位(始终受欢迎)
        public const int GainKiss = 2;              // 亲吻(受欢迎时)
        public const int GainLick = 3;              // 舔舐(受欢迎时)
        // 好感未达门槛时,越界举动会掉好感;强迫掉得更多(负值)
        public const int LossKiss = -10;             // 未达门槛硬亲
        public const int LossKissForce = -10;        // 未达门槛强吻
        public const int LossLick = -5;             // 未达门槛硬舔
        public const int LossLickForce = -10;       // 未达门槛强迫舔
        public const int LossIntimate = -8;         // 未达门槛硬来(性交)
        public const int LossIntimateForce = -15;   // 未达门槛强迫(性交)

        // ============================================================
        //  颜色 & 缩放
        // ============================================================
        // 选项配色:继续/亲密=暖粉、交谈=淡蓝、停止/离开=灰
        private static readonly Color ChoiceContinue = new Color(1f, 0.62f, 0.72f);
        private static readonly Color ChoiceChat = new Color(0.62f, 0.82f, 1f);
        private static readonly Color ChoiceStop = new Color(0.75f, 0.75f, 0.8f);
        private static readonly Color TitlePink = new Color(1f, 0.75f, 0.8f);

        // 对话窗专用缩放:基准 0.9,乘模组设置"对话框大小"(0.6~2.0)
        private static float DlgScale { get { return 0.9f * Mathf.Clamp(Main.DialogScale, 0.6f, 2f); } }
        private static float DS(float v) { return v * DlgScale; }
        private static int DF(int v) { return Mathf.Max(12, Mathf.RoundToInt(v * DlgScale)); }

        private static readonly System.Random _rng = new System.Random();
        private static string Pick(string[] pPool) {
            if (pPool == null || pPool.Length == 0) return "";
            return pPool[_rng.Next(pPool.Length)];
        }
        // 从数组按索引安全取(用于分层文本,索引夹在范围内)
        private static string PickTier(string[][] pTiers, int pTier) {
            if (pTiers == null || pTiers.Length == 0) return "";
            int t = Mathf.Clamp(pTier, 0, pTiers.Length - 1);
            return Pick(pTiers[t]);
        }

        // ============================================================
        //  器官分类:哪些能互动
        // ============================================================
        // 内脏/不可触碰部位:不显示互动按钮(点了也没意义)
        private static readonly HashSet<string> InternalOrgans = new HashSet<string> {
            "brain", "heart", "lung", "kidney", "liver", "intestine", "stomach",
            "spine", "bone", "muscle", "blood", "bladder",
            "uterus", "ovary", "testicle", "prostate", "gills", "teeth", "fang",
        };
        // 亲密器官:互动走"更进一步"流程,需好感达标
        private static readonly HashSet<string> IntimateOrgans = new HashSet<string> {
            "vagina", "anus", "penis", "cloaca", "chest",
        };

        /// <summary>该器官是否可互动(体表能摸到的都行,内脏不行)。供菜单决定是否显示互动按钮。</summary>
        public static bool IsTouchable(string pOrganId) {
            if (string.IsNullOrEmpty(pOrganId)) return false;
            return !InternalOrgans.Contains(pOrganId);
        }

        private static bool IsIntimateOrgan(string pOrganId) {
            return IntimateOrgans.Contains(pOrganId);
        }

        // 性别分类:0=男性 1=女性 2=扶他(双性人)
        private enum SexKind { Male, Female, Intersex }
        private static SexKind GetSexKind(Actor pActor) {
            try {
                if (HealthSimulator.IsIntersex(pActor)) return SexKind.Intersex;
                if (pActor.isSexMale()) return SexKind.Male;
            } catch { }
            return SexKind.Female;
        }

        // 部位的口语名(用于"抚摸他的XX"),缺失回退到器官本地化名
        private static string PartName(string pOrganId) {
            string n;
            if (PartNames.TryGetValue(pOrganId, out n)) return n;
            try {
                Organ o;
                if (OrganData.OrganName.TryGetValue(pOrganId, out o)) return o.LocalizedName;
            } catch { }
            return BioText.T("bio_dial_part_body", "身体");
        }

        // 抚摸的动作描写(按器官),缺失用通用句
        private static string CaressAction(string pOrganId) {
            string[] pool;
            if (CaressActions.TryGetValue(pOrganId, out pool) && pool.Length > 0) return Pick(pool);
            return BioText.F("bio_dial_caress_fallback", "你轻轻抚摸着他的{0}。", PartName(pOrganId));
        }

        // ============================================================
        //  好感度
        // ============================================================
        // 关系称谓(与 BioBodyDoll.RelationNames 对齐,10 档)
        public static string[] RelationNames => BioDialogueLocalizer.Pool("bio_dial_rel", _relFB);
        private static readonly string[] _relFB = { "憎恨", "不满", "警惕", "无感", "友善", "亲近", "心动", "爱慕", "挚爱", "痴迷"};
        public static string RelationName(int pAffection) {return RelationNames[Mathf.Clamp(pAffection / 10, 0, 9)];}

        // 统一改好感度:夹在 0~100,并立即刷新头像旁的爱心 UI。返回夹取后的新值。
        public static int AddAffection(Actor pActor, int pDelta) {
            try {
                ActorWoundState state = HealthSimulator.GetState(pActor.getID());
                int next = Mathf.Clamp(state.Mods.Affection + pDelta, 0, 100);
                state.Mods.Affection = next;
                try { BioBodyDoll.UpdateAffection(pActor); } catch { }
                return next;
            } catch (Exception e) {
                Main.LogError("生物学:调整好感度失败 " + e);
                return 0;
            }
        }

        public static int GetAffection(Actor pActor) {
            try { return HealthSimulator.GetState(pActor.getID()).Mods.Affection; }
            catch { return 0; }
        }

        // ============================================================
        //  赐予祝福 / 送礼物 的真实机制
        // ============================================================
        // 祝福特质池:全是原版正面特质,(名称, id)。赐福时随机挑一个身上还没有的授予。
        // 这些 id 已核对存在于当前版本 ActorTraitLibrary,addTrait 会连带移除对立负面特质。
        private static readonly string[][] BlessTraits = {
            new[] { "迅捷",   "fast" },
            new[] { "强壮",   "strong" },
            new[] { "强健",   "tough" },
            new[] { "再生",   "regeneration" },
            new[] { "幸运",   "lucky" },
            new[] { "免疫",   "immune" },
            new[] { "敏捷",   "agile" },
            new[] { "意志坚定", "strong_minded" },
            new[] { "多产",   "fertile" },
            new[] { "防火",   "fire_proof" },
            new[] { "抗冻",   "freeze_proof" },
            new[] { "受祝福者", "blessed" },
            new[] { "神眷",   "sunblessed" },
        };

        // 赐福:随机授予一个身上没有的正面特质。全有了就升华为不朽(immortal)。
        // 返回追加到旁白末尾的结果文字(金色高亮),死亡单位不处理。
        private static string GrantBlessing(Actor pActor) {
            try {
                if (pActor == null || !pActor.isAlive()) return null;
                List<string[]> pool = new List<string[]>();
                foreach (string[] t in BlessTraits) {
                    if (!ActorHasTrait(pActor, t[1])) pool.Add(t);
                }
                string name, id;
                if (pool.Count == 0) {
                    // 常规祝福特质已集齐:赐予终极祝福「不朽」
                    if (ActorHasTrait(pActor, "immortal"))
                        return "\n<color=#ffd966>✦ " + BioText.T("bio_dial_bless_all", "他已承受了你全部的祝福，无需再多。") + "</color>";
                    name = "不朽"; id = "immortal";
                } else {
                    string[] pick = pool[_rng.Next(pool.Count)];
                    name = pick[0]; id = pick[1];
                }
                pActor.addTrait(id, true);   // true = 同时移除对立的负面特质
                try { pActor.setStatsDirty(); } catch { }
                if (!ActorHasTrait(pActor, id))
                    return null; // 被原版规则拒掉(极少见),不谎报
                return "\n<color=#ffd966>✦ " + BioText.T("bio_dial_bless_gain", "获得祝福特质：") + name + "</color>";
            } catch (Exception e) {
                Main.LogError("生物学:赐福失败 " + e);
                return null;
            }
        }

        private static bool ActorHasTrait(Actor pActor, string pTraitId) {
            try {
                if (pActor == null || pActor.traits == null || string.IsNullOrEmpty(pTraitId)) return false;
                foreach (ActorTrait t in pActor.traits) {
                    if (t != null && t.id == pTraitId) return true;
                }
            } catch { }
            return false;
        }

        // 礼物装备池:(名称, 物品资源id, 装备槽)。送礼时随机挑一件生成并装备。
        // id 已核对存在于当前版本 ItemLibrary。优先塞进空着的槽位,没有空槽再替换。
        private static readonly string[][] GiftItems = {
            new[] { "钢剑",     "sword_steel",   "weapon" },
            new[] { "秘银剑",   "sword_mythril", "weapon" },
            new[] { "钢斧",     "axe_steel",     "weapon" },
            new[] { "钢锤",     "hammer_steel",  "weapon" },
            new[] { "钢头盔",   "helmet_steel",  "helmet" },
            new[] { "秘银头盔", "helmet_mythril","helmet" },
            new[] { "钢甲",     "armor_steel",   "armor" },
            new[] { "秘银甲",   "armor_mythril", "armor" },
            new[] { "钢靴",     "boots_steel",   "boots" },
            new[] { "钢戒指",   "ring_steel",    "ring" },
            new[] { "秘银戒指", "ring_mythril",  "ring" },
            new[] { "钢护符",   "amulet_steel",  "amulet" },
            new[] { "秘银护符", "amulet_mythril","amulet" },
        };

        // 送礼:随机生成一件装备并真正穿到单位身上。返回追加到旁白末尾的结果文字。
        private static string GiveGift(Actor pActor) {
            try {
                if (pActor == null || !pActor.isAlive() || pActor.equipment == null) return null;
                // 优先送空槽位的装备,避免顶掉单位原有的好装备;没有空槽再随机替换
                List<string[]> empty = new List<string[]>();
                foreach (string[] g in GiftItems) {
                    if (SlotIsEmpty(pActor, g[2])) empty.Add(g);
                }
                List<string[]> pool = empty.Count > 0 ? empty : new List<string[]>(GiftItems);
                string[] pick = pool[_rng.Next(pool.Count)];
                if (EquipItem(pActor, pick[1], pick[2]))
                    return "\n<color=#ffd966>✦ " + BioText.T("bio_dial_gift_gain", "获得装备：") + pick[0] + "</color>";
                return null;
            } catch (Exception e) {
                Main.LogError("生物学:送礼失败 " + e);
                return null;
            }
        }

        private static ActorEquipmentSlot GetSlot(Actor pActor, string pSlot) {
            ActorEquipment eq = pActor.equipment;
            switch (pSlot) {
                case "weapon": return eq.weapon;
                case "helmet": return eq.helmet;
                case "armor":  return eq.armor;
                case "boots":  return eq.boots;
                case "ring":   return eq.ring;
                case "amulet": return eq.amulet;
            }
            return null;
        }

        private static bool SlotIsEmpty(Actor pActor, string pSlot) {
            try {
                ActorEquipmentSlot slot = GetSlot(pActor, pSlot);
                return slot != null && slot.isEmpty();
            } catch { return false; }
        }

        // 生成物品并装备到对应槽位;成功穿上返回 true。
        private static bool EquipItem(Actor pActor, string pItemId, string pSlot) {
            try {
                ActorEquipmentSlot slot = GetSlot(pActor, pSlot);
                if (slot == null) return false;
                EquipmentAsset asset = AssetManager.items.get(pItemId);
                if (asset == null) return false;
                Item item = World.world.items.generateItem(asset, null, null, 1, pActor, 10);
                if (item == null) return false;
                slot.setItem(item, pActor);
                try { pActor.setStatsDirty(); } catch { }
                // 回读确认真的穿上了(如无手单位的武器会被原版/本模组拒掉)
                return !slot.isEmpty();
            } catch (Exception e) {
                Main.LogError("生物学:装备礼物失败 " + pItemId + " " + e);
                return false;
            }
        }

        // 关系抬头:每段对话标题都带上当前关系与好感度,像 galgame 的角色状态条
        private static string RelationHeader(Actor pActor) {
            int aff = GetAffection(pActor);
            return BioText.T("bio_dial_rel_header", "关系:") + RelationName(aff) + " " + aff + "%";
        }

        // 好感度变动的着色文字(正绿负红),拼在正文末尾
        private static string AffLine(int pDelta, int pNow) {
            string sign = pDelta >= 0 ? "+" : "";
            string col = pDelta >= 0 ? "#8fd86f" : "#e06666";
            return "\n\n<color=" + col + ">" + BioText.T("bio_dial_aff_label", "好感度 ") + sign + pDelta + " → " + pNow + "%</color>";
        }

        // 好感度档位:0=陌生以下 1=熟悉 2=心动及以上(用于分层台词)
        private static int Tier(Actor pActor) {
            int aff = GetAffection(pActor);
            if (aff >= IntimacyThreshold) return 2;
            if (aff >= 30) return 1;
            return 0;
        }

        // 好感是否已够亲密:达到门槛后,亲吻/舔舐/性交才是"你情我愿"的,会加好感;
        // 低于门槛时这些举动不受欢迎,会掉好感,强迫掉得更多。
        private static bool Welcome(Actor pActor) {
            return GetAffection(pActor) >= IntimacyThreshold;
        }

        // ============================================================
        //  公开入口(供 OrganEditor 调用)
        // ============================================================
        /// <summary>点亲密器官的「互动」:打开攻略主界面。</summary>
        public static void OpenRelation(Actor pActor, string pOrganId) {
            ShowDialog(BuildRelationDialog(pActor, pOrganId), () => OrganEditorUI.Refresh(pActor));
        }

        /// <summary>强化/弱化/删除后的反应弹窗(带好感度变动)。单位已死则只改数值不弹窗。
        /// 开了 AI 就让角色以第一人称吐槽(疼/虚弱/感激等),否则用固定台词。</summary>
        public static void ShowReaction(Actor pActor, string pOrganId, string pTitle, int pDelta, string[] pReplyPool) {
            bool alive = true;
            try { alive = pActor.isAlive(); } catch { }
            if (!alive) { AddAffection(pActor, pDelta); return; }
            Color col = pDelta >= 0 ? new Color(0.56f, 0.85f, 0.44f) : new Color(0.9f, 0.45f, 0.45f);
            int now = AddAffection(pActor, pDelta);

            if (BioAIChat.Available) {
                ShowDialog(ReactionResult(pActor, pTitle, col, BioText.T("bio_dial_loading", "……（对方正在回应）"), 0, now, false),
                    () => OrganEditorUI.Refresh(pActor));
                int req = ++_aiReq;
                BioAIChat.SendAction(pActor, ReactionAiText(pTitle, pOrganId),
                    reply => { if (req == _aiReq) RerenderOpen(ReactionResult(pActor, pTitle, col, WithTokenTip(reply), pDelta, now, true)); },
                    err => { if (req == _aiReq) RerenderOpen(ReactionResult(pActor, pTitle, col, Pick(pReplyPool), pDelta, now, true)); });
                return;
            }
            ShowDialog(ReactionResult(pActor, pTitle, col, Pick(pReplyPool), pDelta, now, true),
                () => OrganEditorUI.Refresh(pActor));
        }

        // 反应结果页:标题带关系,正文 = 台词(+可选好感度变化),一个"好"关闭
        private static DialogData ReactionResult(Actor pActor, string pTitle, Color pColor,
            string pBody, int pDelta, int pNow, bool pShowAff) {
            DialogData d = new DialogData();
            d.Title = pTitle + "  ·  " + RelationHeader(pActor);
            d.TitleColor = pColor;
            d.Text = (pBody ?? "") + (pShowAff ? AffLine(pDelta, pNow) : "");
            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_ok", "好"), null).Tint(ChoiceStop));
            return d;
        }

        // 发给 AI 的举动描述:按操作类型 + 器官名
        private static string ReactionAiText(string pTitle, string pOrganId) {
            string organ = OrganDisplay(pOrganId);
            if (pTitle.Contains("摘除") || pTitle.Contains("删除"))
                return BioText.T("bio_dial_ai_str_0", "神明摘除了你的" + organ + ",剧痛与惊恐瞬间袭来");
            if (pTitle.Contains("弱化"))
                return BioText.T("bio_dial_ai_str_1", "神明削弱了你的" + organ + ",你感到一阵虚弱与难受");
            if (pTitle.Contains("强化") || pTitle.Contains("紧缩"))
                return BioText.T("bio_dial_ai_str_2", "神明强化了你的" + organ + ",一股力量涌入身体");
            return BioText.T("bio_dial_ai_str_3", "神明改动了你的" + organ);
        }

        private static string OrganDisplay(string pOrganId) {
            try {
                Organ o;
                if (OrganData.OrganName.TryGetValue(pOrganId, out o) && o != null) return o.Name;
            } catch { }
            return BioText.T("bio_dial_organ_fallback", "器官");
        }

        // ============================================================
        //  对话流程(分支)
        // ============================================================
        private class DialogChoice {
            public string Text;
            public Action OnSelect;              // 选中时的副作用(可空)
            public Func<DialogData> Next;        // 非空=原地跳转下一段;空=关闭窗口
            public Color? Color;
            public DialogChoice(string pText, Action pOnSelect, Func<DialogData> pNext = null) {
                Text = pText; OnSelect = pOnSelect; Next = pNext;
            }
            public DialogChoice Tint(Color pColor) { Color = pColor; return this; }
        }

        private class DialogData {
            public string Title = "";
            public Color TitleColor = Color.white;
            public string Text = "";
            public List<DialogChoice> Choices = new List<DialogChoice>();
            // 自定义输入行(仅 AI 可用时挂):玩家亲口打字,回车/点「说」把这句发给 AI。
            public bool ShowInput = false;
            public string InputHint = BioText.T("bio_dial_hint_default", "对他说点什么…");
            public Func<string, DialogData> OnSubmit = null; // 提交后跳转到的下一段(通常是加载页)
        }

        // 未成年保护:点亲密器官直接拦下
        private static DialogData BuildChildProtectDialog(Actor pActor) {
            bool isMale = false;
            try { isMale = pActor.isSexMale(); } catch { }
            DialogData d = new DialogData();
            d.Title = BioText.T("bio_dial_title_child", "未成年保护");
            d.TitleColor = new Color(1f, 0.3f, 0.3f);
            d.Text = Pick(isMale ? ChildProtectBoy : ChildProtectGirl);
            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_release", "放开那个孩子！"), null).Tint(ChoiceStop));
            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_refuse", "我不会做这种事"), null).Tint(ChoiceStop));
            return d;
        }

        // 攻略主界面:展示关系,交谈始终可用,好感达标解锁亲密
        private static DialogData BuildRelationDialog(Actor pActor, string pOrganId) {
            bool isChild = false;
            try { isChild = !pActor.isAdult(); } catch { }
            if (isChild) return BuildChildProtectDialog(pActor);

            int aff = GetAffection(pActor);
            DialogData d = new DialogData();
            d.Title = RelationHeader(pActor);
            d.TitleColor = TitlePink;
            d.Text = PickTier(RelationIntro, Tier(pActor));

            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_talk", "和他聊聊天"), null,
                () => BuildChatDialog(pActor, pOrganId)).Tint(ChoiceChat));

            // 按器官类型给不同的触碰选项。越界举动(亲密/亲吻/舔舐)不再上锁:
            // 好感达标=你情我愿加好感;未达标=对方抗拒,做了掉好感,强迫掉更多。
            if (IsIntimateOrgan(pOrganId)) {
                d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_further", "与他更进一步…"), null,
                    () => BuildIntimateDialog(pActor, pOrganId)).Tint(ChoiceContinue));
            } else if (pOrganId == "mouth") {
                // 亲吻:好感达标且开了 AI → 交给 AI 实时回应;否则走原固定台词/抗拒流程
                if (Welcome(pActor) && BioAIChat.Available) {
                    d.Choices.Add(AiActionChoice(BioText.T("bio_dial_btn_kiss", "亲吻他"), pActor, pOrganId,
                        null, BioText.T("bio_dial_aiact_kiss", "神明温柔地亲吻了你"), () => KissWelcome, GainKiss, TitlePink));
                } else {
                    d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_kiss", "亲吻他"), null,
                        () => BuildAdvance(pActor, pOrganId, AdvKind.Kiss)).Tint(ChoiceContinue));
                }
            } else {
                // 体表部位一律可抚摸(始终受欢迎、稳定加好感)。开了 AI 就实时问 AI。
                string org = pOrganId;
                d.Choices.Add(AiActionChoice(BioText.F("bio_dial_btn_caress", "抚摸他的{0}", PartName(org)), pActor, org,
                    () => CaressAction(org), BioText.F("bio_dial_aiact_caress", "神明轻轻抚摸你的{0}", PartName(org)),
                    () => CaressReply[Mathf.Clamp(Tier(pActor), 0, CaressReply.Length - 1)],
                    GainCaress, TitlePink));
                // 手臂额外:舔腋下;脚额外:舔脚。好感达标且开了 AI → AI 实时回应;
                // 未达标(对方抗拒/强迫)仍走固定文本流程,不交给 AI。
                if (pOrganId == "arm")
                    d.Choices.Add(LickChoice(BioText.T("bio_dial_btn_lickpit", "舔他的腋下"), pActor, pOrganId, AdvKind.LickArmpit,
                        BioText.T("bio_dial_aiact_lickpit", "神明俯身舔舐你的腋下"), () => LickPitWelcome));
                else if (pOrganId == "foot")
                    d.Choices.Add(LickChoice(BioText.T("bio_dial_btn_lickfoot", "舔他的脚"), pActor, pOrganId, AdvKind.LickFoot,
                        BioText.T("bio_dial_aiact_lickfoot", "神明捧起你的脚,轻轻舔舐"), () => LickFootWelcome));
            }

            // 开了 AI:额外给「让他给你几个选择」和底部的亲口输入行
            if (BioAIChat.Available) {
                d.Choices.Add(AiSuggestChoice(BioText.T("bio_dial_btn_suggest", "让他给你几个选择"), pActor, pOrganId,
                    BioText.T("bio_dial_scene_chat", "日常相处、攻略培养感情"), () => BuildRelationDialog(pActor, pOrganId)));
                d.ShowInput = true;
                d.InputHint = BioText.T("bio_dial_hint_default", "对他说点什么…");
                d.OnSubmit = t => SubmitPlayerText(pActor, pOrganId, t, TitlePink,
                    () => BuildRelationDialog(pActor, pOrganId));
            }

            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_end", "今天就到这里"), null).Tint(ChoiceStop));
            return d;
        }

        // ============================================================
        //  AI 实时回应:把玩家举动发给 AI,由其以角色口吻回应(失败回退固定台词)
        // ============================================================
        // 生成一个"举动"选项:开了 AI 就异步问 AI,否则同步用固定台词池。
        // pActionLineFn:显示在回应上方的旁白(如"你捧起他的脸蛋"),可为 null。
        // pAiActionText:发给 AI 的玩家举动描述(第二人称,如"神明亲吻了你")。
        // pCannedFn:AI 不可用/失败时的固定台词池。
        // pMechanic:选中时先触发的真实机制(如赐福加特质、送礼加装备),返回一段追加到旁白
        // 末尾的结果文字(如"✦ 获得祝福特质:迅捷"),无实际效果时返回 null/空。可为 null。
        private static DialogChoice AiActionChoice(string pLabel, Actor pActor, string pOrganId,
            Func<string> pActionLineFn, string pAiActionText, Func<string[]> pCannedFn, int pGain, Color pTint,
            Func<string> pMechanic = null) {
            string actionLine = null; int newAff = 0;
            if (BioAIChat.Available) {
                return new DialogChoice(pLabel,
                    () => {
                        actionLine = pActionLineFn != null ? pActionLineFn() : null;
                        if (pMechanic != null) { string m = pMechanic(); if (!string.IsNullOrEmpty(m)) actionLine = (actionLine ?? "") + m; }
                        newAff = AddAffection(pActor, pGain);
                        int req = ++_aiReq;
                        BioAIChat.SendAction(pActor, pAiActionText,
                            reply => { if (req == _aiReq) RerenderOpen(ActionResult(pActor, pOrganId, actionLine, WithTokenTip(reply), pGain, newAff, pTint)); },
                            err => { if (req == _aiReq) RerenderOpen(ActionResult(pActor, pOrganId, actionLine, Pick(pCannedFn != null ? pCannedFn() : null), pGain, newAff, pTint)); });
                    },
                    () => BuildLoading(pActor)).Tint(pTint);
            }
            // 无 AI:同步固定台词
            return new DialogChoice(pLabel, null,
                () => {
                    string al = pActionLineFn != null ? pActionLineFn() : null;
                    if (pMechanic != null) { string m = pMechanic(); if (!string.IsNullOrEmpty(m)) al = (al ?? "") + m; }
                    int now = AddAffection(pActor, pGain);
                    return ActionResult(pActor, pOrganId, al, Pick(pCannedFn != null ? pCannedFn() : null), pGain, now, pTint);
                }).Tint(pTint);
        }

        // 举动结果页:旁白 + 回应 + 好感度变化,底下可继续互动或停下
        private static DialogData ActionResult(Actor pActor, string pOrganId,
            string pActionLine, string pReply, int pDelta, int pNow, Color pColor) {
            DialogData d = new DialogData();
            d.Title = RelationHeader(pActor);
            d.TitleColor = pColor;
            string body = string.IsNullOrEmpty(pActionLine) ? (pReply ?? "") : (pActionLine + "\n" + (pReply ?? ""));
            d.Text = body + AffLine(pDelta, pNow);
            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_interact", "互动"), null,
                () => BuildRelationDialog(pActor, pOrganId)).Tint(ChoiceChat));
            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_stop", "停下"), null).Tint(ChoiceStop));
            return d;
        }

        // AI 回应中的等待页(AI 返回后由回调替换掉)
        private static DialogData BuildLoading(Actor pActor) {
            DialogData d = new DialogData();
            d.Title = RelationHeader(pActor);
            d.TitleColor = ChoiceChat;
            d.Text = BioText.T("bio_dial_loading", "……（对方正在回应）");
            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_stop", "停下"), null).Tint(ChoiceStop));
            return d;
        }

        // 舔舐选项:好感达标且开了 AI → AI 实时回应(加好感);否则走固定文本的抗拒/强迫流程
        private static DialogChoice LickChoice(string pLabel, Actor pActor, string pOrganId,
            AdvKind pKind, string pAiActionText, Func<string[]> pWelcomePool) {
            if (Welcome(pActor) && BioAIChat.Available)
                return AiActionChoice(pLabel, pActor, pOrganId, null, pAiActionText, pWelcomePool, GainLick, ChoiceContinue);
            return new DialogChoice(pLabel, null,
                () => BuildAdvance(pActor, pOrganId, pKind)).Tint(ChoiceContinue);
        }

        // ============================================================
        //  自定义输入 & AI 生成选项(均需开启 AI)
        // ============================================================
        // 玩家亲口打的字(或 AI 生成的选项被点选)→ 作为一次"举动"发给 AI,由角色实时回应。
        // pBack:结果页里「继续」返回到的场景(通常是当前对话本身),使聊天能一直进行下去。
        // 返回一个"加载中"页;AI 回来后异步刷成结果页。
        // 两步:①让角色回应(SendAction,存历史) ②再单独调一次"情感裁判"给这次互动打分(ScoreInteraction)。
        // 好感增量完全交给 AI 判定(-10~+10):取悦→加、冒犯/惊吓/强迫/亵渎→减。
        // 之所以拆成两次调用:角色扮演的人设强制"只说台词、不要旁白",会把塞在同一回复里的评分吞掉(恒为 0),
        // 单独一次干净的打分调用才稳。打分失败才回退到 +1。
        private static DialogData SubmitPlayerText(Actor pActor, string pOrganId, string pText,
            Color pTint, Func<DialogData> pBack) {
            string actionLine = "<color=#9fd0ff>" + BioText.T("bio_dial_you_prefix", "你：") + pText + "</color>";
            if (!BioAIChat.Available) {
                int now0 = GetAffection(pActor);
                return PlayerTextResult(pActor, pOrganId, actionLine,
                    BioText.T("bio_dial_ai_disabled", "（需要在模组设置里开启「AI 对话」，他才能回应你亲口说的话。）"), 0, now0, pTint, pBack);
            }
            int req = ++_aiReq;
            BioAIChat.SendAction(pActor, pText,
                reply => {
                    if (req != _aiReq) return;
                    string tip = WithTokenTip(reply); // 在打分调用覆盖用量前先取回应的 token 提示
                    BioAIChat.ScoreInteraction(pActor, pText, reply,
                        delta => {
                            if (req != _aiReq) return;
                            int now = AddAffection(pActor, delta);
                            RerenderOpen(PlayerTextResult(pActor, pOrganId, actionLine, tip, delta, now, pTint, pBack));
                        },
                        serr => {
                            if (req != _aiReq) return;
                            Main.LogError("生物学:好感打分失败 " + serr);
                            int now = AddAffection(pActor, 1); // 打分拿不到:回退 +1
                            RerenderOpen(PlayerTextResult(pActor, pOrganId, actionLine, tip, 1, now, pTint, pBack));
                        });
                },
                err => {
                    if (req != _aiReq) return;
                    int now = AddAffection(pActor, 1);
                    RerenderOpen(PlayerTextResult(pActor, pOrganId, actionLine, BioText.T("bio_dial_ai_error", "（他怔了怔，似乎没有听清……）"), 1, now, pTint, pBack));
                });
            return BuildLoading(pActor);
        }

        // 自定义输入/AI 选项的结果页:你的话 + 角色回应 + 好感变化。
        // 底下继续挂输入行,方便连续对话;另有「返回」回到来处、「停下」关闭。
        private static DialogData PlayerTextResult(Actor pActor, string pOrganId, string pActionLine,
            string pReply, int pDelta, int pNow, Color pColor, Func<DialogData> pBack) {
            DialogData d = new DialogData();
            d.Title = RelationHeader(pActor);
            d.TitleColor = pColor;
            d.Text = pActionLine + "\n" + (pReply ?? "") + AffLine(pDelta, pNow);
            if (pBack != null)
                d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_back", "返回"), null, pBack).Tint(ChoiceChat));
            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_stop", "停下"), null).Tint(ChoiceStop));
            // 继续挂输入行:直接再打一句就能接着聊
            if (BioAIChat.Available) {
                d.ShowInput = true;
                d.InputHint = BioText.T("bio_dial_hint_continue", "继续对他说…");
                d.OnSubmit = t => SubmitPlayerText(pActor, pOrganId, t, pColor, pBack);
            }
            return d;
        }

        // 「让 AI 给几个选项」按钮:点了先异步问 AI 要候选,返回加载页;拿到后刷成选项页。
        private static DialogChoice AiSuggestChoice(string pLabel, Actor pActor, string pOrganId,
            string pSceneHint, Func<DialogData> pBack) {
            return new DialogChoice(pLabel,
                () => {
                    int req = ++_aiReq;
                    BioAIChat.SuggestOptions(pActor, pSceneHint,
                        opts => { if (req == _aiReq) RerenderOpen(BuildAiOptions(pActor, pOrganId, opts, pSceneHint, pBack)); },
                        err => { if (req == _aiReq) RerenderOpen(AiOptionsError(pActor, pBack)); });
                },
                () => BuildLoading(pActor)).Tint(ChoiceChat);
        }

        // AI 给出的选项页:每个候选是一个按钮,点了就把它当作玩家举动发给 AI。
        // 另有「换一批」重新生成、「返回」回来处。
        private static DialogData BuildAiOptions(Actor pActor, string pOrganId,
            List<string> pOptions, string pSceneHint, Func<DialogData> pBack) {
            DialogData d = new DialogData();
            d.Title = RelationHeader(pActor);
            d.TitleColor = ChoiceChat;
            d.Text = BioText.T("bio_dial_ai_options_body", "他静静等着你的下一步。（下面是他猜你也许想做的事）");
            if (pOptions != null) {
                foreach (string opt in pOptions) {
                    string captured = opt;
                    d.Choices.Add(new DialogChoice(captured, null,
                        () => SubmitPlayerText(pActor, pOrganId, captured, TitlePink, pBack))
                        .Tint(ChoiceContinue));
                }
            }
            d.Choices.Add(AiSuggestChoice(BioText.T("bio_dial_btn_refresh", "换一批"), pActor, pOrganId, pSceneHint, pBack));
            if (pBack != null)
                d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_back", "返回"), null, pBack).Tint(ChoiceStop));
            else
                d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_stop", "停下"), null).Tint(ChoiceStop));
            return d;
        }

        // AI 生成选项失败时的兜底页
        private static DialogData AiOptionsError(Actor pActor, Func<DialogData> pBack) {
            DialogData d = new DialogData();
            d.Title = RelationHeader(pActor);
            d.TitleColor = ChoiceStop;
            d.Text = BioText.T("bio_dial_ai_options_error", "（一时没想出合适的话头，要不你自己开口，或者再试一次？）");
            if (pBack != null)
                d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_back", "返回"), null, pBack).Tint(ChoiceChat));
            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_stop", "停下"), null).Tint(ChoiceStop));
            return d;
        }

        // ============================================================
        //  越界举动:亲吻 / 舔腋下 / 舔脚(受欢迎加好感,未达门槛掉好感,可强迫)
        // ============================================================
        private enum AdvKind { Kiss, LickArmpit, LickFoot }

        private static DialogData BuildAdvance(Actor pActor, string pOrganId, AdvKind pKind) {
            // 你情我愿:直接给出温情结果
            if (Welcome(pActor)) return BuildAdvanceResult(pActor, pOrganId, pKind, 0);
            // 未达门槛:对方抗拒,让玩家选择硬来 / 强迫 / 作罢
            DialogData d = new DialogData();
            d.Title = RelationHeader(pActor);
            d.TitleColor = ChoiceStop;
            d.Text = Pick(AdvReluctIntro(pKind));
            d.Choices.Add(new DialogChoice(AdvSoftLabel(pKind), null,
                () => BuildAdvanceResult(pActor, pOrganId, pKind, 1)).Tint(ChoiceContinue));
            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_force_him", "强迫他"), null,
                () => BuildAdvanceResult(pActor, pOrganId, pKind, 2)).Tint(ChoiceContinue));
            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_giveup", "作罢"), null,
                () => BuildRelationDialog(pActor, pOrganId)).Tint(ChoiceStop));
            return d;
        }

        // pMode: 0=你情我愿(加好感) 1=硬来(掉好感) 2=强迫(掉更多)
        private static DialogData BuildAdvanceResult(Actor pActor, string pOrganId, AdvKind pKind, int pMode) {
            int delta = AdvDelta(pKind, pMode);
            int now = AddAffection(pActor, delta);
            DialogData d = new DialogData();
            d.Title = RelationHeader(pActor);
            d.TitleColor = pMode == 0 ? TitlePink : new Color(0.9f, 0.5f, 0.5f);
            d.Text = Pick(AdvReply(pKind, pMode)) + AffLine(delta, now);
            // 再来:重新进 BuildAdvance(会重新判断是否已情愿)
            d.Choices.Add(new DialogChoice(AdvAgainLabel(pKind), null,
                () => BuildAdvance(pActor, pOrganId, pKind)).Tint(ChoiceContinue));
            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_back", "返回"), null,
                () => BuildRelationDialog(pActor, pOrganId)).Tint(ChoiceChat));
            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_stop", "停下"), null).Tint(ChoiceStop));
            return d;
        }

        private static int AdvDelta(AdvKind pKind, int pMode) {
            switch (pKind) {
                case AdvKind.Kiss: return pMode == 0 ? GainKiss : (pMode == 1 ? LossKiss : LossKissForce);
                default: return pMode == 0 ? GainLick : (pMode == 1 ? LossLick : LossLickForce);
            }
        }
        private static string AdvSoftLabel(AdvKind k) {
            return k == AdvKind.Kiss ? BioText.T("bio_dial_btn_force_kiss", "不管不顾吻下去") : BioText.T("bio_dial_btn_force_lick", "不管不顾舔下去");
        }
        private static string AdvAgainLabel(AdvKind k) {
            return k == AdvKind.Kiss ? BioText.T("bio_dial_btn_kiss_again", "再吻一次") : BioText.T("bio_dial_btn_lick_again", "再舔一次");
        }
        private static string[] AdvReluctIntro(AdvKind k) {
            switch (k) {
                case AdvKind.Kiss: return KissReluctIntro;
                case AdvKind.LickArmpit: return LickPitReluctIntro;
                default: return LickFootReluctIntro;
            }
        }
        private static string[] AdvReply(AdvKind k, int pMode) {
            switch (k) {
                case AdvKind.Kiss:
                    return pMode == 0 ? KissWelcome : (pMode == 1 ? KissReluctant : KissForced);
                case AdvKind.LickArmpit:
                    return pMode == 0 ? LickPitWelcome : (pMode == 1 ? LickPitReluctant : LickPitForced);
                default:
                    return pMode == 0 ? LickFootWelcome : (pMode == 1 ? LickFootReluctant : LickFootForced);
            }
        }

        // 抚摸体表部位:动作文本按器官、反应文本按好感度分层。小幅加好感,可继续/返回。
        private static DialogData BuildCaressResult(Actor pActor, string pOrganId) {
            int now = AddAffection(pActor, GainCaress);
            DialogData d = new DialogData();
            d.Title = RelationHeader(pActor);
            d.TitleColor = TitlePink;
            string action = CaressAction(pOrganId);
            string reply = PickTier(CaressReply, Tier(pActor));
            d.Text = action + "\n" + reply + AffLine(GainCaress, now);
            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_patmore", "再摸摸"), null,
                () => BuildCaressResult(pActor, pOrganId)).Tint(ChoiceContinue));
            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_back", "返回"), null,
                () => BuildRelationDialog(pActor, pOrganId)).Tint(ChoiceChat));
            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_stop", "停下"), null).Tint(ChoiceStop));
            return d;
        }

        // 交谈子菜单:多种话题,各自加好感,选完回攻略主界面(可连续聊)
        private static DialogData BuildChatDialog(Actor pActor, string pOrganId) {
            DialogData d = new DialogData();
            d.Title = RelationHeader(pActor);
            d.TitleColor = ChoiceChat;
            d.Text = Pick(ChatMenuIntro);

            // 每个话题:开了 AI 就把玩家的举动发给 AI 实时回应,否则用固定台词池
            d.Choices.Add(AiActionChoice(BioText.T("bio_dial_btn_greet", "寒暄几句"), pActor, pOrganId,
                () => Pick(ChatGreet), BioText.T("bio_dial_aiact_greet", "神明与你寒暄,问候你的近况"), () => ChatGreetReply, GainGreet, ChoiceChat));
            d.Choices.Add(AiActionChoice(BioText.T("bio_dial_btn_praise", "赞美他"), pActor, pOrganId,
                () => Pick(ChatPraise), BioText.T("bio_dial_aiact_praise", "神明由衷地赞美你"), () => ChatPraiseReply, GainPraise, ChoiceChat));
            d.Choices.Add(AiActionChoice(BioText.T("bio_dial_btn_comfort", "安抚他"), pActor, pOrganId,
                () => Pick(ChatComfort), BioText.T("bio_dial_aiact_comfort", "神明温言安抚你,许诺庇护"), () => ChatComfortReply, GainComfort, ChoiceChat));
            d.Choices.Add(AiActionChoice(BioText.T("bio_dial_btn_gift", "送他礼物"), pActor, pOrganId,
                () => Pick(ChatGift), BioText.T("bio_dial_aiact_gift", "神明送给你一份礼物"), () => ChatGiftReply, GainGift, ChoiceChat,
                () => GiveGift(pActor)));
            d.Choices.Add(AiActionChoice(BioText.T("bio_dial_btn_listen", "倾听心事"), pActor, pOrganId,
                () => Pick(ChatListen), BioText.T("bio_dial_aiact_listen", "神明耐心倾听你的心事"), () => ChatListenReply, GainListen, ChoiceChat));
            d.Choices.Add(AiActionChoice(BioText.T("bio_dial_btn_bless", "赐予祝福"), pActor, pOrganId,
                () => Pick(ChatBless), BioText.T("bio_dial_aiact_bless", "神明为你赐下祝福"), () => ChatBlessReply, GainBless, ChoiceContinue,
                () => GrantBlessing(pActor)));
            // 开了 AI:让他给几个话头 + 亲口输入行
            if (BioAIChat.Available) {
                d.Choices.Add(AiSuggestChoice(BioText.T("bio_dial_btn_suggest_chat", "让他给你几个话头"), pActor, pOrganId,
                    "闲聊、拉家常、培养感情", () => BuildChatDialog(pActor, pOrganId)));
                d.ShowInput = true;
                d.InputHint = BioText.T("bio_dial_hint_default", "对他说点什么…");
                d.OnSubmit = t => SubmitPlayerText(pActor, pOrganId, t, ChoiceChat,
                    () => BuildChatDialog(pActor, pOrganId));
            }
            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_back", "返回"), null,
                () => BuildRelationDialog(pActor, pOrganId)).Tint(ChoiceStop));
            return d;
        }

        // 交谈结果:加好感;好感低时有概率出现冷淡反应(加成减半)
        private static DialogData BuildChatResult(Actor pActor, string pOrganId,
            string[] pActionPool, string[] pReplyPool, int pGain) {
            int aff = GetAffection(pActor);
            bool cold = aff < 20 && _rng.Next(100) < 45;
            int gain = cold ? Mathf.Max(1, pGain / 2) : pGain;
            int now = AddAffection(pActor, gain);

            DialogData d = new DialogData();
            d.Title = RelationHeader(pActor);
            d.TitleColor = ChoiceChat;
            string reply = cold ? Pick(ChatColdReply) : Pick(pReplyPool);
            d.Text = Pick(pActionPool) + "\n" + reply + AffLine(gain, now);

            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_chatmore", "继续聊"), null,
                () => BuildChatDialog(pActor, pOrganId)).Tint(ChoiceChat));
            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_done", "好了，结束"), null).Tint(ChoiceStop));
            return d;
        }

        // 亲密场景入口:三条 galgame 式分支 —— 继续 / 温柔亲昵 / 停下
        private static DialogData BuildIntimateDialog(Actor pActor, string pOrganId) {
            DialogData d = new DialogData();
            d.Title = RelationHeader(pActor);
            if (!Welcome(pActor)) {
                // 好感未达门槛:对方抗拒,只能硬来 / 强迫,均掉好感
                d.TitleColor = ChoiceStop;
                bool isChest = pOrganId == "chest";
                bool isAnus = pOrganId == "anus";
                bool isVagina = pOrganId == "vagina";
                SexKind sex = GetSexKind(pActor);
                bool hasClit = isVagina && sex != SexKind.Male;
                d.Text = Pick(PickSexPool(pActor, IntimateReluctIntroM, IntimateReluctIntroF, IntimateReluctIntroX));
                if (isChest) {
                    d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_force_knead", "强行揉捏"), null,
                        () => BuildIntimateForce(pActor, pOrganId, 1)).Tint(ChoiceContinue));
                    d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_force_bite", "粗暴地咬和吸"), null,
                        () => BuildIntimateForce(pActor, pOrganId, 2)).Tint(ChoiceContinue));
                } else {
                    d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_force_enter", "不顾抗拒地进入"), null,
                        () => BuildIntimateForce(pActor, pOrganId, 1)).Tint(ChoiceContinue));
                    if (isAnus) {
                        d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_force_anuslick", "强迫舔肛"), null,
                            () => BuildIntimateForceOral(pActor, pOrganId, "anus_lick")).Tint(ChoiceContinue));
                    }
                    if (hasClit) {
                        d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_force_clitlick", "强迫舔阴蒂"), null,
                            () => BuildIntimateForceOral(pActor, pOrganId, "clit_lick")).Tint(ChoiceContinue));
                    }
                    if (isVagina) {
                        d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_force_urethralick", "强迫舔尿道"), null,
                            () => BuildIntimateForceOral(pActor, pOrganId, "urethra_lick")).Tint(ChoiceContinue));
                        d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_force_finger", "强迫手指插入"), null,
                            () => BuildIntimateForceOral(pActor, pOrganId, "finger_insert")).Tint(ChoiceContinue));
                    }
                    d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_force_him", "强迫他"), null,
                        () => BuildIntimateForce(pActor, pOrganId, 2)).Tint(ChoiceContinue));
                }
                d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_stop", "停下"), null).Tint(ChoiceStop));
                return d;
            }
            d.TitleColor = TitlePink;
            d.Text = Pick(PickSexPool(pActor, IntimateOpenM, IntimateOpenF, IntimateOpenX));
            AddIntimateChoices(d, pActor, pOrganId);
            return d;
        }

        // 未达门槛的性交:触发机制,但掉好感(硬来 pMode=1 / 强迫 pMode=2 掉更多)
        // 开了 AI 就让角色以第一人称反应(抗拒/恐惧等),否则用固定台词。
        private static DialogData BuildIntimateForce(Actor pActor, string pOrganId, int pMode) {
            OrganEditorUI.ApplyIntimateAct(pActor, pOrganId);
            int delta = pMode == 2 ? LossIntimateForce : LossIntimate;
            int now = AddAffection(pActor, delta);

            if (BioAIChat.Available) {
                int req = ++_aiReq;
                string aiText = IntimateForceAiText(pActor, pOrganId, pMode);
                BioAIChat.SendAction(pActor, aiText,
                    reply => { if (req == _aiReq) RerenderOpen(IntimateForceResult(pActor, pOrganId, WithTokenTip(reply), delta, now)); },
                    err => { if (req == _aiReq) RerenderOpen(IntimateForceResult(pActor, pOrganId, Pick(ForceReplyPool(pActor, pOrganId, pMode)), delta, now)); });
                return BuildLoading(pActor);
            }
            return IntimateForceResult(pActor, pOrganId, Pick(ForceReplyPool(pActor, pOrganId, pMode)), delta, now);
        }

        // 未达门槛的强制口交/手指:触发机制,掉好感
        private static DialogData BuildIntimateForceOral(Actor pActor, string pOrganId, string pAction) {
            // 舔阴蒂/舔尿道/舔肛/手指插入都是口/指的爱抚,不是插入性交:
            // 只按概率引发高潮,绝不走 ApplyIntimateAct 的"侵犯"处理(扩张/疾病/受孕)。
            OrganEditorUI.ApplyOralOrgasm(pActor, pAction);
            int delta = LossIntimate;
            int now = AddAffection(pActor, delta);

            if (BioAIChat.Available) {
                int req = ++_aiReq;
                string aiText = ForceOralAiText(pActor, pAction);
                BioAIChat.SendAction(pActor, aiText,
                    reply => { if (req == _aiReq) RerenderOpen(IntimateForceResult(pActor, pOrganId, WithTokenTip(reply), delta, now)); },
                    err => { if (req == _aiReq) RerenderOpen(IntimateForceResult(pActor, pOrganId, Pick(ForceOralReplyPool(pActor, pAction)), delta, now)); });
                return BuildLoading(pActor);
            }
            return IntimateForceResult(pActor, pOrganId, Pick(ForceOralReplyPool(pActor, pAction)), delta, now);
        }

        // 强制口交/手指 AI 举动(按动作+性别)
        private static string ForceOralAiText(Actor pActor, string pAction) {
            SexKind sex = GetSexKind(pActor);
            if (pAction == "anus_lick") {
                if (sex == SexKind.Male) return BioText.T("bio_dial_ai_force_anuslick", "神明强行把你的腿掰开,低头用力舔舐你的后庭,你痛得叫出声");
                if (sex == SexKind.Intersex) return BioText.T("bio_dial_ai_force_anuslick", "神明强行把你的腿掰开,低头用力舔舐你的后庭,同时粗暴地握住你的阴茎");
                return BioText.T("bio_dial_ai_force_anuslick", "神明强行把你的腿掰开,低头用力舔舐你的后庭,你痛得叫出声");
            }
            if (pAction == "clit_lick") {
                if (sex == SexKind.Intersex) return BioText.T("bio_dial_ai_force_clitlick", "神明强行掰开你的腿,用牙齿咬住你的阴蒂粗暴地拉扯,你痛得尖叫");
                return BioText.T("bio_dial_ai_force_clitlick", "神明强行掰开你的腿,用牙齿咬住你的阴蒂粗暴地拉扯,你痛得尖叫");
            }
            if (pAction == "urethra_lick") {
                if (sex == SexKind.Intersex) return BioText.T("bio_dial_ai_force_urethralick", "神明强行按住你,用舌头粗暴地探入你的尿道口搅动,你浑身发颤");
                return BioText.T("bio_dial_ai_force_urethralick", "神明强行按住你,用舌头粗暴地探入你的尿道口搅动,你浑身发颤");
            }
            if (pAction == "finger_insert") {
                if (sex == SexKind.Intersex) return BioText.T("bio_dial_ai_force_finger", "神明强行把手指粗暴地捅进你的小穴,快速抽插,你痛得叫出声");
                return BioText.T("bio_dial_ai_force_finger", "神明强行把手指粗暴地捅进你的小穴,快速抽插,你痛得叫出声");
            }
            return BioText.T("bio_dial_ai_force_default", "神明强行侵犯了你");
        }

        // 强制口交/手指固定台词池(按动作+性别)
        private static string[] ForceOralReplyPool(Actor pActor, string pAction) {
            if (pAction == "anus_lick")
                return PickSexPool(pActor, ForceAnusLickReplyM, ForceAnusLickReplyF, ForceAnusLickReplyX);
            if (pAction == "clit_lick")
                return PickSexPool(pActor, ForceClitLickReplyM, ForceClitLickReplyF, ForceClitLickReplyX);
            if (pAction == "urethra_lick")
                return PickSexPool(pActor, ForceUrethraLickReplyM, ForceUrethraLickReplyF, ForceUrethraLickReplyX);
            if (pAction == "finger_insert")
                return PickSexPool(pActor, ForceFingerInsertReplyM, ForceFingerInsertReplyF, ForceFingerInsertReplyX);
            return IntimateReluctIntroM;
        }

        // 按器官+性别+硬来/强迫选取固定台词池
        private static string[] ForceReplyPool(Actor pActor, string pOrganId, int pMode) {
            bool forced = pMode == 2;
            if (pOrganId == "chest")
                return forced ? PickSexPool(pActor, ChestForcedReplyM, ChestForcedReplyF, ChestForcedReplyX)
                              : PickSexPool(pActor, ChestReluctReplyM, ChestReluctReplyF, ChestReluctReplyX);
            if (pOrganId == "anus")
                return forced ? PickSexPool(pActor, AnusForcedReplyM, AnusForcedReplyF, AnusForcedReplyX)
                              : PickSexPool(pActor, AnusReluctReplyM, AnusReluctReplyF, AnusReluctReplyX);
            if (pOrganId == "penis")
                return forced ? PickSexPool(pActor, PenisForcedReplyM, PenisForcedReplyF, PenisForcedReplyX)
                              : PickSexPool(pActor, PenisReluctReplyM, PenisReluctReplyF, PenisReluctReplyX);
            // 默认阴道(vagina/cloaca)
            return forced ? PickSexPool(pActor, VaginaForcedReplyM, VaginaForcedReplyF, VaginaForcedReplyX)
                          : PickSexPool(pActor, VaginaReluctReplyM, VaginaReluctReplyF, VaginaReluctReplyX);
        }

        // 未达门槛性交的结果页:回应 + 好感变化,底下继续/停下
        private static DialogData IntimateForceResult(Actor pActor, string pOrganId, string pReply, int pDelta, int pNow) {
            DialogData d = new DialogData();
            d.Title = RelationHeader(pActor);
            d.TitleColor = new Color(0.9f, 0.5f, 0.5f);
            d.Text = (pReply ?? "") + AffLine(pDelta, pNow);
            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_continue", "继续"), null,
                () => BuildIntimateDialog(pActor, pOrganId)).Tint(ChoiceContinue));
            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_stop", "停下"), null).Tint(ChoiceStop));
            return d;
        }

        // 未达门槛性交发给 AI 的举动描述(按器官+性别)
        private static string IntimateForceAiText(Actor pActor, string pOrganId, int pMode) {
            SexKind sex = GetSexKind(pActor);
            if (pMode == 2) {
                if (pOrganId == "vagina") {
                    if (sex == SexKind.Intersex) return BioText.T("bio_dial_ai_vfor1_x", "神明强行把你的腿掰开,绕过你的阴茎粗暴地把肉棒捅进你的小穴,不顾你的哭喊猛烈抽插");
                    return BioText.T("bio_dial_ai_vfor1_f", "神明强行把你的腿掰开,粗暴地把肉棒捅进你的小穴,不顾你的哭喊猛烈抽插");
                }
                if (pOrganId == "anus")
                    return BioText.T("bio_dial_ai_vfor2_m", "神明把你按在地上,从后面强行插入你的后庭,不顾你的挣扎用力操干");
                if (pOrganId == "chest") {
                    if (sex == SexKind.Male) return BioText.T("bio_dial_ai_cfor_m", "神明粗暴地低头咬住你的乳头用力吸吮,牙齿撕扯着你的胸肌,你痛得叫出声");
                    if (sex == SexKind.Intersex) return BioText.T("bio_dial_ai_cfor_x", "神明粗暴地低头咬住你的乳头用力吸吮,牙齿撕扯着你的乳房,你痛得叫出声");
                    return BioText.T("bio_dial_ai_cfor_f", "神明粗暴地低头咬住你的乳头用力吸吮,牙齿撕扯着你的乳房,你痛得叫出声");
                }
                return BioText.T("bio_dial_ai_force_default", "神明暴力地强暴了你,你被按住动弹不得,只能承受他的侵犯");
            }
            if (pOrganId == "vagina") {
                if (sex == SexKind.Intersex) return BioText.T("bio_dial_ai_vrel1_x", "你虽然嘴上抗拒,但神明还是绕过你的阴茎把肉棒插进了你的小穴,你身体渐渐有了反应");
                return BioText.T("bio_dial_ai_vrel1_f", "你虽然嘴上抗拒,但神明还是把肉棒插进了你的小穴,你身体渐渐有了反应");
            }
            if (pOrganId == "anus")
                return BioText.T("bio_dial_ai_vrel2_m", "你不情愿地被神明从后面插入后庭,疼痛中渐渐夹杂着快感");
            if (pOrganId == "chest") {
                if (sex == SexKind.Male) return BioText.T("bio_dial_ai_crel_m", "你半推半就地让神明揉弄你的胸肌,乳头被舔弄得渐渐硬挺起来");
                if (sex == SexKind.Intersex) return BioText.T("bio_dial_ai_crel_x", "你半推半就地让神明揉弄你的乳房,乳头被舔弄得渐渐硬挺起来");
                return BioText.T("bio_dial_ai_crel_f", "你半推半就地让神明揉弄你的胸部,乳头被舔弄得渐渐硬挺起来");
            }
            return BioText.T("bio_dial_ai_force_default", "你半推半就地与神明发生了关系,身体不自觉地迎合起来");
        }

        // 亲密结果页:回应 + 好感变化,底下再挂上继续/温柔/聊天/停下(循环)
        private static DialogData IntimateResult(Actor pActor, string pOrganId, string pReply, int pDelta, int pNow, Color pColor) {
            DialogData d = new DialogData();
            d.Title = RelationHeader(pActor);
            d.TitleColor = pColor;
            d.Text = (pReply ?? "") + AffLine(pDelta, pNow);
            AddIntimateChoices(d, pActor, pOrganId);
            return d;
        }

        // 亲密动作选项:开了 AI 就把举动发给 AI 实时回应,否则用固定台词。
        // pMechanic=true 时先触发对应器官机制(受孕/扩张/射精)。
        private static DialogChoice IntimateChoice(string pLabel, Actor pActor, string pOrganId,
            string pAiActionText, Func<string[]> pCannedFn, int pGain, bool pMechanic, Color pTint,
            Action pExtra = null) {
            int newAff = 0;
            Action doEffect = () => {
                if (pMechanic) OrganEditorUI.ApplyIntimateAct(pActor, pOrganId);
                if (pExtra != null) pExtra();
                newAff = AddAffection(pActor, pGain);
            };
            if (BioAIChat.Available) {
                return new DialogChoice(pLabel,
                    () => {
                        doEffect();
                        int req = ++_aiReq;
                        BioAIChat.SendAction(pActor, pAiActionText,
                            reply => { if (req == _aiReq) RerenderOpen(IntimateResult(pActor, pOrganId, WithTokenTip(reply), pGain, newAff, pTint)); },
                            err => { if (req == _aiReq) RerenderOpen(IntimateResult(pActor, pOrganId, Pick(pCannedFn != null ? pCannedFn() : null), pGain, newAff, pTint)); });
                    },
                    () => BuildLoading(pActor)).Tint(pTint);
            }
            return new DialogChoice(pLabel, null,
                () => { doEffect(); return IntimateResult(pActor, pOrganId, Pick(pCannedFn != null ? pCannedFn() : null), pGain, newAff, pTint); }).Tint(pTint);
        }

        // 亲密"继续"发给 AI 的举动描述(按器官+性别)
        private static string IntimateContinueAiText(Actor pActor, string pOrganId) {
            SexKind sex = GetSexKind(pActor);
            if (pOrganId == "vagina") {
                if (sex == SexKind.Male) return BioText.T("bio_dial_ai_vrel1_m", "神明把你的腿分开,粗暴地插入你的小穴,你咬着嘴唇忍耐");
                if (sex == SexKind.Intersex) return BioText.T("bio_dial_ai_vrel1_x", "神明把你的腿分开,绕过你的阴茎插入你的小穴,开始猛烈抽插");
                return BioText.T("bio_dial_ai_vrel1_f", "神明把你的腿分开,粗暴地插入你的小穴,开始猛烈抽插");
            }
            if (pOrganId == "anus") {
                return BioText.T("bio_dial_ai_arel2", "神明把你翻过去,从后面插入你的后庭,用力操干");
            }
            if (pOrganId == "penis") {
                if (sex == SexKind.Male) return BioText.T("bio_dial_ai_pcont_m", "神明握住你的阴茎,上下套弄,你低吼着射了出来");
                if (sex == SexKind.Intersex) return BioText.T("bio_dial_ai_pcont_x", "神明握住你胯下的肉棒,上下套弄,同时用另一只手玩弄你的小穴");
                return BioText.T("bio_dial_ai_pcont_f", "神明握住你的阴茎,上下套弄,帮你撸管射精");
            }
            if (pOrganId == "cloaca")
                return BioText.T("bio_dial_ai_pcont_cloaca", "神明翻开你的泄殖腔,将肉棒捅了进去");
            if (pOrganId == "chest") {
                if (sex == SexKind.Male) return BioText.T("bio_dial_ai_ccont_m", "神明含住你的乳头用力吮吸,手指揉捏着你结实的胸肌");
                if (sex == SexKind.Intersex) return BioText.T("bio_dial_ai_ccont_x", "神明含住你的乳头用力吮吸,手指揉捏着你柔软的乳房");
                return BioText.T("bio_dial_ai_ccont_f", "神明含住你的乳头用力吮吸,手指揉捏着你的乳房");
            }
            return BioText.T("bio_dial_ai_cont_default", "神明把你压在身下,与你交合在一起");
        }

        // 亲密-停下:结束
        private static DialogData BuildIntimateStop(Actor pActor, string pOrganId) {
            DialogData d = new DialogData();
            d.Title = RelationHeader(pActor);
            d.TitleColor = ChoiceStop;
            bool isChest = pOrganId == "chest";
            d.Text = Pick(isChest ? PickSexPool(pActor, ChestStopReplyM, ChestStopReplyF, ChestStopReplyX) : PickSexPool(pActor, IntimateStopReplyM, IntimateStopReplyF, IntimateStopReplyX));
            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_leave", "离开"), null).Tint(ChoiceStop));
            return d;
        }

        // 亲密场景通用选项:继续 / 温柔亲昵 / 舔肛(仅肛门) / 舔阴蒂(仅阴道) / 舔尿道(仅阴道) / 手指插入(仅阴道) / 聊聊天 / 停下
        private static void AddIntimateChoices(DialogData d, Actor pActor, string pOrganId) {
            bool isChest = pOrganId == "chest";
            bool isAnus = pOrganId == "anus";
            bool isPenis = pOrganId == "penis";
            bool isVagina = pOrganId == "vagina";
            SexKind sex = GetSexKind(pActor);
            bool hasClit = isVagina && sex != SexKind.Male; // 男性无阴蒂
            // 固定台词:按性别+器官选择
            Func<string[]> continueCanned = () => {
                if (isChest) return PickSexPool(pActor, ChestContinueReplyM, ChestContinueReplyF, ChestContinueReplyX);
                if (isAnus) return PickSexPool(pActor, AnusContinueReplyM, AnusContinueReplyF, AnusContinueReplyX);
                if (isPenis) return PickSexPool(pActor, PenisContinueReplyM, PenisContinueReplyF, PenisContinueReplyX);
                return PickSexPool(pActor, VaginaContinueReplyM, VaginaContinueReplyF, VaginaContinueReplyX);
            };
            Func<string[]> tenderCanned = () => isChest ? PickSexPool(pActor, ChestTenderReplyM, ChestTenderReplyF, ChestTenderReplyX) : PickSexPool(pActor, IntimateTenderReplyM, IntimateTenderReplyF, IntimateTenderReplyX);
            Func<string[]> chatCanned = () => isChest ? PickSexPool(pActor, ChestChatReplyM, ChestChatReplyF, ChestChatReplyX) : PickSexPool(pActor, IntimateChatReplyM, IntimateChatReplyF, IntimateChatReplyX);
            Func<string[]> lickAnusCanned = () => PickSexPool(pActor, AnusLickReplyM, AnusLickReplyF, AnusLickReplyX);
            Func<string[]> clitLickCanned = () => PickSexPool(pActor, ClitLickReplyM, ClitLickReplyF, ClitLickReplyX);
            Func<string[]> urethraLickCanned = () => PickSexPool(pActor, UrethraLickReplyM, UrethraLickReplyF, UrethraLickReplyX);
            Func<string[]> fingerCanned = () => PickSexPool(pActor, FingerInsertReplyM, FingerInsertReplyF, FingerInsertReplyX);
            // AI 举动:按性别+器官生成
            string tenderAi = TenderAiText(pActor, pOrganId);
            string chatAi = ChatAiText(pActor, pOrganId);
            string lickAnusAi = AnusLickAiText(pActor);
            string clitLickAi = ClitLickAiText(pActor);
            string urethraLickAi = UrethraLickAiText(pActor);
            string fingerAi = FingerInsertAiText(pActor);

            d.Choices.Add(IntimateChoice(BioText.T("bio_dial_btn_continue", "继续"), pActor, pOrganId,
                IntimateContinueAiText(pActor, pOrganId), continueCanned, GainIntimateContinue, true, ChoiceContinue));
            d.Choices.Add(IntimateChoice(BioText.T("bio_dial_btn_tender", "温柔亲昵"), pActor, pOrganId,
                tenderAi, tenderCanned, GainIntimateTender, false, ChoiceContinue));
            if (isAnus) {
                d.Choices.Add(IntimateChoice(BioText.T("bio_dial_btn_anuslick", "舔肛"), pActor, pOrganId,
                    lickAnusAi, lickAnusCanned, GainIntimateTender, false, ChoiceContinue,
                    () => OrganEditorUI.ApplyOralOrgasm(pActor, "anus_lick")));
            }
            if (hasClit) {
                d.Choices.Add(IntimateChoice(BioText.T("bio_dial_btn_clitlick", "舔阴蒂"), pActor, pOrganId,
                    clitLickAi, clitLickCanned, GainIntimateTender, false, ChoiceContinue,
                    () => OrganEditorUI.ApplyOralOrgasm(pActor, "clit_lick")));
            }
            if (isVagina) {
                d.Choices.Add(IntimateChoice(BioText.T("bio_dial_btn_urethralick", "舔尿道"), pActor, pOrganId,
                    urethraLickAi, urethraLickCanned, GainIntimateTender, false, ChoiceContinue,
                    () => OrganEditorUI.ApplyOralOrgasm(pActor, "urethra_lick")));
                d.Choices.Add(IntimateChoice(BioText.T("bio_dial_btn_finger", "手指插入"), pActor, pOrganId,
                    fingerAi, fingerCanned, GainIntimateTender, false, ChoiceContinue,
                    () => OrganEditorUI.ApplyOralOrgasm(pActor, "finger_insert")));
            }
            d.Choices.Add(IntimateChoice(BioText.T("bio_dial_btn_chat", "聊聊天"), pActor, pOrganId,
                chatAi, chatCanned, GainIntimateChat, false, ChoiceChat));
            // 开了 AI:让他给几个花样 + 亲口输入行
            if (BioAIChat.Available) {
                d.Choices.Add(AiSuggestChoice("让他给你几个花样", pActor, pOrganId,
                    BioText.T("bio_dial_scene_intimate", "正处于亲密/情事场景中"), () => BuildIntimateDialog(pActor, pOrganId)));
                d.ShowInput = true;
                d.InputHint = BioText.T("bio_dial_hint_intimate", "对他说点什么、做点什么…");
                d.OnSubmit = t => SubmitPlayerText(pActor, pOrganId, t, TitlePink,
                    () => BuildIntimateDialog(pActor, pOrganId));
            }
            d.Choices.Add(new DialogChoice(BioText.T("bio_dial_btn_stop", "停下"), null,
                () => BuildIntimateStop(pActor, pOrganId)).Tint(ChoiceStop));
        }

        // 按性别选取台词池
        private static string[] PickSexPool(Actor pActor, string[] m, string[] f, string[] x) {
            switch (GetSexKind(pActor)) {
                case SexKind.Male: return m;
                case SexKind.Intersex: return x;
                default: return f;
            }
        }

        // 温柔亲昵 AI 举动(按性别+器官)
        private static string TenderAiText(Actor pActor, string pOrganId) {
            SexKind sex = GetSexKind(pActor);
            if (pOrganId == "chest") {
                if (sex == SexKind.Male) return BioText.T("bio_dial_ai_tender_chest_m", "神明含住你的乳头轻轻舔咬,手掌揉弄着你结实的胸肌");
                if (sex == SexKind.Intersex) return BioText.T("bio_dial_ai_tender_chest_x", "神明含住你的乳头轻轻舔咬,手掌揉弄着你柔软的乳房");
                return BioText.T("bio_dial_ai_tender_chest_f", "神明含住你的乳头轻轻舔咬,手掌揉弄着你的乳房");
            }
            if (sex == SexKind.Male)
                return BioText.T("bio_dial_ai_tender_m", "神明把你搂进怀里,亲吻你的脖颈,手伸进裤子里揉弄你的下体");
            if (sex == SexKind.Intersex)
                return BioText.T("bio_dial_ai_tender_x", "神明把你搂进怀里,亲吻你的脖颈,一只手揉你的乳房另一只手伸进腿间");
            return BioText.T("bio_dial_ai_tender_f", "神明把你搂进怀里,亲吻你的脖颈,手伸进衣服里揉弄你的身体");
        }

        // 聊天 AI 举动(按性别+器官)
        private static string ChatAiText(Actor pActor, string pOrganId) {
            SexKind sex = GetSexKind(pActor);
            if (pOrganId == "chest") {
                if (sex == SexKind.Male) return BioText.T("bio_dial_ai_chat_chest_m", "神明捧起你的胸膛,用脸颊蹭着你的胸口");
                if (sex == SexKind.Intersex) return BioText.T("bio_dial_ai_chat_chest_x", "神明捧起你的乳房,用脸颊蹭着你的乳沟");
                return BioText.T("bio_dial_ai_chat_chest_f", "神明捧起你的胸部,用脸颊蹭着你的乳沟");
            }
            if (sex == SexKind.Male)
                return BioText.T("bio_dial_ai_chat_m", "神明与你赤裸相拥,一手抚摸你的腹肌一边低声说情话");
            if (sex == SexKind.Intersex)
                return BioText.T("bio_dial_ai_chat_x", "神明与你赤裸相拥,一手揉你的乳房一手抚摸你的阴茎,低声说情话");
            return BioText.T("bio_dial_ai_chat_f", "神明与你赤裸相拥,一边抚摸你的身体一边低声说情话");
        }

        // 舔肛 AI 举动(按性别)
        private static string AnusLickAiText(Actor pActor) {
            SexKind sex = GetSexKind(pActor);
            if (sex == SexKind.Male)
                return BioText.T("bio_dial_ai_anuslick_m", "神明把你翻过去,分开你的臀瓣,用舌头仔细地舔舐你的后庭,口水涂满了你的穴口");
            if (sex == SexKind.Intersex)
                return BioText.T("bio_dial_ai_anuslick_x", "神明把你翻过去,分开你的臀瓣,用舌头仔细地舔舐你的后庭,同时用手握住你垂软的阴茎");
            return BioText.T("bio_dial_ai_anuslick_f", "神明把你翻过去,分开你的臀瓣,用舌头仔细地舔舐你的后庭,口水顺着臀缝流下来");
        }

        // 舔阴蒂 AI 举动(按性别)
        private static string ClitLickAiText(Actor pActor) {
            SexKind sex = GetSexKind(pActor);
            if (sex == SexKind.Intersex)
                return BioText.T("bio_dial_ai_clitlick_x", "神明俯下身,用舌尖轻轻拨开你的包皮,含住你的阴蒂快速舔弄,同时用手套弄你的阴茎");
            return BioText.T("bio_dial_ai_clitlick_f", "神明俯下身,用舌尖轻轻拨开你的阴蒂包皮,含住那颗小小的凸起快速舔弄,你浑身发颤");
        }

        // 舔尿道 AI 举动(按性别)
        private static string UrethraLickAiText(Actor pActor) {
            SexKind sex = GetSexKind(pActor);
            if (sex == SexKind.Intersex)
                return BioText.T("bio_dial_ai_urethralick_x", "神明俯下身,用舌尖探入你的尿道口,轻轻搅动,你浑身一激灵,阴茎不由自主地跳了一下");
            return BioText.T("bio_dial_ai_urethralick_f", "神明俯下身,用舌尖探入你的尿道口,轻轻搅动,你浑身一激灵,下体一阵酥麻");
        }

        // 手指插入 AI 举动(按性别)
        private static string FingerInsertAiText(Actor pActor) {
            SexKind sex = GetSexKind(pActor);
            if (sex == SexKind.Intersex)
                return BioText.T("bio_dial_ai_fingerinsert_x", "神明用手指慢慢探入你的小穴,一边玩弄你的阴茎,手指在你体内弯曲勾弄");
            return BioText.T("bio_dial_ai_fingerinsert_f", "神明用手指慢慢探入你的小穴,指尖在你体内弯曲勾弄G点,你忍不住呻吟出声");
        }

        // ============================================================
        //  窗口渲染
        // ============================================================
        // 当前打开的对话窗:供 AI 异步回调把新内容刷进去(窗口关了或换了请求就作废)
        private static GameObject _openGo;
        private static Action<DialogData> _openRender;
        private static int _aiReq; // AI 请求令牌:只有最新一次的回调能生效

        private static void CloseDialog(GameObject pGo, GameObject pBlocker) {
            _openGo = null;
            _openRender = null;
            _aiReq++; // 关窗即作废所有在途 AI 回调
            UnityEngine.Object.Destroy(pGo);
            UnityEngine.Object.Destroy(pBlocker);
        }

        // 把一段对话刷进当前打开的窗口(若还开着)。AI 回调用。
        private static void RerenderOpen(DialogData pData) {
            if (_openGo != null && _openRender != null) _openRender(pData);
        }

        // 开了「显示Token消耗」就在 AI 回应末尾附一行小字用量(仅 AI 成功时,固定台词不附)
        private static string WithTokenTip(string pReply) {
            if (BioAIChat.ShowTokenTip && !string.IsNullOrEmpty(BioAIChat.LastUsage)) {
                int ts = Mathf.Max(6, Mathf.RoundToInt(DF(14) * 0.55f));
                return (pReply ?? "") + "\n<size=" + ts + "><color=#888888>" + BioAIChat.LastUsage + "</color></size>";
            }
            return pReply;
        }

        private static void ShowDialog(DialogData pData, Action pOnClose) {
            try {
                Canvas c = CanvasMain.instance != null ? CanvasMain.instance.canvas_windows : null;
                if (c == null) return;

                GameObject blocker = new GameObject("DialogBlocker", typeof(RectTransform), typeof(Image));
                blocker.transform.SetParent(c.transform, false);
                RectTransform brt = blocker.GetComponent<RectTransform>();
                brt.anchorMin = Vector2.zero; brt.anchorMax = Vector2.one;
                brt.offsetMin = Vector2.zero; brt.offsetMax = Vector2.zero;
                Image bimg = blocker.GetComponent<Image>();
                bimg.color = new Color(0f, 0f, 0f, 0.3f);
                bimg.raycastTarget = true;
                blocker.AddComponent<MenuBlocker>();

                GameObject go = new GameObject("Dialog", typeof(RectTransform), typeof(Image),
                    typeof(VerticalLayoutGroup), typeof(ContentSizeFitter));
                go.transform.SetParent(c.transform, false);
                RectTransform rt = go.GetComponent<RectTransform>();
                rt.pivot = new Vector2(0.5f, 0.5f);
                rt.anchoredPosition = new Vector2(DS(120f), 0);
                rt.sizeDelta = new Vector2(DS(360f), 0);
                Image img = go.GetComponent<Image>();
                Sprite spr = SpriteTextureLoader.getSprite("ui/special/windowInnerSliced");
                if (spr != null) { img.sprite = spr; img.type = Image.Type.Sliced; }
                img.color = new Color(0.15f, 0.12f, 0.2f, 0.95f);
                img.raycastTarget = false;
                VerticalLayoutGroup vlg = go.GetComponent<VerticalLayoutGroup>();
                vlg.padding = new RectOffset(Mathf.RoundToInt(DS(16f)), Mathf.RoundToInt(DS(16f)),
                    Mathf.RoundToInt(DS(12f)), Mathf.RoundToInt(DS(12f)));
                vlg.spacing = DS(6f);
                vlg.childControlWidth = true;
                vlg.childForceExpandWidth = true;
                vlg.childControlHeight = true;
                vlg.childForceExpandHeight = false;
                vlg.childAlignment = TextAnchor.UpperCenter;
                go.GetComponent<ContentSizeFitter>().verticalFit = ContentSizeFitter.FitMode.PreferredSize;

                // 关闭按钮
                GameObject closeBtn = new GameObject("CloseX", typeof(RectTransform), typeof(Image), typeof(Button));
                closeBtn.transform.SetParent(rt, false);
                RectTransform crt = closeBtn.GetComponent<RectTransform>();
                crt.anchorMin = new Vector2(1f, 1f); crt.anchorMax = new Vector2(1f, 1f);
                crt.pivot = new Vector2(1f, 1f);
                crt.anchoredPosition = new Vector2(DS(-3f), DS(-3f));
                crt.sizeDelta = new Vector2(DS(28f), DS(28f));
                closeBtn.AddComponent<LayoutElement>().ignoreLayout = true;
                Image cimg = closeBtn.GetComponent<Image>();
                cimg.sprite = SpriteTextureLoader.getSprite("ui/icons/iconClose");
                if (cimg.sprite != null) cimg.preserveAspect = true;
                cimg.color = Color.white; cimg.raycastTarget = true;
                Button cbtn = closeBtn.GetComponent<Button>();
                cbtn.targetGraphic = cimg;
                cbtn.transition = Selectable.Transition.None;
                cbtn.onClick.AddListener(() => { CloseDialog(go, blocker); if (pOnClose != null) pOnClose(); });

                // 内容直接加在窗口上;分支跳转时销毁除关闭按钮外的子节点后重建
                Action<DialogData> render = null;
                render = (data) => {
                    if (data == null) { CloseDialog(go, blocker); if (pOnClose != null) pOnClose(); return; }
                    _openGo = go; _openRender = render; // 记录当前窗口,供 AI 异步回调刷新
                    for (int i = rt.childCount - 1; i >= 0; i--) {
                        Transform child = rt.GetChild(i);
                        if (child == closeBtn.transform) continue;
                        UnityEngine.Object.Destroy(child.gameObject);
                    }

                    // 标题
                    GameObject titleObj = new GameObject("Title", typeof(RectTransform), typeof(Text), typeof(LayoutElement));
                    titleObj.transform.SetParent(rt, false);
                    LayoutElement tle = titleObj.GetComponent<LayoutElement>();
                    tle.minHeight = DS(28f); tle.preferredHeight = DS(28f);
                    Text titleTxt = titleObj.GetComponent<Text>();
                    titleTxt.font = LocalizedTextManager.current_font;
                    titleTxt.fontSize = DF(15);
                    titleTxt.fontStyle = FontStyle.Bold;
                    titleTxt.color = data.TitleColor;
                    titleTxt.alignment = TextAnchor.MiddleCenter;
                    titleTxt.raycastTarget = false;
                    titleTxt.text = data.Title;

                    // 剧情正文:VerticalLayoutGroup 读 Text 自身 preferredHeight 自动换行定高
                    GameObject dlgObj = new GameObject("Dialogue", typeof(RectTransform), typeof(Text), typeof(LayoutElement));
                    dlgObj.transform.SetParent(rt, false);
                    dlgObj.GetComponent<LayoutElement>().minHeight = DS(60f);
                    Text dlgTxt = dlgObj.GetComponent<Text>();
                    dlgTxt.font = LocalizedTextManager.current_font;
                    dlgTxt.fontSize = DF(14);
                    dlgTxt.color = new Color(0.9f, 0.85f, 0.95f);
                    dlgTxt.alignment = TextAnchor.UpperCenter;
                    dlgTxt.horizontalOverflow = HorizontalWrapMode.Wrap;
                    dlgTxt.verticalOverflow = VerticalWrapMode.Overflow;
                    dlgTxt.raycastTarget = false;
                    dlgTxt.text = data.Text;

                    // 选项外框:带描边背景,把所有选项框在里面
                    GameObject frame = new GameObject("ChoiceFrame",
                        typeof(RectTransform), typeof(Image), typeof(VerticalLayoutGroup), typeof(LayoutElement));
                    frame.transform.SetParent(rt, false);
                    Image frameImg = frame.GetComponent<Image>();
                    Sprite frameSpr = SpriteTextureLoader.getSprite("ui/special/windowInnerSliced");
                    if (frameSpr != null) { frameImg.sprite = frameSpr; frameImg.type = Image.Type.Sliced; }
                    frameImg.color = new Color(0.09f, 0.08f, 0.13f, 0.95f);
                    frameImg.raycastTarget = false;
                    VerticalLayoutGroup fvlg = frame.GetComponent<VerticalLayoutGroup>();
                    int fp = Mathf.RoundToInt(DS(6f));
                    fvlg.padding = new RectOffset(fp, fp, fp, fp);
                    fvlg.spacing = DS(5f);
                    fvlg.childControlWidth = true;
                    fvlg.childForceExpandWidth = true;
                    fvlg.childControlHeight = true;
                    fvlg.childForceExpandHeight = false;
                    fvlg.childAlignment = TextAnchor.UpperCenter;
                    frame.GetComponent<LayoutElement>().flexibleHeight = 0f;

                    foreach (DialogChoice choice in data.Choices) {
                        DialogChoice captured = choice;
                        AddChoiceButton(frame.transform, captured.Text, captured.Color, () => {
                            if (captured.OnSelect != null) captured.OnSelect();
                            if (captured.Next != null) render(captured.Next());
                            else { CloseDialog(go, blocker); if (pOnClose != null) pOnClose(); }
                        });
                    }

                    // 自定义输入行:玩家亲口打字发给 AI(仅在需要时挂)
                    if (data.ShowInput && data.OnSubmit != null) {
                        DialogData captured = data;
                        AddInputRow(frame.transform, data.InputHint, text => {
                            if (string.IsNullOrEmpty(text) || text.Trim().Length == 0) return;
                            render(captured.OnSubmit(text.Trim()));
                        });
                    }
                    LayoutRebuilder.ForceRebuildLayoutImmediate(rt);
                };
                render(pData);
            } catch (Exception e) {
                Main.LogError("生物学:显示对话失败 " + e);
            }
        }

        private static void AddChoiceButton(Transform pParent, string pText, Color? pTextColor, Action pAction) {
            GameObject btnObj = new GameObject("Choice", typeof(RectTransform), typeof(Image), typeof(Button),
                typeof(LayoutElement));
            btnObj.transform.SetParent(pParent, false);
            LayoutElement ble = btnObj.GetComponent<LayoutElement>();
            ble.minHeight = DS(32f); ble.preferredHeight = DS(32f); ble.flexibleHeight = 0f;
            Image btnImg = btnObj.GetComponent<Image>();
            btnImg.sprite = SpriteTextureLoader.getSprite("ui/special/button");
            if (btnImg.sprite != null) btnImg.type = Image.Type.Sliced;
            btnImg.color = new Color(0.25f, 0.2f, 0.35f, 0.95f);
            btnImg.raycastTarget = true;
            // 描边:每个选项一圈清晰边框
            Outline ol = btnObj.AddComponent<Outline>();
            ol.effectColor = new Color(0.55f, 0.5f, 0.7f, 0.9f);
            ol.effectDistance = new Vector2(DS(1.2f), DS(1.2f));

            // 裁剪层:超出按钮范围的文字被切掉,不换行也不溢出
            GameObject clip = new GameObject("Clip", typeof(RectTransform), typeof(RectMask2D));
            clip.transform.SetParent(btnObj.transform, false);
            RectTransform clrt = clip.GetComponent<RectTransform>();
            clrt.anchorMin = Vector2.zero; clrt.anchorMax = Vector2.one;
            clrt.offsetMin = new Vector2(DS(6f), 0f);
            clrt.offsetMax = new Vector2(-DS(6f), 0f);

            GameObject txtObj = new GameObject("Text", typeof(RectTransform), typeof(Text));
            txtObj.transform.SetParent(clip.transform, false);
            Text btnTxt = txtObj.GetComponent<Text>();
            btnTxt.font = LocalizedTextManager.current_font;
            btnTxt.fontSize = DF(13);
            btnTxt.color = pTextColor ?? new Color(0.95f, 0.9f, 1f);
            btnTxt.text = pText;
            btnTxt.alignment = TextAnchor.MiddleCenter;
            btnTxt.horizontalOverflow = HorizontalWrapMode.Overflow;
            btnTxt.verticalOverflow = VerticalWrapMode.Truncate;
            btnTxt.raycastTarget = false;
            RectTransform btrt = txtObj.GetComponent<RectTransform>();
            btrt.anchorMin = Vector2.zero; btrt.anchorMax = Vector2.one;
            btrt.offsetMin = Vector2.zero; btrt.offsetMax = Vector2.zero;

            Button btn = btnObj.GetComponent<Button>();
            btn.targetGraphic = btnImg;
            btn.transition = Selectable.Transition.ColorTint;
            btn.onClick.AddListener(() => { if (pAction != null) pAction(); });
        }

        // 自定义输入行:一个文本框 + 一个「说」按钮。回车或点按钮都会把内容交给 pOnSend。
        // 发送后清空并重新聚焦,方便连着打字聊天。
        private static void AddInputRow(Transform pParent, string pHint, Action<string> pOnSend) {
            GameObject row = new GameObject("InputRow", typeof(RectTransform), typeof(HorizontalLayoutGroup), typeof(LayoutElement));
            row.transform.SetParent(pParent, false);
            LayoutElement rle = row.GetComponent<LayoutElement>();
            rle.minHeight = DS(34f); rle.preferredHeight = DS(34f); rle.flexibleHeight = 0f;
            HorizontalLayoutGroup hlg = row.GetComponent<HorizontalLayoutGroup>();
            hlg.spacing = DS(5f);
            hlg.childControlWidth = true; hlg.childForceExpandWidth = false;
            hlg.childControlHeight = true; hlg.childForceExpandHeight = true;

            // 输入框
            GameObject fieldObj = new GameObject("Field", typeof(RectTransform), typeof(Image), typeof(InputField), typeof(LayoutElement));
            fieldObj.transform.SetParent(row.transform, false);
            LayoutElement fle = fieldObj.GetComponent<LayoutElement>();
            fle.flexibleWidth = 1f; fle.minWidth = DS(120f);
            Image fimg = fieldObj.GetComponent<Image>();
            Sprite fspr = SpriteTextureLoader.getSprite("ui/special/windowInnerSliced");
            if (fspr != null) { fimg.sprite = fspr; fimg.type = Image.Type.Sliced; }
            fimg.color = new Color(0.06f, 0.05f, 0.09f, 0.98f);
            fimg.raycastTarget = true;

            // 提示文字(占位)
            GameObject phObj = new GameObject("Placeholder", typeof(RectTransform), typeof(Text));
            phObj.transform.SetParent(fieldObj.transform, false);
            Text phTxt = phObj.GetComponent<Text>();
            phTxt.font = LocalizedTextManager.current_font;
            phTxt.fontSize = DF(13);
            phTxt.color = new Color(0.6f, 0.58f, 0.68f, 0.9f);
            phTxt.alignment = TextAnchor.MiddleLeft;
            phTxt.fontStyle = FontStyle.Italic;
            phTxt.horizontalOverflow = HorizontalWrapMode.Overflow;
            phTxt.verticalOverflow = VerticalWrapMode.Truncate;
            phTxt.raycastTarget = false;
            phTxt.text = pHint;
            RectTransform phrt = phObj.GetComponent<RectTransform>();
            phrt.anchorMin = Vector2.zero; phrt.anchorMax = Vector2.one;
            phrt.offsetMin = new Vector2(DS(8f), 0f); phrt.offsetMax = new Vector2(-DS(6f), 0f);

            // 实际文本
            GameObject vtObj = new GameObject("Text", typeof(RectTransform), typeof(Text));
            vtObj.transform.SetParent(fieldObj.transform, false);
            Text vtTxt = vtObj.GetComponent<Text>();
            vtTxt.font = LocalizedTextManager.current_font;
            vtTxt.fontSize = DF(13);
            vtTxt.color = new Color(0.95f, 0.9f, 1f);
            vtTxt.alignment = TextAnchor.MiddleLeft;
            vtTxt.supportRichText = false;
            vtTxt.horizontalOverflow = HorizontalWrapMode.Overflow;
            vtTxt.verticalOverflow = VerticalWrapMode.Truncate;
            vtTxt.raycastTarget = false;
            RectTransform vtrt = vtObj.GetComponent<RectTransform>();
            vtrt.anchorMin = Vector2.zero; vtrt.anchorMax = Vector2.one;
            vtrt.offsetMin = new Vector2(DS(8f), 0f); vtrt.offsetMax = new Vector2(-DS(6f), 0f);
            vtObj.AddComponent<RectMask2D>();

            InputField input = fieldObj.GetComponent<InputField>();
            input.textComponent = vtTxt;
            input.placeholder = phTxt;
            input.lineType = InputField.LineType.SingleLine;
            input.contentType = InputField.ContentType.Standard;
            input.characterLimit = 60;
            input.caretColor = Color.white;
            input.customCaretColor = true;
            input.selectionColor = new Color(0.35f, 0.55f, 0.85f, 0.75f);
            input.text = "";

            // 「说」按钮
            GameObject sendObj = new GameObject("Send", typeof(RectTransform), typeof(Image), typeof(Button), typeof(LayoutElement));
            sendObj.transform.SetParent(row.transform, false);
            LayoutElement sle = sendObj.GetComponent<LayoutElement>();
            sle.minWidth = DS(48f); sle.preferredWidth = DS(48f); sle.flexibleWidth = 0f;
            Image simg = sendObj.GetComponent<Image>();
            Sprite sspr = SpriteTextureLoader.getSprite("ui/special/button");
            if (sspr != null) { simg.sprite = sspr; simg.type = Image.Type.Sliced; }
            simg.color = new Color(0.28f, 0.22f, 0.4f, 0.98f);
            simg.raycastTarget = true;
            GameObject slObj = new GameObject("Label", typeof(RectTransform), typeof(Text));
            slObj.transform.SetParent(sendObj.transform, false);
            Text slTxt = slObj.GetComponent<Text>();
            slTxt.font = LocalizedTextManager.current_font;
            slTxt.fontSize = DF(13);
            slTxt.color = ChoiceContinue;
            slTxt.alignment = TextAnchor.MiddleCenter;
            slTxt.raycastTarget = false;
            slTxt.text = BioText.T("bio_dial_btn_send", "说");
            RectTransform slrt = slObj.GetComponent<RectTransform>();
            slrt.anchorMin = Vector2.zero; slrt.anchorMax = Vector2.one;
            slrt.offsetMin = Vector2.zero; slrt.offsetMax = Vector2.zero;

            Action fire = () => {
                string t = input.text;
                if (string.IsNullOrEmpty(t) || t.Trim().Length == 0) return;
                if (pOnSend != null) pOnSend(t);
            };
            Button sbtn = sendObj.GetComponent<Button>();
            sbtn.targetGraphic = simg;
            sbtn.transition = Selectable.Transition.ColorTint;
            sbtn.onClick.AddListener(() => fire());
            // 回车提交(按下 Enter 时 onEndEdit 会触发;点击别处失焦也会触发,故用按键判断只在回车时发送)
            input.onEndEdit.AddListener(_ => {
                if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter)) fire();
            });
            input.Select();
            input.ActivateInputField();
        }

        // ============================================================
        //  对话文本池   ——   想改台词直接改这里
        // ============================================================

        // ---- 攻略主界面开场白(按关系档:0陌生 / 1熟悉 / 2心动及以上)----
        private static readonly string[][] _relIntroFB = {
            new[] { // 0 陌生
                "他还有些怕你，紧张地站在原地。先试着拉近彼此的距离吧。",
                "他不太敢直视你的眼睛。多陪他说说话，慢慢来。",
                "他对你充满敬畏，也带着几分惧意。",
            },
            new[] { // 1 熟悉
                "他对你已不再陌生，见到你会微微点头致意。",
                "他的神情放松了许多，似乎开始信任你了。",
                "他看你的眼神里，多了一丝亲近。",
            },
            new[] { // 2 心动及以上
                "他望着你，脸颊微红，似乎在等待着什么。你想做些什么？",
                "他的目光追随着你，眼里盛满了藏不住的情意。",
                "他轻轻靠近，只要你开口，他愿意为你做任何事。",
            },
        };
        private static string[][] RelationIntro => BioDialogueLocalizer.TierPool("bio_dial_intro", _relIntroFB);

        // ---- 交谈子菜单开场白 ----
        private static readonly string[] _chatMenuIntroFB = {
            "你想和他聊些什么？",
            "他安静地等着你开口。",
            "四目相对，你决定说点什么。",
        };
        private static string[] ChatMenuIntro => BioDialogueLocalizer.Pool("bio_dial_menu", _chatMenuIntroFB);

        // ---- 寒暄 ----
        private static readonly string[] _chatGreetFB = {
            "你与他攀谈起来，问候他的近况。",
            "你聊起最近的天气与收成，他渐渐放松下来。",
            "你说起世界各地的见闻，他听得入神。",
            "你随口问起他的名字和家人，气氛缓和了不少。",
            "你问他今天过得怎么样。",
        };
        public static string[] ChatGreet => BioDialogueLocalizer.Pool("bio_dial_greet", _chatGreetFB);
        private static readonly string[] _chatGreetReplyFB = {
            "「能与神明说上话，是我莫大的荣幸。」",
            "「您……愿意听我说这些吗？」",
            "「和您聊天，我心里踏实多了。」",
            "「今天过得还算安稳，谢谢您的关照。」",
            "「有您在，日子似乎都有了盼头。」",
        };
        public static string[] ChatGreetReply => BioDialogueLocalizer.Pool("bio_dial_greet_r", _chatGreetReplyFB);

        // ---- 赞美 ----
        private static readonly string[] _chatPraiseFB = {
            "你称赞他的勇敢与勤勉。",
            "你夸奖他把日子过得井井有条。",
            "你告诉他，他在你眼中格外与众不同。",
            "你轻声赞美了他的容貌。",
            "你说他的笑容很好看。",
        };
        public static string[] ChatPraise => BioDialogueLocalizer.Pool("bio_dial_praise", _chatPraiseFB);
        private static readonly string[] _chatPraiseReplyFB = {
            "「您……您这么说，我都不好意思了。」",
            "「被神明夸奖，我一整天都会有干劲。」",
            "「真的吗？我会记住这句话的。」",
            "「脸都红了……谢谢您。」",
            "「我、我会更加努力的！」",
        };
        public static string[] ChatPraiseReply => BioDialogueLocalizer.Pool("bio_dial_praise_r", _chatPraiseReplyFB);

        // ---- 安抚 ----
        private static readonly string[] _chatComfortFB = {
            "你安抚他不必害怕，你会守护这片土地。",
            "你承诺会庇佑他和他的族人。",
            "你轻轻拍了拍他的肩，让他安心。",
            "你告诉他，无论发生什么你都会在。",
            "你温声说，有你在，一切都会好起来。",
        };
        public static string[] ChatComfort => BioDialogueLocalizer.Pool("bio_dial_comfort", _chatComfortFB);
        private static readonly string[] _chatComfortReplyFB = {
            "「有您这句话，我什么都不怕了。」",
            "「我愿意追随您，直到最后。」",
            "「谢谢您……真的。」",
            "「我会把您的恩情告诉所有人。」",
            "「心里的石头，一下子落地了。」",
        };
        public static string[] ChatComfortReply => BioDialogueLocalizer.Pool("bio_dial_comfort_r", _chatComfortReplyFB);

        // ---- 送礼物 ----
        private static readonly string[] _chatGiftFB = {
            "你变出一束鲜花递给他。",
            "你赐予他一件精致的小饰品。",
            "你为他准备了一顿丰盛的食物。",
            "你送给他一枚温润的宝石。",
        };
        public static string[] ChatGift => BioDialogueLocalizer.Pool("bio_dial_gift", _chatGiftFB);
        private static readonly string[] _chatGiftReplyFB = {
            "「这……这是给我的吗？我从没收过这么好的东西！」",
            "「我会好好珍藏它的，谢谢您！」",
            "「太漂亮了……我都舍不得用了。」",
            "「您对我真好……」他小心翼翼地捧着礼物。",
        };
        public static string[] ChatGiftReply => BioDialogueLocalizer.Pool("bio_dial_gift_r", _chatGiftReplyFB);

        // ---- 倾听心事 ----
        private static readonly string[] _chatListenFB = {
            "你耐心地听他讲起过往的经历。",
            "你问起他心底的烦恼，静静听着。",
            "你陪他坐下，听他倾诉埋在心里的话。",
        };
        public static string[] ChatListen => BioDialogueLocalizer.Pool("bio_dial_listen", _chatListenFB);
        private static readonly string[] _chatListenReplyFB = {
            "「这些话……我从没对别人说过。」",
            "「谢谢您愿意听我说这么多。」",
            "「和您说完，心里轻松多了。」",
            "「原来被人倾听，是这样温暖的感觉。」",
        };
        public static string[] ChatListenReply => BioDialogueLocalizer.Pool("bio_dial_listen_r", _chatListenReplyFB);

        // ---- 赐予祝福 ----
        private static readonly string[] _chatBlessFB = {
            "你为他献上一段祝福，暖流淌过他的全身。",
            "你以神力抚平他的疲惫。",
            "你赐予他一缕好运。",
            "你在他额头点下一道祝福的印记。",
        };
        public static string[] ChatBless => BioDialogueLocalizer.Pool("bio_dial_bless", _chatBlessFB);
        private static readonly string[] _chatBlessReplyFB = {
            "「这温暖……是神的恩泽吗？」",
            "「我感到浑身充满了力量！」",
            "「我这辈子都不会忘记这一刻。」",
            "「能得到神的祝福，我别无所求了。」",
        };
        public static string[] ChatBlessReply => BioDialogueLocalizer.Pool("bio_dial_bless_r", _chatBlessReplyFB);

        // ---- 冷淡反应(好感低时偶发,加好感减半)----
        private static readonly string[] _chatColdReplyFB = {
            "他有些拘谨，只是礼貌地点了点头。",
            "他似乎还不太习惯与神明相处，答得很简短。",
            "他低着头，一时不知该说什么。",
            "他有些戒备，回应显得很谨慎。",
        };
        public static string[] ChatColdReply => BioDialogueLocalizer.Pool("bio_dial_cold_r", _chatColdReplyFB);

        // ---- 亲密开场(按性别分三套) ----
        private static readonly string[] _intimateOpenMFb = {
            "两人脱光了衣服纠缠在一起,他的身体已经硬了,等着你来享用……",
            "他喘着粗气靠过来,主动分开了腿……",
            "他趴在你面前翘起屁股,回头用渴望的眼神看着你……",
            "他含住你的肉棒,用舌头灵巧地舔舐着……",
        };
        public static string[] IntimateOpenM => BioDialogueLocalizer.Pool("bio_dial_open_m", _intimateOpenMFb);
        private static readonly string[] _intimateOpenFFb = {
            "两人脱光了衣服纠缠在一起,她的身体已经湿了,等着你来进入……",
            "她喘着粗气靠过来,主动分开了双腿……",
            "她趴在你面前翘起屁股,回头用渴望的眼神看着你……",
            "她含住你的肉棒,用舌头灵巧地舔舐着……",
        };
        public static string[] IntimateOpenF => BioDialogueLocalizer.Pool("bio_dial_open_f", _intimateOpenFFb);
        private static readonly string[] _intimateOpenXFb = {
            "两人脱光了衣服纠缠在一起,他胯下的肉棒已经硬了,小穴也流水了……",
            "他喘着粗气靠过来,主动分开了双腿,露出勃起的阴茎和湿润的小穴……",
            "他趴在你面前翘起屁股,回头用渴望的眼神看着你……",
            "他含住你的肉棒,用舌头灵巧地舔舐着,自己的阴茎也硬得发痛……",
        };
        public static string[] IntimateOpenX => BioDialogueLocalizer.Pool("bio_dial_open_x", _intimateOpenXFb);

        // ---- 亲密-继续-阴道(按性别分三套) ----
        private static readonly string[] _vaginaContinueReplyMFb = {
            "「嗯啊……再深一点……」他夹紧了你的肉棒,呻吟着扭动腰肢。",
            "「唔……好涨……」他咬着嘴唇忍耐,后穴却贪婪地绞紧不放。",
            "「射……射进来……」他痉挛着高潮,精液喷了一床,浑身颤抖地缠住你。",
            "他趴在你身上喘息,屁股还不自觉地往后顶。",
            "他的后穴一缩一缩地吮吸着你,淫水顺着大腿流了下来……",
        };
        public static string[] VaginaContinueReplyM => BioDialogueLocalizer.Pool("bio_dial_vcont_m", _vaginaContinueReplyMFb);
        private static readonly string[] _vaginaContinueReplyFFb = {
            "「啊……再深一点……」她夹紧了你的肉棒,呻吟着扭动腰肢。",
            "「唔嗯……好涨……」她咬着嘴唇忍耐,穴肉却贪婪地绞紧不放。",
            "「射……射给我……」她痉挛着高潮,浑身颤抖地缠住你。",
            "她趴在你身上喘息,下体还紧紧含着不肯松开。",
            "她的小穴一缩一缩地吮吸着你,淫水顺着大腿流了下来……",
        };
        public static string[] VaginaContinueReplyF => BioDialogueLocalizer.Pool("bio_dial_vcont_f", _vaginaContinueReplyFFb);
        private static readonly string[] _vaginaContinueReplyXFb = {
            "「啊……后面好涨……前面也要……」他同时被你的肉棒和手照顾着,淫叫连连。",
            "「唔嗯……小穴好爽……阴茎也被握着……」他咬着嘴唇,身体前后都在颤抖。",
            "「射……射出来……全部射进小穴里……」他痉挛着高潮,精液和爱液一起喷了出来。",
            "他趴在你身上喘息,下体还紧紧含着你的肉棒,阴茎还硬挺挺的。",
            "他的小穴一缩一缩地吮吸着你,淫水顺着大腿和阴茎一起流了下来……",
        };
        public static string[] VaginaContinueReplyX => BioDialogueLocalizer.Pool("bio_dial_vcont_x", _vaginaContinueReplyXFb);
        // ---- 亲密-继续-肛门(按性别分三套) ----
        private static readonly string[] _anusContinueReplyMFb = {
            "「嗯啊……再深一点……」他的后穴紧紧绞着你的肉棒,呻吟着扭动腰肢。",
            "「唔……后穴好涨……」他咬着嘴唇忍耐,后穴却贪婪地绞紧不放。",
            "「射……射进来……」他痉挛着高潮,精液喷了一床,浑身颤抖地缠住你。",
            "他趴在你身上喘息,屁股还不自觉地往后顶。",
            "他的后穴一缩一缩地吮吸着你,淫水顺着大腿流了下来……",
        };
        public static string[] AnusContinueReplyM => BioDialogueLocalizer.Pool("bio_dial_acont_m", _anusContinueReplyMFb);
        private static readonly string[] _anusContinueReplyFFb = {
            "「嗯啊……再深一点……」她的后穴紧紧绞着你的肉棒,呻吟着扭动腰肢。",
            "「唔……后穴好涨……」她咬着嘴唇忍耐,后穴却贪婪地绞紧不放。",
            "「射……射给我……」她痉挛着高潮,浑身颤抖地缠住你。",
            "她趴在你身上喘息,后穴还紧紧含着不肯松开。",
            "她的后穴一缩一缩地吮吸着你,淫水顺着大腿流了下来……",
        };
        public static string[] AnusContinueReplyF => BioDialogueLocalizer.Pool("bio_dial_acont_f", _anusContinueReplyFFb);
        private static readonly string[] _anusContinueReplyXFb = {
            "「嗯啊……后穴好涨……前面也要……」他同时被你的肉棒和手照顾着,淫叫连连。",
            "「唔嗯……后穴好爽……阴茎也被握着……」他咬着嘴唇,身体前后都在颤抖。",
            "「射……射出来……全部射进后穴里……」他痉挛着高潮,精液和爱液一起喷了出来。",
            "他趴在你身上喘息,后穴还紧紧含着你的肉棒,阴茎还硬挺挺的。",
            "他的后穴一缩一缩地吮吸着你,淫水顺着大腿和阴茎一起流了下来……",
        };
        public static string[] AnusContinueReplyX => BioDialogueLocalizer.Pool("bio_dial_acont_x", _anusContinueReplyXFb);
        // ---- 亲密-继续-阴茎(按性别分三套) ----
        private static readonly string[] _penisContinueReplyMFb = {
            "「嗯啊……再用力一点……」他的阴茎在你手中跳动,呻吟着弓起腰肢。",
            "「唔……要射了……」他咬着嘴唇忍耐,精液却不由自主地涌了出来。",
            "「射……射出来……」他痉挛着高潮,精液喷了一床,浑身颤抖地瘫软下去。",
            "他趴在你身上喘息,阴茎还不自觉地在你手中跳动。",
            "他的阴茎一跳一跳地射出精液,淫水顺着大腿流了下来……",
        };
        public static string[] PenisContinueReplyM => BioDialogueLocalizer.Pool("bio_dial_pcont_m", _penisContinueReplyMFb);
        private static readonly string[] _penisContinueReplyFFb = {
            "「嗯啊……再用力一点……」他的阴茎在你手中跳动,呻吟着弓起腰肢。",
            "「唔……要射了……」他咬着嘴唇忍耐,精液却不由自主地涌了出来。",
            "「射……射给我……」他痉挛着高潮,精液喷了一床,浑身颤抖地瘫软下去。",
            "他趴在你身上喘息,阴茎还不自觉地在你手中跳动。",
            "他的阴茎一跳一跳地射出精液,淫水顺着大腿流了下来……",
        };
        public static string[] PenisContinueReplyF => BioDialogueLocalizer.Pool("bio_dial_pcont_f", _penisContinueReplyFFb);
        private static readonly string[] _penisContinueReplyXFb = {
            "「嗯啊……前面好爽……后面也要……」他的阴茎在你手中跳动,小穴也不由自主地流水。",
            "「唔……要射了……小穴也要……」他咬着嘴唇忍耐,精液和淫水一起涌了出来。",
            "「射……射出来……全部射出来……」他痉挛着高潮,精液和爱液一起喷了出来。",
            "他趴在你身上喘息,阴茎在你手中跳动,小穴也一缩一缩的。",
            "他的阴茎一跳一跳地射出精液,小穴也流水了……",
        };
        public static string[] PenisContinueReplyX => BioDialogueLocalizer.Pool("bio_dial_pcont_x", _penisContinueReplyXFb);
        // ---- 亲密-继续(旧名保留兼容) ----
        public static readonly string[] IntimateContinueReplyM = VaginaContinueReplyM;
        public static readonly string[] IntimateContinueReplyF = VaginaContinueReplyF;
        public static readonly string[] IntimateContinueReplyX = VaginaContinueReplyX;

        // ---- 亲密-温柔亲昵(按性别分三套) ----
        private static readonly string[] _intimateTenderReplyMFb = {
            "你含住他的乳头轻轻啃咬,他浑身一颤,抓住了你的肩膀。",
            "你的手滑进他的腿间,握住他硬挺的肉棒轻轻套弄,他闷哼一声。",
            "你吻遍他的全身,他弓起腰,手指插进你的头发里。",
            "你揉弄着他的臀瓣,他扭动着腰,发出低沉的喘息。",
        };
        public static string[] IntimateTenderReplyM => BioDialogueLocalizer.Pool("bio_dial_tender_m", _intimateTenderReplyMFb);
        private static readonly string[] _intimateTenderReplyFFb = {
            "你含住她的乳头轻轻舔弄,她浑身一颤,呻吟出声。",
            "你的手滑进她的腿间,她害羞地夹紧了腿,却在你的挑逗下慢慢打开。",
            "你吻遍她的全身,她弓起腰,手指插进你的头发里。",
            "你揉弄着她的臀瓣,她扭动着腰,发出甜腻的喘息。",
        };
        public static string[] IntimateTenderReplyF => BioDialogueLocalizer.Pool("bio_dial_tender_f", _intimateTenderReplyFFb);
        private static readonly string[] _intimateTenderReplyXFb = {
            "你含住他的乳头轻轻啃咬,他浑身一颤,胯下的阴茎也跟着跳了一下。",
            "你的手滑进他的腿间,一边套弄他的阴茎一边用手指玩弄他的小穴,他淫叫出声。",
            "你吻遍他的全身,他弓起腰,手指插进你的头发里,下体不停地往你手上蹭。",
            "你揉弄着他的臀瓣,他扭动着腰,前后穴一起流水,发出甜腻的喘息。",
        };
        public static string[] IntimateTenderReplyX => BioDialogueLocalizer.Pool("bio_dial_tender_x", _intimateTenderReplyXFb);

        // ---- 亲密-聊天(按性别分三套) ----
        private static readonly string[] _intimateChatReplyMFb = {
            "你们赤裸相拥,他小声说:「……还想要……」",
            "他趴在你胸口,手指在你身上画圈:「……下次能不能……」",
            "你们相视而笑,他凑到你耳边说了句悄悄话,自己先红了脸。",
            "他靠在你肩上,手却不老实地摸向你的下体。",
        };
        public static string[] IntimateChatReplyM => BioDialogueLocalizer.Pool("bio_dial_intchat_m", _intimateChatReplyMFb);
        private static readonly string[] _intimateChatReplyFFb = {
            "你们赤裸相拥,她小声说:「……还想要……」",
            "她趴在你胸口,手指在你身上画圈:「……下次能不能……」",
            "你们相视而笑,她凑到你耳边说了句悄悄话,自己先红了脸。",
            "她靠在你肩上,手却不老实地摸向你的下体。",
        };
        public static string[] IntimateChatReplyF => BioDialogueLocalizer.Pool("bio_dial_intchat_f", _intimateChatReplyFFb);
        private static readonly string[] _intimateChatReplyXFb = {
            "你们赤裸相拥,他小声说:「……后面还想要……前面也想要……」",
            "他趴在你胸口,手指在你身上画圈,另一只手不自觉地撸动自己的阴茎。",
            "你们相视而笑,他凑到你耳边说了句悄悄话,自己先红了脸。",
            "他靠在你肩上,手却不老实地摸向你的下体,自己的阴茎也硬邦邦地蹭着你的腿。",
        };
        public static string[] IntimateChatReplyX => BioDialogueLocalizer.Pool("bio_dial_intchat_x", _intimateChatReplyXFb);

        // ---- 亲密-停下(按性别分三套) ----
        private static readonly string[] _intimateStopReplyMFb = {
            "你退了出来,他挽留地抓住你的手,眼里满是不舍。",
            "「这么快就……好吧……」他舔了舔嘴唇,意犹未尽。",
            "你为他擦去身上的汗水,他满足地蹭了蹭你的掌心。",
            "「下次……要更久一点哦……」他红着脸整理凌乱的头发。",
        };
        public static string[] IntimateStopReplyM => BioDialogueLocalizer.Pool("bio_dial_intstop_m", _intimateStopReplyMFb);
        private static readonly string[] _intimateStopReplyFFb = {
            "你退了出来,她挽留地抓住你的手,眼里满是不舍。",
            "「这么快就……好吧……」她舔了舔嘴唇,意犹未尽。",
            "你为她擦去身上的汗水,她满足地蹭了蹭你的掌心。",
            "「下次……要更久一点哦……」她红着脸整理凌乱的头发。",
        };
        public static string[] IntimateStopReplyF => BioDialogueLocalizer.Pool("bio_dial_intstop_f", _intimateStopReplyFFb);
        private static readonly string[] _intimateStopReplyXFb = {
            "你退了出来,他挽留地抓住你的手,眼里满是不舍,下体还湿漉漉的。",
            "「这么快就……好吧……」他舔了舔嘴唇,意犹未尽,阴茎还不甘心地挺立着。",
            "你为他擦去身上的汗水和淫液,他满足地蹭了蹭你的掌心。",
            "「下次……后面和前面都要满足哦……」他红着脸整理凌乱的头发。",
        };
        public static string[] IntimateStopReplyX => BioDialogueLocalizer.Pool("bio_dial_intstop_x", _intimateStopReplyXFb);

        // ---- 胸部专属台词(按性别分三套) ----
        private static readonly string[] _chestContinueReplyMFb = {
            "「嗯啊……乳头好敏感……」他弓起腰,乳尖在你嘴里硬成了小珠子。",
            "你用力揉捏他的胸肌,他喘着气把你的手按在胸口不让停。",
            "「再舔……再用力一点……」他捧着你的头,把你的脸按向自己的胸。",
            "他的乳头被你舔得又红又肿,他却还嫌不够地往你嘴里送。",
        };
        public static string[] ChestContinueReplyM => BioDialogueLocalizer.Pool("bio_dial_ccont_m", _chestContinueReplyMFb);
        private static readonly string[] _chestContinueReplyFFb = {
            "「嗯啊……乳头好敏感……」她弓起腰,乳尖在你嘴里硬成了小珠子。",
            "你用力揉捏她的乳房,她喘着气把你的手按在胸口不让停。",
            "「再舔……再用力一点……」她捧着你的头,把你的脸按向自己的胸。",
            "她的乳头被你舔得又红又肿,她却还嫌不够地往你嘴里送。",
        };
        public static string[] ChestContinueReplyF => BioDialogueLocalizer.Pool("bio_dial_ccont_f", _chestContinueReplyFFb);
        private static readonly string[] _chestContinueReplyXFb = {
            "「嗯啊……乳头好敏感……」他弓起腰,乳尖在你嘴里硬成了小珠子,胯下的阴茎也跟着跳了一下。",
            "你用力揉捏他的乳房,他喘着气把你的手按在胸口不让停,阴茎在你腿上蹭来蹭去。",
            "「再舔……再用力一点……」他捧着你的头,把你的脸按向自己的胸,腰不停地往前顶。",
            "他的乳头被你舔得又红又肿,他却还嫌不够地往你嘴里送,下体也硬得发痛。",
        };
        public static string[] ChestContinueReplyX => BioDialogueLocalizer.Pool("bio_dial_ccont_x", _chestContinueReplyXFb);
        private static readonly string[] _chestTenderReplyMFb = {
            "你含住他的乳头轻轻啃咬,他浑身一颤,抓住了你的肩膀。",
            "你的手指在他乳尖上画圈,他呼吸越来越重,胸前两点都硬了起来。",
            "你用舌头绕着他的乳晕打转,他咬着嘴唇忍耐,身体却诚实地迎合。",
            "你把脸埋进他的胸肌里,他不好意思地绷紧了身体,却没推开你。",
        };
        public static string[] ChestTenderReplyM => BioDialogueLocalizer.Pool("bio_dial_ctend_m", _chestTenderReplyMFb);
        private static readonly string[] _chestTenderReplyFFb = {
            "你含住她的乳头轻轻啃咬,她浑身一颤,抓住了你的肩膀。",
            "你的手指在她乳尖上画圈,她呼吸越来越重,胸前两点都硬了起来。",
            "你用舌头绕着她的乳晕打转,她咬着嘴唇忍耐,身体却诚实地迎合。",
            "你把脸埋进她的乳沟,她羞红了脸,却主动把胸挺得更高。",
        };
        public static string[] ChestTenderReplyF => BioDialogueLocalizer.Pool("bio_dial_ctend_f", _chestTenderReplyFFb);
        private static readonly string[] _chestTenderReplyXFb = {
            "你含住他的乳头轻轻啃咬,他浑身一颤,抓住了你的肩膀,胯下的阴茎也硬了起来。",
            "你的手指在他乳尖上画圈,他呼吸越来越重,胸前两点都硬了起来,阴茎也跟着一跳一跳。",
            "你用舌头绕着他的乳晕打转,他咬着嘴唇忍耐,身体却诚实地迎合,下体不停地往你腿上蹭。",
            "你把脸埋进他的乳沟,他羞红了脸,却主动把胸挺得更高,阴茎也硬邦邦地顶着你的肚子。",
        };
        public static string[] ChestTenderReplyX => BioDialogueLocalizer.Pool("bio_dial_ctend_x", _chestTenderReplyXFb);
        private static readonly string[] _chestChatReplyMFb = {
            "你一边揉着他的胸肌一边听他说话,他声音越来越小,脸越来越红。",
            "「别……别揉了……我说不下去了……」他按住你的手,却没真的推开。",
            "你用手指弹了弹他的乳头,他浑身一激灵,嗔怪地瞪了你一眼。",
            "他靠在你身上,你的手在他胸前漫不经心地游走,他渐渐心不在焉。",
        };
        public static string[] ChestChatReplyM => BioDialogueLocalizer.Pool("bio_dial_cchat_m", _chestChatReplyMFb);
        private static readonly string[] _chestChatReplyFFb = {
            "你一边揉着她的胸一边听她说话,她声音越来越小,脸越来越红。",
            "「别……别揉了……我说不下去了……」她按住你的手,却没真的推开。",
            "你用手指弹了弹她的乳头,她浑身一激灵,嗔怪地瞪了你一眼。",
            "她靠在你身上,你的手在她胸前漫不经心地游走,她渐渐心不在焉。",
        };
        public static string[] ChestChatReplyF => BioDialogueLocalizer.Pool("bio_dial_cchat_f", _chestChatReplyFFb);
        private static readonly string[] _chestChatReplyXFb = {
            "你一边揉着他的胸一边听他说话,他声音越来越小,脸越来越红,阴茎也跟着硬了。",
            "「别……别揉了……我说不下去了……」他按住你的手,却没真的推开,腰还不自觉地往前顶。",
            "你用手指弹了弹他的乳头,他浑身一激灵,嗔怪地瞪了你一眼,下体也跟着跳了一下。",
            "他靠在你身上,你的手在他胸前漫不经心地游走,他渐渐心不在焉,手不自觉地摸向自己的阴茎。",
        };
        public static string[] ChestChatReplyX => BioDialogueLocalizer.Pool("bio_dial_cchat_x", _chestChatReplyXFb);
        private static readonly string[] _chestStopReplyMFb = {
            "你松开手,他低头看了看自己被揉得红肿的胸口,脸红到了耳根。",
            "「这就……不摸了吗？」他拉起你的手放回自己的胸上。",
            "你为他拉好衣襟,他低头整理时,乳头还不甘心地挺立着。",
            "「被你弄得……好痒……」他揉了揉自己的胸口,眼神迷离。",
        };
        public static string[] ChestStopReplyM => BioDialogueLocalizer.Pool("bio_dial_cstop_m", _chestStopReplyMFb);
        private static readonly string[] _chestStopReplyFFb = {
            "你松开手,她低头看了看自己被揉得红肿的胸口,脸红到了耳根。",
            "「这就……不摸了吗？」她拉起你的手放回自己的胸上。",
            "你为她拉好衣襟,她低头整理时,乳头还不甘心地挺立着。",
            "「被你弄得……好痒……」她揉了揉自己的胸口,眼神迷离。",
        };
        public static string[] ChestStopReplyF => BioDialogueLocalizer.Pool("bio_dial_cstop_f", _chestStopReplyFFb);
        private static readonly string[] _chestStopReplyXFb = {
            "你松开手,他低头看了看自己被揉得红肿的胸口和硬挺的阴茎,脸红到了耳根。",
            "「这就……不摸了吗？」他拉起你的手放回自己的胸上,另一只手不自觉地握住了自己的阴茎。",
            "你为他拉好衣襟,他低头整理时,乳头和阴茎都不甘心地挺立着。",
            "「被你弄得……好痒……」他揉了揉自己的胸口和胯下,眼神迷离。",
        };
        public static string[] ChestStopReplyX => BioDialogueLocalizer.Pool("bio_dial_cstop_x", _chestStopReplyXFb);
        // ---- 胸部硬来/强迫(按性别分三套) ----
        private static readonly string[] _chestReluctReplyMFb = {
            "你强行揉捏他的胸肌,他痛得闷哼一声,身体本能地弓了起来。",
            "他被你捏得乳头发红,咬着嘴唇不让自己叫出声。",
        };
        public static string[] ChestReluctReplyM => BioDialogueLocalizer.Pool("bio_dial_crel_m", _chestReluctReplyMFb);
        private static readonly string[] _chestReluctReplyFFb = {
            "你强行揉捏她的乳房,她痛得闷哼一声,身体本能地弓了起来。",
            "她被你捏得乳头发红,咬着嘴唇不让自己叫出声。",
        };
        public static string[] ChestReluctReplyF => BioDialogueLocalizer.Pool("bio_dial_crel_f", _chestReluctReplyFFb);
        private static readonly string[] _chestReluctReplyXFb = {
            "你强行揉捏他的乳房,他痛得闷哼一声,乳头却不受控制地硬了起来。",
            "他被你捏得乳头发红,咬着嘴唇不让自己叫出声,阴茎也跟着硬了。",
        };
        public static string[] ChestReluctReplyX => BioDialogueLocalizer.Pool("bio_dial_crel_x", _chestReluctReplyXFb);
        private static readonly string[] _chestForcedReplyMFb = {
            "你低头狠狠咬住他的乳头用力吸吮,他痛得尖叫,却挣不开你的嘴。",
            "你牙齿衔住他的乳头拉扯,他浑身发抖,眼泪夺眶而出。",
        };
        public static string[] ChestForcedReplyM => BioDialogueLocalizer.Pool("bio_dial_cfor_m", _chestForcedReplyMFb);
        private static readonly string[] _chestForcedReplyFFb = {
            "你低头狠狠咬住她的乳头用力吸吮,她痛得尖叫,却挣不开你的嘴。",
            "你牙齿衔住她的乳头拉扯,她浑身发抖,眼泪夺眶而出。",
        };
        public static string[] ChestForcedReplyF => BioDialogueLocalizer.Pool("bio_dial_cfor_f", _chestForcedReplyFFb);
        private static readonly string[] _chestForcedReplyXFb = {
            "你低头狠狠咬住他的乳头用力吸吮,他痛得尖叫,乳头却被吸得硬挺起来。",
            "你牙齿衔住他的乳头拉扯,他浑身发抖,眼泪和淫水一起涌了出来。",
        };
        public static string[] ChestForcedReplyX => BioDialogueLocalizer.Pool("bio_dial_cfor_x", _chestForcedReplyXFb);

        // ---- 强化器官反馈(对方感激)----
        private static readonly string[] _strengthenReplyFB = {
            "他感到身体涌起一股力量，惊喜地看向你。",
            "「我……我变得更强壮了！谢谢您，神明！」",
            "他活动了一下身体，眼里满是感激。",
            "「这份力量……我一定不会辜负您！」",
        };
        public static string[] StrengthenReply => BioDialogueLocalizer.Pool("bio_dial_str", _strengthenReplyFB);
        // ---- 弱化器官反馈(对方痛苦/恐惧)----
        private static readonly string[] _weakenReplyFB = {
            "他痛苦地弯下腰，不明白自己做错了什么。",
            "「呃……身体好难受……您为什么要这样？」",
            "他惊恐地看着你，身体不受控制地颤抖。",
            "「求您……住手……好痛……」",
        };
        public static string[] WeakenReply => BioDialogueLocalizer.Pool("bio_dial_wk", _weakenReplyFB);
        // ---- 删除器官反馈(对方惊恐)----
        private static readonly string[] _removeReplyFB = {
            "他发出一声惨叫，难以置信地看着自己的身体。",
            "「不……这不可能……」他的眼神彻底黯淡了。",
            "剧痛让他几乎昏厥，对你的敬畏化作了恐惧。",
            "「为什么……我做错了什么……」",
        };
        public static string[] RemoveReply => BioDialogueLocalizer.Pool("bio_dial_rm", _removeReplyFB);

        // ---- 未成年保护 ----
        private static readonly string[] _childProtectBoyFB = {
            "你这混蛋，该出奇兵了！以雷霆击碎黑暗！",
            "该电一电了！",
            "对未成年出手？等着被雷劈吧！",
        };
        public static string[] ChildProtectBoy => BioDialogueLocalizer.Pool("bio_dial_prot", _childProtectBoyFB);
        private static readonly string[] _childProtectGirlFB = {
            "你这混蛋，该出奇兵了！以雷霆击碎黑暗！",
            "该电一电了！",
            "对未成年出手？等着被雷劈吧！",
        };
        public static string[] ChildProtectGirl => BioDialogueLocalizer.Pool("bio_dial_prot", _childProtectGirlFB);

        // ============================================================
        //  体表触碰   ——   抚摸/亲吻的文本
        // ============================================================
        // 部位口语名(用于"抚摸他的XX")。没列的会回退到器官本地化名。
        private static readonly Dictionary<string, string> _partNamesFB = new Dictionary<string, string> {
            { "head", "脸蛋" }, { "hair", "头发" }, { "fur", "皮毛" },
            { "scale", "鳞片" }, { "feather", "羽毛" }, { "ear", "耳朵" },
            { "nose", "鼻尖" }, { "eye_l", "眼睛" }, { "eye_r", "眼睛" },
            { "neck", "脖颈" }, { "shoulder", "肩膀" }, { "arm", "手臂" },
            { "hand", "手" }, { "leg", "腿" }, { "foot", "脚" },
            { "skin", "肌肤" }, { "tail", "尾巴" }, { "horn", "角" },
            { "wing_l", "翅膀" }, { "wing_r", "翅膀" }, { "beak", "喙" },
        };
        private static Dictionary<string, string> PartNames => BioDialogueLocalizer.Dict("bio_dial_part", _partNamesFB);

        // 抚摸动作描写(按器官)。没列的用通用句"你轻轻抚摸着他的XX。"
        private static readonly Dictionary<string, string[]> _caressActionsFB = new Dictionary<string, string[]> {
            { "head", new[] {
                "你捧起他的脸蛋，用拇指轻轻摩挲。",
                "你捏了捏他软软的脸颊。",
                "你抚过他的脸庞，感受着他的体温。",
            } },
            { "hair", new[] {
                "你的手指穿过他的发丝，轻轻梳理。",
                "你揉了揉他的头发，弄乱又抚平。",
                "你把他额前的碎发别到耳后。",
            } },
            { "ear", new[] {
                "你捏了捏他的耳垂，他耳朵一下子红了。",
                "你的指尖沿着他的耳廓轻轻描过。",
            } },
            { "neck", new[] {
                "你的手指划过他的脖颈，他微微颤了一下。",
                "你抚上他的颈侧，感到他的脉搏在跳。",
            } },
            { "hand", new[] {
                "你握住他的手，十指相扣。",
                "你把玩着他的手指，一根一根抚过。",
                "你把他的手贴在自己掌心，为他取暖。",
            } },
            { "arm", new[] {
                "你顺着他的手臂缓缓抚下。",
                "你轻轻挽住他的胳膊。",
            } },
            { "shoulder", new[] {
                "你揉了揉他的肩膀，替他放松。",
                "你把手搭在他肩上，轻轻按压。",
            } },
            { "skin", new[] {
                "你的指尖在他肌肤上轻轻游走。",
                "你抚过他细腻的皮肤，他微微战栗。",
            } },
            { "tail", new[] {
                "你顺着他的尾巴轻轻捋过，他浑身一激灵。",
                "你握住他的尾巴尖，逗弄般晃了晃。",
            } },
            { "wing_l", new[] { "你抚过他的羽翼，替他理顺了羽毛。" } },
            { "wing_r", new[] { "你抚过他的羽翼，替他理顺了羽毛。" } },
            { "horn", new[] { "你摸了摸他头顶的角，他不好意思地低下头。" } },
        };
        private static Dictionary<string, string[]> CaressActions => BioDialogueLocalizer.PoolDict("bio_dial_caress", _caressActionsFB);

        // 抚摸反应(按好感度分层:0陌生 / 1熟悉 / 2心动及以上)
        private static readonly string[][] _caressReplyFB = {
            new[] { // 0 陌生:紧张、羞怯
                "他浑身一僵，却没有躲开。",
                "「唔……神明大人,这……」他紧张得不敢动。",
                "他脸颊泛红,低着头任由你触碰。",
            },
            new[] { // 1 熟悉:害羞接受
                "他脸红了,却悄悄往你手心里靠了靠。",
                "「这样……有点痒。」他小声说,嘴角却带着笑。",
                "他放松下来,享受着你的触碰。",
            },
            new[] { // 2 心动及以上:主动亲昵
                "他眯起眼,像只满足的猫一样蹭了蹭你的手。",
                "「再多摸一会儿……好吗?」他依偎过来。",
                "他主动握住你的手,贴在自己脸上。",
            },
        };
        private static string[][] CaressReply => BioDialogueLocalizer.TierPool("bio_dial_caress_r", _caressReplyFB);

        // ============================================================
        //  越界举动文本:亲吻 / 舔腋下 / 舔脚
        //  三态:Welcome=你情我愿 / Reluctant=硬来 / Forced=强迫
        // ============================================================

        // ---- 亲吻 ----
        private static readonly string[] _kissReluctIntroFB = {
            "他察觉到你的意图,紧张地抿住了唇,别过脸去。",
            "他往后缩了缩,似乎还没准备好与你接吻。",
        };
        public static string[] KissReluctIntro => BioDialogueLocalizer.Pool("bio_dial_kiss_re", _kissReluctIntroFB);
        private static readonly string[] _kissWelcomeFB = {
            "你吻住他,他主动环住你的脖子,难舍难分……",
            "这个吻缠绵而深切,两人都有些气息不稳……(镜头淡出)",
            "他踮起脚迎合你的吻,把自己完全交托给你……",
        };
        public static string[] KissWelcome => BioDialogueLocalizer.Pool("bio_dial_kiss_ok", _kissWelcomeFB);
        private static readonly string[] _kissReluctantFB = {
            "你不顾他的躲闪吻了上去,他僵在原地,眼里闪过一丝委屈。",
            "唇瓣相触的瞬间他浑身一颤,勉强忍受着,却没有回应。",
            "他被你吻住,过了好久才平复,低声道:「您……何必如此。」",
        };
        public static string[] KissReluctant => BioDialogueLocalizer.Pool("bio_dial_kiss_r", _kissReluctantFB);
        private static readonly string[] _kissForcedFB = {
            "你掐住他的下巴强行吻上去,他惊恐地挣扎,泪水在眼眶里打转。",
            "他死死推着你的胸口,却挣不开,只能任由你夺走这个吻。",
            "「唔——!」他被强吻得喘不过气,眼神里满是恐惧与屈辱。",
        };
        public static string[] KissForced => BioDialogueLocalizer.Pool("bio_dial_kiss_f", _kissForcedFB);

        // ---- 舔腋下 ----
        private static readonly string[] _lickPitReluctIntroFB = {
            "他下意识夹紧了手臂,满脸通红:「这、这也太……」",
            "他慌忙想放下胳膊,不愿让你靠近那里。",
        };
        public static string[] LickPitReluctIntro => BioDialogueLocalizer.Pool("bio_dial_pit_re", _lickPitReluctIntroFB);
        private static readonly string[] _lickPitWelcomeFB = {
            "你埋首舔舐他的腋下,他痒得轻笑颤抖,却主动抬高了手臂。",
            "他羞得满脸通红,却顺从地由着你,发出细碎的喘息。",
            "「神明大人……那里很敏感的……」他半推半就地迎合着。",
        };
        public static string[] LickPitWelcome => BioDialogueLocalizer.Pool("bio_dial_pit_ok", _lickPitWelcomeFB);
        private static readonly string[] _lickPitReluctantFB = {
            "你按住他的手臂舔了下去,他浑身发抖,屈辱地咬紧了嘴唇。",
            "他被迫抬着手臂,满脸羞愤:「您为什么要这样羞辱我……」",
        };
        public static string[] LickPitReluctant => BioDialogueLocalizer.Pool("bio_dial_pit_r", _lickPitReluctantFB);
        private static readonly string[] _lickPitForcedFB = {
            "你强行架开他的手臂舔弄,他剧烈挣扎着,眼里涌出屈辱的泪。",
            "他被死死按住,发出绝望的呜咽,尊严被践踏得一干二净。",
        };
        public static string[] LickPitForced => BioDialogueLocalizer.Pool("bio_dial_pit_f", _lickPitForcedFB);

        // ---- 舔脚 ----
        private static readonly string[] _lickFootReluctIntroFB = {
            "他慌忙缩回脚:「不行不行,那里太脏了……」",
            "他难以置信地看着你,不愿把脚伸给你。",
        };
        public static string[] LickFootReluctIntro => BioDialogueLocalizer.Pool("bio_dial_foot_re", _lickFootReluctIntroFB);
        private static readonly string[] _lickFootWelcomeFB = {
            "你捧起他的脚轻轻舔舐,他痒得蜷起脚趾,脸红到了耳根。",
            "「您……堂堂神明,怎么能……」他嘴上推辞,却没有把脚收回。",
            "他任由你舔弄脚背,羞耻中竟生出一丝异样的悸动。",
        };
        public static string[] LickFootWelcome => BioDialogueLocalizer.Pool("bio_dial_foot_ok", _lickFootWelcomeFB);
        private static readonly string[] _lickFootReluctantFB = {
            "你抓住他的脚踝舔了下去,他羞得无地自容,却挣不开你的手。",
            "他别过头不敢看,屈辱地任由你摆布着他的脚。",
        };
        public static string[] LickFootReluctant => BioDialogueLocalizer.Pool("bio_dial_foot_r", _lickFootReluctantFB);
        private static readonly string[] _lickFootForcedFB = {
            "你死死攥住他的脚强行舔弄,他拼命挣扎,尊严碎了一地。",
            "他被按在地上,脚被强行抬起,屈辱的泪水夺眶而出。",
        };
        public static string[] LickFootForced => BioDialogueLocalizer.Pool("bio_dial_foot_f", _lickFootForcedFB);

        // ---- 未达门槛的性交(按性别分三套) ----
        private static readonly string[] _intimateReluctIntroMFb = {
            "他夹紧双腿,声音发颤:「不……不行……那里不可以……」",
            "他往后缩了缩,眼里含着泪:「求你……不要再逼我了……」",
        };
        public static string[] IntimateReluctIntroM => BioDialogueLocalizer.Pool("bio_dial_irel_m", _intimateReluctIntroMFb);
        private static readonly string[] _intimateReluctIntroFFb = {
            "她夹紧双腿,声音发颤:「不……不行……那里不可以……」",
            "她往后缩了缩,眼里含着泪:「求你……不要再逼我了……」",
        };
        public static string[] IntimateReluctIntroF => BioDialogueLocalizer.Pool("bio_dial_irel_f", _intimateReluctIntroFFb);
        private static readonly string[] _intimateReluctIntroXFb = {
            "他夹紧双腿,声音发颤:「不……不行……后面和前面都不可以……」",
            "他往后缩了缩,眼里含着泪:「求你……不要再逼我了……」",
        };
        public static string[] IntimateReluctIntroX => BioDialogueLocalizer.Pool("bio_dial_irel_x", _intimateReluctIntroXFb);
        // ---- 强制舔肛(按性别分三套) ----
        private static readonly string[] _forceAnusLickReplyMFb = {
            "你强行掰开他的臀瓣,舌头粗暴地舔上他的后庭,他痛得闷哼一声,后穴却不由自主地缩了一下。你尝到一股苦涩的味道,混着汗水的咸味。",
            "他挣扎着想合拢双腿,却被你死死按住。你的舌头在他后穴里搅动,他咬着枕头无声地哭泣,后穴却敏感地绞紧了你的舌头。",
        };
        public static string[] ForceAnusLickReplyM => BioDialogueLocalizer.Pool("bio_dial_falick_m", _forceAnusLickReplyMFb);
        private static readonly string[] _forceAnusLickReplyFFb = {
            "你强行掰开她的臀瓣,舌头粗暴地舔上她的后庭,她痛得闷哼一声,后穴却不由自主地缩了一下。你尝到一股苦涩的味道,混着汗水的咸味。",
            "她挣扎着想合拢双腿,却被你死死按住。你的舌头在她后穴里搅动,她咬着枕头无声地哭泣,后穴却敏感地绞紧了你的舌头。",
        };
        public static string[] ForceAnusLickReplyF => BioDialogueLocalizer.Pool("bio_dial_falick_f", _forceAnusLickReplyFFb);
        private static readonly string[] _forceAnusLickReplyXFb = {
            "你强行掰开他的臀瓣,舌头粗暴地舔上他的后庭,他痛得闷哼一声,后穴却不由自主地缩了一下。你尝到一股苦涩的味道,阴茎也跟着跳了一下。",
            "他挣扎着想合拢双腿,却被你死死按住。你的舌头在他后穴里搅动,他咬着枕头无声地哭泣,后穴却敏感地绞紧了你的舌头,阴茎也硬了起来。",
        };
        public static string[] ForceAnusLickReplyX => BioDialogueLocalizer.Pool("bio_dial_falick_x", _forceAnusLickReplyXFb);
        // ---- 强制舔阴蒂(按性别分三套) ----
        private static readonly string[] _forceClitLickReplyMFb = {
            "你强行掰开他的腿,牙齿咬住他的阴蒂粗暴地拉扯,他痛得尖叫出来,身体本能地弓起。阴蒂被你咬得红肿,味道带着血腥的微甜。",
            "他挣扎着想合拢双腿,却被你死死按住。你用舌头粗暴地拨弄他的阴蒂,他痛得浑身发抖,眼泪流了出来,阴蒂却不由自主地胀大了。",
        };
        public static string[] ForceClitLickReplyM => BioDialogueLocalizer.Pool("bio_dial_fclit_m", _forceClitLickReplyMFb);
        private static readonly string[] _forceClitLickReplyFFb = {
            "你强行掰开她的腿,牙齿咬住她的阴蒂粗暴地拉扯,她痛得尖叫出来,身体本能地弓起。阴蒂被你咬得红肿,味道带着血腥的微甜。",
            "她挣扎着想合拢双腿,却被你死死按住。你用舌头粗暴地拨弄她的阴蒂,她痛得浑身发抖,眼泪流了出来,阴蒂却不由自主地胀大了。",
        };
        public static string[] ForceClitLickReplyF => BioDialogueLocalizer.Pool("bio_dial_fclit_f", _forceClitLickReplyFFb);
        private static readonly string[] _forceClitLickReplyXFb = {
            "你强行掰开他的腿,牙齿咬住他的阴蒂粗暴地拉扯,他痛得尖叫出来,身体本能地弓起。阴蒂被你咬得红肿,阴茎也跟着跳了一下。",
            "他挣扎着想合拢双腿,却被你死死按住。你用舌头粗暴地拨弄他的阴蒂,他痛得浑身发抖,阴蒂却不由自主地胀大了,阴茎也硬了起来。",
        };
        public static string[] ForceClitLickReplyX => BioDialogueLocalizer.Pool("bio_dial_fclit_x", _forceClitLickReplyXFb);
        // ---- 强制舔尿道(按性别分三套) ----
        private static readonly string[] _forceUrethraLickReplyMFb = {
            "你强行按住他,舌头粗暴地探入他的尿道口搅动,他浑身一激灵,痛得叫出声。尿道里的味道腥涩,舌头搅动时他整个人都在发抖。",
            "他挣扎着想躲开,却被你死死按住。你的舌头在他尿道口里搅动,他痛得浑身发抖,精液不由自主地涌了出来,味道浓稠而腥甜。",
        };
        public static string[] ForceUrethraLickReplyM => BioDialogueLocalizer.Pool("bio_dial_fur_m", _forceUrethraLickReplyMFb);
        private static readonly string[] _forceUrethraLickReplyFFb = {
            "你强行按住她,舌头粗暴地探入她的尿道口搅动,她浑身一激灵,痛得叫出声。尿道里的味道腥涩,舌头搅动时她整个人都在发抖。",
            "她挣扎着想躲开,却被你死死按住。你的舌头在她尿道口里搅动,她痛得浑身发抖,淫水不由自主地涌了出来,味道腥甜。",
        };
        public static string[] ForceUrethraLickReplyF => BioDialogueLocalizer.Pool("bio_dial_fur_f", _forceUrethraLickReplyFFb);
        private static readonly string[] _forceUrethraLickReplyXFb = {
            "你强行按住他,舌头粗暴地探入他的尿道口搅动,他浑身一激灵,痛得叫出声。尿道里的味道腥涩,阴茎也跟着跳了一下。",
            "他挣扎着想躲开,却被你死死按住。你的舌头在他尿道口里搅动,他痛得浑身发抖,精液不由自主地涌了出来,味道浓稠而腥甜。",
        };
        public static string[] ForceUrethraLickReplyX => BioDialogueLocalizer.Pool("bio_dial_fur_x", _forceUrethraLickReplyXFb);
        // ---- 强制手指插入(按性别分三套) ----
        private static readonly string[] _forceFingerInsertReplyMFb = {
            "你强行把手指粗暴地捅进他的后穴,快速抽插,他痛得叫出声,后穴却不由自主地绞紧了你的手指。指尖尝到一丝肠液的微涩。",
            "他挣扎着想合拢双腿,却被你死死按住。你的手指在他后穴里快速抽插,他痛得浑身发抖,眼泪流了出来,后穴却敏感地绞紧了你的手指。",
        };
        public static string[] ForceFingerInsertReplyM => BioDialogueLocalizer.Pool("bio_dial_ffing_m", _forceFingerInsertReplyMFb);
        private static readonly string[] _forceFingerInsertReplyFFb = {
            "你强行把手指粗暴地捅进她的小穴,快速抽插,她痛得叫出声,小穴却不由自主地绞紧了你的手指。指尖尝到一丝爱液的微甜。",
            "她挣扎着想合拢双腿,却被你死死按住。你的手指在她小穴里快速抽插,她痛得浑身发抖,眼泪流了出来,小穴却敏感地绞紧了你的手指。",
        };
        public static string[] ForceFingerInsertReplyF => BioDialogueLocalizer.Pool("bio_dial_ffing_f", _forceFingerInsertReplyFFb);
        private static readonly string[] _forceFingerInsertReplyXFb = {
            "你强行把手指粗暴地捅进他的小穴,快速抽插,他痛得叫出声,小穴却不由自主地绞紧了你的手指。阴茎也跟着跳了一下。",
            "他挣扎着想合拢双腿,却被你死死按住。你的手指在他小穴里快速抽插,他痛得浑身发抖,小穴却敏感地绞紧了你的手指,阴茎也硬了起来。",
        };
        public static string[] ForceFingerInsertReplyX => BioDialogueLocalizer.Pool("bio_dial_ffing_x", _forceFingerInsertReplyXFb);
        // ---- 阴道硬来/强迫(默认,按性别分三套) ----
        private static readonly string[] _vaginaReluctReplyMFb = {
            "你强行插入他的后庭,他痛得闷哼一声,指甲抠进了床单里。",
            "他咬着枕头无声地哭泣,身体却不由自主地有了反应。",
        };
        public static string[] VaginaReluctReplyM => BioDialogueLocalizer.Pool("bio_dial_vrel_m", _vaginaReluctReplyMFb);
        private static readonly string[] _vaginaReluctReplyFFb = {
            "你强行插入她的小穴,她痛得闷哼一声,指甲抠进了床单里。",
            "她咬着枕头无声地哭泣,身体却不由自主地有了反应。",
        };
        public static string[] VaginaReluctReplyF => BioDialogueLocalizer.Pool("bio_dial_vrel_f", _vaginaReluctReplyFFb);
        private static readonly string[] _vaginaReluctReplyXFb = {
            "你强行插入他的小穴,他痛得闷哼一声,阴茎却不受控制地硬了起来。",
            "他咬着枕头无声地哭泣,身体却不由自主地迎合起来,前后都在流水。",
        };
        public static string[] VaginaReluctReplyX => BioDialogueLocalizer.Pool("bio_dial_vrel_x", _vaginaReluctReplyXFb);
        private static readonly string[] _vaginaForcedReplyMFb = {
            "你把他按住强行进入后庭,他尖叫着挣扎,却被你死死压住。",
            "他被操得说不出完整的句子,只能发出破碎的哭喊和呻吟。",
        };
        public static string[] VaginaForcedReplyM => BioDialogueLocalizer.Pool("bio_dial_vfor_m", _vaginaForcedReplyMFb);
        private static readonly string[] _vaginaForcedReplyFFb = {
            "你把她按住强行进入小穴,她尖叫着挣扎,却被你死死压住。",
            "她被操得说不出完整的句子,只能发出破碎的哭喊和呻吟。",
        };
        public static string[] VaginaForcedReplyF => BioDialogueLocalizer.Pool("bio_dial_vfor_f", _vaginaForcedReplyFFb);
        private static readonly string[] _vaginaForcedReplyXFb = {
            "你把他按住强行进入他的小穴,他尖叫着挣扎,阴茎却不受控制地硬挺着。",
            "他被操得说不出完整的句子,只能发出破碎的哭喊和淫叫,前后都在流水。",
        };
        public static string[] VaginaForcedReplyX => BioDialogueLocalizer.Pool("bio_dial_vfor_x", _vaginaForcedReplyXFb);
        // ---- 舔阴蒂(按性别分三套) ----
        private static readonly string[] _clitLickReplyMFb = {
            "你俯下身,舌尖轻轻拨开他的包皮,含住那颗小小的阴蒂快速舔弄,他浑身一颤,腰肢发软。阴蒂的味道带着淡淡的咸涩,舌头一碰他就敏感地缩了一下,后穴不由自主地流水了。",
            "你用舌尖在他的阴蒂上画圈,他咬着嘴唇忍耐,身体却不由自主地弓起来。阴蒂在你口中渐渐胀大,味道带着体液的微腥,他抓紧了床单,呻吟着求你继续。",
            "你含住他的阴蒂用力吸吮,舌头快速拨弄,他浑身发抖,精液和淫水一起涌了出来。嘴里满是咸涩的味道,他高潮后阴蒂还在你口中跳动,整个人瘫软在床上。",
        };
        public static string[] ClitLickReplyM => BioDialogueLocalizer.Pool("bio_dial_clit_m", _clitLickReplyMFb);
        private static readonly string[] _clitLickReplyFFb = {
            "你俯下身,舌尖轻轻拨开她的阴蒂包皮,含住那颗小小的凸起快速舔弄,她浑身一颤,腰肢发软。阴蒂的味道带着淡淡的咸涩,舌头一碰她就敏感地缩了一下,小穴流水了。",
            "你用舌尖在她的阴蒂上画圈,她咬着嘴唇忍耐,身体却不由自主地弓起来。阴蒂在你口中渐渐胀大,味道带着体液的微腥,她抓紧了床单,呻吟着求你继续。",
            "你含住她的阴蒂用力吸吮,舌头快速拨弄,她浑身发抖,淫水涌了出来。嘴里满是咸涩的味道,她高潮后阴蒂还在你口中跳动,整个人瘫软在床上。",
        };
        public static string[] ClitLickReplyF => BioDialogueLocalizer.Pool("bio_dial_clit_f", _clitLickReplyFFb);
        private static readonly string[] _clitLickReplyXFb = {
            "你俯下身,舌尖轻轻拨开他的包皮,含住那颗小小的阴蒂快速舔弄,同时用手握住他垂软的阴茎。他浑身一颤,阴蒂和阴茎同时有了反应,嘴里发出甜腻的呻吟。",
            "你用舌尖在他的阴蒂上画圈,另一只手轻轻套弄他的阴茎,他咬着嘴唇忍耐,身体却不由自主地弓起来。阴蒂在你口中渐渐胀大,阴茎也在你手中硬了起来。",
            "你含住他的阴蒂用力吸吮,舌头快速拨弄,同时用手套弄他的阴茎,他浑身发抖,精液和淫水一起涌了出来。嘴里满是咸涩的味道,他高潮后整个人瘫软在床上。",
        };
        public static string[] ClitLickReplyX => BioDialogueLocalizer.Pool("bio_dial_clit_x", _clitLickReplyXFb);
        // ---- 舔尿道(按性别分三套) ----
        private static readonly string[] _urethraLickReplyMFb = {
            "你俯下身,用舌尖轻轻探入他的尿道口,他浑身一激灵,下体一阵酥麻。舌尖在尿道口里轻轻搅动,尝到一丝腥甜的味道,他忍不住呻吟出来,阴茎在你嘴边跳动。",
            "你用舌尖在他的尿道口上画圈,然后慢慢探入,他浑身发颤,手指揪紧了床单。尿道里的味道带着淡淡的腥涩,舌头搅动时他整个人都在发抖,精液不由自主地涌了出来。",
            "你含住他的龟头,舌尖用力探入尿道口,他尖叫一声,精液直接射进了你的嘴里。味道浓稠而腥甜,他射完后整个人瘫软下去,尿道还在微微收缩。",
        };
        public static string[] UrethraLickReplyM => BioDialogueLocalizer.Pool("bio_dial_ur_m", _urethraLickReplyMFb);
        private static readonly string[] _urethraLickReplyFFb = {
            "你俯下身,用舌尖轻轻探入她的尿道口,她浑身一激灵,下体一阵酥麻。舌尖在尿道口里轻轻搅动,尝到一丝腥甜的味道,她忍不住呻吟出来,身体一阵阵发颤。",
            "你用舌尖在她的尿道口上画圈,然后慢慢探入,她浑身发颤,手指揪紧了床单。尿道里的味道带着淡淡的腥涩,舌头搅动时她整个人都在发抖,淫水不由自主地涌了出来。",
            "你含住她的尿道口,舌尖用力探入,她尖叫一声,淫水直接涌了出来。味道腥甜而温热,她高潮后整个人瘫软下去,尿道还在微微收缩。",
        };
        public static string[] UrethraLickReplyF => BioDialogueLocalizer.Pool("bio_dial_ur_f", _urethraLickReplyFFb);
        private static readonly string[] _urethraLickReplyXFb = {
            "你俯下身,用舌尖轻轻探入他的尿道口,他浑身一激灵,阴茎不由自主地跳了一下。舌尖在尿道口里轻轻搅动,尝到一丝腥甜的味道,他忍不住呻吟出来。",
            "你用舌尖在他的尿道口上画圈,然后慢慢探入,另一只手轻轻套弄他的阴茎,他浑身发颤,精液和淫水一起涌了出来。尿道里的味道带着淡淡的腥涩。",
            "你含住他的龟头,舌尖用力探入尿道口,他尖叫一声,精液直接射进了你的嘴里。味道浓稠而腥甜,他射完后整个人瘫软下去,阴茎还在你口中微微跳动。",
        };
        public static string[] UrethraLickReplyX => BioDialogueLocalizer.Pool("bio_dial_ur_x", _urethraLickReplyXFb);
        // ---- 手指插入(按性别分三套) ----
        private static readonly string[] _fingerInsertReplyMFb = {
            "你把手指慢慢探入他的后穴,指尖在内壁上弯曲勾弄,他浑身一颤,后穴不由自主地绞紧了你的手指。指尖尝到一丝肠液的微涩,他咬着嘴唇呻吟,屁股不由自主地往后顶。",
            "你用两根手指在他后穴里抽插,指尖寻找着他的敏感点,他浑身发抖,抓紧了床单。手指抽出来时带着透明的肠液,他整个人都在发抖,后穴一缩一缩地挽留你的手指。",
            "你用手指在他后穴里快速抽插,同时用拇指摩擦他的阴蒂,他浑身痉挛,精液喷了一床。手指被他的后穴紧紧绞住,高潮后还在微微收缩,他瘫软在床上喘息。",
        };
        public static string[] FingerInsertReplyM => BioDialogueLocalizer.Pool("bio_dial_fing_m", _fingerInsertReplyMFb);
        private static readonly string[] _fingerInsertReplyFFb = {
            "你把手指慢慢探入她的小穴,指尖在内壁上弯曲勾弄G点,她浑身一颤,小穴不由自主地绞紧了你的手指。指尖尝到一丝爱液的微甜,她咬着嘴唇呻吟,屁股不由自主地往后顶。",
            "你用两根手指在她小穴里抽插,指尖寻找着她的敏感点,她浑身发抖,抓紧了床单。手指抽出来时带着透明的爱液,她整个人都在发抖,小穴一缩一缩地挽留你的手指。",
            "你用手指在她小穴里快速抽插,同时用拇指摩擦她的阴蒂,她浑身痉挛,淫水涌了一滩。手指被她的小穴紧紧绞住,高潮后还在微微收缩,她瘫软在床上喘息。",
        };
        public static string[] FingerInsertReplyF => BioDialogueLocalizer.Pool("bio_dial_fing_f", _fingerInsertReplyFFb);
        private static readonly string[] _fingerInsertReplyXFb = {
            "你把手指慢慢探入他的小穴,指尖在内壁上弯曲勾弄G点,他浑身一颤,小穴不由自主地绞紧了你的手指。同时用另一只手握住他的阴茎,他忍不住呻吟出来。",
            "你用两根手指在他小穴里抽插,指尖寻找着他的敏感点,另一只手轻轻套弄他的阴茎,他浑身发抖,精液和淫水一起涌了出来。手指抽出来时带着透明的爱液。",
            "你用手指在他小穴里快速抽插,同时用拇指摩擦他的阴蒂,他浑身痉挛,精液和淫水一起喷了出来。手指被他的小穴紧紧绞住,高潮后还在微微收缩,他瘫软在床上喘息。",
        };
        public static string[] FingerInsertReplyX => BioDialogueLocalizer.Pool("bio_dial_fing_x", _fingerInsertReplyXFb);
        // ---- 肛门硬来/强迫(按性别分三套) ----
        private static readonly string[] _anusReluctReplyMFb = {
            "你强行插入他的后庭,他痛得闷哼一声,指甲抠进了床单里。",
            "他咬着枕头无声地哭泣,后穴却不由自主地绞紧了。",
        };
        public static string[] AnusReluctReplyM => BioDialogueLocalizer.Pool("bio_dial_arel_m", _anusReluctReplyMFb);
        private static readonly string[] _anusReluctReplyFFb = {
            "你强行插入她的后庭,她痛得闷哼一声,指甲抠进了床单里。",
            "她咬着枕头无声地哭泣,后穴却不由自主地绞紧了。",
        };
        public static string[] AnusReluctReplyF => BioDialogueLocalizer.Pool("bio_dial_arel_f", _anusReluctReplyFFb);
        private static readonly string[] _anusReluctReplyXFb = {
            "你强行插入他的后庭,他痛得闷哼一声,阴茎却不受控制地硬了起来。",
            "他咬着枕头无声地哭泣,后穴却不由自主地迎合起来。",
        };
        public static string[] AnusReluctReplyX => BioDialogueLocalizer.Pool("bio_dial_arel_x", _anusReluctReplyXFb);
        private static readonly string[] _anusForcedReplyMFb = {
            "你把他按住强行插入后庭,他尖叫着挣扎,却被你死死压住。",
            "他被操得说不出完整的句子,只能发出破碎的哭喊和呻吟。",
        };
        public static string[] AnusForcedReplyM => BioDialogueLocalizer.Pool("bio_dial_afor_m", _anusForcedReplyMFb);
        private static readonly string[] _anusForcedReplyFFb = {
            "你把她按住强行插入后庭,她尖叫着挣扎,却被你死死压住。",
            "她被操得说不出完整的句子,只能发出破碎的哭喊和呻吟。",
        };
        public static string[] AnusForcedReplyF => BioDialogueLocalizer.Pool("bio_dial_afor_f", _anusForcedReplyFFb);
        private static readonly string[] _anusForcedReplyXFb = {
            "你把他按住强行插入后庭,他尖叫着挣扎,阴茎却不受控制地硬挺着。",
            "他被操得说不出完整的句子,只能发出破碎的哭喊和呻吟,前后都在流水。",
        };
        public static string[] AnusForcedReplyX => BioDialogueLocalizer.Pool("bio_dial_afor_x", _anusForcedReplyXFb);
        // ---- 舔肛(按性别分三套,描述口感和反应) ----
        private static readonly string[] _anusLickReplyMFb = {
            "你分开他的臀瓣,舌尖抵上他紧致的后穴,他浑身一颤,后穴不由自主地缩了一下。你尝到一股淡淡的咸味,混着汗水的微涩,舌头探进去时能感到内壁一圈圈地绞紧你。",
            "他趴在你面前翘着屁股,你低头含住他的后穴用力吸吮,他闷哼一声,腰肢发软。后穴的味道带着些微的苦涩和体液的腥甜,舌头搅动时他整个人都在发抖,手指揪紧了床单。",
            "你用舌尖轻轻画圈,他的后穴敏感地收缩着,嘴里尝到汗水和肠液混合的咸涩味道。他咬着枕头呻吟,屁股不由自主地往后顶,后穴贪婪地吮吸着你的舌头。",
        };
        public static string[] AnusLickReplyM => BioDialogueLocalizer.Pool("bio_dial_alick_m", _anusLickReplyMFb);
        private static readonly string[] _anusLickReplyFFb = {
            "你分开她的臀瓣,舌尖抵上她紧致的后穴,她浑身一颤,后穴不由自主地缩了一下。你尝到一股淡淡的咸味,混着汗水的微涩,舌头探进去时能感到内壁一圈圈地绞紧你。",
            "她趴在你面前翘着屁股,你低头含住她的后穴用力吸吮,她闷哼一声,腰肢发软。后穴的味道带着些微的苦涩和体液的腥甜,舌头搅动时她整个人都在发抖,手指揪紧了床单。",
            "你用舌尖轻轻画圈,她的后穴敏感地收缩着,嘴里尝到汗水和肠液混合的咸涩味道。她咬着枕头呻吟,屁股不由自主地往后顶,后穴贪婪地吮吸着你的舌头。",
        };
        public static string[] AnusLickReplyF => BioDialogueLocalizer.Pool("bio_dial_alick_f", _anusLickReplyFFb);
        private static readonly string[] _anusLickReplyXFb = {
            "你分开他的臀瓣,舌尖抵上他紧致的后穴,他浑身一颤,后穴不由自主地缩了一下。你尝到一股淡淡的咸味,混着汗水的微涩,舌头探进去时能感到内壁一圈圈地绞紧你,阴茎也跟着跳了一下。",
            "他趴在你面前翘着屁股,你低头含住他的后穴用力吸吮,他闷哼一声,腰肢发软,阴茎也硬了起来。后穴的味道带着些微的苦涩和体液的腥甜,舌头搅动时他整个人都在发抖。",
            "你用舌尖轻轻画圈,他的后穴敏感地收缩着,嘴里尝到汗水和肠液混合的咸涩味道。他咬着枕头呻吟,屁股不由自主地往后顶,后穴贪婪地吮吸着你的舌头,胯下的肉棒也胀得发痛。",
        };
        public static string[] AnusLickReplyX => BioDialogueLocalizer.Pool("bio_dial_alick_x", _anusLickReplyXFb);
        // ---- 阴茎硬来/强迫(按性别分三套) ----
        private static readonly string[] _penisReluctReplyMFb = {
            "你强行握住他的阴茎粗暴地撸动,他痛得闷哼一声,身体本能地弓了起来。",
            "他咬着嘴唇忍耐,精液却被你硬生生挤了出来。",
        };
        public static string[] PenisReluctReplyM => BioDialogueLocalizer.Pool("bio_dial_prel_m", _penisReluctReplyMFb);
        private static readonly string[] _penisReluctReplyFFb = {
            "你强行握住他的阴茎粗暴地撸动,他痛得闷哼一声,身体本能地弓了起来。",
            "他咬着嘴唇忍耐,精液却被你硬生生挤了出来。",
        };
        public static string[] PenisReluctReplyF => BioDialogueLocalizer.Pool("bio_dial_prel_f", _penisReluctReplyFFb);
        private static readonly string[] _penisReluctReplyXFb = {
            "你强行握住他的阴茎粗暴地撸动,他痛得闷哼一声,小穴却不由自主地流水了。",
            "他咬着嘴唇忍耐,精液和淫水一起涌了出来。",
        };
        public static string[] PenisReluctReplyX => BioDialogueLocalizer.Pool("bio_dial_prel_x", _penisReluctReplyXFb);
        private static readonly string[] _penisForcedReplyMFb = {
            "你死死攥住他的阴茎用力套弄,他痛得叫出声,却被你逼着射了出来。",
            "他被你撸得精关失守,精液喷了一地,浑身无力地瘫软下去。",
        };
        public static string[] PenisForcedReplyM => BioDialogueLocalizer.Pool("bio_dial_pfor_m", _penisForcedReplyMFb);
        private static readonly string[] _penisForcedReplyFFb = {
            "你死死攥住他的阴茎用力套弄,他痛得叫出声,却被你逼着射了出来。",
            "他被你撸得精关失守,精液喷了一地,浑身无力地瘫软下去。",
        };
        public static string[] PenisForcedReplyF => BioDialogueLocalizer.Pool("bio_dial_pfor_f", _penisForcedReplyFFb);
        private static readonly string[] _penisForcedReplyXFb = {
            "你死死攥住他的阴茎用力套弄,他痛得叫出声,小穴也跟着一阵痉挛。",
            "他被你撸得精关失守,精液和淫水一起喷了出来,浑身无力地瘫软下去。",
        };
        public static string[] PenisForcedReplyX => BioDialogueLocalizer.Pool("bio_dial_pfor_x", _penisForcedReplyXFb);
    }
}
