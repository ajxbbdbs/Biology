using NeoModLoader.api;
using UnityEngine;

namespace RimWorldMod {
    public class Main : BasicMod<Main> {
        // 添加器官/操纵器官菜单的等比缩放倍率(由模组设置"窗口设置>菜单缩放"控制)
        public static float MenuScale = 1f;
        // 添加器官/操纵器官菜单的基准面板宽度(px,由模组设置"窗口设置>面板宽度"控制)
        public static int MenuWidth = 280;
        // 器官面板(生物学标签)的加宽倍率:1=不加宽,2=宽度翻倍(向右扩展)
        public static float PanelWidthFactor = 2f;
        // 是否为动物启用器官系统:关闭时只有人类/精灵/矮人/兽人等文明种族有器官面板
        public static bool AnimalOrgans = false;
        // 调试用:生物学标签内点击时把光标下的 UI 节点打进日志(默认关闭,避免刷日志)
        public static bool ClickProbe = false;
        // 立绘是否用裸体那套图层。女性/扶他换成 body_Nude/body_NudeTorso,
        // 男性换成 male_TorsoNude 并额外挂上睾丸/阴毛/阴茎(阴茎按器官尺寸挑贴图)
        public static bool NudeDoll = false;
        // 器官磨损:打架/生孩子/走路会慢慢磨低对应器官的百分比(见 BioExperience)。
        // 大世界里嫌吵或者嫌费性能可以关掉,关掉后只剩玩家手动强化/弱化
        public static bool OrganWear = true;

        // 模组设置回调:器官磨损开关
        public static void OnOrganWearChanged(bool pEnabled) {
            OrganWear = pEnabled;
            Main.LogInfo("生物学:器官磨损已" + (pEnabled ? "启用" : "关闭"));
        }

        // 模组设置回调:裸体立绘开关(改完立即重搭立绘)
        public static void OnNudeDollChanged(bool pEnabled) {
            NudeDoll = pEnabled;
            Main.LogInfo("生物学:裸体立绘已" + (pEnabled ? "启用" : "关闭"));
            try {
                BioBodyDoll.ResetBuild();
                UnitHealthTab.RefreshAfterEdit();
            } catch (System.Exception e) {
                LogError("生物学:切换裸体立绘后刷新面板失败 " + e);
            }
        }

        // 模组设置回调:发色诊断(当按钮用,打开开关关掉设置窗口就把状态打进日志)
        public static void OnHairDiagChanged(bool pEnabled) {
            if (!pEnabled) return;
            BioHeadHair.LogStatus();
        }

        // 模组设置回调:导出原版头部贴图(当按钮用,打开开关关掉设置窗口就导出一次)
        public static void OnDumpHeadsChanged(bool pEnabled) {
            if (!pEnabled) return;
            LogInfo("生物学:开始导出原版头部贴图");
            BioHeadDump.Dump();
        }

        // 模组设置回调:点击探针开关
        public static void OnClickProbeChanged(bool pEnabled) {
            ClickProbe = pEnabled;
            Main.LogInfo("生物学:点击探针已" + (pEnabled ? "启用" : "关闭"));
        }

        // 模组设置回调:动物器官开关(改完立即刷新已打开的器官面板)
        public static void OnAnimalOrgansChanged(bool pEnabled) {
            AnimalOrgans = pEnabled;
            Main.LogInfo("生物学:动物器官已" + (pEnabled ? "启用" : "关闭"));
            try {
                UnitHealthTab.RefreshAfterEdit();
            } catch (System.Exception e) {
                LogError("生物学:切换动物器官后刷新面板失败 " + e);
            }
        }

        // 模组设置回调:器官面板加宽倍率
        public static void OnPanelWidthFactorChanged(float pFactor) {
            PanelWidthFactor = Mathf.Clamp(pFactor, 1f, 3f);
            Main.LogInfo("生物学:器官面板加宽倍率已更新为 " + PanelWidthFactor);
        }

        // 模组设置回调:关闭设置窗口后生效
        public static void OnMenuScaleChanged(float pScale) {
            MenuScale = Mathf.Max(0.3f, pScale);
            Main.LogInfo("生物学:菜单缩放已更新为 " + MenuScale);
        }

        // 模组设置回调:面板宽度变化时按比例缩放(等比缩放)
        public static void OnMenuWidthChanged(int pWidth) {
            MenuWidth = Mathf.Clamp(pWidth, 100, 600);
            Main.LogInfo("生物学:面板宽度已更新为 " + MenuWidth);
        }

        protected override void OnModLoad() {
            // 读取模组设置中的菜单缩放/面板宽度
            try {
                var scaleItem = GetConfig()["窗口设置"]["菜单缩放"];
                if (scaleItem != null) MenuScale = Mathf.Max(0.3f, scaleItem.FloatVal);
                var widthItem = GetConfig()["窗口设置"]["面板宽度"];
                if (widthItem != null) MenuWidth = Mathf.Clamp(widthItem.IntVal, 100, 600);
                var factorItem = GetConfig()["窗口设置"]["器官面板加宽倍数"];
                if (factorItem != null) PanelWidthFactor = Mathf.Clamp(factorItem.FloatVal, 1f, 3f);
            } catch (System.Exception e) {
                LogError("生物学:读取菜单缩放配置失败 " + e);
            }
            // 功能开关:动物器官(默认关闭,只支持文明种族)+ 点击探针(调试)
            try {
                var animalItem = GetConfig()["功能开关"]["启用动物器官"];
                if (animalItem != null) AnimalOrgans = animalItem.BoolVal;
                var probeItem = GetConfig()["功能开关"]["点击探针"];
                if (probeItem != null) ClickProbe = probeItem.BoolVal;
                var nudeItem = GetConfig()["功能开关"]["裸体立绘"];
                if (nudeItem != null) NudeDoll = nudeItem.BoolVal;
                var wearItem = GetConfig()["功能开关"]["器官磨损"];
                if (wearItem != null) OrganWear = wearItem.BoolVal;
                LogInfo("生物学:动物器官=" + (AnimalOrgans ? "启用" : "关闭")
                    + " 点击探针=" + (ClickProbe ? "启用" : "关闭")
                    + " 裸体立绘=" + (NudeDoll ? "启用" : "关闭")
                    + " 器官磨损=" + (OrganWear ? "启用" : "关闭"));
            } catch (System.Exception e) {
                LogError("生物学:读取功能开关失败 " + e);
            }
            UnitHealthTab.Ensure();
            // 小人头发:接管重绘的头部贴图 + 按单位发色换色(和立绘同色)
            BioHeadHair.Ensure();
            // 器官面板加宽动画驱动(左锚点固定,只向右扩展)
            BioPanelWidth.Ensure();
            // 调试用点击探针(由"功能开关>点击探针"控制,关闭时不产生任何日志)
            BioClickProbe.Ensure();
            FamilyTracker.Ensure();
            // 神之侵犯致孕的那一胎:孕期走完时接管分娩,换成神之子
            OrganEditorUI.EnsureDivineBirthPatch();
            // 打架/生孩子/走路 → 器官磨损;另外双腿被摘掉时真的走不动(原版有移速保底 1)
            BioExperience.Ensure();
            // 收藏的单位死了先把家底抄一份,留着以后复活(见 BioResurrect)
            BioResurrect.Ensure();
            // 胃被摘除 → 无法消化,饱食度强制归零
            NutritionGuard.Ensure();
            // 大脑强化:取消法力上限 + 增加智力;弱化反之
            BrainStat.Ensure();
            // 常驻行为:选中单位时持续执行致命状态扣血(呼吸衰竭/尿毒症/内出血等)
            try {
                GameObject go = new GameObject("RimWorldHealthDrain");
                go.AddComponent<HealthDrainBehaviour>();
                UnityEngine.Object.DontDestroyOnLoad(go);
            } catch (System.Exception e) {
                LogError("生物学:创建持续扣血行为失败 " + e);
            }
            // 常驻守卫:双性人单位窗口性别图标每帧廉价覆盖(UnitStatsElement._icon_sex)
            try {
                GameObject go2 = new GameObject("RimWorldSexIconGuard");
                go2.AddComponent<SexIconGuardBehaviour>();
                UnityEngine.Object.DontDestroyOnLoad(go2);
            } catch (System.Exception e) {
                LogError("生物学:创建性别图标守卫失败 " + e);
            }
        }
    }
}
