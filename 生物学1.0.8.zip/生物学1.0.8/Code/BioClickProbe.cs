using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;

namespace RimWorldMod {

    // 每帧检测鼠标点击(诊断用)
    public class BioClickProbeBehaviour : MonoBehaviour {
        private void Update() {
            BioClickProbe.Tick();
        }
    }

    /// <summary>
    /// 点击探针(临时诊断工具):只在单位窗口的生物学标签内生效。
    /// 每次点击把光标下所有可见 UI 节点按"最上层优先"打进日志,带完整层级路径、尺寸、
    /// 图片名/文字、透明度、是否可点击。用来精确指认"要删掉/隐藏的那块东西"。
    /// 连续点击会依次编号([点击#1]、[点击#2]…),方便按顺序对应。
    /// 不需要时删掉本文件 + Main 里的 BioClickProbe.Ensure() 调用即可。
    /// </summary>
    public static class BioClickProbe {

        private const int MaxHits = 24;    // 每次点击最多打印的节点数
        private const int MaxDepth = 12;   // 遍历深度上限

        private static int _clickIndex;
        private static BioClickProbeBehaviour _behaviour;

        /// <summary> 创建常驻探针对象(Main 调用一次) </summary>
        public static void Ensure() {
            if (_behaviour != null) return;
            try {
                GameObject go = new GameObject("BioClickProbe");
                _behaviour = go.AddComponent<BioClickProbeBehaviour>();
                UnityEngine.Object.DontDestroyOnLoad(go);
                Main.LogInfo("生物学:点击探针组件就绪(是否输出日志由「功能开关>点击探针」控制)");
            } catch (Exception e) {
                Main.LogError("生物学:创建点击探针失败 " + e);
            }
        }

        public static void Tick() {
            try {
                if (!Main.ClickProbe) return;   // 关闭时零开销,不产生任何日志
                int button = -1;
                if (Input.GetMouseButtonDown(0)) button = 0;
                else if (Input.GetMouseButtonDown(1)) button = 1;
                else if (Input.GetMouseButtonDown(2)) button = 2;
                if (button < 0) return;

                UnitWindow win = UnitHealthTab.GetWindow();
                if (win == null || !win.gameObject.activeInHierarchy) return;
                if (!UnitHealthTab.IsBioTab(win)) return;

                Vector2 screen = Input.mousePosition;
                Canvas canvas = win.GetComponentInParent<Canvas>();
                Camera cam = null;
                if (canvas != null && canvas.renderMode != RenderMode.ScreenSpaceOverlay) {
                    cam = canvas.worldCamera;
                }

                _clickIndex++;
                Main.LogInfo("生物学:[点击#" + _clickIndex + "] " + ButtonName(button)
                    + " 屏幕(" + Mathf.RoundToInt(screen.x) + "," + Mathf.RoundToInt(screen.y) + ")");

                // 深度优先按子级顺序收集 = Unity 的绘制顺序,倒序打印即"最上层优先"
                List<RectTransform> hits = new List<RectTransform>();
                Collect(win.transform, screen, cam, hits, 0);
                if (hits.Count == 0) {
                    Main.LogInfo("生物学:[点击#" + _clickIndex + "] 光标下没有窗口内的可见节点");
                    return;
                }
                int printed = 0;
                for (int i = hits.Count - 1; i >= 0 && printed < MaxHits; i--) {
                    printed++;
                    Main.LogInfo("生物学:[点击#" + _clickIndex + "]-" + printed + " " + Describe(hits[i], win.transform));
                }
                if (hits.Count > printed) {
                    Main.LogInfo("生物学:[点击#" + _clickIndex + "] 另有 " + (hits.Count - printed) + " 个更底层节点未打印");
                }
            } catch (Exception e) {
                Main.LogError("生物学:点击探针异常 " + e);
            }
        }

        private static string ButtonName(int pButton) {
            if (pButton == 0) return "左键";
            if (pButton == 1) return "右键";
            return "中键";
        }

        // 收集光标下所有"可见图形"节点(隐藏的子树整体跳过;子级可能超出父级范围,所以不做提前剪枝)
        private static void Collect(Transform pNode, Vector2 pScreen, Camera pCam, List<RectTransform> pOut, int pDepth) {
            if (pNode == null || pDepth > MaxDepth) return;
            if (!pNode.gameObject.activeInHierarchy) return;

            RectTransform rt = pNode as RectTransform;
            if (rt != null) {
                Graphic g = rt.GetComponent<Graphic>();
                if (g != null && g.enabled && g.color.a > 0.01f &&
                    RectTransformUtility.RectangleContainsScreenPoint(rt, pScreen, pCam)) {
                    pOut.Add(rt);
                }
            }
            for (int i = 0; i < pNode.childCount; i++) {
                Collect(pNode.GetChild(i), pScreen, pCam, pOut, pDepth + 1);
            }
        }

        private static string Describe(RectTransform pRect, Transform pRoot) {
            StringBuilder sb = new StringBuilder();
            sb.Append(PathOf(pRect, pRoot));
            sb.Append(" 尺寸(").Append(pRect.rect.width.ToString("F0")).Append("x")
              .Append(pRect.rect.height.ToString("F0")).Append(")");
            Graphic g = pRect.GetComponent<Graphic>();
            if (g != null) {
                sb.Append(" 类型=").Append(g.GetType().Name);
                sb.Append(" alpha=").Append(g.color.a.ToString("F2"));
                sb.Append(" 可点击=").Append(g.raycastTarget ? "是" : "否");
                Image img = g as Image;
                if (img != null && img.sprite != null) {
                    // 图片名 + 绘制方式 + 九宫格边距:照搬某个框的样式时这三样都要
                    sb.Append(" 图片=").Append(img.sprite.name);
                    sb.Append(" 绘制=").Append(img.type);
                    Vector4 bd = img.sprite.border;
                    if (bd != Vector4.zero) {
                        sb.Append(" 九宫格(").Append(bd.x.ToString("F0")).Append(",").Append(bd.y.ToString("F0"))
                          .Append(",").Append(bd.z.ToString("F0")).Append(",").Append(bd.w.ToString("F0")).Append(")");
                    }
                    sb.Append(" 原图(").Append(img.sprite.rect.width.ToString("F0")).Append("x")
                      .Append(img.sprite.rect.height.ToString("F0")).Append(")");
                    sb.Append(" 颜色=").Append(ColorHex(img.color));
                }
                Text txt = g as Text;
                if (txt != null) {
                    string t = txt.text != null ? txt.text : "";
                    t = t.Replace("\n", " ");
                    if (t.Length > 20) t = t.Substring(0, 20) + "…";
                    sb.Append(" 文字=\"").Append(t).Append("\"");
                }
            }
            return sb.ToString();
        }

        internal static string ColorHex(Color pColor) {
            return "#" + Mathf.RoundToInt(pColor.r * 255f).ToString("X2")
                       + Mathf.RoundToInt(pColor.g * 255f).ToString("X2")
                       + Mathf.RoundToInt(pColor.b * 255f).ToString("X2")
                       + Mathf.RoundToInt(pColor.a * 255f).ToString("X2");
        }

        /// <summary>
        /// 一次性把某棵子树里所有 Image 打进日志(路径/图片名/绘制方式/九宫格/尺寸/颜色)。
        /// 用来找"原版某个框长什么样",由「功能开关>点击探针」控制,关闭时不输出。
        /// </summary>
        public static void DumpImages(Transform pRoot, string pTag, int pMaxLines = 80) {
            if (!Main.ClickProbe || pRoot == null) return;
            try {
                Main.LogInfo("生物学:[图树 " + pTag + "] 根=" + pRoot.name);
                int printed = 0;
                DumpImagesInner(pRoot, pRoot, pTag, ref printed, pMaxLines, 0);
                Main.LogInfo("生物学:[图树 " + pTag + "] 共打印 " + printed + " 个 Image");
            } catch (Exception e) {
                Main.LogError("生物学:打印图树失败 " + e);
            }
        }

        private static void DumpImagesInner(Transform pNode, Transform pRoot, string pTag,
            ref int pPrinted, int pMaxLines, int pDepth) {
            if (pNode == null || pDepth > MaxDepth || pPrinted >= pMaxLines) return;
            Image img = pNode.GetComponent<Image>();
            if (img != null && img.sprite != null) {
                RectTransform rt = pNode as RectTransform;
                StringBuilder sb = new StringBuilder();
                sb.Append("生物学:[图树 ").Append(pTag).Append("] ").Append(PathOf(pNode, pRoot));
                if (rt != null) {
                    sb.Append(" 尺寸(").Append(rt.rect.width.ToString("F0")).Append("x")
                      .Append(rt.rect.height.ToString("F0")).Append(")");
                }
                sb.Append(" 图片=").Append(img.sprite.name);
                sb.Append(" 绘制=").Append(img.type);
                Vector4 bd = img.sprite.border;
                if (bd != Vector4.zero) {
                    sb.Append(" 九宫格(").Append(bd.x.ToString("F0")).Append(",").Append(bd.y.ToString("F0"))
                      .Append(",").Append(bd.z.ToString("F0")).Append(",").Append(bd.w.ToString("F0")).Append(")");
                }
                sb.Append(" 原图(").Append(img.sprite.rect.width.ToString("F0")).Append("x")
                  .Append(img.sprite.rect.height.ToString("F0")).Append(")");
                sb.Append(" 颜色=").Append(ColorHex(img.color));
                sb.Append(img.enabled && pNode.gameObject.activeInHierarchy ? " 显示中" : " 已隐藏");
                Main.LogInfo(sb.ToString());
                pPrinted++;
            }
            for (int i = 0; i < pNode.childCount; i++) {
                DumpImagesInner(pNode.GetChild(i), pRoot, pTag, ref pPrinted, pMaxLines, pDepth + 1);
            }
        }

        // 从窗口根节点到目标的完整路径
        private static string PathOf(Transform pTarget, Transform pRoot) {
            List<string> parts = new List<string>();
            Transform cur = pTarget;
            while (cur != null) {
                parts.Add(cur.name);
                if (cur == pRoot) break;
                cur = cur.parent;
            }
            parts.Reverse();
            return string.Join("/", parts.ToArray());
        }
    }
}
