using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace RimWorldMod {

    // 挂在每个可编辑组件上的长按/拖动/滚轮缩放处理器
    public class LayoutPressable : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IDragHandler, IScrollHandler {
        public RectTransform Target;   // 要拖动的矩形(按钮/标题文字/关闭按钮)

        public void OnPointerDown(PointerEventData pEvent) { LayoutEditor.HandleDown(this, pEvent); }
        public void OnPointerUp(PointerEventData pEvent) { LayoutEditor.HandleUp(this); }
        public void OnDrag(PointerEventData pEvent) { LayoutEditor.HandleDrag(this, pEvent); }
        public void OnScroll(PointerEventData pEvent) { LayoutEditor.HandleScroll(this, pEvent); }
    }

    // 挂在窗口上的长按检测器(按住不动达到时长即开始拖动)
    public class LayoutWatcher : MonoBehaviour {
        private void Update() { LayoutEditor.Tick(); }
    }

    // 布局微调:长按组件 → 直接拖动 → 全屏网格背景 + 网格吸附/边缘对齐 → 松手记住位置
    public static class LayoutEditor {

        private const float LongPressTime = 0.55f;   // 长按判定时长(秒)
        private const float MoveDeadzone = 12f;      // 长按期间允许的最大位移
        private const float GridSizeBase = 8f;       // 网格吸附尺寸(= 背景网格间距)
        private const float AlignThresholdBase = 6f; // 边缘对齐吸附阈值

        private static Instance _inst;

        // 生物学标签Header(布局编辑绑定目标):器官菜单关闭后自动恢复绑定
        private static RectTransform _bioHeader;
        public static void SetBioHeader(RectTransform pHeader) { _bioHeader = pHeader; }

        private class Instance {
            public RectTransform Menu;
            public string SaveKey;
            public float Scale = 1f;
            public Canvas Canvas;
            public LayoutPressable Pressed;
            public float PressStartTime;
            public Vector2 PressStartScreen;
            public RectTransform Dragging;
            public Button DragButton;          // 拖动时禁用的按钮(防松手误触发点击)
            public bool DragButtonWasEnabled;
            public GameObject GridOverlay;     // 全屏网格背景
            public Button PendingRestore;      // 下一帧恢复可交互(等点击事件处理完)
            public bool PendingRestoreWasEnabled;
            public float SnapGrid;             // 吸附网格尺寸
            public Image MenuBg;               // 面板背景(拖动时半透明让网格透出)
            public Color MenuBgColor;
            public LayoutPressable Selected;   // 当前选中组件(滚轮缩放)
            public GameObject SelectBorder;    // 选中高亮
            public bool LayoutMode;            // E 键布局模式:禁用所有组件功能
            public List<Button> Buttons = new List<Button>();      // 布局模式禁用的按钮
            public Dictionary<Button, bool> ButtonStates = new Dictionary<Button, bool>();
            public MenuBlocker Blocker;        // 模态遮挡(布局模式下禁用点击关闭)
            public bool BlockerEnabled;
            public bool NeedReapply;           // 下一帧重新应用已保存布局(防延迟重建)
        }

        private static Texture2D _gridTex;

        // 与操控器官窗口一致的网格尺寸(受菜单缩放/宽度影响)
        public static float GetSnapGrid() {
            float scale = Mathf.Max(0.1f, Main.MenuScale * (Main.MenuWidth / 280f));
            return GridSizeBase * scale;
        }

        // 供外部(如折叠按钮拖动)复用的全屏白色井字格
        private static GameObject _staticGrid;
        public static void ShowGridOverlay(Canvas pCanvas, float pGrid) {
            if (_staticGrid != null) return;
            if (pCanvas == null) return;
            GameObject go = new GameObject("LayoutGridOverlay", typeof(RectTransform), typeof(RawImage));
            go.transform.SetParent(pCanvas.transform, false);
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
            RawImage ri = go.GetComponent<RawImage>();
            ri.texture = GridTexture();
            ri.color = new Color(1f, 1f, 1f, 0.32f);
            ri.raycastTarget = false;
            RectTransform canvasRt = pCanvas.transform as RectTransform;
            if (canvasRt != null && pGrid > 0.01f) {
                ri.uvRect = new Rect(0f, 0f, canvasRt.rect.width / pGrid, canvasRt.rect.height / pGrid);
            }
            _staticGrid = go;
        }
        public static void HideGridOverlay() {
            if (_staticGrid != null) {
                UnityEngine.Object.Destroy(_staticGrid);
                _staticGrid = null;
            }
        }

        private struct SavedPos {
            public Vector2 Pos;
            public float Scale;
        }

        // 内置默认布局:留空。网格按钮由 GridLayoutGroup 统一排布(2×n 整齐一致),
        // 标题/关闭按钮由各自布局组自然定位,不再用固定坐标覆盖,避免布局被改坏。
        private static readonly Dictionary<string, SavedPos> DefaultLayout = new Dictionary<string, SavedPos> {
        };

        // 应用单个组件的位置/缩放;网格单元格由 GridLayoutGroup 统一排布,不应用任何自定义位置/缩放
        private static void ApplyCellLayout(RectTransform target, SavedPos sp) {
            if (target == null) return;
            if (target.parent != null && target.parent.GetComponent<GridLayoutGroup>() != null) return;
            target.anchoredPosition = sp.Pos;
            float s = Mathf.Max(0.1f, sp.Scale);
            target.localScale = new Vector3(s, s, 1f);
        }

        // 应用内置的默认布局(在布局组完成重建之后调用)
        private static void ApplyDefaultLayout(RectTransform pMenu, string pSaveKey) {
            foreach (KeyValuePair<string, SavedPos> kv in DefaultLayout) {
                if (!kv.Key.StartsWith(pSaveKey + "|")) continue;
                RectTransform target = FindByPath(pMenu, kv.Key.Substring(pSaveKey.Length + 1));
                if (target == null) continue;
                ApplyCellLayout(target, kv.Value);
            }
        }

        private static string FilePath {
            get { return Path.Combine(Application.persistentDataPath, "biology_layout.txt"); }
        }

        // 绑定菜单:应用已保存的自定义布局 + 给组件挂长按处理器
        // pFreeze=true 冻结布局组(器官操作菜单); false 不冻结(用于生物学标签Header,不影响原版布局)
        public static void BindMenu(RectTransform pMenu, string pSaveKey, bool pFreeze = true) {
            _inst = null;
            if (pMenu == null) return;
            Instance inst = new Instance();
            inst.Menu = pMenu;
            inst.SaveKey = pSaveKey;
            inst.Scale = Mathf.Max(0.1f, Main.MenuScale * (Main.MenuWidth / 280f));
            inst.SnapGrid = GridSizeBase * inst.Scale;
            inst.Canvas = pMenu.GetComponentInParent<Canvas>();
            _inst = inst;
            // 先应用内置默认布局(用户修正版),再应用保存文件中的调整(可覆盖默认值)
            ApplyDefaultLayout(pMenu, pSaveKey);
            ApplySaved(pMenu, pSaveKey);
            inst.NeedReapply = true;
            // 冻结布局:禁用布局组与尺寸适配器,防止任何后续布局重建把已保存的位置还原
            if (pFreeze) {
                foreach (LayoutGroup g in pMenu.GetComponentsInChildren<LayoutGroup>(true)) g.enabled = false;
                foreach (ContentSizeFitter f in pMenu.GetComponentsInChildren<ContentSizeFitter>(true)) f.enabled = false;
            }
            CollectTargets(pMenu.transform);
            if (pMenu.gameObject.GetComponent<LayoutWatcher>() == null) {
                pMenu.gameObject.AddComponent<LayoutWatcher>();
            }
            LogGridPositions(pMenu, pSaveKey);
        }

        // 调试:打印网格各按钮的最终位置与行距(排查行与行之间的间距问题)
        private static void LogGridPositions(RectTransform pMenu, string pSaveKey) {
            try {
                Transform gridT = pMenu.Find("AddGrid");
                if (gridT == null) gridT = pMenu.Find("OpGrid");
                if (gridT == null) return;
                GridLayoutGroup glg = gridT.GetComponent<GridLayoutGroup>();
                if (glg != null) {
                    Main.LogInfo("生物学:布局[" + pSaveKey + "] 网格 格子(" + glg.cellSize.x.ToString("F1") + "x" + glg.cellSize.y.ToString("F1")
                        + ") 间距(" + glg.spacing.x.ToString("F1") + "," + glg.spacing.y.ToString("F1") + ") 共" + gridT.childCount + "格");
                }
                float prevY = float.NaN;
                for (int i = 0; i < gridT.childCount; i++) {
                    RectTransform cell = gridT.GetChild(i) as RectTransform;
                    if (cell == null) continue;
                    float y = cell.anchoredPosition.y;
                    string gap = "";
                    if (!float.IsNaN(prevY)) {
                        gap = " 与上一格行距=" + Mathf.Abs(prevY - y).ToString("F2");
                    }
                    Main.LogInfo("生物学:布局[" + pSaveKey + "] 格" + i + " [" + cell.name + "] 位置("
                        + cell.anchoredPosition.x.ToString("F1") + "," + y.ToString("F1") + ")" + gap);
                    prevY = y;
                }
            } catch (Exception e) {
                Main.LogError("生物学:打印网格布局失败 " + e);
            }
        }

        // 菜单关闭时清理:退出布局模式、隐藏网格,解除绑定
        public static void OnMenuClose() {
            Instance inst = _inst;
            if (inst == null) return;
            if (inst.LayoutMode) ExitLayoutMode(inst);
            if (inst.GridOverlay != null) {
                UnityEngine.Object.Destroy(inst.GridOverlay);
                inst.GridOverlay = null;
            }
            _inst = null;
        }

        private static void CollectTargets(Transform pRoot) {
            foreach (Transform child in pRoot) {
                GameObject go = child.gameObject;
                // 折叠按钮用专用拖动组件(BioFoldDrag),跳过 LayoutPressable
                if (child.name == "HeaderFoldBtn") {
                    CollectTargets(child);
                    continue;
                }
                // 网格单元格由 GridLayoutGroup 统一排布,不挂拖动/缩放处理器(保持按钮整齐一致)
                if (child.parent != null && child.parent.GetComponent<GridLayoutGroup>() != null) {
                    CollectTargets(child);
                    continue;
                }
                if (go.GetComponent<LayoutPressable>() != null) continue; // 防重复挂载
                if (go.GetComponent<Button>() != null) {
                    LayoutPressable lp = go.AddComponent<LayoutPressable>();
                    lp.Target = child as RectTransform;
                } else if (child.name == "Title") {
                    Text t = go.GetComponent<Text>();
                    if (t != null) t.raycastTarget = true;
                    LayoutPressable lp = go.AddComponent<LayoutPressable>();
                    lp.Target = child as RectTransform;
                }
                CollectTargets(child);
            }
        }

        // ===== 指针事件 =====

        public static void HandleDown(LayoutPressable pPressable, PointerEventData pEvent) {
            Instance inst = _inst;
            if (inst == null) return;
            // 布局模式:点击即选中组件(滚轮缩放),左键按下用于拖动移动
            if (inst.LayoutMode) {
                Select(inst, pPressable);
                if (pEvent.button == PointerEventData.InputButton.Left) {
                    inst.Pressed = pPressable;
                    inst.PressStartTime = Time.unscaledTime;
                    inst.PressStartScreen = pEvent.position;
                }
                return;
            }
            if (pEvent.button != PointerEventData.InputButton.Left) return;
            inst.Pressed = pPressable;
            inst.PressStartTime = Time.unscaledTime;
            inst.PressStartScreen = pEvent.position;
        }

        // 选中组件:显示高亮;滚轮在其上滚动即可缩放
        private static void Select(Instance inst, LayoutPressable pPressable) {
            if (pPressable == null || pPressable.Target == null) return;
            Deselect(inst);
            inst.Selected = pPressable;
            GameObject border = new GameObject("SelBorder", typeof(RectTransform), typeof(Image));
            border.transform.SetParent(pPressable.Target, false);
            RectTransform brt = border.GetComponent<RectTransform>();
            brt.anchorMin = Vector2.zero;
            brt.anchorMax = Vector2.one;
            brt.offsetMin = new Vector2(-2f, -2f);
            brt.offsetMax = new Vector2(2f, 2f);
            Image bimg = border.GetComponent<Image>();
            bimg.color = new Color(1f, 0.9f, 0.3f, 0.35f);
            bimg.raycastTarget = false;
            inst.SelectBorder = border;
        }

        private static void Deselect(Instance inst) {
            if (inst.SelectBorder != null) {
                UnityEngine.Object.Destroy(inst.SelectBorder);
                inst.SelectBorder = null;
            }
            inst.Selected = null;
        }

        // 滚轮缩放选中组件(0.5x~3x),并记住位置+缩放
        public static void HandleScroll(LayoutPressable pPressable, PointerEventData pEvent) {
            Instance inst = _inst;
            if (inst == null || !inst.LayoutMode) return;
            if (inst.Selected == null) Select(inst, pPressable);
            if (inst.Selected != pPressable) return;
            RectTransform rt = pPressable.Target;
            if (rt == null) return;
            float s = rt.localScale.x + Mathf.Sign(pEvent.scrollDelta.y) * 0.1f;
            s = Mathf.Clamp(s, 0.5f, 3f);
            rt.localScale = new Vector3(s, s, 1f);
            SaveEntry(inst.SaveKey, PathOf(inst.Menu, rt), rt.anchoredPosition, s);
            Main.LogInfo("生物学:组件缩放 " + rt.name + " -> x" + s);
        }

        public static void HandleUp(LayoutPressable pPressable) {
            Instance inst = _inst;
            if (inst == null) return;
            if (inst.Pressed == pPressable) inst.Pressed = null;
            if (inst.Dragging != null) EndDrag(inst);
        }

        public static void HandleDrag(LayoutPressable pPressable, PointerEventData pEvent) {
            Instance inst = _inst;
            if (inst == null || inst.Pressed != pPressable) return;
            if (inst.Dragging == null) {
                if (inst.LayoutMode) {
                    // 布局模式:按下后移动即拖动(无需长按)
                    BeginDrag(inst, pPressable);
                } else if (Time.unscaledTime - inst.PressStartTime >= LongPressTime &&
                    Vector2.Distance(pEvent.position, inst.PressStartScreen) <= MoveDeadzone) {
                    // 非布局模式:长按后移动 → 开始拖动
                    BeginDrag(inst, pPressable);
                } else {
                    return;
                }
            }
            if (inst.Dragging != null) MoveRect(inst, inst.Dragging, pEvent);
        }

        // 每帧检测:按 E 切换布局模式;按住不动达到长按时长 → 开始拖动;顺带延迟恢复被禁用的按钮
        public static void Tick() {
            // 若当前无绑定(如器官菜单已关闭)且处于生物学标签,自动恢复布局编辑绑定
            if (_inst == null && _bioHeader != null && _bioHeader.gameObject.activeInHierarchy) {
                BindMenu(_bioHeader, "bio", false);
            }
            Instance inst = _inst;
            if (inst == null) return;
            if (inst.NeedReapply) {
                inst.NeedReapply = false;
                Main.LogInfo("生物学:下一帧重新应用布局");
                ApplySaved(inst.Menu, inst.SaveKey);
            }
            if (inst.PendingRestore != null) {
                inst.PendingRestore.interactable = inst.PendingRestoreWasEnabled;
                inst.PendingRestore = null;
            }
            // E 键:开启/关闭布局模式(开启期间所有组件功能失效)
            if (Input.GetKeyDown(KeyCode.E)) {
                if (inst.LayoutMode) ExitLayoutMode(inst);
                else EnterLayoutMode(inst);
            }
            // Esc 取消选中
            if (Input.GetKeyDown(KeyCode.Escape)) Deselect(inst);
            if (inst.Pressed == null || inst.Dragging != null) return;
            if (!inst.LayoutMode && Time.unscaledTime - inst.PressStartTime >= LongPressTime &&
                Vector2.Distance(inst.PressStartScreen, Input.mousePosition) <= MoveDeadzone) {
                BeginDrag(inst, inst.Pressed);
            }
        }

        // ===== 布局模式(E 键) =====

        private static void EnterLayoutMode(Instance inst) {
            if (inst.LayoutMode) return;
            inst.LayoutMode = true;
            // 禁用所有按钮:点击无任何功能(不触发器官操作,也不会因点击关闭窗口)
            inst.Buttons.Clear();
            inst.ButtonStates.Clear();
            foreach (Button b in inst.Menu.GetComponentsInChildren<Button>(true)) {
                inst.Buttons.Add(b);
                inst.ButtonStates[b] = b.interactable;
                b.interactable = false;
            }
            // 禁用模态遮挡的点击关闭
            Canvas c = inst.Canvas;
            if (c != null) {
                Transform blockT = c.transform.Find("MenuBlocker");
                if (blockT != null) {
                    MenuBlocker mb = blockT.GetComponent<MenuBlocker>();
                    if (mb != null) {
                        inst.Blocker = mb;
                        inst.BlockerEnabled = mb.enabled;
                        mb.enabled = false;
                    }
                }
            }
            // 面板半透明让网格透出 + 可点击(点击空白不穿透、不关窗)
            Image bg = inst.Menu.GetComponent<Image>();
            if (bg != null) {
                inst.MenuBg = bg;
                inst.MenuBgColor = bg.color;
                bg.color = new Color(1f, 1f, 1f, 0.30f);
                bg.raycastTarget = true;
            }
            ShowGrid(inst);
            Main.LogInfo("生物学:进入布局模式(按E退出)");
        }

        private static void ExitLayoutMode(Instance inst) {
            if (!inst.LayoutMode) return;
            inst.LayoutMode = false;
            // 保存所有组件的位置+缩放(兜底)
            SaveAll(inst);
            // 恢复按钮
            foreach (Button b in inst.Buttons) {
                bool st;
                b.interactable = inst.ButtonStates.TryGetValue(b, out st) ? st : true;
            }
            inst.Buttons.Clear();
            inst.ButtonStates.Clear();
            // 恢复模态遮挡关闭
            if (inst.Blocker != null) {
                inst.Blocker.enabled = inst.BlockerEnabled;
                inst.Blocker = null;
            }
            // 恢复面板
            if (inst.MenuBg != null) {
                inst.MenuBg.color = inst.MenuBgColor;
                inst.MenuBg.raycastTarget = false;
                inst.MenuBg = null;
            }
            HideGrid(inst);
            Deselect(inst);
            Main.LogInfo("生物学:退出布局模式");
        }

        private static void BeginDrag(Instance inst, LayoutPressable pPressable) {
            if (pPressable == null || pPressable.Target == null) return;
            inst.Dragging = pPressable.Target;
            // 面板背景半透明,让下层网格透出
            Image bg = inst.Menu.GetComponent<Image>();
            if (bg != null) {
                inst.MenuBg = bg;
                inst.MenuBgColor = bg.color;
                bg.color = new Color(1f, 1f, 1f, 0.30f);
            }
            // 禁用该按钮,防止松手时触发点击(如长按"删除"后误删器官)
            Button btn = pPressable.GetComponent<Button>();
            if (btn != null) {
                inst.DragButton = btn;
                inst.DragButtonWasEnabled = btn.interactable;
                btn.interactable = false;
            }
            ShowGrid(inst);
        }

        private static void EndDrag(Instance inst) {
            RectTransform dragged = inst.Dragging;
            inst.Dragging = null;
            // 恢复面板不透明
            if (inst.MenuBg != null) {
                inst.MenuBg.color = inst.MenuBgColor;
                inst.MenuBg = null;
            }
            HideGrid(inst);
            if (inst.DragButton != null) {
                // 延迟一帧恢复:先让 Button 的点击事件(已禁用的按钮不会触发)处理完
                inst.PendingRestore = inst.DragButton;
                inst.PendingRestoreWasEnabled = inst.DragButtonWasEnabled;
                inst.DragButton = null;
            }
            // 松手记住位置+缩放
            if (dragged != null) {
                SaveEntry(inst.SaveKey, PathOf(inst.Menu, dragged), dragged.anchoredPosition, dragged.localScale.x);
            }
        }

        // ===== 拖动与吸附 =====

        private static void MoveRect(Instance inst, RectTransform rt, PointerEventData pEvent) {
            // 用世界坐标增量移动:不受面板放大倍率影响
            Vector3 curW, prevW;
            if (RectTransformUtility.ScreenPointToWorldPointInRectangle(rt, pEvent.position,
                    pEvent.pressEventCamera, out curW) &&
                RectTransformUtility.ScreenPointToWorldPointInRectangle(rt, pEvent.position - pEvent.delta,
                    pEvent.pressEventCamera, out prevW)) {
                rt.position += (curW - prevW);
            } else {
                rt.position += (Vector3)pEvent.delta;
            }
            ApplySnap(inst, rt);
        }

        // 网格吸附 + 与同父组件/窗口边缘对齐(画布本地坐标比较)
        private static void ApplySnap(Instance inst, RectTransform rt) {
            Canvas c = inst.Canvas;
            if (c == null) return;
            float grid = inst.SnapGrid;
            float threshold = AlignThresholdBase * inst.Scale;
            Vector2 center = (Vector2)c.transform.InverseTransformPoint(rt.position);
            Vector2 size = CanvasSize(rt, c);
            float bestDx = Mathf.Round(center.x / grid) * grid - center.x;
            float bestDy = Mathf.Round(center.y / grid) * grid - center.y;
            // 对齐目标:同一父节点下的其他组件 + 父节点 + 窗口自身
            List<RectTransform> peers = new List<RectTransform>();
            foreach (Transform t in rt.parent) {
                if (t == rt) continue;
                RectTransform pr = t as RectTransform;
                if (pr != null) peers.Add(pr);
            }
            peers.Add(rt.parent as RectTransform);
            peers.Add(inst.Menu);
            foreach (RectTransform peer in peers) {
                if (peer == null) continue;
                Vector2 pc = (Vector2)c.transform.InverseTransformPoint(peer.position);
                Vector2 ps = CanvasSize(peer, c);
                float pl = pc.x - ps.x * peer.pivot.x;
                float prr = pc.x + ps.x * (1f - peer.pivot.x);
                float l = center.x - size.x * rt.pivot.x;
                float rr = center.x + size.x * (1f - rt.pivot.x);
                TrySnap(pl, l, threshold, ref bestDx);
                TrySnap(pc.x, center.x, threshold, ref bestDx);
                TrySnap(prr, rr, threshold, ref bestDx);
                TrySnap(pl, rr, threshold, ref bestDx);
                TrySnap(prr, l, threshold, ref bestDx);
                float pb = pc.y - ps.y * peer.pivot.y;
                float pt = pc.y + ps.y * (1f - peer.pivot.y);
                float b = center.y - size.y * rt.pivot.y;
                float t2 = center.y + size.y * (1f - rt.pivot.y);
                TrySnap(pb, b, threshold, ref bestDy);
                TrySnap(pc.y, center.y, threshold, ref bestDy);
                TrySnap(pt, t2, threshold, ref bestDy);
                TrySnap(pb, t2, threshold, ref bestDy);
                TrySnap(pt, b, threshold, ref bestDy);
            }
            if (bestDx == 0f && bestDy == 0f) return;
            Vector3 world = c.transform.TransformPoint(new Vector3(center.x + bestDx, center.y + bestDy, 0f));
            rt.position = world;
        }

        private static void TrySnap(float pPeerEdge, float pMyEdge, float pThreshold, ref float pBest) {
            float d = pPeerEdge - pMyEdge;
            if (Mathf.Abs(d) < pThreshold && Mathf.Abs(d) < Mathf.Abs(pBest)) pBest = d;
        }

        // 把矩形尺寸换算到画布本地空间
        private static Vector2 CanvasSize(RectTransform rt, Canvas c) {
            float sx = rt.lossyScale.x / Mathf.Max(0.0001f, c.transform.lossyScale.x);
            float sy = rt.lossyScale.y / Mathf.Max(0.0001f, c.transform.lossyScale.y);
            return new Vector2(rt.rect.width * sx, rt.rect.height * sy);
        }

        // ===== 全屏网格背景 =====

        private static Texture2D GridTexture() {
            if (_gridTex != null) return _gridTex;
            int tile = 8;
            _gridTex = new Texture2D(tile, tile, TextureFormat.RGBA32, false);
            for (int y = 0; y < tile; y++) {
                for (int x = 0; x < tile; x++) {
                    bool line = x == tile - 1 || y == tile - 1;
                    _gridTex.SetPixel(x, y, new Color(1f, 1f, 1f, line ? 1f : 0f));
                }
            }
            _gridTex.wrapMode = TextureWrapMode.Repeat;
            _gridTex.filterMode = FilterMode.Point;
            _gridTex.Apply();
            return _gridTex;
        }

        private static void ShowGrid(Instance inst) {
            if (inst.GridOverlay != null) return;
            Canvas c = inst.Canvas;
            if (c == null) return;
            GameObject go = new GameObject("LayoutGridOverlay", typeof(RectTransform), typeof(RawImage));
            go.transform.SetParent(c.transform, false);
            // 放在菜单下层:网格垫底,菜单与组件在上层清晰可见
            go.transform.SetSiblingIndex(inst.Menu.GetSiblingIndex());
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
            RawImage ri = go.GetComponent<RawImage>();
            ri.texture = GridTexture();
            ri.color = new Color(1f, 1f, 1f, 0.32f);
            ri.raycastTarget = false;
            RectTransform canvasRt = c.transform as RectTransform;
            float tile = inst.SnapGrid;
            if (canvasRt != null && tile > 0.01f) {
                ri.uvRect = new Rect(0f, 0f, canvasRt.rect.width / tile, canvasRt.rect.height / tile);
            }
            inst.GridOverlay = go;
        }

        private static void HideGrid(Instance inst) {
            if (inst.GridOverlay != null) {
                UnityEngine.Object.Destroy(inst.GridOverlay);
                inst.GridOverlay = null;
            }
        }

        // ===== 持久化 =====

        // 保存菜单内全部组件的位置+缩放(布局模式退出时兜底)
        private static void SaveAll(Instance inst) {
            LayoutPressable[] all = inst.Menu.GetComponentsInChildren<LayoutPressable>(true);
            foreach (LayoutPressable lp in all) {
                if (lp == null || lp.Target == null) continue;
                SaveEntry(inst.SaveKey, PathOf(inst.Menu, lp.Target),
                    lp.Target.anchoredPosition, lp.Target.localScale.x);
            }
        }

        // 保存单个组件的位置+缩放(松手/滚轮即记),格式:每行 "窗口key|组件路径=x,y,缩放"
        private static void SaveEntry(string pSaveKey, string pPath, Vector2 pPos, float pScale = 1f) {
            try {
                if (string.IsNullOrEmpty(pPath)) return;
                string key = pSaveKey + "|" + pPath;
                List<string> lines = new List<string>();
                if (File.Exists(FilePath)) {
                    string[] all = File.ReadAllLines(FilePath);
                    foreach (string line in all) {
                        if (string.IsNullOrEmpty(line)) continue;
                        if (line.StartsWith(key + "=")) continue; // 覆盖旧条目
                        lines.Add(line);
                    }
                }
                string val = pPos.x.ToString("F1", System.Globalization.CultureInfo.InvariantCulture) + ","
                    + pPos.y.ToString("F1", System.Globalization.CultureInfo.InvariantCulture)
                    + "," + pScale.ToString("F2", System.Globalization.CultureInfo.InvariantCulture);
                lines.Add(key + "=" + val);
                File.WriteAllLines(FilePath, lines.ToArray());
                Main.LogInfo("生物学:记住组件位置 " + key + " = " + val);
            } catch (Exception ex) {
                Main.LogError("生物学:保存布局失败 " + ex);
            }
        }

        // 读取全部已保存位置+缩放:路径 → 坐标/缩放
        private static Dictionary<string, SavedPos> LoadData() {
            Dictionary<string, SavedPos> map = new Dictionary<string, SavedPos>();
            try {
                if (!File.Exists(FilePath)) {
                    Main.LogInfo("生物学:布局文件不存在 " + FilePath);
                    return map;
                }
                string[] all = File.ReadAllLines(FilePath);
                foreach (string line in all) {
                    if (string.IsNullOrEmpty(line)) continue;
                    int eq = line.IndexOf('=');
                    if (eq <= 0) continue;
                    string key = line.Substring(0, eq);
                    string val = line.Substring(eq + 1);
                    int comma = val.IndexOf(',');
                    int comma2 = val.IndexOf(',', comma + 1);
                    float x, y, scale = 1f;
                    // y 必须只取到第二个逗号为止,否则 "-0.9,1.40" 整段解析失败导致整行丢弃
                    string yStr = comma2 > 0 ? val.Substring(comma + 1, comma2 - comma - 1) : val.Substring(comma + 1);
                    if (comma > 0 &&
                        float.TryParse(val.Substring(0, comma), System.Globalization.NumberStyles.Float,
                            System.Globalization.CultureInfo.InvariantCulture, out x) &&
                        float.TryParse(yStr, System.Globalization.NumberStyles.Float,
                            System.Globalization.CultureInfo.InvariantCulture, out y)) {
                        // 旧格式只有 x,y;新格式附带 ,缩放
                        if (comma2 > 0) {
                            float.TryParse(val.Substring(comma2 + 1), System.Globalization.NumberStyles.Float,
                                System.Globalization.CultureInfo.InvariantCulture, out scale);
                        }
                        SavedPos sp = new SavedPos();
                        sp.Pos = new Vector2(x, y);
                        sp.Scale = scale;
                        map[key] = sp;
                        Main.LogInfo("生物学:读到布局 " + key + " -> (" + x + "," + y + ") x" + scale);
                    } else {
                        Main.LogError("生物学:布局行解析失败,已跳过: [" + line + "]");
                    }
                }
            } catch (Exception ex) {
                Main.LogError("生物学:读取布局失败 " + ex);
            }
            return map;
        }

        // 应用已保存的布局(在布局组重建完成后调用,且之后不再触发重建)
        private static void ApplySaved(RectTransform pMenu, string pSaveKey) {
            try {
                Dictionary<string, SavedPos> map = LoadData();
                Main.LogInfo("生物学:应用布局 " + pSaveKey + ",共 " + map.Count + " 条");
                if (map.Count == 0) return;
                string prefix = pSaveKey + "|";
                foreach (KeyValuePair<string, SavedPos> kv in map) {
                    if (!kv.Key.StartsWith(prefix)) continue;
                    RectTransform target = FindByPath(pMenu, kv.Key.Substring(prefix.Length));
                    if (target != null) {
                        ApplyCellLayout(target, kv.Value);
                        Main.LogInfo("生物学:已应用 " + kv.Key + " 位置(" + kv.Value.Pos.x + "," + kv.Value.Pos.y
                            + ") 缩放x" + Mathf.Max(0.1f, kv.Value.Scale) + " -> 实际位置(" + target.anchoredPosition.x + ","
                            + target.anchoredPosition.y + ") 实际缩放x" + target.localScale.x);
                    } else {
                        Main.LogError("生物学:找不到组件路径,已跳过: " + kv.Key);
                    }
                }
            } catch (Exception ex) {
                Main.LogError("生物学:读取布局失败 " + ex);
            }
        }

        // 从窗口根节点到目标的路径(按名称+同名索引,如 "OpGrid/GridBtn@2")
        private static string PathOf(RectTransform pRoot, RectTransform pTarget) {
            List<string> parts = new List<string>();
            RectTransform cur = pTarget;
            while (cur != null && cur != pRoot) {
                parts.Add(SegmentOf(cur));
                cur = cur.parent as RectTransform;
            }
            if (cur == null) return null;
            parts.Reverse();
            return string.Join("/", parts);
        }

        private static string SegmentOf(RectTransform pRect) {
            string name = pRect.name;
            int idx = 0;
            Transform parent = pRect.parent;
            foreach (Transform t in parent) {
                if (t == pRect) return name + "@" + idx;
                if (t.name == name) idx++;
            }
            return name + "@0";
        }

        private static RectTransform FindByPath(RectTransform pRoot, string pPath) {
            RectTransform cur = pRoot;
            foreach (string seg in pPath.Split('/')) {
                int at = seg.LastIndexOf('@');
                string name = at >= 0 ? seg.Substring(0, at) : seg;
                int want = at >= 0 ? int.Parse(seg.Substring(at + 1)) : 0;
                RectTransform found = null;
                int idx = 0;
                foreach (Transform t in cur) {
                    if (t.name == name) {
                        if (idx == want) {
                            found = t as RectTransform;
                            break;
                        }
                        idx++;
                    }
                }
                if (found == null) return null;
                cur = found;
            }
            return cur;
        }
    }
}
