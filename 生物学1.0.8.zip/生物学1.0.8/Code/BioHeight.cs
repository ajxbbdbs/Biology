using System;
using UnityEngine;

namespace RimWorldMod {

    /// <summary>
    /// 单位身高。身高不进存档,而是由单位 id 定死地推出来 —— 同一个单位每次打开面板都是同一个数,
    /// 关掉游戏再进来也一样,省掉一套存档字段。
    ///
    /// 当前规则(暂定,等以后做种族/血统再细化):
    ///   成年(>= AdultAge 岁)     : AdultMinM ~ AdultMaxM 之间取一个定值
    ///   成年 + 「巨大」特质       : GiantMinM ~ GiantMaxM
    ///   成年 + 「渺小」特质       : TinyMinM ~ TinyMaxM
    ///   未成年                   : 从出生身高 BirthM 线性长到它自己的成年身高
    ///
    /// 巨大和渺小在原版里互为对立特质(ActorTraitLibrary 里两边都 addOpposite),不会同时出现;
    /// 万一被别的模组硬塞成同时有,按渺小算。
    /// </summary>
    public static class BioHeight {

        public const float AdultMinM = 1.55f;   // 成年下限
        public const float AdultMaxM = 1.89f;   // 成年上限
        public const float GiantMinM = 2.00f;   // 巨大特质下限
        public const float GiantMaxM = 2.50f;   // 巨大特质上限
        // 渺小特质:模组里这条特质绑的是侏儒症(见 DiseaseLibrary),所以按侏儒的身高段给,
        // 上限压在成年下限之下留一段空档 —— 带渺小的单位不该和最矮的普通人一样高
        public const float TinyMinM = 1.00f;    // 渺小特质下限
        public const float TinyMaxM = 1.35f;    // 渺小特质上限
        public const float BirthM = 0.50f;      // 出生身高
        public const float AdultAge = 16f;      // 到这个岁数算长齐

        /// <summary> 成年段的中位数,取不到单位时拿它兜底,免得布局算出 0 </summary>
        public static float DefaultM { get { return (AdultMinM + AdultMaxM) * 0.5f; } }

        /// <summary> 单位身高(米) </summary>
        public static float MetersOf(Actor pActor) {
            if (pActor == null) return DefaultM;
            try {
                bool tiny = IsTiny(pActor);
                bool giant = !tiny && IsGiant(pActor);
                float lo = tiny ? TinyMinM : (giant ? GiantMinM : AdultMinM);
                float hi = tiny ? TinyMaxM : (giant ? GiantMaxM : AdultMaxM);
                // 定死的"随机":种子只跟单位 id 有关,所以同一个单位每次都是同一个身高。
                // 巨大/渺小各用一份盐,后天获得或失去特质的单位身高会跟着变一次,这是有意的。
                int salt = tiny ? 0x27D4EB2F : (giant ? 0x51ED2701 : 0x2545F491);
                float adult = Mathf.Lerp(lo, hi, Frac01(Seed(pActor) ^ salt));

                float age = AgeOf(pActor);
                // age <= 0 一律当成年:真婴儿画成大人只是不好看,而万一某个版本的 getAge()
                // 对成年单位也返回 0,反过来就会把满地的大人全画成 0.5 米,那才是灾难。
                if (age >= AdultAge || age <= 0f) return adult;
                // 未成年:出生身高 → 成年身高 直线长。真实生长曲线以后再说。
                // 渺小的成年身高比出生身高还是高不少,所以这条直线不会反着走。
                return Mathf.Lerp(BirthM, adult, Mathf.Clamp01(age / AdultAge));
            } catch (Exception e) {
                Main.LogError("生物学:计算身高失败 " + e);
                return DefaultM;
            }
        }

        /// <summary> 身高上限(米):画尺子时用来判断该画到哪一段 </summary>
        public static float MaxMetersOf(Actor pActor) {
            if (IsTiny(pActor)) return TinyMaxM;
            return IsGiant(pActor) ? GiantMaxM : AdultMaxM;
        }

        /// <summary> 是否带「巨大」特质 </summary>
        public static bool IsGiant(Actor pActor) {
            return HasTrait(pActor, "giant", "巨大", "Giant");
        }

        /// <summary> 是否带「渺小」特质 </summary>
        public static bool IsTiny(Actor pActor) {
            return HasTrait(pActor, "tiny", "渺小", "侏儒", "Tiny");
        }

        // 先比 id,对不上再退一步看译名 —— 有些整合包会改 id
        private static bool HasTrait(Actor pActor, string pId, params string[] pNames) {
            if (pActor == null) return false;
            try {
                if (pActor.traits == null) return false;
                foreach (ActorTrait t in pActor.traits) {
                    if (t == null) continue;
                    if (!string.IsNullOrEmpty(t.id) &&
                        string.Equals(t.id, pId, StringComparison.OrdinalIgnoreCase)) return true;
                    string n = t.getTranslatedName();
                    if (string.IsNullOrEmpty(n)) continue;
                    for (int i = 0; i < pNames.Length; i++) {
                        if (n.Contains(pNames[i])) return true;
                    }
                }
            } catch (Exception e) {
                Main.LogInfo("生物学:读取特质 " + pId + " 失败 " + e.Message);
            }
            return false;
        }

        // getAge() 的返回类型在不同版本里不一定是 int,用 Convert 兜一层,免得编译期挑不到重载
        private static float AgeOf(Actor pActor) {
            try { return Convert.ToSingle(pActor.getAge()); } catch { return AdultAge; }
        }

        // 单位的稳定种子:优先用存档里的数字 id,拿不到再退到 getID()
        private static int Seed(Actor pActor) {
            try {
                if (pActor.data != null && pActor.data.id != 0L) return pActor.data.id.GetHashCode();
            } catch { }
            try { return pActor.getID().GetHashCode(); } catch { }
            return 0;
        }

        // 把种子打散成 0..1。用 System.Random 而不是自己搓位运算,保证同种子同结果
        private static float Frac01(int pSeed) {
            return (float)new System.Random(pSeed).NextDouble();
        }
    }
}
