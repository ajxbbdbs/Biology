using System;
using System.Collections.Generic;
using UnityEngine;

namespace RimWorldMod {

    /// <summary>
    /// 发色。游戏原版没有发色数据(单位贴图里头发就是王国色),所以这里自己定一套,
    /// 世界里的小人和面板立绘共用同一份,保证两边永远同色:
    ///   · 小人:头部贴图里用 Marker0..3 这四个关键色画头发,烘贴图时换成下面的 4 级明暗
    ///           (走法和原版把绿色系换肤色、品红系换衣服色完全一样,见 BioHeadHair)
    ///   · 立绘:body_Hair.png 整片是 #7F007F,换成同一套明暗里的主色调
    /// 默认按单位 id 在六色里定死一个(同一个单位每次看都一样),
    /// 玩家点立绘上的头发可以手动改,改动存在该单位的器官状态里。
    /// </summary>
    public static class BioHairColor {

        /// <summary>
        /// 头部贴图里代表头发的四个关键色,由深到浅。美术直接拿这四个色画头发,
        /// 运行时按单位发色换成 Ramps 里对应档位的颜色。
        /// </summary>
        public static readonly Color32 Marker0 = new Color32(150, 66, 83, 255);
        public static readonly Color32 Marker1 = new Color32(227, 105, 86, 255);
        public static readonly Color32 Marker2 = new Color32(255, 145, 102, 255);
        public static readonly Color32 Marker3 = new Color32(255, 181, 112, 255);

        /// <summary> 一种发色的明暗档数,和 Marker0..3 一一对应 </summary>
        public const int Shades = 4;

        public const int Count = 6;

        // 0=黑 1=暗红 2=黄 3=绿 4=蓝 5=白,每行 4 级由深到浅
        // 黑不用纯黑、白不用纯白:小人只有几个像素,两头顶死了会和描边/高光糊在一起
        private static readonly Color32[][] Ramps = {
            new[] { new Color32( 23,  23,  28, 255), new Color32( 38,  38,  46, 255),
                    new Color32( 56,  56,  66, 255), new Color32( 78,  78,  90, 255) },
            new[] { new Color32( 58,  14,  20, 255), new Color32( 92,  26,  31, 255),
                    new Color32(126,  42,  42, 255), new Color32(160,  58,  51, 255) },
            new[] { new Color32(138,  90,  22, 255), new Color32(192, 138,  34, 255),
                    new Color32(229, 178,  58, 255), new Color32(255, 217, 122, 255) },
            new[] { new Color32( 18,  58,  28, 255), new Color32( 31, 107,  50, 255),
                    new Color32( 47, 155,  73, 255), new Color32( 88, 206, 116, 255) },
            new[] { new Color32( 19,  42,  82, 255), new Color32( 34,  65, 127, 255),
                    new Color32( 55,  99, 180, 255), new Color32( 95, 146, 230, 255) },
            new[] { new Color32(142, 147, 158, 255), new Color32(178, 184, 194, 255),
                    new Color32(213, 218, 226, 255), new Color32(246, 249, 255, 255) },
        };
        private static readonly string[] Names = { "黑", "暗红", "黄", "绿", "蓝", "白" };

        /// <summary>
        /// 白发那一档。跟六色色板是分开的:它不是玩家能选的发色,而是"上了年纪"的覆盖色,
        /// 深浅照着原版老年头贴图上那串灰阶定的。
        /// </summary>
        private static readonly Color32[] WhiteRamp = {
            new Color32(122, 122, 128, 255), new Color32(168, 168, 174, 255),
            new Color32(202, 202, 208, 255), new Color32(230, 230, 236, 255),
        };

        /// <summary> 该发色的 4 级明暗(0=最深,下标与 Marker0..3 对应) </summary>
        public static Color32[] RampOf(int pIndex) {
            return Ramps[((pIndex % Count) + Count) % Count];
        }

        /// <summary> pWhite=true 时不管选的是什么发色,一律用白发那一档 </summary>
        public static Color32[] RampOf(int pIndex, bool pWhite) {
            return pWhite ? WhiteRamp : RampOf(pIndex);
        }

        /// <summary> 该单位的 4 级明暗(明智单位自动变白发) </summary>
        public static Color32[] RampFor(Actor pActor) {
            return RampOf(GetIndex(pActor), IsWhiteHaired(pActor));
        }

        /// <summary>
        /// 这个单位现在该不该是白发。
        ///
        /// 原版的规则:有"明智"特质、而且这个种族有老年头贴图时,小人会换成 head_old_male /
        /// head_old_female,那两张图的头发本来就是灰白的。立绘和头像框得跟着白,否则同一个单位
        /// 世界里一头白发、面板里还是黑发。发色档位本身不动,只是显示时被白发盖过去。
        /// </summary>
        public static bool IsWhiteHaired(Actor pActor) {
            if (pActor == null) return false;
            try {
                if (!pActor.hasTrait("wise")) return false;
                return HasOldHeads(pActor);
            } catch {
                return false;
            }
        }

        /// <summary> 这个单位的贴图组里有没有老年头(亚种换皮的话按换皮那套算,和原版取法一致) </summary>
        public static bool HasOldHeads(Actor pActor) {
            try {
                ActorTextureSubAsset tex = null;
                if (pActor.hasSubspecies() && pActor.subspecies != null
                    && pActor.subspecies.has_mutation_reskin
                    && pActor.subspecies.mutation_skin_asset != null) {
                    tex = pActor.subspecies.mutation_skin_asset.texture_asset;
                } else if (pActor.asset != null) {
                    tex = pActor.asset.texture_asset;
                }
                return tex != null && tex.has_old_heads;
            } catch {
                return false;
            }
        }

        /// <summary>
        /// 这个像素是不是发色关键色。返回 0..3 = 对应的明暗档,-1 = 不是。
        /// 只比 RGB:半透明边缘像素保留自己的 alpha。
        /// </summary>
        public static int MarkerSlot(Color32 pColor) {
            if (pColor.r == 150 && pColor.g ==  66 && pColor.b ==  83) return 0;
            if (pColor.r == 227 && pColor.g == 105 && pColor.b ==  86) return 1;
            if (pColor.r == 255 && pColor.g == 145 && pColor.b == 102) return 2;
            if (pColor.r == 255 && pColor.g == 181 && pColor.b == 112) return 3;
            return -1;
        }

        /// <summary> 该单位当前发色档位(未手动指定过就按 id 定死一个) </summary>
        public static int GetIndex(Actor pActor) {
            if (pActor == null) return 0;
            long id = 0;
            try { id = pActor.getID(); } catch { return 0; }
            return GetIndexById(id);
        }

        /// <summary>
        /// 只拿单位 id 查发色。UI 头像框那条链路(DynamicActorSpriteCreatorUI)手里没有 Actor,
        /// 只有 data.id,而发色本来就只跟 id 有关,所以两边查出来的一定是同一个结果。
        /// </summary>
        public static int GetIndexById(long pActorId) {
            try {
                ActorWoundState state;
                if (HealthSimulator.TryGetState(pActorId, out state)
                    && state != null && state.Mods != null && state.Mods.HairColor >= 0) {
                    return state.Mods.HairColor % Count;
                }
            } catch { }
            return AutoIndexById(pActorId);
        }

        /// <summary> 按单位 id 摊到六色上:同一单位结果恒定,不同单位分布均匀 </summary>
        public static int AutoIndexById(long pActorId) {
            // 先做一次整数散列,避免连号 id 出现"黑暗红黄绿蓝白"循环的规律
            long h = pActorId * 2654435761L;
            h ^= h >> 13;
            int v = (int)(h % Count);
            if (v < 0) v += Count;
            return v;
        }

        public static void SetIndex(Actor pActor, int pIndex) {
            if (pActor == null) return;
            try {
                ActorWoundState state = HealthSimulator.GetState(pActor.getID());
                if (state == null || state.Mods == null) return;
                state.Mods.HairColor = ((pIndex % Count) + Count) % Count;
            } catch (Exception e) {
                Main.LogError("生物学:设置发色失败 " + e);
            }
        }

        /// <summary>
        /// 该发色的主色调 = 明暗档里的 2 号。头部贴图上这一档占的面积最大,
        /// 立绘那片 #7F007F 和色板格子都用它,所以两边看上去是同一个颜色。
        /// </summary>
        public static Color32 ColorOf(int pIndex) {
            return RampOf(pIndex)[2];
        }

        public static string NameOf(int pIndex) {
            string zh = Names[((pIndex % Count) + Count) % Count];
            return BioText.T("bio_hair_color_" + zh, zh);
        }
    }

    /// <summary>
    /// 肤色色板。一格 = 一个「表型 + 明暗档」组合,颜色直接取表型资源里的那一档,
    /// 和亚种修改器里那排色块同源(那边也是按表型资源的 colors 铺格子)。
    ///
    /// 格子直接从 AssetManager.phenotype_library.list 枚举,取每个表型资源自己的 phenotype_index
    /// 和它的 4 级明暗色,不做序号猜测。
    /// </summary>
    public static class BioSkinColor {

        private const int Shades = 4;          // = PhenotypeLibrary.PHENOTYPE_SHADES
        private const int PhenotypeNone = 0;   // = PhenotypeLibrary.PHENOTYPE_NONE

        public class Swatch {
            public int Phenotype;
            public int Shade;
            public Color32 Color;
        }

        private static List<Swatch> _all;

        /// <summary> 所有可选肤色格子(首次调用时枚举并缓存) </summary>
        public static List<Swatch> All() {
            if (_all != null) return _all;
            _all = new List<Swatch>();
            try {
                PhenotypeLibrary lib = AssetManager.phenotype_library;
                if (lib == null || lib.list == null) return _all;
                foreach (PhenotypeAsset pa in lib.list) {
                    if (pa == null || pa.colors == null || pa.colors.Length < Shades) continue;
                    // 0 号是 PHENOTYPE_NONE,意思是"这个单位的皮肤不上色"。选它世界里的小人不会有
                    // 任何变化(贴图缓存键里 0 号连明暗档都会被丢掉),所以不能放进色板。
                    if (pa.phenotype_index == PhenotypeNone) continue;
                    for (int s = 0; s < Shades; s++) {
                        _all.Add(new Swatch { Phenotype = pa.phenotype_index, Shade = s, Color = pa.colors[s] });
                    }
                }
                Main.LogInfo("生物学:肤色色板 表型数=" + (_all.Count / Shades) + " 格子数=" + _all.Count);
            } catch (Exception e) {
                Main.LogError("生物学:枚举肤色色板失败 " + e);
            }
            return _all;
        }

        public static bool IsCurrent(Actor pActor, Swatch pSwatch) {
            if (pActor == null || pSwatch == null) return false;
            try {
                return pActor.data != null
                    && pActor.data.phenotype_index == pSwatch.Phenotype
                    && pActor.data.phenotype_shade == pSwatch.Shade;
            } catch {
                return false;
            }
        }

        /// <summary> 换肤色:只写这一个单位自己的表型数据,同表型的其他单位不受影响 </summary>
        public static void Apply(Actor pActor, Swatch pSwatch) {
            if (pActor == null || pSwatch == null) return;
            try {
                if (pActor.data == null) return;
                pActor.data.phenotype_index = pSwatch.Phenotype;
                pActor.data.phenotype_shade = pSwatch.Shade;
                // 立绘那套换色贴图按肤色指纹缓存,指纹变了要丢掉重烘
                BioDollSkin.Invalidate();
                // 世界里那个小人贴图每次动画换帧都会自己重算(链路见下),这里清一下它的上色缓存,
                // 让站着不动、动画不换帧的单位也能立刻变色
                try { pActor.clearLastColorCache(); }
                catch (Exception e) { Main.LogError("生物学:清单位上色缓存失败 " + e); }
                Main.LogInfo("生物学:肤色已改为 表型#" + pSwatch.Phenotype + " 明暗#" + pSwatch.Shade);
            } catch (Exception e) {
                Main.LogError("生物学:设置肤色失败 " + e);
            }
        }

        // 小人贴图的上色链路(读 Actor / DynamicSpriteCreator 的 IL 确认过,不是猜的):
        //   getSpriteToRender → checkSpriteToRender → asset.need_colored_sprite ? calculateColoredSprite
        //   calculateColoredSprite 里 isColoredSpriteNeedsCheck 只比 _last_main_sprite 和王国配色,
        //   所以动画一换帧就会重算,并且是现读 data.phenotype_index / phenotype_shade,
        //   然后交给 DynamicSpriteCreator.getSpriteUnit,它的缓存键是
        //     王国色index_id*1e12 + 头部图id*1e9 + 身体图id*1e6 + 表型序号*1e3 + 明暗档
        //   —— 表型在键里,所以改了序号必然缓存不中,会重新烘一张,不需要额外清全局缓存。
        //
        // 两个坑:
        //   1. 0 号表型是 PHENOTYPE_NONE(不上色),而且键里 0 号连明暗档都不参与,所以选它没反应。
        //      色板已经把 0 号排除掉了。
        //   2. Actor.generatePhenotypeAndShade() 会按 subspecies 重抽表型,但全程序只有
        //      generatePersonality() 一处调用(出生时),所以我们写进 data 的值不会被回滚。
    }

    /// <summary>
    /// 人物立绘的关键色换色。
    ///
    /// 美术贴图直接沿用原版单位贴图的调色板键:
    ///   绿色系 #B8FF96 / #00FF00 / #00AF00 / #4A831F = Toolbox.color_phenotype_green_0..3(肤色键)
    ///   品红系 #FF00FF / #DE00DE / #A700A7 / #7F007F / #580058 = Toolbox.color_magenta_0..4(王国色键=衣服色)
    /// 换色目标与原版 DynamicColorPixelTool.checkSpecialColors 一致:
    ///   绿色 → 该单位表型(肤色)的 4 级明暗;品红 → 该单位王国配色的 5 级明暗(毛发层改取发色)。
    /// 因此人类/精灵/矮人/兽人各自会套用自己的肤色与衣服颜色,不需要为每个种族单独出图。
    ///
    /// 匹配不是"逐像素比对关键色",而是按 FitKey 拟合一条关键色斜坡(见那里的说明)。
    /// 原因:手绘带抗锯齿的图(男性那套就是)只有八九成像素正好落在关键色上,剩下的是关键色
    /// 与描边之间的过渡、以及美术自己在两个关键色之间调出来的中间色。只认精确值的话这些像素
    /// 会原样留下 —— 深肤色单位身上每条边都镶一圈荧光绿。拟合把它们一起换掉,而正好等于关键色的
    /// 像素拟合结果必然是 (u=0, s=1, n=0),换出来和查表一模一样,所以旧的女性素材表现不变。
    ///
    /// 生成的贴图按不透明像素包围盒裁剪,一份调色板只保留一套纹理,
    /// 切换到肤色/王国色不同的单位时整套重建。
    /// </summary>
    public static class BioDollSkin {

        /// <summary> 换色后的单个部位:贴图 + 它在 340x882 画布里的位置(Cx 相对画布水平中心, CyTop 自画布顶边向下) </summary>
        public class Piece {
            public Sprite Sprite;
            public float Cx, CyTop, W, H;
        }

        // 单张源图的分析结果:裁剪后的原始像素 + 命中关键色的像素下标与拟合参数
        private class Source {
            public bool Usable;
            public int CanvasW, CanvasH;
            public int BoxX, BoxY, BoxW, BoxH;   // 包围盒(纹理坐标, Y 向上)
            public Color32[] Base;
            public int[] KeyIdx;
            public byte[] KeyId;                 // 1..4=绿色系(肤色档) 5..9=品红系(衣服/发色档)
            public byte[] KeyU;                  // 与下一档之间的混合位置 ×255
            public byte[] KeyS;                  // 明暗系数 ×200
            public byte[] KeyN;                   // 叠加的灰雾
        }

        private const int SkinShades = 4;
        private const int ClothShades = 5;

        /// <summary> 品红系关键色的取色来源:王国配色(衣服) / 发色(毛发层专用) </summary>
        public const int ClothFromKingdom = 0;
        public const int ClothFromHair = 1;

        private static readonly Dictionary<string, Source> _sources = new Dictionary<string, Source>();
        private static readonly Dictionary<string, Piece> _pieces = new Dictionary<string, Piece>();
        private static readonly List<UnityEngine.Object> _generated = new List<UnityEngine.Object>();
        private static string _paletteSig;

        private static readonly Color32[] _skin = new Color32[SkinShades];
        private static readonly Color32[] _cloth = new Color32[ClothShades];
        private static readonly Color32[] _hair = new Color32[ClothShades];

        /// <summary>
        /// 调色板指纹:表型(肤色)+ 王国配色 + 发色。指纹相同的单位共用同一套换色贴图。
        /// </summary>
        public static string Signature(Actor pActor) {
            int pheno = 0, shade = 0;
            string king = "-";
            try {
                if (pActor != null && pActor.data != null) {
                    pheno = pActor.data.phenotype_index;
                    shade = pActor.data.phenotype_shade;
                }
            } catch { }
            try {
                ColorAsset ca = GetKingdomColor(pActor);
                if (ca != null) king = ca.color_text + "/" + ca.color_main;
            } catch { }
            return pheno + ":" + shade + "|" + king + "|h" + BioHairColor.GetIndex(pActor)
                + (BioHairColor.IsWhiteHaired(pActor) ? "w" : "");
        }

        /// <summary>
        /// 取该单位的部位贴图(必要时重新换色)。返回 null 表示贴图缺失。
        /// pClothMode 决定品红系关键色换成王国衣服色还是发色。
        /// pTargetScale 是这张图最终会被缩到的倍率:贴图按这个倍率用面积平均预先缩好,
        /// 交给 GPU 时基本是 1:1。直接把 882px 的原图丢给 GPU 缩到 1/3 或 1/8,
        /// 无论开不开 mipmap 都会出现细线断裂或糊成一团的脏色块(脸上的"花纹"就是这么来的)。
        /// </summary>
        public static Piece Get(string pSpritePath, Actor pActor, int pClothMode, float pTargetScale) {
            string sig = Signature(pActor);
            if (sig != _paletteSig) {
                ResolvePalette(pActor);
                ClearGenerated();
                _paletteSig = sig;
            }
            int scaleTag = Mathf.Clamp(Mathf.RoundToInt(pTargetScale * 1000f), 1, 1000);
            string key = pSpritePath + "|" + pClothMode + "|" + scaleTag;
            Piece piece;
            if (_pieces.TryGetValue(key, out piece)) return piece;
            piece = Build(pSpritePath, pClothMode, scaleTag / 1000f);
            _pieces[key] = piece;
            return piece;
        }

        /// <summary>
        /// 中性版本:关键色不换成肤色/衣服色,而是换成同一套阶梯的灰白。
        ///
        /// 受伤上色时拿这一张再乘伤情色,得到的就是纯正的伤情色。要是拿按肤色染好的那张去乘,
        /// 深肤色单位乘完还是一团黑 —— 伤情根本看不出来,这也是当初"黑皮看不出受伤"的原因。
        /// </summary>
        public static Piece GetNeutral(string pSpritePath, int pClothMode, float pTargetScale) {
            int scaleTag = Mathf.Clamp(Mathf.RoundToInt(pTargetScale * 1000f), 1, 1000);
            string key = pSpritePath + "|n" + pClothMode + "|" + scaleTag;
            Piece piece;
            if (_pieces.TryGetValue(key, out piece)) return piece;

            // 临时把调色板换成灰白阶梯,复用同一套换色 + 预缩流程,烘完立刻还原
            Color32[] skinBak = (Color32[])_skin.Clone();
            Color32[] clothBak = (Color32[])_cloth.Clone();
            Color32[] hairBak = (Color32[])_hair.Clone();
            try {
                for (int i = 0; i < SkinShades; i++) _skin[i] = Gray(255 - i * 25);
                for (int i = 0; i < ClothShades; i++) {
                    Color32 g = Gray(255 - i * 25);
                    _cloth[i] = g;
                    _hair[i] = g;
                }
                piece = Build(pSpritePath, pClothMode, scaleTag / 1000f);
            } finally {
                Array.Copy(skinBak, _skin, SkinShades);
                Array.Copy(clothBak, _cloth, ClothShades);
                Array.Copy(hairBak, _hair, ClothShades);
            }
            _pieces[key] = piece;
            return piece;
        }

        private static Color32 Gray(int pLevel) {
            byte v = (byte)Mathf.Clamp(pLevel, 0, 255);
            return new Color32(v, v, v, 255);
        }

        /// <summary> 丢弃已生成的换色贴图(下次取用时重建) </summary>
        public static void Invalidate() {
            ClearGenerated();
            _paletteSig = null;
        }

        private static void ClearGenerated() {
            _pieces.Clear();
            for (int i = 0; i < _generated.Count; i++) {
                if (_generated[i] != null) UnityEngine.Object.Destroy(_generated[i]);
            }
            _generated.Clear();
        }

        // ===== 调色板 =====

        private static ColorAsset GetKingdomColor(Actor pActor) {
            try {
                if (pActor == null || pActor.kingdom == null) return null;
                return pActor.kingdom.getColor();
            } catch {
                return null;
            }
        }

        private static void ResolvePalette(Actor pActor) {
            // 肤色:表型基色 → 4 级明暗(与 DynamicColorPixelTool.loadPhenotype 相同)
            Color32 skinBase = Toolbox.makeColor("#F5D6BA");
            string phenoId = "默认";
            try {
                if (pActor != null && pActor.data != null && AssetManager.phenotype_library != null) {
                    PhenotypeAsset pa = AssetManager.phenotype_library
                        .getAssetByPhenotypeIndex(pActor.data.phenotype_index);
                    if (pa != null && pa.colors != null && pa.colors.Length >= SkinShades) {
                        skinBase = pa.colors[Mathf.Clamp(pActor.data.phenotype_shade, 0, SkinShades - 1)];
                        phenoId = pa.id + "(" + pa.shades_from + "→" + pa.shades_to + ")#"
                            + Mathf.Clamp(pActor.data.phenotype_shade, 0, SkinShades - 1);
                    }
                }
            } catch (Exception e) {
                Main.LogError("生物学:立绘取表型肤色失败 " + e);
            }
            _skin[0] = Toolbox.makeDarkerColor(skinBase, 1f);
            _skin[1] = Toolbox.makeDarkerColor(skinBase, 0.9f);
            _skin[2] = Toolbox.makeDarkerColor(skinBase, 0.8f);
            _skin[3] = Toolbox.makeDarkerColor(skinBase, 0.7f);
            // 衣服色:王国配色的 k 组明暗(与 ColorAsset.initColor 相同)
            ColorAsset ca = GetKingdomColor(pActor);
            bool gotKingdom = false;
            if (ca != null) {
                try {
                    ca.initColor();
                    _cloth[0] = ca.k_color_0;
                    _cloth[1] = ca.k_color_1;
                    _cloth[2] = ca.k_color_2;
                    _cloth[3] = ca.k_color_3;
                    _cloth[4] = ca.k_color_4;
                    gotKingdom = true;
                } catch (Exception e) {
                    Main.LogError("生物学:立绘取王国配色失败 " + e);
                }
            }
            if (!gotKingdom) {
                // 无王国(野人/宠物等):用中性灰按同一公式推明暗
                Color32 fallback = Toolbox.makeColor("#9AA3AD");
                Color32 dark = new Color32(30, 30, 30, 255);
                _cloth[0] = fallback;
                _cloth[1] = Color32.Lerp(fallback, dark, 0.13f);
                _cloth[2] = Color32.Lerp(fallback, dark, 0.35f);
                _cloth[3] = Color32.Lerp(fallback, dark, 0.51f);
                _cloth[4] = Color32.Lerp(fallback, dark, 0.66f);
            }

            // 发色:毛发层整片用的是 magenta_3,所以让 3 号档正好等于该发色的主色调
            // (= 头部贴图上 Marker2 换成的那个色),其余档位在同一条明暗阶梯上取深浅。
            // 这样小人的头发和面板立绘的头发是同一套颜色,不会一个金一个土。
            Color32[] ramp = BioHairColor.RampFor(pActor);
            _hair[0] = Color32.Lerp(ramp[3], Color.white, 0.35f);
            _hair[1] = ramp[3];
            _hair[2] = Color32.Lerp(ramp[2], ramp[3], 0.5f);
            _hair[3] = ramp[2];
            _hair[4] = ramp[0];

            Main.LogInfo("生物学:立绘配色 表型=" + phenoId
                + " 肤色=" + Hex(_skin[0]) + "/" + Hex(_skin[1]) + "/" + Hex(_skin[2]) + "/" + Hex(_skin[3])
                + " 衣服=" + Hex(_cloth[0]) + ".." + Hex(_cloth[4])
                + " 发色=" + Hex(_hair[3]) + "(" + BioHairColor.NameOf(BioHairColor.GetIndex(pActor))
                + (BioHairColor.IsWhiteHaired(pActor) ? ",明智→白发" : "") + ")");
        }

        private static string Hex(Color32 pColor) {
            return "#" + pColor.r.ToString("X2") + pColor.g.ToString("X2") + pColor.b.ToString("X2");
        }

        /// <summary>
        /// 拟合参数 → 实际颜色: out = lerp(档位i, 档位i+1, u) × s + n
        /// pKeyId 1..4 走肤色档(与 pClothMode 无关), 5..9 走衣服色或发色档。
        /// </summary>
        private static Color32 ColorForFit(byte pKeyId, byte pU, byte pS, byte pN, int pClothMode) {
            Color32[] ramp;
            int i;
            if (pKeyId <= SkinShades) {
                ramp = _skin;
                i = pKeyId - 1;
            } else {
                ramp = pClothMode == ClothFromHair ? _hair : _cloth;
                i = pKeyId - SkinShades - 1;
            }
            i = Mathf.Clamp(i, 0, ramp.Length - 1);
            int j = Mathf.Min(i + 1, ramp.Length - 1);
            float u = pU * (1f / 255f);
            float s = pS * (1f / 200f);
            float n = pN;
            return new Color32(
                ToByte((ramp[i].r + (ramp[j].r - ramp[i].r) * u) * s + n),
                ToByte((ramp[i].g + (ramp[j].g - ramp[i].g) * u) * s + n),
                ToByte((ramp[i].b + (ramp[j].b - ramp[i].b) * u) * s + n),
                255);
        }

        // ===== 贴图生成 =====

        private static Piece Build(string pSpritePath, int pClothMode, float pTargetScale) {
            Source src = GetSource(pSpritePath);
            if (src == null || !src.Usable) return null;

            Color32[] buf = new Color32[src.Base.Length];
            Array.Copy(src.Base, buf, buf.Length);
            for (int i = 0; i < src.KeyIdx.Length; i++) {
                int idx = src.KeyIdx[i];
                Color32 c = ColorForFit(src.KeyId[i], src.KeyU[i], src.KeyS[i], src.KeyN[i], pClothMode);
                c.a = buf[idx].a;   // 关键色像素保留原始透明度(边缘半透明不会变硬)
                buf[idx] = c;
            }

            // 按最终显示倍率预先缩好:面积平均(带 alpha 加权),细描边会变淡但不会断、不会串色
            int texW = src.BoxW, texH = src.BoxH;
            if (pTargetScale < 0.999f) {
                texW = Mathf.Max(1, Mathf.RoundToInt(src.BoxW * pTargetScale));
                texH = Mathf.Max(1, Mathf.RoundToInt(src.BoxH * pTargetScale));
                buf = Downsample(buf, src.BoxW, src.BoxH, texW, texH);
            }

            Texture2D tex = new Texture2D(texW, texH, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Bilinear;
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.SetPixels32(buf);
            tex.Apply(false, false);
            _generated.Add(tex);
            Main.LogInfo("生物学:烘立绘贴图 " + pSpritePath + " 倍率=" + pTargetScale.ToString("F3")
                + " " + src.BoxW + "x" + src.BoxH + " → " + texW + "x" + texH);

            Piece piece = new Piece();
            piece.Sprite = Sprite.Create(tex, new Rect(0f, 0f, texW, texH),
                new Vector2(0.5f, 0.5f), 1f, 0, SpriteMeshType.FullRect);
            _generated.Add(piece.Sprite);
            // W/H/Cx/CyTop 一律是设计空间(原始画布像素)的值,和贴图实际分辨率无关,
            // 这样调用方的布局算法不用管缩放
            piece.W = src.BoxW;
            piece.H = src.BoxH;
            piece.Cx = src.BoxX + src.BoxW * 0.5f - src.CanvasW * 0.5f;
            // 纹理 Y 向上,立绘设计空间 Y 向下 → 换算成"自画布顶边向下"的距离
            piece.CyTop = src.CanvasH - (src.BoxY + src.BoxH * 0.5f);
            return piece;
        }

        /// <summary>
        /// 面积平均缩图。按 alpha 加权累加再反算颜色(等价于预乘 alpha 下的盒式滤波),
        /// 否则透明像素的黑色会渗进边缘。Unity 自带的 mipmap 就是不做这一步,
        /// 所以细线会糊成脏色块。
        /// </summary>
        private static Color32[] Downsample(Color32[] pSrc, int pW, int pH, int pOutW, int pOutH) {
            Color32[] dst = new Color32[pOutW * pOutH];
            for (int oy = 0; oy < pOutH; oy++) {
                int y0 = oy * pH / pOutH;
                int y1 = (oy + 1) * pH / pOutH;
                if (y1 <= y0) y1 = y0 + 1;
                if (y1 > pH) y1 = pH;
                for (int ox = 0; ox < pOutW; ox++) {
                    int x0 = ox * pW / pOutW;
                    int x1 = (ox + 1) * pW / pOutW;
                    if (x1 <= x0) x1 = x0 + 1;
                    if (x1 > pW) x1 = pW;

                    float sr = 0f, sg = 0f, sb = 0f, sa = 0f;
                    int n = 0;
                    for (int y = y0; y < y1; y++) {
                        int row = y * pW;
                        for (int x = x0; x < x1; x++) {
                            Color32 c = pSrc[row + x];
                            float a = c.a * (1f / 255f);
                            sr += c.r * a;
                            sg += c.g * a;
                            sb += c.b * a;
                            sa += a;
                            n++;
                        }
                    }
                    Color32 o = new Color32(0, 0, 0, 0);
                    if (n > 0 && sa > 0.0001f) {
                        o.r = ToByte(sr / sa);
                        o.g = ToByte(sg / sa);
                        o.b = ToByte(sb / sa);
                        o.a = ToByte(sa / n * 255f);
                    }
                    dst[oy * pOutW + ox] = o;
                }
            }
            return dst;
        }

        private static byte ToByte(float pValue) {
            return (byte)Mathf.Clamp(Mathf.RoundToInt(pValue), 0, 255);
        }

        private static Source GetSource(string pSpritePath) {
            Source src;
            if (_sources.TryGetValue(pSpritePath, out src)) return src;
            src = Analyze(pSpritePath);
            _sources[pSpritePath] = src;
            return src;
        }

        // 扫描源图:求不透明像素包围盒,裁剪像素,记录命中关键色的位置
        private static Source Analyze(string pSpritePath) {
            Source src = new Source();
            Sprite sp = null;
            try { sp = SpriteTextureLoader.getSprite(pSpritePath); } catch { }
            if (sp == null || sp.texture == null) {
                Main.LogError("生物学:人物立绘缺少贴图 " + pSpritePath);
                return src;
            }

            Color32[] all;
            try {
                all = sp.texture.GetPixels32();
            } catch (Exception e) {
                Main.LogError("生物学:立绘贴图不可读,无法换色 " + pSpritePath + " " + e.Message);
                return src;
            }
            int w = sp.texture.width;
            int h = sp.texture.height;
            if (all == null || all.Length != w * h) return src;
            src.CanvasW = w;
            src.CanvasH = h;

            int minX = w, minY = h, maxX = -1, maxY = -1;
            for (int y = 0; y < h; y++) {
                int row = y * w;
                for (int x = 0; x < w; x++) {
                    if (all[row + x].a == 0) continue;
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }
            if (maxX < 0) return src;   // 全透明

            src.BoxX = minX;
            src.BoxY = minY;
            src.BoxW = maxX - minX + 1;
            src.BoxH = maxY - minY + 1;
            src.Base = new Color32[src.BoxW * src.BoxH];
            List<int> keyIdx = new List<int>();
            List<byte> keyId = new List<byte>();
            List<byte> keyU = new List<byte>();
            List<byte> keyS = new List<byte>();
            List<byte> keyN = new List<byte>();
            // 一张图上不同的颜色只有几百到几千种,拟合按颜色缓存,几万像素也只拟合几百次
            Dictionary<int, uint> fitted = new Dictionary<int, uint>();
            for (int y = 0; y < src.BoxH; y++) {
                int srcRow = (minY + y) * w + minX;
                int dstRow = y * src.BoxW;
                for (int x = 0; x < src.BoxW; x++) {
                    Color32 c = all[srcRow + x];
                    src.Base[dstRow + x] = c;
                    if (c.a == 0) continue;
                    int rgb = (c.r << 16) | (c.g << 8) | c.b;
                    uint packed;
                    if (!fitted.TryGetValue(rgb, out packed)) {
                        packed = FitKey(c);
                        fitted[rgb] = packed;
                    }
                    byte id = (byte)(packed >> 24);
                    if (id == 0) continue;
                    keyIdx.Add(dstRow + x);
                    keyId.Add(id);
                    keyU.Add((byte)((packed >> 16) & 0xFF));
                    keyS.Add((byte)((packed >> 8) & 0xFF));
                    keyN.Add((byte)(packed & 0xFF));
                }
            }
            src.KeyIdx = keyIdx.ToArray();
            src.KeyId = keyId.ToArray();
            src.KeyU = keyU.ToArray();
            src.KeyS = keyS.ToArray();
            src.KeyN = keyN.ToArray();
            src.Usable = true;
            Main.LogInfo("生物学:立绘贴图 " + pSpritePath + " 包围盒(" + src.BoxW + "x" + src.BoxH
                + ") 关键色像素=" + src.KeyIdx.Length + " 色数=" + fitted.Count);
            return src;
        }

        // ===== 关键色拟合 =====
        //
        // 一个手绘像素按这个模型解释:
        //     c = s × lerp(关键色[i], 关键色[i+1], u) + n
        //   s  这一档被压暗的程度(抗锯齿边缘向描边淡出)
        //   u  美术在相邻两个关键色之间调出来的中间色
        //   n  混进来的灰/白(高光、雾化的描边)
        // 换色时把关键色换成该单位的档位色、其余参数照搬:
        //     out = s × lerp(档位[i], 档位[i+1], u) + n
        //
        // 灰度像素(描边、纯白眼白)一律不动:max-min 小于 GraySpread 就直接判为非关键色。
        // 挑候选时给 n 和"压暗量"各加一点罚分 —— 不加的话有两处会判错:
        //   · 淡绿(#B8FF96)既可以读成"淡绿键原样",也可以读成"饱和绿键 + 一层厚白雾",
        //     后者换色后会变成惨白;罚 n 就会选前者。
        //   · 品红那 5 个键在 RGB 里是共线的(都是 (v,0,v)),#7F007F 既是 3 号键、
        //     也正好是 0 号键的 50% 亮度;罚"压暗量"才会选中 3 号键本身,
        //     这样它才换成王国配色的 3 号档,而不是 0 号档的一半亮度。

        private struct Cand {
            public byte Base;                    // 该候选对应的 KeyId
            public byte U;                       // 混合位置 ×255
            public float Kr, Kg, Kb;
            public float Kk, K1, Det;
        }

        private const int GraySpread = 24;       // 彩度门槛:低于此值算灰,不参与关键色
        private const float FitTol = 26f;        // 允许的最大逐通道残差
        private const float SMin = 0.06f;
        private const float SMax = 1.25f;
        private const float NPenalty = 0.05f;    // 每单位灰雾的罚分
        private const float SPenalty = 3f;       // 压到全黑的罚分
        private const int USteps = 8;

        private static Cand[] _candGreen;
        private static Cand[] _candMagenta;

        private static void EnsureCands() {
            if (_candGreen != null) return;
            Color32[] green = {
                Toolbox.color_phenotype_green_0, Toolbox.color_phenotype_green_1,
                Toolbox.color_phenotype_green_2, Toolbox.color_phenotype_green_3 };
            Color32[] magenta = {
                Toolbox.color_magenta_0, Toolbox.color_magenta_1, Toolbox.color_magenta_2,
                Toolbox.color_magenta_3, Toolbox.color_magenta_4 };
            // 候选表只算一次,所以万一 Toolbox 的调色板还没初始化就别缓存,
            // 否则这一局剩下的时间里所有关键色都会判不出来
            if (green[0].r == 0 && green[0].g == 0 && green[0].b == 0) {
                Main.LogError("生物学:Toolbox 调色板尚未初始化,本次跳过关键色拟合");
                return;
            }
            _candGreen = BuildCands(green, 1);
            _candMagenta = BuildCands(magenta, SkinShades + 1);
        }

        private static Cand[] BuildCands(Color32[] pKeys, int pBase) {
            List<Cand> list = new List<Cand>();
            for (int i = 0; i < pKeys.Length; i++) {
                int j = Mathf.Min(i + 1, pKeys.Length - 1);
                int steps = j == i ? 1 : USteps + 1;
                for (int st = 0; st < steps; st++) {
                    float u = steps > 1 ? st / (float)USteps : 0f;
                    Cand cd = new Cand();
                    cd.Base = (byte)(pBase + i);
                    cd.U = (byte)Mathf.RoundToInt(u * 255f);
                    cd.Kr = pKeys[i].r + (pKeys[j].r - pKeys[i].r) * u;
                    cd.Kg = pKeys[i].g + (pKeys[j].g - pKeys[i].g) * u;
                    cd.Kb = pKeys[i].b + (pKeys[j].b - pKeys[i].b) * u;
                    cd.Kk = cd.Kr * cd.Kr + cd.Kg * cd.Kg + cd.Kb * cd.Kb;
                    cd.K1 = cd.Kr + cd.Kg + cd.Kb;
                    cd.Det = cd.Kk * 3f - cd.K1 * cd.K1;
                    if (cd.Kk < 1f || Mathf.Abs(cd.Det) < 0.0001f) continue;
                    list.Add(cd);
                }
            }
            return list.ToArray();
        }

        /// <summary> 拟合一个像素,返回 KeyId&lt;&lt;24 | U&lt;&lt;16 | S&lt;&lt;8 | N;KeyId=0 表示不是关键色 </summary>
        private static uint FitKey(Color32 pColor) {
            if (pColor.r == 52 && pColor.g == 221 && pColor.b == 52)
                pColor = Toolbox.color_phenotype_green_2;
            else if (pColor.r == 57 && pColor.g == 134 && pColor.b == 57)
                pColor = Toolbox.color_phenotype_green_3;
            int mx = Mathf.Max(pColor.r, Mathf.Max(pColor.g, pColor.b));
            int mn = Mathf.Min(pColor.r, Mathf.Min(pColor.g, pColor.b));
            if (mx - mn < GraySpread) return 0;
            EnsureCands();
            if (_candGreen == null) return 0;
            Cand[] cands;
            if (pColor.g > pColor.r && pColor.g > pColor.b) cands = _candGreen;
            else if (pColor.r > pColor.g && pColor.b > pColor.g) cands = _candMagenta;
            else return 0;

            float ck = pColor.r + pColor.g + pColor.b;
            float bestScore = float.MaxValue, bestErr = 0f, bestS = 1f, bestN = 0f;
            int best = -1;
            for (int q = 0; q < cands.Length; q++) {
                Cand cd = cands[q];
                float dot = pColor.r * cd.Kr + pColor.g * cd.Kg + pColor.b * cd.Kb;
                // 最小二乘解 (s, n);n 被约束为非负,压边时退回只解 s
                float s = (dot * 3f - cd.K1 * ck) / cd.Det;
                float n = (cd.Kk * ck - cd.K1 * dot) / cd.Det;
                if (n < 0f) {
                    n = 0f;
                    s = dot / cd.Kk;
                }
                if (s < SMin) continue;
                if (s > SMax) {
                    s = SMax;
                    n = (ck - s * cd.K1) / 3f;
                    if (n < 0f) n = 0f;
                }
                if (n > 255f) continue;
                float err = Mathf.Max(Mathf.Abs(pColor.r - (s * cd.Kr + n)),
                    Mathf.Max(Mathf.Abs(pColor.g - (s * cd.Kg + n)),
                              Mathf.Abs(pColor.b - (s * cd.Kb + n))));
                float score = err + NPenalty * n + SPenalty * (1f - Mathf.Min(s, 1f));
                if (score < bestScore) {
                    bestScore = score;
                    bestErr = err;
                    bestS = s;
                    bestN = n;
                    best = q;
                }
            }
            if (best < 0 || bestErr > FitTol) return 0;
            uint sByte = (uint)Mathf.Clamp(Mathf.RoundToInt(bestS * 200f), 1, 250);
            uint nByte = (uint)Mathf.Clamp(Mathf.RoundToInt(bestN), 0, 255);
            return ((uint)cands[best].Base << 24) | ((uint)cands[best].U << 16) | (sByte << 8) | nByte;
        }
    }
}
