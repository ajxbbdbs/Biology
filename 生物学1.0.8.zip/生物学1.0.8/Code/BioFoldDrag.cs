using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace RimWorldMod {

    // 折叠按钮拖动:按住移动>4px 开始拖动(显示白色网格),按钮自由吸附在UI网格上移动(仅移动位置,不改Header高度)。
    // 展开(V)与折叠(Λ)位置各自独立保存,重开/切换恢复。
    public class BioFoldDrag : MonoBehaviour, IPointerDownHandler, IPointerUpHandler {
        public RectTransform Target;
        public bool Folded; // 当前是否折叠(Λ显示)

        private const string KeyLam = "biofold_lam=";
        private const string KeyVee = "biofold_vee=";
        private const float DragThreshold = 4f;
        private Button _btn;
        private bool _down;
        private bool _dragging;
        private bool _pendingRestore;
        private bool _gridShown;
        private bool _btnWasEnabled;
        private Vector2 _downPos;

        private static string FilePath {
            get { return Path.Combine(Application.persistentDataPath, "biology_layout.txt"); }
        }

        private float Grid {
            get { return LayoutEditor.GetSnapGrid(); }
        }

        private void Awake() {
            _btn = GetComponent<Button>();
        }

        public void OnPointerDown(PointerEventData e) {
            _down = true;
            _dragging = false;
            _gridShown = false;
            _downPos = e.position;
        }

        private void Update() {
            if (_pendingRestore) {
                _pendingRestore = false;
                if (_btn != null) _btn.interactable = _btnWasEnabled;
            }
            if (!_down) return;
            if (!_dragging) {
                if (Vector2.Distance(_downPos, Input.mousePosition) > DragThreshold) {
                    _dragging = true;
                    if (!_gridShown) {
                        _gridShown = true;
                        LayoutEditor.ShowGridOverlay(GetComponentInParent<Canvas>(), Grid);
                    }
                    if (_btn != null) {
                        _btnWasEnabled = _btn.interactable;
                        _btn.interactable = false;
                    }
                }
                return;
            }
            // 拖动中:按钮自由吸附在UI网格上移动(仅移动位置)
            if (Target == null) return;
            Vector3 mouseWorld;
            if (!RectTransformUtility.ScreenPointToWorldPointInRectangle(Target, Input.mousePosition, null, out mouseWorld)) return;
            Target.position = SnapToGrid(mouseWorld);
        }

        public void OnPointerUp(PointerEventData e) {
            if (_gridShown) {
                _gridShown = false;
                LayoutEditor.HideGridOverlay();
            }
            if (_dragging && Target != null) {
                Save(Folded ? KeyLam : KeyVee, Target.anchoredPosition);
                Main.LogInfo("生物学:折叠按钮位置已保存 " + (Folded ? "Λ" : "V") + " " + Target.anchoredPosition);
            }
            if (_btn != null && _dragging) {
                _pendingRestore = true;
            }
            _down = false;
            _dragging = false;
        }

        // 世界坐标 → 画布左下原点网格吸附 → 世界坐标(与背景网格 uvRect 对齐)
        private Vector3 SnapToGrid(Vector3 pWorld) {
            float g = Grid;
            if (g <= 0.01f) g = 8f;
            Canvas canvas = GetComponentInParent<Canvas>();
            RectTransform canvasRt = canvas != null ? canvas.transform as RectTransform : null;
            if (canvasRt == null) return pWorld;
            Vector2 cl = (Vector2)canvas.transform.InverseTransformPoint(pWorld);
            cl.x += canvasRt.rect.width * canvasRt.pivot.x;
            cl.y += canvasRt.rect.height * canvasRt.pivot.y;
            cl.x = Mathf.Round(cl.x / g) * g;
            cl.y = Mathf.Round(cl.y / g) * g;
            cl.x -= canvasRt.rect.width * canvasRt.pivot.x;
            cl.y -= canvasRt.rect.height * canvasRt.pivot.y;
            return canvas.transform.TransformPoint(cl);
        }

        // 读取 V/Λ 各自位置(默认:Λ y=13(尖端距底19), V y=11(尖端距底5))
        public static void Load(out Vector2 lam, out Vector2 vee) {
            lam = new Vector2(0f, 13f);
            vee = new Vector2(0f, 11f);
            Vector2? l = Read(KeyLam);
            Vector2? v = Read(KeyVee);
            if (l.HasValue) lam = l.Value;
            if (v.HasValue) vee = v.Value;
        }

        private static Vector2? Read(string key) {
            try {
                if (!File.Exists(FilePath)) return null;
                foreach (string line in File.ReadAllLines(FilePath)) {
                    if (string.IsNullOrEmpty(line) || !line.StartsWith(key)) continue;
                    string val = line.Substring(key.Length);
                    int c = val.IndexOf(',');
                    if (c <= 0) continue;
                    float x, y;
                    if (float.TryParse(val.Substring(0, c), NumberStyles.Float, CultureInfo.InvariantCulture, out x) &&
                        float.TryParse(val.Substring(c + 1), NumberStyles.Float, CultureInfo.InvariantCulture, out y)) {
                        return new Vector2(x, y);
                    }
                }
            } catch { }
            return null;
        }

        private static void Save(string key, Vector2 pos) {
            try {
                List<string> lines = new List<string>();
                if (File.Exists(FilePath)) {
                    foreach (string l in File.ReadAllLines(FilePath)) {
                        if (string.IsNullOrEmpty(l) || l.StartsWith(key)) continue;
                        lines.Add(l);
                    }
                }
                lines.Add(key + pos.x.ToString("F1", CultureInfo.InvariantCulture) + ","
                    + pos.y.ToString("F1", CultureInfo.InvariantCulture));
                File.WriteAllLines(FilePath, lines.ToArray());
            } catch (System.Exception ex) {
                Main.LogError("生物学:保存折叠按钮位置失败 " + ex);
            }
        }
    }
}
