using UnityEngine;
using UnityEngine.EventSystems;

namespace RimWorldMod {

    // 器官悬停提示:直接用 Unity 标准指针事件触发游戏原生 Tooltip
    public class OrganTooltip : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler {
        public string TipTitle;
        public string TipDescription;

        public void OnPointerEnter(PointerEventData pEvent) {
            if (string.IsNullOrEmpty(TipTitle) && string.IsNullOrEmpty(TipDescription)) return;
            try {
                Tooltip.show(gameObject, "tip", new TooltipData {
                    tip_name = TipTitle,
                    tip_description = TipDescription
                });
            } catch (System.Exception e) {
                Main.LogError("生物学:显示器官提示失败 " + e);
            }
        }

        public void OnPointerExit(PointerEventData pEvent) {
            try {
                Tooltip.hideTooltip();
            } catch (System.Exception e) {
                Main.LogError("生物学:隐藏器官提示失败 " + e);
            }
        }
    }
}
