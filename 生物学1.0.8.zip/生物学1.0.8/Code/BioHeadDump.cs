using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;

namespace RimWorldMod {

    /// <summary>
    /// 把原版四个文明种族的头部贴图整张导出成 png,并顺带诊断 GameResources/ui/heads/ 里
    /// 那些重绘图各自对得上哪一张原版贴图 —— 也就是"哪些文件名不对"。
    ///
    /// 导出的文件名就是 BioHeadHair 认得的形式(&lt;种族&gt;_&lt;原版贴图名&gt;.png),
    /// 照着重绘完直接丢进 GameResources/ui/heads/ 就能被接管,不用再靠像素猜。
    ///
    /// 写到模组目录下的「原版头部贴图」里,不写进 GameResources:那边的图会被当成重绘图去
    /// 认领原版贴图,把没有发色关键色的原图放进去只会每次启动刷报错。
    ///
    /// 触发方式:模组设置 → 功能开关 → 导出原版头部贴图,打开开关再关掉设置窗口即导出一次。
    /// 贴图要等资源加载完才读得到,所以只能在游戏里触发,不能在模组加载时做。
    /// </summary>
    public static class BioHeadDump {

        public const string FolderName = "原版头部贴图";
        private const string ReportName = "对照清单.txt";

        public static void Dump() {
            try {
                string root = Path.Combine(Main.Instance.GetDeclaration().FolderPath, FolderName);
                Directory.CreateDirectory(root);

                StringBuilder report = new StringBuilder();
                report.AppendLine("原版头部贴图导出 " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                report.AppendLine();

                List<BioHeadHair.Sheet> vanilla = WriteVanilla(root, report);
                WriteDiagnosis(vanilla, report);

                File.WriteAllText(Path.Combine(root, ReportName), report.ToString(), Encoding.UTF8);
                Main.LogInfo("生物学:原版头部贴图已导出到 " + root);
            } catch (Exception e) {
                Main.LogError("生物学:导出原版头部贴图失败 " + e);
            }
        }

        /// <summary>
        /// 一张一张导出原版贴图,同时把每张 sheet 里那些子精灵(head_0..head_11)的位置
        /// 和 pivot 记进清单 —— 重绘时要知道 12 个头各自占哪一格。
        /// </summary>
        private static List<BioHeadHair.Sheet> WriteVanilla(string pRoot, StringBuilder pReport) {
            List<BioHeadHair.Sheet> sheets = new List<BioHeadHair.Sheet>();
            HashSet<Texture2D> seen = new HashSet<Texture2D>();
            pReport.AppendLine("== 原版贴图 ==");
            foreach (string path in BioHeadHair.AllVanillaPaths()) {
                string key = BioHeadHair.KeyOfPath(path);
                Sprite[] arr = null;
                try { arr = SpriteTextureLoader.getSpriteList(path, true); } catch { }
                if (arr == null || arr.Length == 0) {
                    pReport.AppendLine(key + ".png   —— 这个种族没有这张贴图");
                    continue;
                }
                Texture2D tex = arr[0].texture;
                if (tex == null) {
                    pReport.AppendLine(key + ".png   —— 读不到贴图");
                    continue;
                }
                Color32[] px = BioHeadHair.ReadPixels(tex);
                if (px == null) {
                    pReport.AppendLine(key + ".png   —— 贴图不可读");
                    continue;
                }
                if (seen.Add(tex)) {
                    try {
                        File.WriteAllBytes(Path.Combine(pRoot, key + ".png"), EncodePng(tex, px));
                    } catch (Exception e) {
                        Main.LogError("生物学:写 " + key + ".png 失败 " + e);
                    }
                    sheets.Add(new BioHeadHair.Sheet {
                        Key = key, Texture = tex, Pixels = px, W = tex.width, H = tex.height,
                    });
                }
                pReport.AppendLine(key + ".png   " + tex.width + "x" + tex.height
                    + "   子精灵 " + arr.Length + " 个");
                foreach (Sprite sp in arr) {
                    Rect r = sp.rect;
                    Vector2 p = sp.pivot;
                    pReport.AppendLine("    " + sp.name + "   rect=(" + (int)r.x + "," + (int)r.y
                        + " " + (int)r.width + "x" + (int)r.height + ")   pivot=("
                        + p.x.ToString("0.##") + "," + p.y.ToString("0.##") + ")");
                }
            }
            pReport.AppendLine();
            return sheets;
        }

        private static byte[] EncodePng(Texture2D pSource, Color32[] pPixels) {
            Texture2D copy = new Texture2D(pSource.width, pSource.height, TextureFormat.RGBA32, false);
            copy.filterMode = FilterMode.Point;
            copy.SetPixels32(pPixels);
            copy.Apply(false, false);
            byte[] png = copy.EncodeToPNG();
            UnityEngine.Object.Destroy(copy);
            return png;
        }

        /// <summary>
        /// 逐个诊断 ui/heads 里的重绘图:尺寸、发色关键色有多少、和哪几张原版贴图对得上。
        /// "对得上"= 除发色关键色以外的像素完全一致。只有恰好一张对得上时才认得出来,
        /// 这里把所有情况都列出来,该改成什么文件名一目了然。
        /// </summary>
        private static void WriteDiagnosis(List<BioHeadHair.Sheet> pVanilla, StringBuilder pReport) {
            pReport.AppendLine("== GameResources/ui/heads 里的重绘图 ==");
            List<Sprite> mods = BioHeadHair.LoadModSheets();
            if (mods.Count == 0) {
                pReport.AppendLine("(一张都没有)");
                return;
            }
            foreach (Sprite m in mods) {
                Color32[] px = BioHeadHair.ReadPixels(m.texture);
                if (px == null) {
                    pReport.AppendLine(m.name + "   —— 贴图不可读");
                    continue;
                }
                int w = m.texture.width;
                int h = m.texture.height;
                int markers = 0;
                for (int i = 0; i < px.Length; i++) {
                    if (BioHairColor.MarkerSlot(px[i]) >= 0) markers++;
                }
                pReport.AppendLine(m.name + ".png   " + w + "x" + h + "   发色像素 " + markers + " 个");
                if (markers == 0) {
                    pReport.AppendLine("    没有发色关键色,不会被接管");
                }

                List<string> exact = new List<string>();
                List<KeyValuePair<int, string>> near = new List<KeyValuePair<int, string>>();
                foreach (BioHeadHair.Sheet s in pVanilla) {
                    int miss = BioHeadHair.Mismatch(px, s, w, h, int.MaxValue);
                    if (miss < 0) continue;
                    if (miss == 0) exact.Add(s.Key);
                    else near.Add(new KeyValuePair<int, string>(miss, s.Key));
                }
                if (exact.Count == 1) {
                    pReport.AppendLine("    认得出 → 改名成 " + exact[0] + ".png");
                } else if (exact.Count > 1) {
                    pReport.AppendLine("    和这几张都对得上,分不出来 → " + string.Join("、", exact.ToArray()));
                    pReport.AppendLine("    必须自己挑一个改成 <种族>_<原版贴图名>.png");
                } else if (near.Count > 0) {
                    near.Sort((a, b) => a.Key.CompareTo(b.Key));
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < near.Count && i < 6; i++) {
                        if (i > 0) sb.Append('、');
                        sb.Append(near[i].Value).Append("(差").Append(near[i].Key).Append(')');
                    }
                    pReport.AppendLine("    没有完全对得上的,最接近的 → " + sb);
                } else {
                    pReport.AppendLine("    尺寸和原版任何一张头部贴图都不一样");
                }
            }
        }
    }
}
