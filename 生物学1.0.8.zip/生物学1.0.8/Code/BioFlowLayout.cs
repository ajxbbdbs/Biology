using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace RimWorldMod {

    /// <summary>
    /// 器官条目的流式排版：短条目并排，过长条目独占整行并自动换行。
    /// 排版可以反复执行（宽度变化后、或布局稳定后再算一次真实行高），
    /// 每次都会把流容器的高度重算，黑框(GroupBox)的 ContentSizeFitter 随之向下扩充，
    /// 因此换行不会把后面的条目挤到框外。
    /// </summary>
    public class BioFlowLayout : MonoBehaviour {

        private const float LineHeight = 20f;   // 单行条目的行高
        private const float RowGap = 4f;        // 行间距
        private const float ItemGap = 8f;       // 同行条目间距

        public RectTransform Flow;              // 承载条目的流容器

        private readonly List<Text> _items = new List<Text>();

        public void AddItem(Text pText) {
            if (pText != null) _items.Add(pText);
        }

        public void Relayout(float pFlowWidth) {
            if (Flow == null || pFlowWidth < 20f) return;
            float x = 0f;
            float y = 0f;
            float maxY = 0f;

            for (int i = 0; i < _items.Count; i++) {
                Text t = _items[i];
                if (t == null) continue;
                RectTransform rt = t.rectTransform;
                if (rt == null) continue;

                float w = UnitHealthTab.EstimateTextWidth(t.text, t.fontSize) + 10f;
                if (w > pFlowWidth) {
                    // 单条过长(带疾病/来源说明):独占整行并自动换行
                    if (x > 0f) {
                        x = 0f;
                        y += LineHeight + RowGap;
                    }
                    t.horizontalOverflow = HorizontalWrapMode.Wrap;
                    t.alignment = TextAnchor.UpperLeft;
                    // 先按整行宽定尺寸,这样 preferredHeight 才是按这个宽度排版出来的真实高度
                    rt.sizeDelta = new Vector2(pFlowWidth, LineHeight);
                    float need = LineHeight * Mathf.Max(1, Mathf.CeilToInt(w / pFlowWidth));
                    float pref = 0f;
                    try { pref = t.preferredHeight; } catch { }
                    if (pref > 1f) need = Mathf.Max(LineHeight, pref + 4f);
                    rt.sizeDelta = new Vector2(pFlowWidth, need);
                    rt.anchoredPosition = new Vector2(0f, -y);
                    maxY = Mathf.Max(maxY, y + need);
                    y += need + RowGap;
                    x = 0f;
                } else {
                    t.horizontalOverflow = HorizontalWrapMode.Overflow;
                    t.alignment = TextAnchor.MiddleLeft;
                    if (x + w > pFlowWidth) {
                        x = 0f;
                        y += LineHeight + RowGap;
                    }
                    rt.sizeDelta = new Vector2(w, LineHeight);
                    rt.anchoredPosition = new Vector2(x, -y);
                    x += w + ItemGap;
                    maxY = Mathf.Max(maxY, y + LineHeight);
                }
            }

            Flow.sizeDelta = new Vector2(0f, maxY);
        }
    }
}
