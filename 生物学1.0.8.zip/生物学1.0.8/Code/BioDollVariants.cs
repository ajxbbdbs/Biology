using System;
using System.Collections.Generic;
using System.IO;

namespace RimWorldMod {

    /// <summary>
    /// 立绘上"一层有好几张可选贴图"的那些部位(发型、衣服)按单位挑一张。
    ///
    /// 用法:在 BioBodyDoll 的布局表里给这一层填 Variants = 目录名(ui/body/ 下的相对目录),
    /// 建立绘时就会从那个目录里按单位 id 挑一张。想加发型/衣服只要往目录里丢 png,不用改代码。
    ///
    /// 挑的是"目录里第几张",不是随机数:同一个单位每次看都是同一张,存档里也不用存东西。
    /// 代价是往目录里加删文件会让一部分单位换发型 —— 序号变了,挑中的自然就变了。
    ///
    /// 文件名不参与判定,只用来排序(按 ordinal 排,body_Hair 在 body_Hair1 前面)。
    /// 目录是直接扫模组文件夹拿的,不走资源树:资源树里精灵名和文件名不保证一致,而这里需要
    /// 一个跨启动稳定的顺序。
    /// </summary>
    public static class BioDollVariants {

        // 目录(ui/body/ 下的相对路径) → 该目录里的贴图名(不含扩展名),已排好序
        private static readonly Dictionary<string, string[]> _cache = new Dictionary<string, string[]>();

        private static readonly string[] Empty = new string[0];

        /// <summary> 这个目录下可选的贴图名(不含扩展名)。目录不存在或没有 png 时返回空数组 </summary>
        public static string[] Names(string pFolder) {
            if (string.IsNullOrEmpty(pFolder)) return Empty;
            string[] names;
            if (_cache.TryGetValue(pFolder, out names)) return names;
            names = Scan(pFolder);
            _cache[pFolder] = names;
            return names;
        }

        /// <summary>
        /// 这个单位在这个目录里挑中的下标。目录里只有一张(或一张都没有)时恒为 0,
        /// 所以美术只放一张图时行为和以前完全一样。
        /// </summary>
        public static int PickIndex(string pFolder, Actor pActor) {
            string[] names = Names(pFolder);
            if (names.Length <= 1) return 0;
            long id = 0;
            try { if (pActor != null) id = pActor.getID(); } catch { }
            return Mix(id, Salt(pFolder), names.Length);
        }

        /// <summary>
        /// 这个单位这一层该用哪张图,返回 ui/body/ 下的相对路径。
        /// 目录里一张 png 都没有时回退到 pFallback(布局表里写死的那张)。
        /// </summary>
        public static string Pick(string pFolder, string pFallback, Actor pActor) {
            string[] names = Names(pFolder);
            if (names.Length == 0) return pFallback;
            return pFolder + "/" + names[PickIndex(pFolder, pActor)];
        }

        // 扫模组目录。只在第一次用到某个目录时扫一次 —— 游戏运行中新丢进去的 png 不会被
        // NeoModLoader 注册成资源,扫到了也加载不了,所以没必要重复扫。
        private static string[] Scan(string pFolder) {
            try {
                string root = Main.Instance.GetDeclaration().FolderPath;
                string dir = Path.Combine(Path.Combine(root, "GameResources/ui/body"),
                    pFolder.Replace('/', Path.DirectorySeparatorChar));
                if (!Directory.Exists(dir)) {
                    Main.LogError("生物学:立绘可选贴图目录不存在 " + dir + " —— 这一层退回布局表里写死的那张");
                    return Empty;
                }
                string[] files = Directory.GetFiles(dir, "*.png");
                List<string> names = new List<string>(files.Length);
                for (int i = 0; i < files.Length; i++) {
                    names.Add(Path.GetFileNameWithoutExtension(files[i]));
                }
                names.Sort(StringComparer.Ordinal);
                Main.LogInfo("生物学:立绘可选贴图 " + pFolder + " 共" + names.Count + "张 "
                    + string.Join(" / ", names.ToArray()));
                return names.ToArray();
            } catch (Exception e) {
                Main.LogError("生物学:扫描立绘可选贴图目录失败 " + pFolder + " " + e);
                return Empty;
            }
        }

        // 单位 id → 下标。连号 id 直接取模会排出规律(第 1、2、3 个单位依次是第 1、2、3 张),
        // 所以先散列一遍;pSalt 让同一个单位在不同目录里挑到的下标互不相关,否则发型和衣服会
        // 永远同步变化。
        private static int Mix(long pId, long pSalt, int pCount) {
            long h = (pId + pSalt) * 2654435761L;
            h ^= h >> 13;
            h *= 1103515245L;
            h ^= h >> 16;
            int v = (int)(h % pCount);
            if (v < 0) v += pCount;
            return v;
        }

        // 目录名的 FNV-1a。不用 string.GetHashCode:那个不保证跨进程稳定,一变单位就换发型
        private static long Salt(string pFolder) {
            ulong h = 14695981039346656037UL;
            for (int i = 0; i < pFolder.Length; i++) {
                h ^= pFolder[i];
                h *= 1099511628211UL;
            }
            return (long)(h & 0x7FFFFFFFFFFFL);
        }
    }
}
