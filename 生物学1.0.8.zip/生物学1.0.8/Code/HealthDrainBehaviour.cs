using UnityEngine;

namespace RimWorldMod {

    // 持续扣血:呼吸衰竭/尿毒症/瘫痪等致命状态持续掉血,直到死亡
    public class HealthDrainBehaviour : MonoBehaviour {
        private float _lastCheck;

        private void Update() {
            try {
                if (Time.unscaledTime < _lastCheck + 0.2f) return;
                _lastCheck = Time.unscaledTime;

                // 只处理当前选中的单位,不进行任何场景扫描
                if (SelectedUnit.isSet()) {
                    Actor a = SelectedUnit.unit;
                    // 动物器官未启用时,动物完全不参与器官逻辑
                    if (a != null && HealthSimulator.IsOrganSupported(a)) {
                        // 器官缺失/受损 → 属性联动(血量/攻击/移速/攻速),每秒同步
                        OrganStats.ApplyStats(a);
                        // 大脑强化/弱化 → 智力加成实时同步
                        BrainStat.ApplyStats(a);
                        // 无胃 → 饱食度强制归零(兜底,主逻辑见 NutritionGuard 的 Harmony 补丁)
                        if (!HealthSimulator.HasStomach(a) && a.data != null && a.data.nutrition > 0) {
                            a.data.nutrition = 0;
                        }
                        // 刷新 Header 概览数值(让器官修改的影响实时可见)
                        UnitHealthTab.RefreshHeaderValues(a);
                        DrainIfCritical(a);
                    }
                }
            } catch (System.Exception e) {
                Main.LogError("生物学:持续扣血异常 " + e);
            }
        }

        // 呼吸衰竭/尿毒症/瘫痪等致命状态:持续扣血直到死亡
        private void DrainIfCritical(Actor pActor) {
            try {
                ActorWoundState state = HealthSimulator.GetState(pActor.getID());
                bool drain = false;
                float ratio = 0f;
                string reason = "";
                if (HasModDisease(state, "chest", "respiratory_failure")) {
                    drain = true;
                    ratio = 0.02f;
                    reason = "呼吸衰竭";
                }
                if (HasModDisease(state, "blood", "uremia")) {
                    drain = true;
                    ratio = 0.015f;
                    reason = "尿毒症";
                }
                if (HasModDisease(state, "blood", "internal_bleeding")) {
                    drain = true;
                    ratio = 0.03f;
                    reason = "内出血";
                }
                if (HasModDisease(state, "intestine", "no_stomach")) {
                    drain = true;
                    ratio = 0.02f;
                    reason = "无胃症";
                }
                if (HasModDisease(state, "intestine", "anal_blockage")) {
                    drain = true;
                    ratio = 0.01f;
                    reason = "肛门堵塞";
                }
                if (HasModDisease(state, "spine", "paralysis")) {
                    drain = true;
                    ratio = 0.01f;
                    reason = "瘫痪";
                }
                // 瘫痪:持续施加混乱,使其无法正常移动行动
                if (HasModDisease(state, "spine", "paralysis")) {
                    try {
                        pActor.makeConfused(-1f, true);
                    } catch (System.Exception ce) {
                        Main.LogError("生物学:瘫痪施加行动限制失败 " + ce);
                    }
                }
                // 扣到 0 为止(允许死亡)
                if (drain && pActor.getHealth() > 0f) {
                    pActor.getHit(pActor.getHealth() * ratio, false, AttackType.Divine, null, false, false, false);
                    Main.LogInfo("生物学:持续扣血 " + reason);
                }
            } catch (System.Exception e) {
                Main.LogError("生物学:持续扣血异常 " + e);
            }
        }

        private static bool HasModDisease(ActorWoundState pState, string pHost, string pDiseaseId) {
            if (pState == null || pState.Mods == null) return false;
            string cur;
            return pState.Mods.ModDiseases.TryGetValue(pHost, out cur) && cur == pDiseaseId;
        }
    }
}
