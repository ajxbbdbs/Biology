using UnityEngine;

namespace RimWorldMod {

    /// <summary>
    /// 矮人「变色装备」的金属色板。
    ///
    /// 美术把变色铠甲/变色头盔画成品红五级(#FF00FF/#DE00DE/#A700A7/#7F007F/#580058),
    /// 也就是原版拿来换王国衣服色的那五个关键色。烘贴图之前先由我们自己把这五级换成
    /// 装备材质对应的五级金属色(见 Ramps),换完图里就没有品红了,原版那套王国换色
    /// 自然就碰不到铠甲——所以同一个单位可以「铜甲 + 钢盔」,两件各自变色互不干扰。
    ///
    /// 材质 id 用的是原版 ItemAsset.material 的写法(注意秘银在原版里拼作 mythril)。
    /// </summary>
    public static class BioDwarfMetal {

        /// <summary> 品红五级关键色,由浅到深,和 Ramps 里每行的下标一一对应 </summary>
        public static int MarkerSlot(Color32 pColor) {
            if (pColor.r == 255 && pColor.g ==   0 && pColor.b == 255) return 0;
            if (pColor.r == 222 && pColor.g ==   0 && pColor.b == 222) return 1;
            if (pColor.r == 167 && pColor.g ==   0 && pColor.b == 167) return 2;
            if (pColor.r == 127 && pColor.g ==   0 && pColor.b == 127) return 3;
            if (pColor.r ==  88 && pColor.g ==   0 && pColor.b ==  88) return 4;
            return -1;
        }

        /// <summary> 一种金属的明暗档数 </summary>
        public const int Shades = 5;

        /// <summary> 能变色的金属数量(下标 0..Count-1,另有 -1 表示「不变色」) </summary>
        public const int Count = 6;

        // 由浅到深五级。铜和铁最深两级美术给的是同一个色,原样保留。
        // 秘银美术只给了四级,最深那一级按铜/铁的写法重复一次(见文件末尾说明)。
        private static readonly Color32[][] Ramps = {
            // 0 铜 copper
            new[] { new Color32(247, 159, 111, 255), new Color32(191, 142,  85, 255),
                    new Color32(131,  97,  55, 255), new Color32( 89,  50,  50, 255),
                    new Color32( 89,  50,  50, 255) },
            // 1 青铜 bronze
            new[] { new Color32(224, 174,  54, 255), new Color32(197, 154,  52, 255),
                    new Color32(169, 127,  25, 255), new Color32(104, 121,  59, 255),
                    new Color32( 75,  85,  44, 255) },
            // 2 铁 iron
            new[] { new Color32(157, 157, 157, 255), new Color32(115, 115, 115, 255),
                    new Color32( 74,  74,  74, 255), new Color32( 40,  40,  40, 255),
                    new Color32( 40,  40,  40, 255) },
            // 3 钢 steel
            new[] { new Color32(224, 224, 224, 255), new Color32(173, 173, 190, 255),
                    new Color32(127, 126, 156, 255), new Color32(104, 102, 127, 255),
                    new Color32( 75,  74,  93, 255) },
            // 4 银 silver
            new[] { new Color32(141, 222, 206, 255), new Color32(131, 191, 178, 255),
                    new Color32( 91, 158, 144, 255), new Color32( 69, 130, 117, 255),
                    new Color32( 54,  99,  89, 255) },
            // 5 秘银 mythril
            new[] { new Color32(  0, 211, 249, 255), new Color32( 26, 127, 173, 255),
                    new Color32( 50,  84, 134, 255), new Color32( 26,  49,  82, 255),
                    new Color32( 26,  49,  82, 255) },
        };

        private static readonly string[] Ids = {
            "copper", "bronze", "iron", "steel", "silver", "mythril",
        };

        private static readonly string[] Names = { "铜", "青铜", "铁", "钢", "银", "秘银" };

        /// <summary> 会走「换色」这条路的材质 → 金属下标;不在表里的返回 -1 </summary>
        public static int IndexOf(string pMaterial) {
            if (string.IsNullOrEmpty(pMaterial)) return -1;
            for (int i = 0; i < Ids.Length; i++) {
                if (Ids[i] == pMaterial) return i;
            }
            return -1;
        }

        /// <summary> 该金属的五级明暗(0=最浅);下标越界时取铁 </summary>
        public static Color32[] RampOf(int pIndex) {
            if (pIndex < 0 || pIndex >= Ramps.Length) return Ramps[2];
            return Ramps[pIndex];
        }

        public static string NameOf(int pIndex) {
            if (pIndex < 0 || pIndex >= Names.Length) return "无";
            return Names[pIndex];
        }

        /// <summary>
        /// 把一整块像素里的品红五级换成该金属的五级。pIndex 为 -1 时原样返回
        /// (留着让原版按王国色去换,休闲装/王袍就是走这条)。就地改传进来的数组。
        /// </summary>
        public static void Recolor(Color32[] pPixels, int pMetalIndex) {
            if (pPixels == null || pMetalIndex < 0) return;
            Color32[] ramp = RampOf(pMetalIndex);
            for (int i = 0; i < pPixels.Length; i++) {
                if (pPixels[i].a == 0) continue;
                int slot = MarkerSlot(pPixels[i]);
                if (slot < 0) continue;
                Color32 c = ramp[slot];
                c.a = pPixels[i].a;
                pPixels[i] = c;
            }
        }
    }
}
