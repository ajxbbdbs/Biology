using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace RimWorldMod {

    // 双性人(⚥)时,把游戏原生性别图标(Icon Sex)替换为原版"雌雄同体繁殖"贴图
    // 贴图路径来自亚种编辑器:trait_reproduction_hermaphroditic
    public static class SexIconSync {

        private static bool _loggedOnce;
        private static Sprite _hermaphSprite;
        private static bool _spriteResolved;

        // 候选路径:优先用 Mod 自带的雌雄同体图标
        private static readonly string[] HermaphSpriteCandidates = {
            "ui/icons/iconHermaphrodite",
            "ui/icons/iconIntersex",
            "ui/icons/iconSexes",
            "ui/icons/trait_reproduction_hermaphroditic",
        };

        public static Sprite ResolveHermaphSprite() {
            return GetHermaphSprite();
        }

        private static Sprite GetHermaphSprite() {
            if (_spriteResolved) return _hermaphSprite;
            _spriteResolved = true;
            foreach (string path in HermaphSpriteCandidates) {
                try {
                    Sprite s = SpriteTextureLoader.getSprite(path);
                    if (s != null) {
                        _hermaphSprite = s;
                        Main.LogInfo("生物学:[图标] 找到雌雄同体图标: " + path);
                        return s;
                    }
                } catch {
                }
            }
            Main.LogInfo("生物学:[图标] 候选路径均未命中,使用紫色 ⚥ 覆盖");
            return null;
        }

        // 在指定 Transform 下查找单位窗口标题行的性别图标并替换
        public static void SyncIconSex(Transform pRoot, Actor pActor) {
            if (pRoot == null || pActor == null) return;
            int gender = HealthSimulator.GetGender(pActor);
            string sexMale = "?";
            try { sexMale = pActor.isSexMale().ToString(); } catch (System.Exception e) { sexMale = "ERR:" + e.Message; }
            Main.LogInfo("生物学:[图标] SyncIconSex 根=" + pRoot.name + " actor=" + pActor.getName() + " gender=" + gender + " isSexMale=" + sexMale);
            if (gender != 3) {
                Main.LogInfo("生物学:[图标] 非双性(gender=" + gender + ") 直接return,交由原版驱动");
                return;
            }
            List<Transform> found = new List<Transform>();
            FindTitleIcon(pRoot, found);
            Main.LogInfo("生物学:[图标] 找到图标候选 " + found.Count + " 个(根=" + pRoot.name + ")");
            if (found.Count == 0) {
                Main.LogInfo("生物学:[图标] 未找到单位标题性别图标,根=" + pRoot.name);
                return;
            }
            Sprite hermaph = GetHermaphSprite();
            foreach (Transform t in found) {
                Main.LogInfo("生物学:[图标] 应用双性图标到 " + t.name + " 父=" + (t.parent != null ? t.parent.name : "null"));
                ApplyIntersex(t, hermaph);
            }
        }

        // 查找父链含 tab_title_container_unit 的 icon_left/icon_right(性别图标)
        private static void FindTitleIcon(Transform pRoot, List<Transform> pOut) {
            if (pRoot == null) return;
            if ((pRoot.name == "icon_left" || pRoot.name == "icon_right")
                && HasAncestor(pRoot, "tab_title_container_unit")) {
                pOut.Add(pRoot);
            }
            for (int i = 0; i < pRoot.childCount; i++) {
                FindTitleIcon(pRoot.GetChild(i), pOut);
            }
        }

        private static bool HasAncestor(Transform t, string pName) {
            Transform cur = t.parent;
            int guard = 0;
            while (cur != null && guard < 20) {
                if (cur.name == pName) return true;
                cur = cur.parent;
                guard++;
            }
            return false;
        }

        private static void ApplyIntersex(Transform t, Sprite pHermaph) {
            RectTransform rt = t as RectTransform;
            if (rt == null) rt = t.GetComponent<RectTransform>();
            if (rt == null) return;

            Image img = t.GetComponent<Image>();
            if (img != null) {
                img.raycastTarget = false;
                if (pHermaph != null) {
                    // 直接替换为雌雄同体贴图(不设 overrideSprite,避免阻断动画组件)
                    img.enabled = true;
                    img.sprite = pHermaph;
                    img.color = Color.white;
                    img.type = Image.Type.Simple;
                    img.preserveAspect = true;
                    DestroyOverlay(t);
                    return;
                }
                // 无贴图:原 Image 染紫色
                img.enabled = true;
                img.color = new Color(0.75f, 0.40f, 1f, 1f);
            }

            // 叠加 ⚥ 覆盖文字
            Transform overlay = t.Find("RimWorldSexOverlay");
            Text txt = overlay != null ? overlay.GetComponent<Text>() : null;
            if (txt == null) {
                if (overlay == null) {
                    GameObject go = new GameObject("RimWorldSexOverlay", typeof(RectTransform));
                    go.transform.SetParent(t, false);
                    overlay = go.transform;
                }
                RectTransform ort = overlay as RectTransform;
                if (ort != null) {
                    ort.anchorMin = Vector2.zero;
                    ort.anchorMax = Vector2.one;
                    ort.offsetMin = Vector2.zero;
                    ort.offsetMax = Vector2.zero;
                }
                txt = overlay.gameObject.AddComponent<Text>();
            }
            txt.font = LocalizedTextManager.current_font != null
                ? LocalizedTextManager.current_font
                : Resources.GetBuiltinResource<Font>("Arial.ttf");
            txt.fontSize = 16;
            txt.fontStyle = FontStyle.Bold;
            txt.color = Color.white;
            txt.alignment = TextAnchor.MiddleCenter;
            txt.horizontalOverflow = HorizontalWrapMode.Overflow;
            txt.verticalOverflow = VerticalWrapMode.Overflow;
            txt.raycastTarget = false;
            txt.text = "⚥";
        }

        private static void DestroyOverlay(Transform t) {
            Transform overlay = t.Find("RimWorldSexOverlay");
            if (overlay != null) {
                UnityEngine.Object.Destroy(overlay.gameObject);
            }
        }
    }
}
