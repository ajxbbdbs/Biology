using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace RimWorldMod {

    /// <summary> 点已故名单里的一行 → 复活他 </summary>
    public class BioGraveClick : MonoBehaviour, UnityEngine.EventSystems.IPointerClickHandler {
        public long Id;
        public string Who;

        public void OnPointerClick(UnityEngine.EventSystems.PointerEventData pEvent) {
            try {
                Main.LogInfo("生物学:请求复活 <" + Who + "> id=" + Id);
                if (BioResurrect.Resurrect(Id)) {
                    BioGraveTab.Render();
                }
            } catch (Exception e) {
                Main.LogError("生物学:复活点击失败 " + e);
            }
        }
    }

    /// <summary>
    /// 单位窗口上的「已故收藏」标签。
    ///
    /// 为什么单独开一个标签而不是塞进原版收藏栏:原版那套列表(WindowFavorites)从 getObjects 到
    /// showElement(Actor) 全程都要一个活着的 Actor,而死亡之后唯一可信的只有 BioResurrect 存的
    /// 那份 data 快照(踩过的坑见 BioResurrect 类头)。所以这里自己画行,只读快照,不碰原版列表。
    ///
    /// 标签是照 UnitHealthTab.EnsureTab 那套做法克隆现有 WindowMetaTab 得来的,区别是:
    ///   · 图标用原版收藏夹那张 ui/Icons/iconFavoritesList
    ///   · 追加在标签列表末尾(不 Insert 到前面),左边那一列已经排满了
    ///   · tab_elements 留空 —— 这是一份全局名单,不需要把 Header 那些格子跟着点亮
    /// </summary>
    public static class BioGraveTab {

        public const string TabName = "RimWorldGraveTab";
        private const string TitleKey = "bio_grave_tab_title";
        private const string DescKey = "bio_grave_tab_desc";
        private const string TitleFallback = "已故收藏";
        private const string DescFallback = "已死去的收藏单位,数据仍保留着";
        private const string IconPath = "ui/Icons/iconFavoritesList";
        /// <summary> 标签插在第几位。生物学那个占的是 4,这个紧跟其后,才会落在窗口右边那一列里 </summary>
        private const int TabSlot = 5;

        private static readonly Color ColorGold = new Color(1f, 0.84f, 0.35f, 1f);
        private static readonly Color ColorGray = new Color(0.72f, 0.74f, 0.78f, 1f);
        private static readonly Color ColorDim = new Color(0.55f, 0.57f, 0.60f, 1f);
        private static readonly Color ColorRevive = new Color(0.55f, 0.90f, 0.60f, 1f);

        private static UnitWindow _window;
        private static Transform _content;
        private static WindowMetaTab _tab;
        private static float _width = 240f;

        public static bool IsTab(WindowMetaTab pTab) {
            return pTab != null && pTab.name == TabName;
        }

        /// <summary> 在单位窗口上挂出标签(每个窗口只挂一次) </summary>
        public static void Ensure(UnitWindow pWindow) {
            if (pWindow == null) return;
            if (_window == pWindow && _tab != null) return;
            try {
                RegisterLocales();
                Transform tabsContainer = pWindow.transform.Find("Background/Tabs");
                Transform realContent = pWindow.transform.Find("Background/Scroll View/Viewport/Content");
                if (tabsContainer == null || realContent == null) {
                    Main.LogError("生物学:已故收藏标签找不到挂载点");
                    return;
                }
                // 已经挂过了(窗口被原版重建过但标签还在)
                Transform exist = tabsContainer.Find(TabName);
                if (exist != null) {
                    _window = pWindow;
                    _tab = exist.GetComponent<WindowMetaTab>();
                    return;
                }

                WindowMetaTab source = null;
                for (int i = 0; i < tabsContainer.childCount; i++) {
                    source = tabsContainer.GetChild(i).GetComponent<WindowMetaTab>();
                    if (source != null) break;
                }
                if (source == null) {
                    Main.LogError("生物学:已故收藏标签找不到可克隆的标签");
                    return;
                }

                WindowMetaTab tab = UnityEngine.Object.Instantiate(source, tabsContainer);
                tab.name = TabName;
                // 排在生物学标签后面。上一版用 SetAsLastSibling 追加,结果标签列溢出、
                // 折到了窗口左边那一列去 —— 那一列本来就满了,所以改成插进右边这一列里。
                tab.transform.SetSiblingIndex(TabSlot);
                tab.tab_action = new WindowMetaTabEvent();
                if (tab._tip_button != null) {
                    tab._tip_button.textOnClick = TitleKey;
                    tab._tip_button.textOnClickDescription = DescKey;
                }
                tab._worldtip_text = tab.getWorldTipText();

                Transform iconT = tab.transform.Find("Icon");
                if (iconT != null) {
                    Image img = iconT.GetComponent<Image>();
                    if (img != null) {
                        Sprite sp = null;
                        try { sp = SpriteTextureLoader.getSprite(IconPath); } catch { }
                        if (sp != null) img.sprite = sp;
                        else Main.LogError("生物学:已故收藏标签取不到图标 " + IconPath);
                    }
                }

                GameObject container = new GameObject("RimWorldGraveContent",
                    typeof(RectTransform), typeof(VerticalLayoutGroup),
                    typeof(ContentSizeFitter), typeof(LayoutElement));
                container.transform.SetParent(realContent, false);
                RectTransform crt = container.GetComponent<RectTransform>();
                crt.anchorMin = new Vector2(0f, 1f);
                crt.anchorMax = new Vector2(0f, 1f);
                crt.pivot = new Vector2(0f, 1f);
                crt.anchoredPosition = Vector2.zero;
                // 宽度必须显式给,不然 sizeDelta.x 是 0,子元素拿到的宽也是 0,文字会一个字一行
                // (上一版就是这样"已故收藏:1 / 人"断成两行的)。走 UnitHealthTab 那套算法,和生物学面板同宽。
                _width = UnitHealthTab.ResolveWidth(pWindow, realContent);
                if (_width < 60f) _width = 240f;
                crt.sizeDelta = new Vector2(_width, 0f);
                LayoutElement cle = container.GetComponent<LayoutElement>();
                cle.minWidth = _width;
                cle.preferredWidth = _width;
                cle.flexibleWidth = 0f;
                VerticalLayoutGroup vlg = container.GetComponent<VerticalLayoutGroup>();
                vlg.childControlWidth = true;
                vlg.childForceExpandWidth = true;
                vlg.childControlHeight = true;
                vlg.childForceExpandHeight = false;
                vlg.spacing = 5f;
                vlg.childAlignment = TextAnchor.UpperLeft;
                vlg.padding = new RectOffset(10, 10, 8, 8);
                ContentSizeFitter fitter = container.GetComponent<ContentSizeFitter>();
                fitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
                fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

                tab.tab_elements = new List<Transform>();   // 全局名单,不牵动 Header 的格子
                tab.container = pWindow.tabs;
                pWindow.tabs._tabs.Add(tab);
                pWindow.tabs.addTabContent(tab, container.transform);
                pWindow.tabs.refillTabsWithContent();

                tab.tab_action.AddListener((WindowMetaTab t) => {
                    try {
                        pWindow.showTab(t);
                        Render();
                    } catch (Exception e) {
                        Main.LogError("生物学:已故收藏标签动作失败 " + e);
                    }
                });

                _window = pWindow;
                _tab = tab;
                _content = container.transform;
                // 标签具体落在窗口哪一列是原版 refillTabsWithContent 的布局决定的,只能事后看。
                // 把这一列现在的排布打出来,位置不对时照着调 TabSlot 就行。
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.Append("生物学:已故收藏标签已挂出 槽位=").Append(TabSlot)
                  .Append(" 本列共").Append(tabsContainer.childCount).Append("个:");
                for (int i = 0; i < tabsContainer.childCount; i++) {
                    sb.Append(' ').Append(i).Append('=').Append(tabsContainer.GetChild(i).name);
                }
                Main.LogInfo(sb.ToString());
            } catch (Exception e) {
                Main.LogError("生物学:挂出已故收藏标签失败 " + e);
            }
        }

        /// <summary>
        /// 重画名单。版式照收藏夹那个窗口来:上面一条深色标题栏(左边标题、右边人数),
        /// 下面一个带边框的框子装名单。名单只在有人死时才变,切到本标签时画一次就够。
        /// </summary>
        public static void Render() {
            try {
                if (_content == null) return;
                for (int i = _content.childCount - 1; i >= 0; i--) {
                    UnityEngine.Object.DestroyImmediate(_content.GetChild(i).gameObject);
                }
                int n = BioResurrect.Count;
                AddHeaderBar(BioText.T("bio_grave_header", "所有已故收藏单位"), n.ToString());

                Transform box = AddFrame();
                if (n == 0) {
                    Text empty = AddText(box, BioText.T("bio_grave_empty", "还没有收藏单位死去。"),
                        11, ColorDim, FontStyle.Normal);
                    empty.alignment = TextAnchor.MiddleCenter;
                    return;
                }
                List<BioResurrect.Grave> graves = BioResurrect.All();
                for (int i = 0; i < graves.Count; i++) {
                    BioResurrect.Grave g = graves[i];
                    string king = g.WasKing ? BioText.T("bio_grave_king", "  <color=#FFD700>· 国王</color>") : "";
                    Text name = AddText(box, g.Name + king, 12, ColorGray, FontStyle.Bold);
                    AddText(box, BioText.F("bio_grave_line", "{0} · 卒于第 {1} 天",
                        g.AssetId, Mathf.FloorToInt((float)g.DiedTime)), 10, ColorDim, FontStyle.Normal);
                    // 整行名字就是复活按钮
                    Text act = AddText(box, BioText.T("bio_grave_revive", "  ▸ 点这里复活"),
                        11, ColorRevive, FontStyle.Bold);
                    act.raycastTarget = true;
                    BioGraveClick click = act.gameObject.AddComponent<BioGraveClick>();
                    click.Id = g.Id;
                    click.Who = g.Name;
                    name.raycastTarget = true;
                    BioGraveClick click2 = name.gameObject.AddComponent<BioGraveClick>();
                    click2.Id = g.Id;
                    click2.Who = g.Name;
                }
                AddText(box, BioText.T("bio_grave_note",
                    "复活会连关系与身份一起还原;生前是国王且王国还在的会重新加冕。"),
                    10, ColorDim, FontStyle.Italic);
            } catch (Exception e) {
                Main.LogError("生物学:重画已故收藏失败 " + e);
            }
        }

        // 深色标题栏:左边标题、右边计数,和收藏夹那条"所有已收藏单位 | 0"一个意思
        private static void AddHeaderBar(string pTitle, string pCount) {
            GameObject bar = new GameObject("Header", typeof(RectTransform), typeof(Image), typeof(LayoutElement));
            bar.transform.SetParent(_content, false);
            Image bg = bar.GetComponent<Image>();
            ApplyPanelSprite(bg, new Color(0.07f, 0.08f, 0.06f, 0.95f));
            LayoutElement le = bar.GetComponent<LayoutElement>();
            le.minHeight = 22f;
            le.preferredHeight = 22f;

            Text title = AddText(bar.transform, pTitle, 12, ColorGold, FontStyle.Bold);
            Stretch(title.rectTransform, 8f, 40f);
            title.alignment = TextAnchor.MiddleLeft;

            Text count = AddText(bar.transform, pCount, 12, ColorGold, FontStyle.Bold);
            Stretch(count.rectTransform, _width - 40f, 8f);
            count.alignment = TextAnchor.MiddleRight;
        }

        // 带边框的框子,名单画在里面
        private static Transform AddFrame() {
            GameObject box = new GameObject("Frame", typeof(RectTransform), typeof(Image),
                typeof(VerticalLayoutGroup), typeof(ContentSizeFitter));
            box.transform.SetParent(_content, false);
            ApplyPanelSprite(box.GetComponent<Image>(), new Color(0.10f, 0.11f, 0.09f, 0.92f));
            VerticalLayoutGroup vlg = box.GetComponent<VerticalLayoutGroup>();
            vlg.childControlWidth = true;
            vlg.childForceExpandWidth = true;
            vlg.childControlHeight = true;
            vlg.childForceExpandHeight = false;
            vlg.spacing = 3f;
            vlg.childAlignment = TextAnchor.UpperLeft;
            vlg.padding = new RectOffset(10, 10, 8, 8);
            ContentSizeFitter csf = box.GetComponent<ContentSizeFitter>();
            csf.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
            csf.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            return box.transform;
        }

        // 原版那张九宫格底板:取不到就退化成纯色块,不至于什么都不显示
        private static void ApplyPanelSprite(Image pImage, Color pColor) {
            if (pImage == null) return;
            pImage.color = pColor;
            pImage.raycastTarget = false;
            Sprite sp = null;
            try { sp = SpriteTextureLoader.getSprite("ui/special/windowInnerSliced"); } catch { }
            if (sp == null) { try { sp = SpriteTextureLoader.getSprite("ui/special/button"); } catch { } }
            if (sp == null) { pImage.type = Image.Type.Simple; return; }
            pImage.sprite = sp;
            pImage.type = sp.border == Vector4.zero ? Image.Type.Simple : Image.Type.Sliced;
            pImage.fillCenter = true;
        }

        private static void Stretch(RectTransform pRt, float pLeft, float pRight) {
            pRt.anchorMin = new Vector2(0f, 0f);
            pRt.anchorMax = new Vector2(1f, 1f);
            pRt.offsetMin = new Vector2(pLeft, 0f);
            pRt.offsetMax = new Vector2(-pRight, 0f);
        }

        private static Text AddText(Transform pParent, string pText, int pSize, Color pColor, FontStyle pStyle) {
            GameObject go = new GameObject("Row", typeof(RectTransform), typeof(Text));
            go.transform.SetParent(pParent, false);
            Text t = go.GetComponent<Text>();
            t.font = LocalizedTextManager.current_font;
            t.fontSize = pSize;
            t.color = pColor;
            t.fontStyle = pStyle;
            t.text = pText;
            t.alignment = TextAnchor.UpperLeft;
            t.horizontalOverflow = HorizontalWrapMode.Wrap;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            t.raycastTarget = false;
            t.supportRichText = true;
            return t;
        }

        // 标签的悬停标题/说明走游戏自己的本地化表,Locales 里的 json 也有同名键,这里只是兜底
        private static void RegisterLocales() {
            try {
                if (LocalizedTextManager.instance == null
                    || LocalizedTextManager.instance._localized_text == null) return;
                if (!LocalizedTextManager.instance._localized_text.ContainsKey(TitleKey)) {
                    LocalizedTextManager.instance._localized_text[TitleKey] = TitleFallback;
                }
                if (!LocalizedTextManager.instance._localized_text.ContainsKey(DescKey)) {
                    LocalizedTextManager.instance._localized_text[DescKey] = DescFallback;
                }
            } catch (Exception e) {
                Main.LogError("生物学:注册已故收藏标签本地化失败 " + e);
            }
        }
    }
}
