using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace RimWorldMod {

    /// <summary>
    /// 小人(世界里那个几像素高的单位)头发接管。干两件事:
    ///
    /// 1. 头部贴图接管:把 GameResources/ui/heads/ 下重绘过的整张头部贴图,顶掉原版
    ///    actors/species/civs/{human,elf,dwarf,orc}/ 里同尺寸的那一张。原版一张 sheet
    ///    切了 12 个头(head_0..head_11),这里按原版子精灵自己的 rect 从重绘图上取同一
    ///    块像素,pivot 照抄,所以头的位置一个像素都不会偏。
    ///    (NeoModLoader 的 GameResources 覆盖是"目录节点 + 精灵名"匹配的,单张 png 丢在
    ///     ui/heads 下顶不掉 sheet 里的子精灵,所以只能走代码接管这条路。)
    ///
    /// 2. 发色换色:重绘图里的头发用 BioHairColor.Marker0..3 四个关键色画(由深到浅),
    ///    烘单位贴图时换成该单位发色的 4 级明暗。换色发生的位置和原版把绿色系换肤色、
    ///    品红系换王国衣服色是同一处(DynamicSpriteCreator 往图集铺像素的时候),
    ///    发色也进了贴图缓存键,否则同王国同肤色的两个单位会共用同一张缓存图。
    ///
    /// 重绘图的文件名可以直接写成 &lt;种族&gt;_&lt;原版贴图名&gt;(如 human_heads_male.png)来
    /// 指定顶掉哪一张;没按这个格式命名时(例如从游戏里导出的 "heads_male #2405.png"),
    /// 会拿"非头发像素"和原版四个种族的贴图逐像素比对,自动认出是哪一张,认完写日志。
    /// </summary>
    public static class BioHeadHair {

        // 重绘图所在目录(模组 GameResources 下的相对路径)
        private const string ModFolder = "ui/heads";

        private static readonly string[] Races = { "human", "elf", "dwarf", "orc" };

        // 一个种族目录下所有会当成头用的贴图。sheet 类(12 个子精灵)和单张类都在里面
        private static readonly string[] SheetNames = {
            "heads_male", "heads_female",
            "heads_male_santa", "heads_female_santa", "heads_zombie",
            "head_king", "head_warrior", "head_old_male", "head_old_female",
        };

        /// <summary> 原版头部贴图的资源路径,给导出工具用 </summary>
        internal static IEnumerable<string> AllVanillaPaths() {
            foreach (string race in Races) {
                foreach (string name in SheetNames) {
                    yield return "actors/species/civs/" + race + "/" + name;
                }
            }
        }

        /// <summary> 资源路径 → 文件名形式的键(human_heads_male) </summary>
        internal static string KeyOfPath(string pPath) {
            string[] parts = pPath.Split('/');
            return parts.Length < 2 ? pPath : parts[parts.Length - 2] + "_" + parts[parts.Length - 1];
        }

        // 原版头部贴图 → 重绘后的整张像素(尺寸相同,逐像素替换)
        private static readonly Dictionary<Texture2D, Color32[]> _sheets =
            new Dictionary<Texture2D, Color32[]>();

        // 原版头部子精灵 → 用重绘像素做出来的替身精灵(一个原版精灵只做一份)
        private static readonly Dictionary<Sprite, Sprite> _swap = new Dictionary<Sprite, Sprite>();

        // 哪些替身精灵身上真有头发像素(没有的不必把发色算进缓存键)
        private static readonly HashSet<Sprite> _hairHeads = new HashSet<Sprite>();

        // 我们自己造出来的所有替身精灵。用来认出"这个头已经换过了",不必再换一遍
        private static readonly HashSet<Sprite> _mine = new HashSet<Sprite>();

        // 已经接管的原版贴图名字,只用于诊断日志
        private static readonly List<string> _boundKeys = new List<string>();

        // 发色写进贴图缓存键的步长。原版的键是
        //   王国色*1e12 + 头部图id*1e9 + 身体图id*1e6 + 表型*1e3 + 明暗档
        // 最高位到 1e12,所以 1e17 这一档是空的,发色塞这里不会和任何一项串位。
        private const long HairKeyStep = 100000000000000000L;

        private static bool _patched;
        private static bool _mapped;

        // 一次烘贴图期间的发色明暗档(由 getSpriteUnit 前后夹住)
        private static bool _baking;
        private static Color32[] _ramp;

        // ===== 诊断 =====
        // 这几条链路都在渲染热路径上,每帧几千次,所以同一类日志只打前几条,
        // 剩下的只累加计数,想看全貌用「模组设置 → 功能开关 → 发色诊断」。

        private static readonly Dictionary<string, int> _noteCount = new Dictionary<string, int>();
        private static int _swapHit, _swapMiss, _bakeWithHair, _bakeNoHair, _recolorCalls, _recolorPixels;
        private static int _swapHitUI;

        /// <summary>
        /// 记一次这类事件,并回答"这条还要不要写日志"。热路径上先问再拼字符串,
        /// 不然光是拼消息就够每帧分配上千个字符串了。
        /// </summary>
        private static bool Tick(string pTag, int pMax) {
            int n;
            _noteCount.TryGetValue(pTag, out n);
            _noteCount[pTag] = n + 1;
            if (n == pMax) {
                Main.LogInfo("生物学[发色/" + pTag + "] 同类日志已打满 " + pMax
                    + " 条,后面只计数,用「功能开关 → 发色诊断」看汇总");
            }
            return n < pMax;
        }

        private static void Note(string pTag, int pMax, string pMessage) {
            if (Tick(pTag, pMax)) Main.LogInfo("生物学[发色/" + pTag + "] " + pMessage);
        }

        /// <summary> 把当前状态一次性打进日志:补丁装没装上、接管了哪些贴图、换了多少像素 </summary>
        public static void LogStatus() {
            bool mappedBefore = _mapped;
            Main.LogInfo("生物学[发色诊断] 补丁=" + (_patched ? "已装" : "没装")
                + " 贴图对应关系=" + (mappedBefore ? "已建立" : "还没建立,现在就建一次看看"));
            // 还没有单位触发过换头时,这里主动建一次,日志里就能直接看到读到了哪些图
            EnsureMap();
            Main.LogInfo("生物学[发色诊断] 接管贴图 " + _sheets.Count + " 张:"
                + string.Join("、", _boundKeys.ToArray()));
            Main.LogInfo("生物学[发色诊断] 已造替身精灵 " + _mine.Count + " 个(带头发 " + _hairHeads.Count + " 个)"
                + ";换头命中 世界 " + _swapHit + " 次 / 头像框 " + _swapHitUI + " 次 / 没接管 " + _swapMiss + " 次"
                + ";烘贴图时带头发 " + _bakeWithHair + " 次 / 不带 " + _bakeNoHair + " 次"
                + ";实际换色 " + _recolorCalls + " 次,共 " + _recolorPixels + " 个像素");
            if (_sheets.Count == 0) {
                Main.LogError("生物学[发色诊断] 一张贴图都没接管:重绘图没放进 GameResources/ui/heads/,"
                    + "或者文件名/尺寸对不上。上面那几行 [发色] 日志写了具体原因");
                return;
            }
            if (_swapHit == 0 && _swapHitUI == 0) {                Main.LogError("生物学[发色诊断] 贴图接管了但没有任何单位换过头。"
                    + "世界里得有人类/精灵/矮人/兽人,而且不能是蛋或者不渲染头的婴儿;"
                    + "已经生成的单位可以缩放一下视角逼它重取贴图");
                return;
            }
            if (_recolorPixels == 0) {
                Main.LogError("生物学[发色诊断] 换了头但一个像素都没换色。"
                    + "要么重绘图里没有发色关键色(150,66,83 / 227,105,86 / 255,145,102 / 255,181,112),"
                    + "要么 drawPixelsAll 的补丁没生效");
            }
            foreach (KeyValuePair<string, int> kv in _noteCount) {
                Main.LogInfo("生物学[发色诊断] 事件 " + kv.Key + " 共 " + kv.Value + " 次");
            }
        }

        // ===== 启用 =====

        public static void Ensure() {
            if (_patched) return;
            _patched = true;
            Harmony harmony = new Harmony("rimworld_health_headhair");
            int ok = 0;
            // 一个一个装,哪个装不上就只报那一个,不会连带把后面的吞掉。
            // setHeadSprite 只有一句赋值,Mono 很可能把它内联进 checkSpriteHead,补丁就打不着了,
            // 所以两处都挂:checkSpriteHead 收尾时直接看 cached_sprite_head 该不该换。
            ok += Apply(harmony, typeof(Actor), "checkSpriteHead",
                null, nameof(CheckSpriteHeadPostfix), null, "换头(收尾兜底,防内联)");
            ok += Apply(harmony, typeof(Actor), "setHeadSprite",
                nameof(SetHeadSpritePrefix), null, null, "换头(把原版头换成重绘替身)");
            ok += Apply(harmony, typeof(DynamicSpriteCreator), "getSpriteUnit",
                nameof(GetSpriteUnitPrefix), null, nameof(GetSpriteUnitFinalizer), "烘贴图(发色进缓存键)");
            ok += Apply(harmony, typeof(DynamicSpriteCreator), "drawPixelsAll",
                null, nameof(DrawPixelsAllPostfix), null, "铺像素之后(换发色)");
            // 单位窗口头像框里那个蹦跳的小人走的是另一条路:DynamicActorSpriteCreatorUI
            // 自己从 animation_container 取头、自己算缓存键(公式和世界里那条还不一样),
            // 完全不经过 Actor.checkSpriteHead / getSpriteUnit,所以这两处得单独挂。
            ok += Apply(harmony, typeof(DynamicActorSpriteCreatorUI), "getSpriteHeadForUI",
                null, nameof(HeadForUIPostfix), null, "头像框取头(换成重绘替身)");
            ok += Apply(harmony, typeof(DynamicActorSpriteCreatorUI), "getUnitSpriteForUI",
                nameof(UnitSpriteForUIPrefix), null, nameof(GetSpriteUnitFinalizer),
                "头像框烘贴图(发色进缓存键)", UISpriteArgs);
            Main.LogInfo("生物学:小人头发接管补丁 " + ok + "/6 装上了");
        }

        // getUnitSpriteForUI 有两个重载,得按参数表点名要长的那个
        private static readonly Type[] UISpriteArgs = {
            typeof(ActorAsset), typeof(Sprite), typeof(AnimationContainerUnit), typeof(bool), typeof(ActorSex),
            typeof(int), typeof(int), typeof(ColorAsset), typeof(long), typeof(int),
            typeof(bool), typeof(bool), typeof(bool), typeof(bool),
        };

        private static int Apply(Harmony pHarmony, Type pType, string pMethod,
            string pPrefix, string pPostfix, string pFinalizer, string pWhat, Type[] pArgs = null) {
            try {
                System.Reflection.MethodInfo target = pArgs == null
                    ? AccessTools.Method(pType, pMethod)
                    : AccessTools.Method(pType, pMethod, pArgs);
                if (target == null) {
                    Main.LogError("生物学:找不到 " + pType.Name + "." + pMethod + " —— " + pWhat + " 装不上");
                    return 0;
                }
                pHarmony.Patch(target,
                    prefix: pPrefix == null ? null
                        : new HarmonyMethod(AccessTools.Method(typeof(BioHeadHair), pPrefix)),
                    postfix: pPostfix == null ? null
                        : new HarmonyMethod(AccessTools.Method(typeof(BioHeadHair), pPostfix)),
                    finalizer: pFinalizer == null ? null
                        : new HarmonyMethod(AccessTools.Method(typeof(BioHeadHair), pFinalizer)));
                Main.LogInfo("生物学:补丁已装 " + pType.Name + "." + pMethod + " —— " + pWhat);
                return 1;
            } catch (Exception e) {
                Main.LogError("生物学:补丁装不上 " + pType.Name + "." + pMethod + " —— " + pWhat + " " + e);
                return 0;
            }
        }

        /// <summary> 改完发色后调用:丢掉替身缓存以外的东西,让该单位立刻重烘贴图 </summary>
        public static void RefreshActor(Actor pActor) {
            if (pActor == null) return;
            try {
                pActor.clearSprites();          // dirty_sprite_head/main → 下一帧重取头、重烘
                pActor.clearLastColorCache();   // 丢掉 _last_colored_sprite,站着不动也会立刻变
            } catch (Exception e) {
                Main.LogError("生物学:刷新单位发色失败 " + e);
            }
            RefreshAvatars(pActor);
        }

        /// <summary>
        /// 让界面上正在显示这个单位的头像框重新取一遍贴图。
        ///
        /// UnitAvatarLoader 在 load() 的时候就把整套动画帧烘好存进 _unit_sprites 了,之后每帧只是
        /// 换下标播放,所以光把贴图缓存改掉没用 —— 不重新 load 一次,头像框会一直放着改色前那几张,
        /// 要等关掉窗口再点开(重新 load)才变。这里主动把它 load 一遍。
        ///
        /// 家谱、关系之类的地方也可能同时挂着同一个单位的头像,所以是按单位找全部,不是只找单位窗口。
        /// 只在玩家点色块的时候走一次,不在热路径上,FindObjectsOfType 的开销无所谓。
        /// </summary>
        public static void RefreshAvatars(Actor pActor) {
            if (pActor == null) return;
            try {
                UnitAvatarLoader[] all = UnityEngine.Object.FindObjectsOfType<UnitAvatarLoader>();
                int n = 0;
                foreach (UnitAvatarLoader loader in all) {
                    if (loader == null || loader._actor != pActor) continue;
                    loader.load(pActor);
                    n++;
                }
                Main.LogInfo("生物学[发色] 头像框已重新加载 " + n + " 个(共扫到 " + all.Length + " 个)");
            } catch (Exception e) {
                Main.LogError("生物学:刷新头像框失败 " + e);
            }
        }

        // ===== 补丁 =====

        /// <summary>
        /// 原版决定用哪个头之后,换成重绘的替身。这个方法体只有一句赋值,很可能被内联掉,
        /// 所以真正兜底的是下面 checkSpriteHead 的收尾补丁。
        /// </summary>
        public static void SetHeadSpritePrefix(ref Sprite pSprite) {
            try {
                Sprite swapped = Swap(pSprite);
                if (swapped != null) pSprite = swapped;
            } catch (Exception e) {
                Main.LogError("生物学:替换头部贴图失败 " + e);
            }
        }

        /// <summary>
        /// setHeadSprite 那一句赋值大概率被内联了,所以在 checkSpriteHead 收尾时再看一眼:
        /// 现在挂着的头要是原版的,就换成替身。已经是替身了就什么都不做。
        /// </summary>
        public static void CheckSpriteHeadPostfix(Actor __instance) {
            try {
                // 矮人贴图开着的时候矮人的头由 BioDwarfSkin 自己合成(还要往上叠头盔/皇冠),
                // 这里不用再造一份用不上的替身
                if (BioDwarfSkin.TakesOverHeads(__instance)) return;
                Sprite head = __instance.cached_sprite_head;
                if (head == null || _mine.Contains(head)) return;
                Sprite swapped = Swap(head);
                if (swapped != null) {
                    __instance.cached_sprite_head = swapped;
                    _swapHit++;
                    if (Tick("换头", 8)) {
                        Main.LogInfo("生物学[发色/换头] " + head.name + " → 替身"
                            + (_hairHeads.Contains(swapped) ? "(带头发)" : "(这一格没头发)"));
                    }
                } else {
                    _swapMiss++;
                    if (Tick("没接管的头", 8)) {
                        Main.LogInfo("生物学[发色/没接管的头] " + Describe(head));
                    }
                }
            } catch (Exception e) {
                Main.LogError("生物学:替换头部贴图失败(收尾) " + e);
            }
        }

        private static string Describe(Sprite pSprite) {
            try {
                Texture2D t = pSprite.texture;
                Rect r = pSprite.rect;
                return pSprite.name + " 来自贴图 " + (t == null ? "(空)" : t.name + " " + t.width + "x" + t.height)
                    + " 子区域 " + (int)r.x + "," + (int)r.y + " " + (int)r.width + "x" + (int)r.height;
            } catch {
                return "(读不出来)";
            }
        }

        /// <summary>
        /// 有发色的单位由我们自己查缓存:键沿用原版那条公式,再加上发色档位。
        /// 不能只靠给 DynamicSpritesAsset.getSprite/addSprite 打补丁改键 —— 那两个方法各只有一行,
        /// 会被内联进这里,补丁根本打不着,结果同王国同肤色的单位全共用第一次烘出来的那张图。
        /// 没有发色的单位直接放回原版逻辑走,不碰。
        /// </summary>
        public static bool GetSpriteUnitPrefix(ref Sprite __result, AnimationFrameData pFrameData,
            Sprite pMainSprite, Actor pActor, ColorAsset pKingdomColor,
            int pPhenotypeIndex, int pPhenotypeShade, UnitTextureAtlasID pTextureAtlasID) {
            _baking = false;
            try {
                if (pActor == null) return true;
                // 矮人贴图开着的时候整套图由 BioDwarfSkin 出,身体和头都不走下面这条
                if (BioDwarfSkin.TryBakeWorld(ref __result, pMainSprite, pActor, pKingdomColor,
                        pPhenotypeIndex, pPhenotypeShade, pTextureAtlasID)) {
                    return false;
                }
                Sprite head = pActor.cached_sprite_head;
                if (head == null) {
                    if (Tick("烘贴图时没有头", 4)) Main.LogInfo("生物学[发色/烘贴图时没有头] 单位 " + pActor.getID());
                    return true;
                }
                if (!_hairHeads.Contains(head)) {
                    _bakeNoHair++;
                    if (Tick("烘贴图的头不带发色", 8)) Main.LogInfo("生物学[发色/烘贴图的头不带发色] " + head.name);
                    return true;
                }
                int idx = BioHairColor.GetIndex(pActor);
                bool white = BioHairColor.IsWhiteHaired(pActor);
                _ramp = BioHairColor.RampOf(idx, white);
                _baking = true;
                _bakeWithHair++;

                long key = VanillaKey(pActor, pMainSprite, pKingdomColor, pPhenotypeIndex, pPhenotypeShade)
                         + HairSlot(idx, white, false) * HairKeyStep;
                DynamicSpritesAsset units = DynamicSpritesLibrary.units;
                Sprite sprite = units.getSprite(key);
                if ((object)sprite == null) {
                    sprite = DynamicSpriteCreator.createNewSpriteUnit(pFrameData, pMainSprite, head,
                        pKingdomColor, pActor.asset, pPhenotypeIndex, pPhenotypeShade, pTextureAtlasID);
                    units.addSprite(key, sprite);
                    if (Tick("烘出新贴图", 8)) {
                        Main.LogInfo("生物学[发色/烘出新贴图] 单位 " + pActor.getID()
                            + " 发色=" + BioHairColor.NameOf(idx) + " 缓存键=" + key);
                    }
                } else if (Tick("命中缓存", 4)) {
                    Main.LogInfo("生物学[发色/命中缓存] 发色=" + BioHairColor.NameOf(idx) + " 缓存键=" + key);
                }
                __result = sprite;
                return false;
            } catch (Exception e) {
                _baking = false;
                Main.LogError("生物学:烘小人贴图失败,回退原版 " + e);
                return true;
            }
        }

        // 发色在缓存键最高那一档里占的号。世界和头像框用同一个贴图缓存,而两条键公式量级不同、
        // 原版本来就可能撞,所以头像框整体挪到 21 起跳,和世界那段(1..12)彻底分开。
        // 明智白发要单独占号,不然白发和黑发会共用同一张烘好的图。
        private static long HairSlot(int pIndex, bool pWhite, bool pForUI) {
            return (pForUI ? 21 : 1) + pIndex + (pWhite ? BioHairColor.Count : 0);
        }

        // 原版 getSpriteUnit 里那条缓存键:
        //   王国色index+1)*1e12 + 头部图id*1e9 + 身体图id*1e6 + 表型*1e3 + 明暗档+1
        private static long VanillaKey(Actor pActor, Sprite pMainSprite, ColorAsset pKingdomColor,
            int pPhenotypeIndex, int pPhenotypeShade) {
            long kingdom = 0L, headId = 0L, shade = 0L;
            long bodyId = DynamicSpriteCreator.getBodySpriteSmallID(pMainSprite);
            if (pActor.has_rendered_sprite_head) headId = HeadSmallId(pActor.cached_sprite_head);
            if (pPhenotypeIndex != 0) shade = pPhenotypeShade + 1;
            if (pKingdomColor != null) kingdom = pKingdomColor.index_id + 1;
            return kingdom * 1000000000000L + headId * 1000000000L + bodyId * 1000000L
                 + pPhenotypeIndex * 1000L + shade;
        }

        // 头部贴图在原版那本小册子里的编号,没登记过就登记一个(和原版同一份字典)
        private static long HeadSmallId(Sprite pHead) {
            if (pHead == null) return 0L;
            int v;
            ActorAnimationLoader.int_ids_heads.TryGetValue(pHead, out v);
            if (v == 0) {
                v = ActorAnimationLoader.int_ids_heads.Count + 1;
                ActorAnimationLoader.int_ids_heads.Add(pHead, v);
            }
            return v;
        }

        // ===== 头像框里那个小人 =====

        /// <summary> 头像框自己从 animation_container 里挑头,挑完在这里换成重绘替身 </summary>
        public static void HeadForUIPostfix(ref Sprite __result) {
            if (__result == null) return;
            try {
                if (_mine.Contains(__result)) return;
                Sprite swapped = Swap(__result);
                if (swapped == null) return;
                Sprite vanilla = __result;
                __result = swapped;
                _swapHitUI++;
                if (Tick("头像框换头", 8)) {
                    Main.LogInfo("生物学[发色/头像框换头] " + vanilla.name + " → 替身"
                        + (_hairHeads.Contains(swapped) ? "(带头发)" : "(这一格没头发)"));
                }
            } catch (Exception e) {
                Main.LogError("生物学:头像框替换头部贴图失败 " + e);
            }
        }

        /// <summary>
        /// 头像框的烘贴图。和世界那条一个套路:带发色的自己算键自己查存,不带的放回原版。
        /// 注意这里的键公式和世界那条不一样(原版就是两套),所以不能共用 VanillaKey。
        /// 手里只有 data.id 没有 Actor,而发色只跟 id 有关,所以按 id 查。
        /// </summary>
        public static bool UnitSpriteForUIPrefix(ref Sprite __result, ActorAsset pAsset, Sprite pMainSprite,
            AnimationContainerUnit pContainer, bool pAdult, ActorSex pSex,
            int pPhenotypeIndex, int pPhenotypeShade, ColorAsset pKingdomColor, long pActorId, int pHeadId,
            bool pEgg, bool pKing, bool pWarrior, bool pWise) {
            _baking = false;
            try {
                // 矮人贴图开着的时候头像框里的矮人也由 BioDwarfSkin 出
                if (BioDwarfSkin.TryBakeUI(ref __result, pAsset, pMainSprite, pAdult, pSex,
                        pPhenotypeIndex, pPhenotypeShade, pKingdomColor, pActorId, pKing, pWise, pEgg)) {
                    return false;
                }
                // 这一句会走到上面的 HeadForUIPostfix,拿回来的已经是替身了
                Sprite head = DynamicActorSpriteCreatorUI.getSpriteHeadForUI(pAsset, pSex, pContainer,
                    pActorId, pHeadId, pAdult, pEgg, pKing, pWarrior, pWise);
                if (head == null || !_hairHeads.Contains(head)) return true;

                int idx = BioHairColor.GetIndexById(pActorId);
                // 明智单位在原版会换成老年头、头发是灰白的,头像框跟着白
                bool white = pWise && pAsset != null && pAsset.texture_asset != null
                             && pAsset.texture_asset.has_old_heads;
                _ramp = BioHairColor.RampOf(idx, white);
                _baking = true;
                _bakeWithHair++;

                long kingdom = pKingdomColor == null ? 0L : pKingdomColor.index_id + 1;
                long shade = pPhenotypeIndex == 0 ? 0L : pPhenotypeShade + 1;
                long bodyId = DynamicSpriteCreator.getBodySpriteSmallID(pMainSprite);
                long key = kingdom * 10000000L + HeadSmallId(head) * 1000000L + bodyId * 1000L
                         + pPhenotypeIndex * 10L + shade
                         + HairSlot(idx, white, true) * HairKeyStep;

                AnimationFrameData frame = null;
                if (pContainer != null && pContainer.dict_frame_data != null) {
                    pContainer.dict_frame_data.TryGetValue(pMainSprite.name, out frame);
                }
                DynamicSpritesAsset units = DynamicSpritesLibrary.units;
                Sprite sprite = units.getSprite(key);
                if ((object)sprite == null) {
                    sprite = DynamicSpriteCreator.createNewSpriteUnit(frame, pMainSprite, head,
                        pKingdomColor, pAsset, pPhenotypeIndex, pPhenotypeShade, pAsset.texture_atlas);
                    units.addSprite(key, sprite);
                    if (Tick("头像框烘出新贴图", 8)) {
                        Main.LogInfo("生物学[发色/头像框烘出新贴图] 单位 " + pActorId
                            + " 发色=" + BioHairColor.NameOf(idx) + " 缓存键=" + key);
                    }
                }
                __result = sprite;
                return false;
            } catch (Exception e) {
                _baking = false;
                Main.LogError("生物学:烘头像框贴图失败,回退原版 " + e);
                return true;
            }
        }

        public static void GetSpriteUnitFinalizer() {
            _baking = false;
        }

        /// <summary>
        /// 给 BioDwarfSkin 用:它自己调 createNewSpriteUnit 拼矮人,拼之前把发色明暗档挂上,
        /// 下面 DrawPixelsAllPostfix 才会把重绘头上的发色关键色换掉。
        /// </summary>
        internal static void BeginHairBake(Color32[] pRamp) {
            if (pRamp == null) return;
            _ramp = pRamp;
            _baking = true;
        }

        internal static void EndHairBake() {
            _baking = false;
        }

        /// <summary>
        /// 头部像素已经铺进图集,这里把四个发色关键色改写成该单位发色的对应明暗档。
        /// 关键色像素在原版眼里是"普通像素",全都躺在 arr_pixels_normal 里按原色铺,
        /// 所以只要照原版那套下标算法在同一个位置盖一遍就行。
        /// </summary>
        public static void DrawPixelsAllPostfix(PixelBag pBag, UnitSpriteConstructorAtlas pAtlas,
            int pPartX, int pPartY, bool pDynamicZombie, ActorAsset pActorAsset, bool pHead) {
            if (!pHead || !_baking) return;
            try {
                Pixel[] arr = pBag.arr_pixels_normal;
                if (arr == null) {
                    Note("头部没有普通像素", 4, "arr_pixels_normal 是空的,发色关键色不在这一桶里");
                    return;
                }
                Color32[] px = pAtlas.pixels;
                int width = pAtlas.texture.width;
                int hit = 0;
                for (int i = 0; i < arr.Length; i++) {
                    int slot = BioHairColor.MarkerSlot(arr[i].color);
                    if (slot < 0) continue;
                    int x = arr[i].x + pPartX;
                    int y = arr[i].y + pPartY;
                    if (x < 0) x = 0;
                    if (y < 0) y = 0;
                    int idx = x + y * width;
                    Color32 c = _ramp[slot];
                    // 僵尸化的单位原版会把每个像素再乘一遍尸色,发色也得跟着乘,不然头发不烂
                    if (pDynamicZombie) {
                        c = DynamicColorPixelTool.checkZombieColors(pActorAsset, c, idx / 3 + x, true);
                    }
                    px[idx] = c;
                    hit++;
                }
                _recolorCalls++;
                _recolorPixels += hit;
                string tag = hit > 0 ? "换色" : "换色但没找到发色关键色";
                if (Tick(tag, 8)) {
                    Main.LogInfo("生物学[发色/" + tag + "] 普通像素 " + arr.Length
                        + " 个,其中发色 " + hit + " 个");
                }
            } catch (Exception e) {
                Main.LogError("生物学:小人头发换色失败 " + e);
            }
        }

        // ===== 替身精灵 =====

        /// <summary> 原版头部精灵 → 重绘替身。这张贴图没被接管就返回 null(照用原版) </summary>
        private static Sprite Swap(Sprite pVanilla) {
            if (pVanilla == null) return null;
            EnsureMap();
            if (_sheets.Count == 0) return null;
            Sprite swapped;
            if (_swap.TryGetValue(pVanilla, out swapped)) return swapped;
            swapped = Build(pVanilla);
            _swap[pVanilla] = swapped;
            return swapped;
        }

        /// <summary>
        /// 从重绘的整张贴图上抠出原版这个子精灵占的那一块,单独做成一张贴图。
        /// 尺寸和 pivot 完全照抄原版精灵,烘贴图时算头的位置用的就是这两个值。
        /// </summary>
        private static Sprite Build(Sprite pVanilla) {
            Texture2D tex;
            try { tex = pVanilla.texture; } catch { return null; }
            Color32[] sheet;
            if (tex == null || !_sheets.TryGetValue(tex, out sheet)) return null;

            Rect r = pVanilla.rect;
            int w = Mathf.Max(1, (int)r.width);
            int h = Mathf.Max(1, (int)r.height);
            int x0 = (int)r.x;
            int y0 = (int)r.y;
            int sheetW = tex.width;
            int sheetH = tex.height;
            if (x0 < 0 || y0 < 0 || x0 + w > sheetW || y0 + h > sheetH) {
                Main.LogError("生物学:头部子精灵 " + pVanilla.name + " 的范围 (" + x0 + "," + y0
                    + " " + w + "x" + h + ") 超出贴图 " + sheetW + "x" + sheetH + ",这个头不换");
                return null;
            }
            Color32[] buf = new Color32[w * h];
            bool hasHair = false;
            for (int y = 0; y < h; y++) {
                int src = (y0 + y) * sheetW + x0;
                int dst = y * w;
                for (int x = 0; x < w; x++) {
                    Color32 c = sheet[src + x];
                    buf[dst + x] = c;
                    if (BioHairColor.MarkerSlot(c) >= 0) hasHair = true;
                }
            }

            Texture2D outTex = new Texture2D(w, h, TextureFormat.RGBA32, false);
            outTex.filterMode = FilterMode.Point;
            outTex.wrapMode = TextureWrapMode.Clamp;
            outTex.SetPixels32(buf);
            outTex.Apply(false, false);

            Vector2 pivot = pVanilla.pivot;   // 原版给的是像素,Sprite.Create 要归一化
            Sprite sp = Sprite.Create(outTex, new Rect(0f, 0f, w, h),
                new Vector2(pivot.x / w, pivot.y / h), 1f, 0, SpriteMeshType.FullRect);
            sp.name = pVanilla.name;
            _mine.Add(sp);
            if (hasHair) _hairHeads.Add(sp);
            Note("造替身", 20, pVanilla.name + " " + w + "x" + h
                + " pivot=" + pivot.x.ToString("0.##") + "," + pivot.y.ToString("0.##")
                + (hasHair ? " 带头发" : " 没有发色关键色"));
            return sp;
        }

        // ===== 重绘图 ↔ 原版贴图的对应关系 =====

        // 原版一张候选贴图
        internal class Sheet {
            public string Key;        // 种族_贴图名,也是文件名可以直接写的那个形式
            public Texture2D Texture;
            public Color32[] Pixels;
            public int W, H;
        }

        /// <summary> 第一次要用头的时候建立对应关系。资源在这时候肯定已经加载好了 </summary>
        private static void EnsureMap() {
            if (_mapped) return;
            _mapped = true;
            try {
                Main.LogInfo("生物学[发色] 开始建立头部贴图对应关系");
                List<Sprite> mods = LoadModSheets();
                Main.LogInfo("生物学[发色] " + ModFolder + " 里读到重绘图 " + mods.Count + " 张:"
                    + Join(mods));
                List<Sheet> vanilla = LoadVanillaSheets();
                Main.LogInfo("生物学[发色] 原版候选贴图 " + vanilla.Count + " 张:" + JoinSheets(vanilla));
                if (vanilla.Count == 0) {
                    Main.LogError("生物学[发色] 读不到原版四个种族的头部贴图,接管跳过");
                    return;
                }
                if (mods.Count == 0) {
                    Main.LogError("生物学[发色] " + ModFolder + " 下一张重绘图都没读到。检查 GameResources/"
                        + ModFolder + "/ 里有没有 png,以及 NeoModLoader 有没有把这个目录当资源加载");
                }
                foreach (Sprite m in mods) Bind(m, vanilla);
                int bound = _sheets.Count;
                Main.LogInfo("生物学[发色] 头部贴图接管 " + bound + " / " + mods.Count + " 张");
                if (bound < mods.Count) {
                    // 有认不出来的,把所有可用的目标名字打出来,照着改文件名就行
                    Main.LogInfo("生物学[发色] 可用的目标文件名 —— " + JoinSheets(vanilla));
                }
            } catch (Exception e) {
                Main.LogError("生物学:建立头部贴图对应关系失败 " + e);
            }
        }

        private static string Join(List<Sprite> pList) {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            foreach (Sprite sp in pList) {
                sb.Append(sp.name).Append('(').Append(sp.texture.width).Append('x')
                  .Append(sp.texture.height).Append(") ");
            }
            return sb.ToString();
        }

        private static string JoinSheets(List<Sheet> pList) {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            foreach (Sheet s in pList) {
                sb.Append(s.Key).Append('(').Append(s.W).Append('x').Append(s.H).Append(") ");
            }
            return sb.ToString();
        }

        internal static List<Sprite> LoadModSheets() {
            List<Sprite> list = new List<Sprite>();
            try {
                Sprite[] arr = SpriteTextureLoader.getSpriteList(ModFolder, true);
                if (arr != null) {
                    foreach (Sprite sp in arr) {
                        if (sp != null && sp.texture != null) list.Add(sp);
                    }
                }
            } catch (Exception e) {
                Main.LogError("生物学:读取 " + ModFolder + " 失败 " + e);
            }
            return list;
        }

        internal static List<Sheet> LoadVanillaSheets() {
            List<Sheet> list = new List<Sheet>();
            HashSet<Texture2D> seen = new HashSet<Texture2D>();
            foreach (string path in AllVanillaPaths()) {
                Sprite[] arr = null;
                try { arr = SpriteTextureLoader.getSpriteList(path, true); } catch { }
                if (arr == null) continue;
                foreach (Sprite sp in arr) {
                    if (sp == null || sp.texture == null || !seen.Add(sp.texture)) continue;
                    Color32[] px = ReadPixels(sp.texture);
                    if (px == null) continue;
                    list.Add(new Sheet {
                        Key = KeyOfPath(path),
                        Texture = sp.texture,
                        Pixels = px,
                        W = sp.texture.width,
                        H = sp.texture.height,
                    });
                }
            }
            return list;
        }

        internal static Color32[] ReadPixels(Texture2D pTexture) {
            try {
                Color32[] px = pTexture.GetPixels32();
                if (px != null && px.Length == pTexture.width * pTexture.height) return px;
            } catch (Exception e) {
                Main.LogError("生物学:头部贴图不可读 " + pTexture.name + " " + e.Message);
            }
            return null;
        }

        /// <summary> 把一张重绘图挂到它该顶掉的那张原版贴图上 </summary>
        private static void Bind(Sprite pMod, List<Sheet> pVanilla) {
            Color32[] px = ReadPixels(pMod.texture);
            if (px == null) return;
            int w = pMod.texture.width;
            int h = pMod.texture.height;

            int markers = 0;
            for (int i = 0; i < px.Length; i++) {
                if (BioHairColor.MarkerSlot(px[i]) >= 0) markers++;
            }
            if (markers == 0) {
                Main.LogError("生物学:" + pMod.name + " 里没有发色关键色(150,66,83 / 227,105,86 / "
                    + "255,145,102 / 255,181,112),这张不接管");
                return;
            }

            // 文件名直接写成 human_heads_male 这种就按名字认,省得靠像素猜
            Sheet target = null;
            string key = pMod.name.Trim().ToLower();
            foreach (Sheet s in pVanilla) {
                if (s.Key == key) { target = s; break; }
            }
            if (target != null && (target.W != w || target.H != h)) {
                Main.LogError("生物学:" + pMod.name + " 尺寸 " + w + "x" + h + " 和原版 "
                    + target.Key + " 的 " + target.W + "x" + target.H + " 不一致,这张不接管");
                return;
            }
            if (target == null) target = AutoMatch(pMod.name, px, w, h, pVanilla);
            if (target == null) return;

            Color32[] old;
            if (_sheets.TryGetValue(target.Texture, out old) && old != px) {
                Main.LogError("生物学:" + target.Key + " 被两张重绘图同时认领,后一张(" + pMod.name
                    + ")覆盖前一张。建议把文件名改成 " + target.Key + ".png 之类的明确写法");
            }
            _sheets[target.Texture] = px;
            if (!_boundKeys.Contains(target.Key)) _boundKeys.Add(target.Key);
            Main.LogInfo("生物学[发色] 头部贴图 " + pMod.name + " → " + target.Key
                + " (" + w + "x" + h + ",发色像素 " + markers + " 个)");
        }

        /// <summary>
        /// 重绘图和原版某张贴图差了几个像素。只比"不是发色关键色"的像素:头发那几个点原版
        /// 是什么色都不管,剩下的脸、描边、耳朵尖必须一模一样。尺寸不同直接算 -1(没法比)。
        /// pStopAt 是提前退出的上限,只想知道"是不是 0"时传 1 能省一半功夫。
        /// </summary>
        internal static int Mismatch(Color32[] pPixels, Sheet pSheet, int pW, int pH, int pStopAt) {
            if (pSheet.W != pW || pSheet.H != pH) return -1;
            int miss = 0;
            for (int i = 0; i < pPixels.Length; i++) {
                Color32 m = pPixels[i];
                if (BioHairColor.MarkerSlot(m) >= 0) continue;
                Color32 v = pSheet.Pixels[i];
                if (m.a == 0 && v.a == 0) continue;
                if (m.a == v.a && m.r == v.r && m.g == v.g && m.b == v.b) continue;
                miss++;
                if (miss >= pStopAt) break;
            }
            return miss;
        }

        /// <summary>
        /// 按像素认出这张重绘图改的是哪一张原版贴图。差 0 个像素且只有一张对得上才算认出来;
        /// 有多张同时对得上就不认(宁可不换,也不能给人类顶上精灵的头)。
        /// </summary>
        private static Sheet AutoMatch(string pName, Color32[] pPixels, int pW, int pH, List<Sheet> pVanilla) {
            Sheet best = null;
            int sizeMatched = 0;
            int exact = 0;
            int bestMiss = int.MaxValue;
            foreach (Sheet s in pVanilla) {
                int miss = Mismatch(pPixels, s, pW, pH, int.MaxValue);
                if (miss < 0) continue;
                sizeMatched++;
                if (miss == 0) { exact++; if (best == null) best = s; }
                if (miss < bestMiss) bestMiss = miss;
            }
            if (sizeMatched == 0) {
                Main.LogError("生物学:" + pName + " 的尺寸 " + pW + "x" + pH
                    + " 和原版任何一张头部贴图都不一样,这张不接管");
                return null;
            }
            if (exact == 0) {
                Main.LogError("生物学:" + pName + " 认不出对应的原版贴图(最接近的也差 " + bestMiss
                    + " 个像素)。请把文件名改成 <种族>_<原版贴图名>.png,例如 human_heads_male.png");
                return null;
            }
            if (exact > 1) {
                Main.LogError("生物学:" + pName + " 和 " + exact + " 张原版贴图都对得上,认不出是哪一张,"
                    + "这张不接管(宁可不换也不能给人类顶上精灵的头)。"
                    + "请把文件名改成 <种族>_<原版贴图名>.png,例如 human_heads_male.png、elf_heads_female.png");
                return null;
            }
            return best;
        }
    }
}
