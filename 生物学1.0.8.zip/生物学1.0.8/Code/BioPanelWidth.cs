using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace RimWorldMod {

    // 每帧推进器官面板加宽/收缩动画(常驻对象,窗口关闭时负责还原)
    public class BioPanelWidthBehaviour : MonoBehaviour {
        private void Update() {
            BioPanelWidth.Tick(Time.unscaledDeltaTime);
        }

        // 内容区顶部留白由原版反复重设,放在 LateUpdate 校正:UI 布局在所有 LateUpdate 之后结算,不会闪
        private void LateUpdate() {
            UnitHealthTab.EnforceSplitTopPadding();
        }
    }

    /// <summary>
    /// 器官面板(生物学标签)加宽:
    /// - 左边缘锚点固定,只向右扩展宽度(默认 2 倍),并限制在画布可视范围内
    /// - 退出(CloseBackground)/收藏等贴右边缘的挂件随右边缘同步右移;左侧标签栏保持不动
    /// - 进出带平滑动画(SmoothStep)
    /// - 只改动当前单位窗口相关矩形的 宽度/水平位置,收缩时按快照精确还原,不影响其他窗口
    /// - 切到其他标签页或窗口关闭 → 自动收缩回默认宽度
    /// </summary>
    public static class BioPanelWidth {

        private const float AnimDuration = 0.22f;   // 动画时长(秒)
        private const float SpanRatio = 0.70f;      // 子级宽度达父级 70% 视为横跨,随父级一起加宽
        private const float EdgeRightF = 0.65f;     // 中心位于父级 65% 之后视为贴右边缘
        private const float EdgeLeftF = 0.35f;      // 中心位于父级 35% 之前视为贴左边缘
        private const int MaxDepth = 4;             // 递归深度上限(更深的层级由布局组自行处理)
        private const float CanvasMargin = 70f;     // 右侧预留(画布单位),给收藏按钮列留空间
        // Header 保持原宽并贴左:它自带不透明背景,若跟着加宽会盖住右半边的器官栏
        private const string KeepWidthLeftNode = "Header";
        // Header 贴左后再往右挪一点(屏幕像素),避免看着太贴左边框
        private const float HeaderShiftPx = 20f;

        // 一个受影响的矩形:记录原始宽度/水平位置(快照),动画按进度在快照上叠加增量
        private class Node {
            public RectTransform Rect;
            public float BaseWidth;    // 原始 sizeDelta.x
            public float BasePosX;     // 原始 anchoredPosition.x
            public float WidthDelta;   // 宽度增量
            public float PosDelta;     // 水平位移增量
            public string Tag;         // 日志用
        }

        private static readonly List<Node> _nodes = new List<Node>();
        private static UnitWindow _window;
        private static BioPanelWidthBehaviour _behaviour;
        private static float _progress;   // 当前动画进度 0..1
        private static float _target;     // 目标进度 0(默认宽度) 或 1(加宽)
        private static int _pendingRefresh; // 展开到位后延迟几帧再重排内容

        /// <summary> 创建常驻动画驱动对象(Main 调用一次) </summary>
        public static void Ensure() {
            if (_behaviour != null) return;
            try {
                GameObject go = new GameObject("BioPanelWidth");
                _behaviour = go.AddComponent<BioPanelWidthBehaviour>();
                UnityEngine.Object.DontDestroyOnLoad(go);
            } catch (Exception e) {
                Main.LogError("生物学:创建面板加宽驱动失败 " + e);
            }
        }

        /// <summary> 是否处于加宽状态(含动画中) </summary>
        public static bool IsExpanded() {
            return _nodes.Count > 0 && _target > 0f;
        }

        /// <summary>
        /// 切换加宽状态:切到生物学标签传 true,切走/关闭传 false。
        /// 反复调用同一状态不会重复计算,动画中途反向也会平滑衔接。
        /// </summary>
        public static void SetExpanded(UnitWindow pWindow, bool pExpand) {
            try {
                if (pWindow == null) return;
                if (_window != pWindow) {
                    // 换了窗口实例:先把旧窗口还原干净
                    if (_nodes.Count > 0) {
                        Apply(0f);
                        Clear();
                    }
                    _window = pWindow;
                }
                if (pExpand) {
                    if (_nodes.Count == 0 && !BuildPlan(pWindow)) return;
                    _target = 1f;
                } else {
                    if (_nodes.Count == 0) return;
                    _target = 0f;
                }
            } catch (Exception e) {
                Main.LogError("生物学:面板加宽切换失败 " + e);
            }
        }

        /// <summary> 每帧推进动画;窗口失效时立即还原 </summary>
        public static void Tick(float pDeltaTime) {
            try {
                if (_window == null || !_window.gameObject.activeInHierarchy) {
                    if (_nodes.Count > 0) {
                        Apply(0f);
                        Clear();
                    }
                    return;
                }
                if (_nodes.Count == 0) return;
                if (Mathf.Approximately(_progress, _target)) {
                    // 展开到位后等布局稳定一两帧,再按新宽度重排器官流式布局(换行列数变化)
                    if (_pendingRefresh > 0) {
                        _pendingRefresh--;
                        if (_pendingRefresh == 0) UnitHealthTab.RefreshAfterResize();
                    }
                    return;
                }

                float step = pDeltaTime / Mathf.Max(0.01f, AnimDuration);
                _progress = Mathf.MoveTowards(_progress, _target, step);
                Apply(Mathf.SmoothStep(0f, 1f, _progress));
                UnitHealthTab.SyncContentWidth();

                if (!Mathf.Approximately(_progress, _target)) return;
                if (_target <= 0f) {
                    // 收缩到底:精确还原快照并解除接管
                    Apply(0f);
                    Clear();
                } else {
                    _pendingRefresh = 2;
                }
            } catch (Exception e) {
                Main.LogError("生物学:面板加宽动画失败 " + e);
                try { Apply(0f); } catch { }
                Clear();
            }
        }

        // ===== 计划构建 =====

        // 采集所有需要跟随的矩形并记录快照。只在完全收缩状态下调用,保证快照是原始值。
        private static bool BuildPlan(UnitWindow pWindow) {
            _nodes.Clear();
            _progress = 0f;
            _target = 0f;
            _pendingRefresh = 0;

            RectTransform bg = pWindow.transform.Find("Background") as RectTransform;
            if (bg == null) {
                Main.LogError("生物学:面板加宽未找到 Background");
                return false;
            }
            float delta = ComputeDelta(bg);
            if (delta < 8f) {
                Main.LogInfo("生物学:面板加宽增量过小(" + delta.ToString("F1") + "),跳过");
                return false;
            }

            // 面板本体:宽度 +delta,中心右移 delta*pivot.x → 左边缘保持不动
            AddNode(bg, delta, bg.pivot.x * delta, "面板");
            Collect(bg, delta, 1);

            // 与面板同级的挂件(退出 CloseBackground / 收藏按钮列等):只有贴右边缘的跟随右移
            Transform root = pWindow.transform;
            float bgWidth = bg.rect.width;
            for (int i = 0; i < root.childCount; i++) {
                RectTransform c = root.GetChild(i) as RectTransform;
                if (c == null || c == bg) continue;
                if (c.rect.width > bgWidth * 1.5f) continue;         // 跳过全屏遮罩类节点
                if (FractionInside(bg, c) <= EdgeRightF) continue;    // 只处理贴右边缘的
                AddNode(c, 0f, delta, c.name);
            }

            Main.LogInfo("生物学:面板加宽计划 增量=" + delta.ToString("F1") + "px 节点数=" + _nodes.Count);
            for (int i = 0; i < _nodes.Count; i++) {
                Node n = _nodes[i];
                Main.LogInfo("生物学:面板加宽 [" + n.Tag + "] 宽度+" + n.WidthDelta.ToString("F1")
                    + " 位移+" + n.PosDelta.ToString("F1"));
            }
            return _nodes.Count > 0;
        }

        // 递归采集 pParent 的子级。pParentDelta 为父级本次加宽量(父级左边缘视为不动)。
        private static void Collect(RectTransform pParent, float pParentDelta, int pDepth) {
            if (pParent == null || pDepth > MaxDepth || pParentDelta <= 0.01f) return;
            // 布局组会自行重排子级,交给 Unity,不手工干预
            LayoutGroup lg = pParent.GetComponent<LayoutGroup>();
            if (lg != null && lg.enabled) return;

            float pw = pParent.rect.width;
            if (pw <= 1f) return;

            for (int i = 0; i < pParent.childCount; i++) {
                RectTransform c = pParent.GetChild(i) as RectTransform;
                if (c == null) continue;

                if (Mathf.Abs(c.anchorMax.x - c.anchorMin.x) > 0.001f) {
                    // 横向拉伸锚点:Unity 自动跟随父级变宽,只需继续处理其子级
                    Collect(c, pParentDelta * (c.anchorMax.x - c.anchorMin.x), pDepth + 1);
                    continue;
                }

                if (c.name == KeepWidthLeftNode) {
                    // Header:保持原宽度并贴住左边缘,让出右半边给器官内容(它的背景不透明,加宽会遮挡)
                    // 再按 HeaderShiftPx 往右挪一点(像素→局部单位换算)
                    float scale = Mathf.Abs(c.lossyScale.x);
                    float shift = scale > 0.0001f ? HeaderShiftPx / scale : 0f;
                    float dxKeep = pParentDelta * (0f - c.anchorMin.x) + shift;
                    if (Mathf.Abs(dxKeep) > 0.01f) AddNode(c, 0f, dxKeep, c.name + "(原宽/贴左+" + HeaderShiftPx + "px)");
                    continue;
                }

                if (c.rect.width >= pw * SpanRatio) {
                    // 横跨父级(滚动视图等):一起加宽,并保持自身左边缘不动
                    AddNode(c, pParentDelta, c.pivot.x * pParentDelta - pParentDelta * c.anchorMin.x, c.name);
                    Collect(c, pParentDelta, pDepth + 1);
                    continue;
                }

                // 非横跨节点:按当前位置判定贴左/居中/贴右,只补位移
                float f = FractionInside(pParent, c);
                float targetU = f > EdgeRightF ? 1f : (f < EdgeLeftF ? 0f : 0.5f);
                float dx = pParentDelta * (targetU - c.anchorMin.x);
                if (Mathf.Abs(dx) < 0.01f) continue;
                AddNode(c, 0f, dx, c.name);
            }
        }

        // 目标增量:按倍率加宽,并保证右边缘(含预留)不超出画布
        private static float ComputeDelta(RectTransform pBg) {
            float baseWidth = pBg.rect.width;
            if (baseWidth < 40f) return 0f;
            float want = baseWidth * Mathf.Clamp(Main.PanelWidthFactor - 1f, 0f, 2f);
            if (want <= 0f) return 0f;

            Canvas canvas = pBg.GetComponentInParent<Canvas>();
            RectTransform canvasRt = canvas != null ? canvas.transform as RectTransform : null;
            if (canvasRt != null && canvasRt.rect.width > 40f) {
                float scale = pBg.lossyScale.x / Mathf.Max(0.0001f, canvasRt.lossyScale.x);
                Vector3 worldRight = pBg.TransformPoint(new Vector3(pBg.rect.xMax, 0f, 0f));
                float rightInCanvas = canvasRt.InverseTransformPoint(worldRight).x;
                float avail = (canvasRt.rect.xMax - rightInCanvas - CanvasMargin) / Mathf.Max(0.0001f, scale);
                if (avail < want) {
                    Main.LogInfo("生物学:面板加宽受画布宽度限制 " + want.ToString("F0") + " → " + avail.ToString("F0"));
                    want = avail;
                }
            }
            return Mathf.Max(0f, want);
        }

        // 子级中心在参照矩形横向上的归一化位置(0=左边缘,1=右边缘;可超出该范围)
        private static float FractionInside(RectTransform pRef, RectTransform pChild) {
            try {
                Vector3 world = pChild.TransformPoint(new Vector3(pChild.rect.center.x, pChild.rect.center.y, 0f));
                Vector3 local = pRef.InverseTransformPoint(world);
                float w = pRef.rect.width;
                if (w <= 0.01f) return 0.5f;
                return (local.x - pRef.rect.xMin) / w;
            } catch {
                return 0.5f;
            }
        }

        private static void AddNode(RectTransform pRect, float pWidthDelta, float pPosDelta, string pTag) {
            if (pRect == null) return;
            Node n = new Node();
            n.Rect = pRect;
            n.BaseWidth = pRect.sizeDelta.x;
            n.BasePosX = pRect.anchoredPosition.x;
            n.WidthDelta = pWidthDelta;
            n.PosDelta = pPosDelta;
            n.Tag = pTag;
            _nodes.Add(n);
        }

        // ===== 应用与还原 =====

        // 按缓动进度在快照上叠加增量(只改 x 方向,y 保持原版当前值,不与纵向布局冲突)
        private static void Apply(float pEased) {
            for (int i = 0; i < _nodes.Count; i++) {
                Node n = _nodes[i];
                if (n.Rect == null) continue;
                if (Mathf.Abs(n.WidthDelta) > 0.001f) {
                    Vector2 sd = n.Rect.sizeDelta;
                    n.Rect.sizeDelta = new Vector2(n.BaseWidth + pEased * n.WidthDelta, sd.y);
                }
                if (Mathf.Abs(n.PosDelta) > 0.001f) {
                    Vector2 ap = n.Rect.anchoredPosition;
                    n.Rect.anchoredPosition = new Vector2(n.BasePosX + pEased * n.PosDelta, ap.y);
                }
            }
        }

        private static void Clear() {
            _nodes.Clear();
            _progress = 0f;
            _target = 0f;
            _pendingRefresh = 0;
        }
    }
}
