using System.Collections.Generic;

namespace RimWorldMod {

    public class Organ {
        public string Id;
        public string Name;
        public Organ(string pId, string pName) {
            Id = pId;
            Name = pName;
        }

        // 显示名:优先走动态器官名键(鱼尾/左爪/龟背等),否则按器官 id 键本地化(NML 多语言)
        public string LocalizedName {
            get {
                string dynKey = "bio_dyn_" + Name;
                if (BioText.Has(dynKey)) return BioText.T(dynKey, Name);
                return BioText.T("bio_organ_" + Id, Name);
            }
        }
    }

    public class OrganGroup {
        public string Name;
        public List<string> OrganIds;
        public OrganGroup(string pName, params string[] pOrganIds) {
            Name = pName;
            OrganIds = new List<string>(pOrganIds);
        }

        // 显示名:分组名本地化(躯干/头部/翅膀等),键缺失回退中文原文
        public string LocalizedName {
            get { return BioText.T("bio_group_" + Name, Name); }
        }
    }

    public static class OrganData {

        public static readonly Dictionary<string, Organ> OrganName = new Dictionary<string, Organ> {
            { "chest",   new Organ("chest", "乳房") },
            { "abdomen", new Organ("abdomen", "腹部") },
            { "spine",   new Organ("spine", "脊椎") },
            { "stomach", new Organ("stomach", "胃") },
            { "heart",   new Organ("heart", "心脏") },
            { "lung",    new Organ("lung", "肺") },
            { "kidney",  new Organ("kidney", "肾") },
            { "liver",   new Organ("liver", "肝") },
            { "intestine",new Organ("intestine", "肠道") },
            { "anus",    new Organ("anus", "肛门") },
            { "bladder", new Organ("bladder", "膀胱") },
            { "bone",    new Organ("bone", "关节骨") },
            { "muscle",  new Organ("muscle", "肌肉") },
            { "blood",   new Organ("blood", "血液") },
            { "neck",    new Organ("neck", "颈部") },
            { "head",    new Organ("head", "头部") },
            { "brain",   new Organ("brain", "大脑") },
            { "eye_l",   new Organ("eye_l", "左眼") },
            { "eye_r",   new Organ("eye_r", "右眼") },
            { "ear",     new Organ("ear", "耳朵") },
            { "nose",    new Organ("nose", "鼻") },
            { "mouth",   new Organ("mouth", "嘴巴") },
            { "teeth",   new Organ("teeth", "牙齿") },
            { "fang",    new Organ("fang", "毒牙") },
            { "shoulder",new Organ("shoulder", "双肩") },
            { "arm",     new Organ("arm", "双臂") },
            { "hand",    new Organ("hand", "双手") },
            { "leg",     new Organ("leg", "双腿") },
            { "foot",    new Organ("foot", "双脚") },
            { "skin",    new Organ("skin", "皮肤") },
            { "hair",    new Organ("hair", "毛发") },
            { "fur",     new Organ("fur", "皮毛") },
            { "scale",   new Organ("scale", "鳞片") },
            { "feather", new Organ("feather", "羽毛") },
            { "horn",    new Organ("horn", "角") },
            { "beak",    new Organ("beak", "喙") },
            { "tail",    new Organ("tail", "尾巴") },
            { "wing_l",  new Organ("wing_l", "左翼") },
            { "wing_r",  new Organ("wing_r", "右翼") },
            { "gills",   new Organ("gills", "鳃") },
            { "uterus",  new Organ("uterus", "子宫") },
            { "ovary",   new Organ("ovary", "卵巢") },
            { "vagina",  new Organ("vagina", "阴道") },
            { "testicle",new Organ("testicle", "睾丸") },
            { "prostate",new Organ("prostate", "前列腺") },
            { "penis",   new Organ("penis", "阴茎") },
            { "cloaca",  new Organ("cloaca", "泄殖腔") },
        };

        public static readonly List<OrganGroup> HumanGroups = new List<OrganGroup> {
            new OrganGroup("躯干", "chest", "abdomen", "spine", "stomach", "heart", "lung",
                "kidney", "liver", "intestine", "blood", "bone", "muscle"),
            new OrganGroup("生殖泌尿系统", "bladder", "anus", "penis", "vagina", "uterus", "ovary", "testicle", "prostate"),
            new OrganGroup("头部", "brain", "eye_l", "eye_r", "ear", "nose", "mouth", "teeth"),
            new OrganGroup("手臂", "shoulder", "arm", "hand"),
            new OrganGroup("腿部", "leg", "foot"),
            new OrganGroup("皮肤与毛发", "skin", "hair"),
        };

        public static readonly List<OrganGroup> AnimalGroups = new List<OrganGroup> {
            new OrganGroup("躯干", "chest", "abdomen", "spine", "stomach", "heart", "lung",
                "kidney", "liver", "intestine", "blood", "bone", "muscle"),
            new OrganGroup("生殖泌尿系统", "bladder", "anus", "cloaca", "penis", "vagina", "uterus", "ovary", "testicle"),
            new OrganGroup("头部", "brain", "eye_l", "eye_r", "ear", "nose", "mouth", "teeth", "beak", "gills", "horn"),
            new OrganGroup("翅膀", "wing_l", "wing_r"),
            new OrganGroup("腿部", "leg"),
            new OrganGroup("尾部", "tail"),
            new OrganGroup("皮肤与毛发", "skin", "fur", "scale", "feather"),
        };

        public static List<OrganGroup> GetPlan(bool pAnimal) {
            return pAnimal ? AnimalGroups : HumanGroups;
        }

        // 根据物种 id 判断动物类别:返回 "mammal"(哺乳)/ "bird"(禽) / "fish"(鱼) / "reptile"(爬行) / "other"(未知)
        public static string GetAnimalKind(string pSpeciesId) {
            if (string.IsNullOrEmpty(pSpeciesId)) return "other";
            string s = pSpeciesId.ToLowerInvariant();
            // 鱼类/鲨鱼/鲸类/水栖:鱼类(用鳞片 + 泄殖腔,无乳房)
            if (s.Contains("fish") || s.Contains("shark") || s.Contains("whale") || s.Contains("dolphin")
                || s.Contains("squid") || s.Contains("jellyfish") || s.Contains("octopus")
                || s.Contains("eel") || s.Contains("crab") || s.Contains("lobster")
                || s.Contains("piranha") || s.Contains("mermaid")
                || s.Contains("frog") || s.Contains("toad") || s.Contains("salamander")) {
                return "fish";
            }
            // 禽类/鸟类:羽毛 + 泄殖腔,无乳房
            if (s.Contains("bird") || s.Contains("chicken") || s.Contains("duck") || s.Contains("goose")
                || s.Contains("eagle") || (s.Contains("owl") && !s.Contains("knowledge"))
                || s.Contains("crow") || s.Contains("parrot")
                || s.Contains("turkey") || s.Contains("swan") || s.Contains("penguin") || s.Contains("dodo")
                || s.Contains("seagull") || s.Contains("raven") || s.Contains("peacock")
                || s.Contains("ostrich") || s.Contains("rooster") || s.Contains("mallard")
                || s.Contains("falcon") || s.Contains("hawk") || s.Contains("vulture") || s.Contains("emu")
                || s.Contains("flamingo") || s.Contains("dove") || s.Contains("phoenix")
                || s.Contains("fenghuang") || s.Contains("zhuque")) {
                return "bird";
            }
            // 爬行类:鳞片 + 泄殖腔,无乳房(含恐龙/龙/龟)
            if (s.Contains("snake") || s.Contains("lizard") || s.Contains("croc") || s.Contains("alligator")
                || s.Contains("dragon") || s.Contains("gecko") || s.Contains("iguana") || s.Contains("turtle")
                || s.Contains("saurus") || s.Contains("raptor") || s.Contains("ceratops")
                || s.Contains("pterodactyl") || s.Contains("wyvern") || s.Contains("dino")
                || s.Contains("qinglong") || s.Contains("xuanwu")) {
                return "reptile";
            }
            // 其余默认哺乳
            return "mammal";
        }

        // 根据物种 id 判断动物皮肤类型:鱼类→鳞片,鸟类→羽毛,爬行/昆虫→鳞片,其余哺乳→皮毛
        // 龟类:无鳞片(角质骨甲/龟壳),皮肤用默认皮肤
        // 返回该动物应使用的皮肤器官 id(缺省 "fur")
        public static string GetAnimalSkin(string pSpeciesId) {
            string kind = GetAnimalKind(pSpeciesId);
            if (kind == "bird") return "feather";
            if (kind == "fish" || kind == "reptile") {
                string s = pSpeciesId == null ? "" : pSpeciesId.ToLowerInvariant();
                // 龟类无鳞片,改为默认皮肤(龟壳骨甲另行表示)
                if (s.Contains("turtle") || s.Contains("xuanwu")) return "skin";
                return "scale";
            }
            return "fur";
        }

        // 根据物种 id 判断尾巴名称:鱼→鱼尾,鸟→尾羽,其余→尾巴(原始中文;显示走 Organ.LocalizedName 的 bio_dyn_* 键)
        public static string GetTailName(string pSpeciesId) {
            string kind = GetAnimalKind(pSpeciesId);
            if (kind == "fish") return "鱼尾";
            if (kind == "bird") return "尾羽";
            return "尾巴";
        }

        // 根据物种 id 判断腿部名称:鸟→双爪,鱼→双鳍,其余→双腿(原始中文;显示走 bio_dyn_* 键)
        public static string GetLegName(string pSpeciesId) {
            string kind = GetAnimalKind(pSpeciesId);
            if (kind == "bird") return "双爪";
            if (kind == "fish") return "双鳍";
            return "双腿";
        }

        // 该物种是否长角(牛羊鹿等有角哺乳动物)
        public static bool HasHorn(string pSpeciesId) {
            string s = pSpeciesId == null ? "" : pSpeciesId.ToLowerInvariant();
            return s.Contains("sheep") || s.Contains("goat") || s.Contains("cow") || s.Contains("bull")
                || s.Contains("cattle") || s.Contains("deer") || s.Contains("elk") || s.Contains("moose")
                || s.Contains("bison") || s.Contains("buffalo") || s.Contains("ram") || s.Contains("ox")
                || s.Contains("gazelle") || s.Contains("antelope") || s.Contains("unicorn") || s.Contains("rhino")
                || s.Contains("horned") || s.Contains("bighorn");
        }

        // 该物种是否有四肢(蛇/蠕虫无腿):默认有,蛇/蠕虫无
        public static bool HasLegs(string pSpeciesId) {
            string s = pSpeciesId == null ? "" : pSpeciesId.ToLowerInvariant();
            if (s.Contains("snake") || s.Contains("worm") || s.Contains("ouro")) return false;
            return true;
        }

        // 龟类:脊椎与肋骨融合成龟壳(骨盔),脊椎显示为"龟背"
        public static bool UsesShell(string pSpeciesId) {
            string s = pSpeciesId == null ? "" : pSpeciesId.ToLowerInvariant();
            return s.Contains("turtle") || s.Contains("xuanwu");
        }

        // 该物种是否有翅膀:鸟类有(含鸵鸟等翅膀退化的鸟,仍保留翼骨结构)
        public static bool HasWings(string pSpeciesId) {
            return GetAnimalKind(pSpeciesId) == "bird";
        }

        // 该物种是否有鳃:鱼类有鳃、无肺(用鳃呼吸)
        public static bool HasGills(string pSpeciesId) {
            return GetAnimalKind(pSpeciesId) == "fish";
        }

        // 该物种是否用喙(无牙):鸟类 + 龟类(龟嘴是角质喙,无牙齿)
        public static bool UsesBeak(string pSpeciesId) {
            string s = pSpeciesId == null ? "" : pSpeciesId.ToLowerInvariant();
            return GetAnimalKind(pSpeciesId) == "bird"
                || s.Contains("turtle") || s.Contains("xuanwu");
        }

        // 该物种是否有乳房:只有哺乳动物有
        public static bool HasBreast(string pSpeciesId) {
            return GetAnimalKind(pSpeciesId) == "mammal";
        }

        // 该物种使用泄殖腔(鱼/禽/爬行),而非阴茎/阴道
        public static bool UsesCloaca(string pSpeciesId) {
            string kind = GetAnimalKind(pSpeciesId);
            return kind == "fish" || kind == "bird" || kind == "reptile";
        }

        // 哺乳动物体型分类:0=小型(猫/兔/鼠等,罩杯A~B),1=中型(狗/狼/狐狸等,罩杯A~D),2=大型(羊/牛/马等,罩杯D~G)
        public static int GetMammalSize(string pSpeciesId) {
            string s = pSpeciesId == null ? "" : pSpeciesId.ToLowerInvariant();
            // 大型:羊/牛/马/鹿/熊/狮/虎/骆驼/象/犀牛/河马/野牛/野猪
            if (s.Contains("sheep") || s.Contains("goat") || s.Contains("cow") || s.Contains("bull")
                || s.Contains("horse") || s.Contains("deer") || s.Contains("elk") || s.Contains("moose")
                || s.Contains("bear") || s.Contains("lion") || s.Contains("tiger") || s.Contains("camel")
                || s.Contains("elephant") || s.Contains("rhino") || s.Contains("hippo") || s.Contains("buffalo")
                || s.Contains("bison") || s.Contains("boar") || s.Contains("pig") || s.Contains("cattle")
                || s.Contains("ram") || s.Contains("cow_")) {
                return 2;
            }
            // 小型:猫/兔/鼠/松鼠/雪貂/蝙蝠/鼹鼠/刺猬/仓鼠
            if (s.Contains("cat") || s.Contains("kitten") || s.Contains("rabbit") || s.Contains("hare")
                || s.Contains("mouse") || s.Contains("rat") || s.Contains("squirrel") || s.Contains("ferret")
                || s.Contains("bat") || s.Contains("mole") || s.Contains("hedgehog") || s.Contains("hamster")) {
                return 0;
            }
            return 1;
        }
    }
}
