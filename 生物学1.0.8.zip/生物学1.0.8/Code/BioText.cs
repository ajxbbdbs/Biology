namespace RimWorldMod
{

    /// <summary>
    /// 本地化查询辅助类。
    /// 当指定的键在本地化字典中不存在时，自动回退到给定的中文原文（fallback），
    /// 行为与原版 RimWorld 的本地化机制保持一致。
    /// 适用于模组开发中需要动态获取翻译文本的场景。
    /// </summary>
    public static class BioText
    {

        /// <summary>
        /// 检查本地化字典中是否存在指定的键。
        /// </summary>
        /// <param name="pKey">要查询的本地化键（如 "BioText.Example"）。</param>
        /// <returns>如果键存在且管理器有效，返回 true；否则返回 false。</returns>
        public static bool Has(string pKey)
        {
            if (string.IsNullOrEmpty(pKey)) return false;
            try
            {
                var inst = LocalizedTextManager.instance;
                return inst != null && inst._localized_text != null && inst._localized_text.ContainsKey(pKey);
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 内部方法，仅用于封装对 <see cref="Has(string)"/> 的调用。
        /// </summary>
        /// <param name="pKey">要检查的键。</param>
        /// <returns>同 <see cref="Has(string)"/> 的返回值。</returns>
        private static bool HasKey(string pKey)
        {
            return Has(pKey);
        }

        /// <summary>
        /// 获取指定键的本地化文本，若键不存在或发生异常则返回给定的回退文本。
        /// </summary>
        /// <param name="pKey">本地化键。</param>
        /// <param name="pFallback">当键缺失或获取失败时使用的默认中文原文。</param>
        /// <returns>找到的本地化文本或回退文本。</returns>
        public static string T(string pKey, string pFallback)
        {
            try
            {
                if (HasKey(pKey)) return LocalizedTextManager.getText(pKey, null, false);
            }
            catch { }
            return pFallback;
        }

        /// <summary>
        /// 获取指定键的本地化文本，并支持格式化参数。
        /// 若键缺失或异常则使用回退文本，之后再应用格式化。
        /// </summary>
        /// <param name="pKey">本地化键。</param>
        /// <param name="pFallback">默认中文原文（可包含占位符如 {0}）。</param>
        /// <param name="pArgs">用于格式化的参数数组。</param>
        /// <returns>格式化后的文本字符串。</returns>
        /// <example>
        /// 假设键 "Greeting" 对应 "你好，{0}！"，调用：
        /// <code>BioText.F("Greeting", "你好，{0}！", "玩家")</code>
        /// 将返回 "你好，玩家！"。
        /// </example>
        public static string F(string pKey, string pFallback, params object[] pArgs)
        {
            string text;
            try
            {
                text = HasKey(pKey) ? LocalizedTextManager.getText(pKey, null, false) : pFallback;
            }
            catch
            {
                text = pFallback;
            }
            if (pArgs == null || pArgs.Length == 0) return text;
            try
            {
                return string.Format(text, pArgs);
            }
            catch
            {
                return text; // 格式化失败时返回未格式化的原始文本
            }
        }
    }
}
