using System;
using UnityEngine;
using UnityEngine.UI;

namespace RimWorldMod {

    /// <summary>
    /// 头像框与立绘之间的身高尺。
    ///
    /// 尺子是用纯色方块现画的,不需要任何贴图 —— 一根竖脊 + 每 10cm 一道短刻度 + 每 50cm 一道长刻度
    /// 带数字。这样任何分辨率下都是干净的直角边,不会像位图那样缩放糊掉。
    ///
    /// 两条规矩:
    ///   刻度朝右长,冲着立绘那一侧;数字排在竖脊左边(靠头像框那一侧)。
    ///   尺子只画到这个单位自己的身高就截断,再往上的刻度一根都不画 —— 尺顶就是他的头顶。
    ///
    /// 比例尺(每米多少单位)由 BioBodyDoll 统一给,立绘用的是同一个值,所以刻度和立绘对得上。
    /// </summary>
    public static class BioHeightRuler {

        public const float MaxMeters = 3.0f;    // 刻度节点的预建上限(画多少由身高决定,这只是数组大小)

        private const float StepM = 0.1f;       // 小刻度间隔
        private const int MajorEvery = 5;       // 每几个小刻度算一道大刻度(5 → 每 0.5m)
        private const float LabelW = 22f;       // 竖脊左边留给数字的宽度
        private const float SpineW = 2f;        // 竖脊宽度
        private const float MinorLen = 4f;      // 小刻度长度(往右,朝着立绘)
        private const float MajorLen = 8f;      // 大刻度长度
        private const float TickH = 1.5f;       // 刻度线粗细
        private const int FontSize = 9;         // 数字字号
        private const float LabelH = 11f;       // 数字行高(也用来判断顶端读数会不会压住刻度数字)

        /// <summary> 尺子这一列的总宽度:数字区 + 竖脊 + 最长刻度 </summary>
        public const float Width = LabelW + SpineW + MajorLen;

        private static readonly Color ColorSpine = new Color(0.60f, 0.63f, 0.58f, 0.95f);
        private static readonly Color ColorTick = new Color(0.72f, 0.75f, 0.70f, 0.95f);
        private static readonly Color ColorLabel = new Color(0.78f, 0.80f, 0.76f, 1f);
        private static readonly Color ColorTop = new Color(0.92f, 0.93f, 0.90f, 1f);

        private static RectTransform _root;
        private static Image _spine;
        private static Image[] _ticks;
        private static Text[] _tickLabels;      // 只有大刻度有,小刻度处为 null
        private static Text _topLabel;          // 尺顶读数(精确身高)

        /// <summary> 建节点。只在重搭容器时调一次,之后靠 Apply 摆位 </summary>
        public static void Build(RectTransform pParent) {
            _root = null; _spine = null; _ticks = null; _tickLabels = null; _topLabel = null;
            if (pParent == null) return;
            try {
                GameObject go = new GameObject("HeightRuler", typeof(RectTransform));
                go.transform.SetParent(pParent, false);
                _root = go.GetComponent<RectTransform>();
                _root.anchorMin = new Vector2(0f, 0f);
                _root.anchorMax = new Vector2(0f, 0f);
                _root.pivot = new Vector2(0f, 0f);

                _spine = NewBar("Spine", ColorSpine);

                int count = Mathf.RoundToInt(MaxMeters / StepM) + 1;
                _ticks = new Image[count];
                _tickLabels = new Text[count];
                for (int i = 0; i < count; i++) {
                    _ticks[i] = NewBar("Tick" + i, ColorTick);
                    if (i % MajorEvery == 0) _tickLabels[i] = NewLabel("Label" + i, ColorLabel);
                }

                _topLabel = NewLabel("TopLabel", ColorTop);
                _topLabel.fontStyle = FontStyle.Bold;
            } catch (Exception e) {
                Main.LogError("生物学:身高尺创建失败 " + e);
            }
        }

        /// <summary>
        /// 按当前比例摆位。pX = 尺子这一列的左边距, pUnitsPerMeter = 每米多少单位(必须与立绘一致),
        /// pMeters = 这个单位的身高。尺子高度 = 身高,超出身高的刻度全部隐藏。
        /// </summary>
        public static void Apply(float pX, float pUnitsPerMeter, float pMeters) {
            if (_root == null || _ticks == null) return;
            try {
                float top = Mathf.Max(0f, pMeters) * pUnitsPerMeter;
                _root.anchoredPosition = new Vector2(pX, 0f);
                _root.sizeDelta = new Vector2(Width, top);

                float tickX = LabelW + SpineW;      // 刻度从竖脊右侧起,朝立绘长
                Place(_spine, LabelW, 0f, SpineW, top);

                for (int i = 0; i < _ticks.Length; i++) {
                    bool major = i % MajorEvery == 0;
                    float m = i * StepM;
                    float y = m * pUnitsPerMeter;
                    // 超过身高的刻度一根不画。留半根线的余量,免得刚好等高那道被浮点误差吃掉
                    bool inRange = y <= top + TickH * 0.5f;

                    if (_ticks[i] != null) {
                        _ticks[i].gameObject.SetActive(inRange);
                        if (inRange) {
                            Place(_ticks[i], tickX, y - TickH * 0.5f, major ? MajorLen : MinorLen, TickH);
                        }
                    }

                    Text lab = _tickLabels[i];
                    if (lab == null) continue;
                    // 顶端读数会压住刻度数字时,让刻度数字避让
                    bool showLabel = inRange && Mathf.Abs(y - top) >= LabelH;
                    lab.gameObject.SetActive(showLabel);
                    if (!showLabel) continue;
                    lab.text = m.ToString("F1");
                    lab.fontSize = FontSize;
                    Place(lab.rectTransform, 0f, y - LabelH * 0.5f, LabelW - 2f, LabelH);
                }

                if (_topLabel != null) {
                    _topLabel.text = pMeters.ToString("F2");
                    _topLabel.fontSize = FontSize;
                    Place(_topLabel.rectTransform, 0f, top - LabelH * 0.5f, LabelW - 2f, LabelH);
                }
            } catch (Exception e) {
                Main.LogError("生物学:身高尺摆位失败 " + e);
            }
        }

        private static void Place(Component pNode, float pX, float pY, float pW, float pH) {
            if (pNode == null) return;
            RectTransform rt = pNode is RectTransform ? (RectTransform)pNode : pNode.transform as RectTransform;
            if (rt == null) return;
            rt.anchoredPosition = new Vector2(pX, pY);
            rt.sizeDelta = new Vector2(Mathf.Max(0f, pW), Mathf.Max(0f, pH));
        }

        // 纯色方块:Image 不给 sprite 时 Graphic 会按 color 画一个实心矩形,不用任何贴图
        private static Image NewBar(string pName, Color pColor) {
            GameObject go = new GameObject(pName, typeof(RectTransform), typeof(Image));
            go.transform.SetParent(_root, false);
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 0f);
            rt.anchorMax = new Vector2(0f, 0f);
            rt.pivot = new Vector2(0f, 0f);
            Image img = go.GetComponent<Image>();
            img.color = pColor;
            img.raycastTarget = false;
            return img;
        }

        // 数字统一右对齐贴着竖脊,读起来是一列
        private static Text NewLabel(string pName, Color pColor) {
            GameObject go = new GameObject(pName, typeof(RectTransform), typeof(Text));
            go.transform.SetParent(_root, false);
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 0f);
            rt.anchorMax = new Vector2(0f, 0f);
            rt.pivot = new Vector2(0f, 0f);
            Text t = go.GetComponent<Text>();
            t.font = LocalizedTextManager.current_font;
            t.fontSize = FontSize;
            t.color = pColor;
            t.alignment = TextAnchor.MiddleRight;
            t.horizontalOverflow = HorizontalWrapMode.Overflow;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            t.raycastTarget = false;
            return t;
        }
    }
}
