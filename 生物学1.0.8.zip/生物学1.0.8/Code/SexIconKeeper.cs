using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace RimWorldMod
{
    // 性别图标同步工具(事件驱动):在窗口打开/切换选中单位/器官编辑后调用。
    // 不做每帧轮询,避免放置小人等高频场景的额外开销导致卡顿。
    // 双性(⚥)时用图标 sprite 替换原版性别图标;非双性时恢复原版。
    public static class SexIconKeeper
    {
        // 记录被强制替换过的图标,用于恢复
        private static readonly Dictionary<Transform, RestoreData> _forced = new Dictionary<Transform, RestoreData>();

        private class RestoreData
        {
            public Sprite Sprite;
            public Color Color;
            public Image.Type Type;
            public bool Enabled;
        }

        // 立即同步选中面板(selected_unit)与单位窗口(unit)
        public static void SyncNow()
        {
            try
            {
                Actor selected = null;
                try { if (SelectedUnit.isSet()) selected = SelectedUnit.unit; } catch { }
                SyncRoot(GameObject.Find("selected_unit"), selected, true);

                UnitWindow win = null;
                try { win = UnityEngine.Object.FindObjectOfType<UnitWindow>(); } catch { }
                if (win != null)
                {
                    Actor winActor = null;
                    try { winActor = UnitHealthTab.CurrentUnitWindowActor(); } catch { }
                    SyncRoot(win.transform, winActor, true);
                }
            }
            catch
            {
            }
        }

        public static void SyncRoot(GameObject pRootGo, Actor pActor, bool pRestore)
        {
            if (pRootGo == null || pActor == null) return;
            try
            {
                SyncRoot(pRootGo.transform, pActor, pRestore);
            }
            catch
            {
            }
        }

        public static void SyncRoot(Transform pRoot, Actor pActor, bool pRestore)
        {
            if (pRoot == null || pActor == null) return;

            int gender = 0;
            try { gender = HealthSimulator.GetGender(pActor); } catch { gender = 0; }

            List<Transform> icons = new List<Transform>();
            CollectTitleIcons(pRoot, icons);
            Main.LogInfo("生物学:[诊断] SyncRoot 根=" + pRoot.name + " actor=" + pActor.getName() + " gender=" + gender + " 找到图标=" + icons.Count);
            foreach (Transform t in icons)
            {
                Image im = t.GetComponent<Image>();
                Main.LogInfo("生物学:[诊断]   候选 " + GetPath(t) + " sprite=" + (im != null && im.sprite != null ? im.sprite.name : "null"));
            }
            if (icons.Count == 0) return;

            if (gender == 3)
            {
                Sprite hermaph = null;
                try { hermaph = SexIconSync.ResolveHermaphSprite(); } catch { }
                foreach (Transform t in icons)
                {
                    ForceIntersex(t, hermaph);
                }
            }
            else if (pRestore)
            {
                foreach (Transform t in icons)
                {
                    RestoreIcon(t);
                }
            }
        }

        private static void ForceIntersex(Transform t, Sprite pHermaph)
        {
            RectTransform rt = t as RectTransform;
            if (rt == null) rt = t.GetComponent<RectTransform>();
            if (rt == null) return;

            Image img = t.GetComponent<Image>();
            if (img == null) return;

            // 保护:只有当前显示的是原版性别图标(♂/♀)才覆盖,避免误盖种族图标
            Sprite cur = img.sprite;
            if (cur != null)
            {
                string n = cur.name;
                bool isSexIcon = n == "IconMale" || n == "IconFemale"
                    || n == "iconMale" || n == "iconFemale"
                    || n == "ui/icons/IconMale" || n == "ui/icons/IconFemale";
                if (!isSexIcon && !(n == "iconHermaphrodite" || n == "iconIntersex"))
                {
                    Main.LogInfo("生物学:[诊断] ForceIntersex 跳过 " + GetPath(t) + " sprite=" + n + "(非性别图标)");
                    return;
                }
            }

            if (!_forced.ContainsKey(t))
            {
                _forced[t] = new RestoreData
                {
                    Sprite = img.sprite,
                    Color = img.color,
                    Type = img.type,
                    Enabled = img.enabled
                };
            }

            img.raycastTarget = false;
            if (pHermaph != null)
            {
                img.enabled = true;
                img.sprite = pHermaph;
                img.color = Color.white;
                img.type = Image.Type.Simple;
                img.preserveAspect = true;
            }
            else
            {
                img.enabled = true;
                img.color = new Color(0.75f, 0.40f, 1f, 1f);
                img.sprite = null;
            }
            Main.LogInfo("生物学:[诊断] ForceIntersex 已应用 " + GetPath(t) + " → sprite=" + (img.sprite != null ? img.sprite.name : "null"));
        }

        // 拼接 Transform 完整路径,便于日志定位
        internal static string GetPath(Transform t)
        {
            if (t == null) return "null";
            string s = t.name;
            Transform cur = t.parent;
            int guard = 0;
            while (cur != null && guard < 20)
            {
                s = cur.name + "/" + s;
                cur = cur.parent;
                guard++;
            }
            return s;
        }

        private static void RestoreIcon(Transform t)
        {
            RestoreData data;
            if (!_forced.TryGetValue(t, out data)) return;

            Image img = t.GetComponent<Image>();
            if (img != null)
            {
                img.enabled = data.Enabled;
                img.sprite = data.Sprite;
                img.color = data.Color;
                img.type = data.Type;
                img.raycastTarget = true;
            }
            _forced.Remove(t);
        }

        private static void CollectTitleIcons(Transform pRoot, List<Transform> pOut)
        {
            if (pRoot == null) return;
            if ((pRoot.name == "icon_left" || pRoot.name == "icon_right")
                && HasAncestor(pRoot, "tab_title_container_unit", "tab_title_container"))
            {
                pOut.Add(pRoot);
            }
            for (int i = 0; i < pRoot.childCount; i++)
            {
                CollectTitleIcons(pRoot.GetChild(i), pOut);
            }
        }

        private static bool HasAncestor(Transform t, params string[] pNames)
        {
            Transform cur = t.parent;
            int guard = 0;
            while (cur != null && guard < 20)
            {
                foreach (string n in pNames)
                {
                    if (cur.name == n) return true;
                }
                cur = cur.parent;
                guard++;
            }
            return false;
        }
    }
}