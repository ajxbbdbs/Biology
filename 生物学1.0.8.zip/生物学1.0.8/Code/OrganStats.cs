using System.Collections.Generic;
using UnityEngine;

namespace RimWorldMod {

    // 器官缺失/受损 → Actor 属性联动
    // 挖掉(缺失)器官会按映射扣减 Actor 的 血量/攻击力/移动速度/攻击速度,
    // 恢复器官(加回/治愈)后属性自动还原。每次应用采用"反推基础值"方式,不长期缓存,可跟踪属性变化。
    public static class OrganStats {

        // 器官 → 影响属性列表:(stat, 最大扣减比例)
        private static readonly Dictionary<string, KeyValuePair<string, float>[]> Map =
            new Dictionary<string, KeyValuePair<string, float>[]> {
                // ===== 最大血量 health =====
                { "heart",      new[] { KV("health", 0.50f) } },  // 心脏
                { "lung",       new[] { KV("health", 0.40f) } },  // 肺(原左右肺 0.20+0.20)
                { "blood",      new[] { KV("health", 0.30f) } },  // 血液
                { "kidney",     new[] { KV("health", 0.20f) } },  // 肾(原左右肾 0.10+0.10)
                { "liver",      new[] { KV("health", 0.15f) } },  // 肝
                { "brain",      new[] { KV("health", 0.15f) } },  // 大脑
                { "stomach",    new[] { KV("health", 0.10f) } },  // 胃
                { "intestine",  new[] { KV("health", 0.10f) } },  // 肠道
                { "spine",      new[] { KV("health", 0.10f) } },  // 脊椎

                // ===== 攻击力 damage =====
                { "muscle",     new[] { KV("damage", 0.25f), KV("attack_speed", 0.10f), KV("armor", 0.10f) } }, // 肌肉
                { "arm",        new[] { KV("damage", 0.30f) } },  // 双臂(原左右臂 0.15+0.15)
                { "hand",       new[] { KV("damage", 0.20f), KV("attack_speed", 0.20f) } }, // 双手
                { "shoulder",   new[] { KV("damage", 0.16f) } },  // 双肩(原左右肩 0.08+0.08)
                { "fang",       new[] { KV("damage", 0.10f) } },  // 毒牙
                { "horn",       new[] { KV("damage", 0.05f) } },  // 角

                // ===== 移动速度 speed =====
                { "leg",        new[] { KV("speed", 0.50f) } },   // 双腿(原左右腿 0.25+0.25)
                { "foot",       new[] { KV("speed", 0.30f) } },   // 双脚(原左右脚 0.15+0.15)
                // 关节骨 = 原 关节(speed 0.20) + 骨骼(speed 0.10) + 骨髓(health 0.15)
                { "bone",       new[] { KV("speed", 0.30f), KV("health", 0.15f) } },
                { "tail",       new[] { KV("speed", 0.05f) } },   // 尾巴

                // ===== 生育率 birth_rate =====
                // 原版拿 (int)stats["birth_rate"] 当"额外再生几个"的次数上限(每次 50% 起、
                // 逐个 ×0.85 递减,见 BabyMaker.makeBabyFromPregnancy),文明种族基础值是 5。
                // 所以强化子宫会实打实提高多胞胎概率,摘掉/弱化则相反。
                { "uterus",     new[] { KV("birth_rate", 0.60f) } },
                { "ovary",      new[] { KV("birth_rate", 0.30f) } },
            };

        private static KeyValuePair<string, float> KV(string pStat, float pRatio) {
            return new KeyValuePair<string, float>(pStat, pRatio);
        }

        // 上次应用的总扣减比例(用于反推基础值,避免重复扣减)
        private static readonly Dictionary<long, Dictionary<string, float>> _lastMod =
            new Dictionary<long, Dictionary<string, float>>();

        // 双腿皆失时记录的基础移速(恢复双腿时按此还原,避免被强制为 1 的当前值污染反推)
        private static readonly Dictionary<long, float> _leglessSpeedBase =
            new Dictionary<long, float>();

        // 上次应用器官联动时的 stats_dirty_version(仅在原版 updateStats 真正重建后重算一次,避免重复叠加)
        private static readonly Dictionary<long, int> _recalcVersion = new Dictionary<long, int>();

        // 原版 Actor.updateStats() 重建完所有属性后调用:此时 stats 为纯净基础值,
        // 直接按当前器官修正重写(不 setStatsDirty,避免再次触发重建形成死循环)。
        public static void ApplyAfterRecalc(Actor pActor) {
            if (pActor == null || !HealthSimulator.IsOrganSupported(pActor)) return;
            try {
                long id = pActor.getID();
                int ver = pActor.getStatsDirtyVersion();
                int lastVer;
                if (_recalcVersion.TryGetValue(id, out lastVer) && lastVer == ver) return; // 未重建,跳过
                _recalcVersion[id] = ver;

                Dictionary<string, float> mods = ComputeMods(pActor);
                bool legsGone = IsLegless(id);
                foreach (KeyValuePair<string, float> kv in mods) {
                    string st = kv.Key;
                    float nm = kv.Value;
                    // 双腿皆失:显示的移速也归零。真正让他动不了的是 BioExperience 那个钩子
                    // (原版在 precalcMovementSpeed 末尾有移速保底 1,光改这个属性拦不住)
                    if (st == "speed" && legsGone) {
                        pActor.stats[st] = 0f;
                        continue;
                    }
                    float cur = pActor.stats[st]; // 重建后的基础值
                    // 削减方向保底 5%;加成方向不再封顶(强化血液可持续提高血量)
                    float factor = 1f - nm;
                    factor = Mathf.Clamp(factor, 0.05f, nm < 0f ? 100f : 2f);
                    pActor.stats[st] = cur * factor;
                }
                _lastMod[id] = mods;
            } catch (System.Exception e) {
                Main.LogError("生物学:重建后应用器官属性联动失败 " + e);
            }
        }

        // 按当前器官缺失状态把属性修正应用到 Actor(选中单位常驻调用)
        public static void ApplyStats(Actor pActor) {
            if (pActor == null || !HealthSimulator.IsOrganSupported(pActor)) return;
            try {
                long id = pActor.getID();
                Dictionary<string, float> mods = ComputeMods(pActor);
                Dictionary<string, float> last;
                _lastMod.TryGetValue(id, out last);

                bool legsGone = IsLegless(id);

                HashSet<string> statKeys = new HashSet<string>();
                foreach (string k in mods.Keys) statKeys.Add(k);
                if (last != null)
                {
                    foreach (string k in last.Keys) statKeys.Add(k);
                }

                foreach (string st in statKeys) {
                    float cur = pActor.stats[st];
                    float lm = 0f;
                    float nm = 0f;
                    if (last != null) last.TryGetValue(st, out lm);
                    mods.TryGetValue(st, out nm);
                    // 双腿皆失:移速固定为 1(先记录失去双腿前的基础移速,便于恢复时还原)
                    if (st == "speed" && legsGone) {
                        if (!_leglessSpeedBase.ContainsKey(id)) {
                            float b = (1f - lm) >= 0.05f ? cur / (1f - lm) : cur * 20f;
                            if (b < 1f) b = 0f;
                            _leglessSpeedBase[id] = b;
                        }
                        pActor.stats["speed"] = 0f;
                        // 不把 speed 修正写回 last,否则恢复双腿时会按错误基础反推
                        mods["speed"] = 0f;
                        continue;
                    }
                    // 刚从"双腿皆失"恢复:用记录的基础移速直接计算,而不是按当前 1 反推
                    if (st == "speed") {
                        float saved;
                        if (_leglessSpeedBase.TryGetValue(id, out saved)) {
                            _leglessSpeedBase.Remove(id);
                            pActor.stats["speed"] = saved * Mathf.Clamp(1f - nm, 0.05f, 2f);
                            continue;
                        }
                    }
                    // 反推基础值(消除上次修正),再按新修正乘算(正=削减,负=加成)
                    float baseVal = (1f - lm) >= 0.05f ? cur / (1f - lm) : cur * 20f;
                    if (baseVal < 1f) baseVal = 1f;
                    // 削减方向保底 5%(器官全摘仍有残值);加成方向不再封顶(强化血液可持续提高血量)
                    float factor = 1f - nm;
                    factor = Mathf.Clamp(factor, 0.05f, nm < 0f ? 100f : 2f);
                    float newVal = baseVal * factor;
                    pActor.stats[st] = newVal;
                    if (st == "health") LogHealthDiag(id, pActor, cur, lm, nm, baseVal, factor, newVal);
                }
                _lastMod[id] = mods;
                pActor.setStatsDirty();
            } catch (System.Exception e) {
                Main.LogError("生物学:应用器官属性联动失败 " + e);
            }
        }

        // 双腿是不是被摘了
        private static bool IsLegless(long pActorId) {
            try {
                ActorWoundState st = HealthSimulator.GetState(pActorId);
                return st != null && st.Mods != null && st.Mods.RemovedOrgans != null
                    && st.Mods.RemovedOrgans.Contains("leg");
            } catch {
                return false;
            }
        }

        // 当前计算的各属性修正:统计 → 修正系数(正=削减,负=加成)
        private static Dictionary<string, float> ComputeMods(Actor pActor) {
            Dictionary<string, float> mods = new Dictionary<string, float>();
            try {
                ActorWoundState state = HealthSimulator.GetState(pActor.getID());
                if (state == null || state.Mods == null) return mods;
                // 被挖掉的器官:全扣
                if (state.Mods.RemovedOrgans != null) {
                    foreach (string oid in state.Mods.RemovedOrgans) {
                        KeyValuePair<string, float>[] entries;
                        if (!Map.TryGetValue(oid, out entries)) continue;
                        foreach (KeyValuePair<string, float> e in entries) {
                            float cur;
                            mods.TryGetValue(e.Key, out cur);
                            mods[e.Key] = cur + e.Value;
                        }
                    }
                }
                // 弱化(负 HpMods) → 按比例削减对应属性;达到衰竭(≤-100)等同缺失全扣
                // 强化(正 HpMods,仅腿/脚) → 提升移动速度
                foreach (KeyValuePair<string, KeyValuePair<string, float>[]> kv in Map) {
                    if (state.Mods.RemovedOrgans != null && state.Mods.RemovedOrgans.Contains(kv.Key)) continue;
                    int hm;
                    if (!state.Mods.HpMods.TryGetValue(kv.Key, out hm)) continue;
                    if (hm == 0) continue;
                    bool limbSpeed = kv.Key == "leg" || kv.Key == "foot";
                    foreach (KeyValuePair<string, float> e in kv.Value) {
                        float cur;
                        mods.TryGetValue(e.Key, out cur);
                        if (hm < 0) {
                            // 弱化:线性削减,弱到 -100 即等同摘除(与上方的全扣一致)
                            float ratio = Mathf.Clamp(-hm, 0f, 100f) / 100f;
                            mods[e.Key] = cur + e.Value * ratio;
                        } else if (kv.Key == "blood" && e.Key == "health") {
                            // 血液强化:按等级持续提升最大血量(种族基础血量 × 血液占比 × 强化百分比),
                            // 与弱化对称,无上限(可无限强化加血)
                            float boost = (float)hm / 100f * e.Value;
                            mods[e.Key] = cur - boost;
                        } else if (kv.Key == "muscle") {
                            // 肌肉强化:按等级提升攻击力+攻击速度+防御力(与弱化对称,无上限)
                            float boost = (float)hm / 100f * e.Value;
                            mods[e.Key] = cur - boost;
                        } else if (limbSpeed && e.Key == "speed") {
                            // 腿/脚强化:满强化(≥100)提升与摘除相反,约 +25% 移动速度
                            float boost = Mathf.Clamp(hm, 0f, 100f) / 100f * 0.25f;
                            mods[e.Key] = cur - boost;
                        } else if (e.Key == "birth_rate") {
                            // 子宫/卵巢强化:按等级提升生育率(与弱化对称,无上限 —— 强化得越狠越容易多胞胎)
                            float boost = (float)hm / 100f * e.Value;
                            mods[e.Key] = cur - boost;
                        }
                    }
                }
            } catch { }
            return mods;
        }

        // 血量联动诊断:仅在数值/修正变化时打印一次(选中单位每0.2s调用,避免刷屏)
        private static string _lastHealthDiag = "";
        private static void LogHealthDiag(long pId, Actor pActor, float pCur, float pLastMod,
            float pNewMod, float pBaseVal, float pFactor, float pNewVal) {
            try {
                int bloodHm = 0;
                ActorWoundState st = HealthSimulator.GetState(pId);
                if (st != null && st.Mods != null) st.Mods.HpMods.TryGetValue("blood", out bloodHm);
                string diag = string.Format("生物学:[血量诊断] actor={0} 血mod={1} cur={2:F0} lastMod={3:F2} newMod={4:F2} base={5:F0} factor={6:F2} newVal={7:F0}",
                    pActor.getName(), bloodHm, pCur, pLastMod, pNewMod, pBaseVal, pFactor, pNewVal);
                if (diag != _lastHealthDiag) {
                    _lastHealthDiag = diag;
                    Main.LogInfo(diag);
                }
            } catch { }
        }
    }
}
