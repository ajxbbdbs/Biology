using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using Newtonsoft.Json;

namespace RimWorldMod {

    /// <summary>
    /// 已故收藏:收藏的单位死了不当它没存在过,把它死亡那一刻的完整数据留一份,以后能原样复活。
    ///
    /// 为什么必须在死亡"之前"拍快照 —— 读过 Actor.die 的 IL:
    ///   · clearManagers() 会对 clan/army/culture/family 各调一次 manager.unitDied(...),
    ///     然后把 Actor 上那几个运行期引用(Actor.clan 等)置空
    ///   · setCity(null) / removeKing() / destroyAllEquipment() / takeAwayItems() /
    ///     clearHomeBuilding() / stopBeingWarrior() 会把身份和随身物一并拆掉
    /// 好消息是这些动作清的是运行期引用,ActorData 里那一整套 id 字段不动:
    ///   civ_kingdom_id / cityID / clan / family / culture / religion / language / army /
    ///   subspecies / plot / lover / best_friend_id / parent_id_1 / parent_id_2 /
    ///   ancestor_family / generation / renown / kills / births / level / experience /
    ///   money / homeBuildingID / profession / saved_traits / phenotype_* ...
    /// 也就是说"这个人是谁、和谁有关系、是什么身份"全都在 data 里,而且是按 id 存的。
    /// 所以只要在 die 前把 data 深拷贝一份,复活时把这些 id 重新接回去就能还原关系与身份 ——
    /// 这也是为什么要在 prefix 里拍,晚一步 setCity(null) 之类就把 cityID 抹了。
    ///
    /// ⚠ 千万不要留 Actor 对象的引用。试过,踩过:
    /// 单位被移出 units 之后,那个 Actor 对象会回到对象池给下一个新生单位复用。曾经想着
    /// "把尸体留着,收藏栏那一行直接拿它渲染、以后原地复活",还前置 putForRecycle 想拦住回收 ——
    /// 拦截没生效,实测日志里快照记的 id=5、手上那个对象已经变成 id=6 的另一个人,
    /// 结果就是往收藏栏塞进一个毫无关系的活人,窗口反复重排、关掉之后视角卡死。
    /// 结论:死亡之后唯一可信的东西就是这份 data 快照,别碰 Actor 引用。
    ///
    /// 也因此,已故名单不能直接塞进原版收藏栏 —— WindowFavorites 那套列表是按 List&lt;Actor&gt;
    /// 渲染的(getObjects → getElements → showElement(Actor)),没有活 Actor 就没有行可渲染。
    /// 要显示得由模组自己开一个窗口,拿快照里的名字/种族/死亡时间画,见 Ready 的说明。
    /// </summary>
    public static class BioResurrect {

        /// <summary> 一份死亡快照 </summary>
        public class Grave {
            public long Id;             // 原单位 id。复活要沿用它,别人 data 里指向他的 id 才能重新解析到
            public string Name;
            public string AssetId;      // 种族/单位类型(ActorManager.createNewUnit 要它)
            public double DiedTime;     // 世界时间
            public int X, Y;            // 死亡位置
            public bool WasKing;        // 死的时候是不是国王
            public long KingdomId;      // 生前王国(复活时这个王国还在才谈得上"仍然是国王")
            public ActorData Data;      // die 拆解之前的完整数据(深拷贝)
            public ActorWoundState Organs;  // 这个模组自己那套器官/伤情状态
        }

        // 按死亡时间从早到晚
        private static readonly List<Grave> _graves = new List<Grave>();
        private static readonly Dictionary<long, Grave> _byId = new Dictionary<long, Grave>();
        private static bool _patched;

        /// <summary> 已故收藏名单(最近死的排在前面) </summary>
        public static List<Grave> All() {
            List<Grave> copy = new List<Grave>(_graves);
            copy.Reverse();
            return copy;
        }

        public static int Count { get { return _graves.Count; } }

        public static bool TryGet(long pActorId, out Grave pGrave) {
            return _byId.TryGetValue(pActorId, out pGrave);
        }

        public static void Ensure() {
            if (_patched) return;
            _patched = true;
            try {
                Harmony harmony = new Harmony("rimworld_health_resurrect");
                harmony.Patch(
                    AccessTools.Method(typeof(Actor), "die"),
                    prefix: new HarmonyMethod(AccessTools.Method(typeof(BioResurrect), nameof(OnBeforeDie)))
                );
                Main.LogInfo("生物学:已故收藏记录已启用");
            } catch (Exception e) {
                Main.LogError("生物学:已故收藏启用失败 " + e);
            }
        }

        // Actor.die 的前置:趁数据还完整,把收藏单位的家底抄一份
        public static void OnBeforeDie(Actor __instance) {
            try {
                if (__instance == null) return;
                if (!__instance.isAlive()) return;          // 已经死了,别重复记
                if (!__instance.isFavorite()) return;       // 只记收藏的
                if (_byId.ContainsKey(__instance.getID())) return;
                Snapshot(__instance);
            } catch (Exception e) {
                Main.LogError("生物学:记录已故收藏失败 " + e);
            }
        }

        private static void Snapshot(Actor pActor) {
            Grave g = new Grave();
            g.Id = pActor.getID();
            try { g.Name = pActor.getName(); } catch { g.Name = "?"; }
            try { g.AssetId = pActor.asset != null ? pActor.asset.id : null; } catch { }
            try { g.DiedTime = World.world != null ? World.world.getCurWorldTime() : 0.0; } catch { }
            try {
                if (pActor.current_tile != null) {
                    g.X = pActor.current_tile.x;
                    g.Y = pActor.current_tile.y;
                }
            } catch { }
            try { g.WasKing = pActor.isKing(); } catch { }
            try { g.KingdomId = pActor.kingdom != null ? pActor.kingdom.getID() : 0L; } catch { }
            g.Data = CloneData(pActor.data);
            // 器官状态是这个模组自己的表,直接把整条搬过来 —— 复活后伤情和手术记录都在
            try {
                ActorWoundState st;
                if (HealthSimulator.TryGetState(g.Id, out st)) g.Organs = st;
            } catch { }

            if (g.Data == null) {
                Main.LogError("生物学:已故收藏快照失败(数据拷不出来)" + g.Name);
                return;
            }
            _graves.Add(g);
            _byId[g.Id] = g;
            Main.LogInfo("生物学:已故收藏 +1 <" + g.Name + "> id=" + g.Id
                + (g.WasKing ? " (国王)" : "") + " 名单共 " + _graves.Count + " 人");
        }

        /// <summary>
        /// 深拷贝 ActorData。不逐字段抄是因为那是四十多个字段,漏一个就是复活出来少一样东西;
        /// 这个类本身就是存档序列化的对象,过一遍 json 最省事也最不容易漏。
        /// 每个收藏单位一辈子只走一次,不在热路径上。
        /// </summary>
        private static ActorData CloneData(ActorData pData) {
            if (pData == null) return null;
            try {
                string json = JsonConvert.SerializeObject(pData);
                return JsonConvert.DeserializeObject<ActorData>(json);
            } catch (Exception e) {
                Main.LogError("生物学:拷贝单位数据失败 " + e);
                return null;
            }
        }

        /// <summary>
        /// 复活。⚠ 实验性:这一步会往世界里加单位并改 units 的 id 索引,先在能丢的存档上试。
        ///
        /// 做法:先用 createNewUnit 建一个同种族的活单位(原版会把贴图/格子/管理器都接好),
        /// 再把死亡快照那份 data 整份换上去 —— data 里带着原 id、名字、特质、等级、声望,
        /// 以及 kingdom/city/clan/family/culture/religion/lover/parent 这一整套 id,
        /// 所以"他是谁、和谁有关系"跟着一起回来了。然后:
        ///   · 把 units 的 id 索引从新 id 改回原 id,别人 data 里指向他的 id 才能重新解析到
        ///   · 按 data 里的 id 把运行期引用(Actor.kingdom / city / clan / ...)逐个接回去
        ///   · 生前是国王且王国还在 → 重新加冕
        ///   · 器官/伤情状态搬回原 id
        /// 任何一步失败都只是这个单位少接一样东西,不会把整张表改坏 —— id 索引那一步失败就退回
        /// 用新 id(关系会断,但世界是完整的)。
        /// </summary>
        public static bool Resurrect(long pActorId) {
            Grave g;
            if (!_byId.TryGetValue(pActorId, out g) || g.Data == null) {
                Main.LogError("生物学:复活失败,名单里没有 id=" + pActorId);
                return false;
            }
            if (string.IsNullOrEmpty(g.AssetId)) {
                Main.LogError("生物学:复活失败,快照里没有种族 id");
                return false;
            }
            Actor a = null;
            try {
                WorldTile tile = null;
                try { tile = World.world.GetTileSimple(g.X, g.Y); } catch { }
                if (tile == null) { try { tile = World.world.GetTile(g.X, g.Y); } catch { } }
                if (tile == null) {
                    Main.LogError("生物学:复活失败,死亡位置那块地已经没了 (" + g.X + "," + g.Y + ")");
                    return false;
                }
                a = World.world.units.createNewUnit(g.AssetId, tile, false, 0f, null, null,
                    false, true, false, false);
                if (a == null) {
                    Main.LogError("生物学:复活失败,createNewUnit 返回 null(" + g.AssetId + ")");
                    return false;
                }
            } catch (Exception e) {
                Main.LogError("生物学:复活失败,生成单位时出错 " + e);
                return false;
            }

            long freshId = -1;
            try { freshId = a.getID(); } catch { }
            // 换数据。⚠ 不能直接 a.data = 快照:快照是 json 深拷贝出来的,BaseSystemData 里
            // custom_data_int / long / float / bool / string / flags 那几个容器会是 null,
            // 而原版每帧的 BatchActors.updateStats 要走 data["xxx"] 索引器,那个索引器直接
            // 解引用容器 → 单位更新的并行任务每帧抛 NullReferenceException、调度器停摆,
            // 表现就是时间冻住、点开窗口一秒就被弹回(第一版复活踩的就是这个)。
            // 所以改成把快照的字段逐个拷到活单位那份 data 上,容器保持活的那一份。
            try {
                CopyData(g.Data, a.data);
            } catch (Exception e) {
                Main.LogError("生物学:复活失败,拷数据时出错 " + e);
                return false;
            }
            // id 索引:原版按 getID() 入表,现在 id 变回原值了,表里那个键得跟着改
            bool idRestored = false;
            try {
                Dictionary<long, Actor> dict = World.world.units.dict;
                if (dict != null && !dict.ContainsKey(g.Id)) {
                    if (freshId >= 0) dict.Remove(freshId);
                    dict[g.Id] = a;
                    idRestored = true;
                } else {
                    Main.LogError("生物学:原 id " + g.Id + " 已被占用,这次用新 id " + freshId
                        + "(关系会断,但世界是完整的)");
                }
            } catch (Exception e) {
                Main.LogError("生物学:改 id 索引失败,保留新 id " + e);
            }

            Relink(a, g);
            RestoreTraits(a, g);
            RestoreOrgans(a, g);
            RecrownIfKing(a, g);

            try { a.setStatsDirty(); } catch { }
            try { a.data.favorite = true; } catch { }
            try { World.world.locateAndFollow(a, null, null); } catch { }

            _graves.Remove(g);
            _byId.Remove(g.Id);
            Main.LogInfo("生物学:复活完成 <" + g.Name + "> 原id=" + g.Id
                + " 沿用原id=" + idRestored + " 名单剩 " + _graves.Count + " 人");
            try {
                new WorldLogMessage(WorldLogLibrary.auto_tester,
                    BioText.F("bio_log_resurrect", "{0} 回来了", g.Name)).add();
            } catch { }
            return true;
        }

        /// <summary>
        /// 把快照那份 data 的字段拷到活单位那份 data 上。
        ///
        /// custom_data_* 那六个容器一律不拷,永远保留活单位自己的那一份。第一版是"整个对象替换",
        /// 第二版改成"拷过去再把 null 的补回来" —— 都还是会让时间冻住,因为 json 反序列化出来的
        /// CustomDataContainer 对象本身不是 null,是它里面那个字典是 null,所以补空判断根本不触发,
        /// 而原版每帧 data["xxx"] 一解引用就在 CustomDataContainer.TryGetValue 里抛 NRE,
        /// 单位更新的并行任务停摆 → 时间停、窗口弹回。
        /// 代价是单位身上存的那些 custom_data 不跟着复活,换来的是世界能正常跑。
        /// </summary>
        private static readonly string[] ContainerFields = {
            "custom_data_int", "custom_data_long", "custom_data_float",
            "custom_data_bool", "custom_data_string", "custom_data_flags"
        };

        private static void CopyData(ActorData pFrom, ActorData pTo) {
            List<FieldInfo> all = new List<FieldInfo>();
            Type t = typeof(ActorData);
            while (t != null && t != typeof(object)) {
                all.AddRange(t.GetFields(BindingFlags.Instance | BindingFlags.Public
                    | BindingFlags.NonPublic | BindingFlags.DeclaredOnly));
                t = t.BaseType;
            }
            int copied = 0, skipped = 0;
            for (int i = 0; i < all.Count; i++) {
                FieldInfo f = all[i];
                if (f.IsStatic || f.IsLiteral) continue;
                if (Array.IndexOf(ContainerFields, f.Name) >= 0) {
                    skipped++;
                    continue;
                }
                try {
                    f.SetValue(pTo, f.GetValue(pFrom));
                    copied++;
                } catch { }
            }
            Main.LogInfo("生物学:复活拷字段 " + copied + " 个,跳过容器 " + skipped + " 个");
        }

        // 按 data 里那些 id 把运行期引用接回去。每一步单独 try:接不上就少接一样,不影响其它
        private static void Relink(Actor pActor, Grave pGrave) {
            ActorData d = pGrave.Data;
            try {
                Kingdom k = World.world.kingdoms.get(d.civ_kingdom_id);
                if (k != null) pActor.setKingdom(k);
            } catch (Exception e) { Main.LogInfo("生物学:复活接王国失败 " + e.Message); }
            try {
                City c = World.world.cities.get(d.cityID);
                if (c != null) pActor.setCity(c);
            } catch (Exception e) { Main.LogInfo("生物学:复活接城市失败 " + e.Message); }
            try {
                Clan cl = World.world.clans.get(d.clan);
                if (cl != null) pActor.setClan(cl);
            } catch (Exception e) { Main.LogInfo("生物学:复活接氏族失败 " + e.Message); }
            try {
                Family f = World.world.families.get(d.family);
                if (f != null) pActor.setFamily(f);
            } catch (Exception e) { Main.LogInfo("生物学:复活接家族失败 " + e.Message); }
            try {
                Culture cu = World.world.cultures.get(d.culture);
                if (cu != null) pActor.setCulture(cu);
            } catch (Exception e) { Main.LogInfo("生物学:复活接文化失败 " + e.Message); }
            try {
                Religion r = World.world.religions.get(d.religion);
                if (r != null) pActor.setReligion(r);
            } catch (Exception e) { Main.LogInfo("生物学:复活接信仰失败 " + e.Message); }
            try {
                Subspecies s = World.world.subspecies.get(d.subspecies);
                if (s != null) pActor.setSubspecies(s);
            } catch (Exception e) { Main.LogInfo("生物学:复活接亚种失败 " + e.Message); }
        }

        // 特质:换 data 之后 Actor.traits 那份运行期列表还是新单位的,按快照补齐
        private static void RestoreTraits(Actor pActor, Grave pGrave) {
            try {
                List<string> want = pGrave.Data.saved_traits;
                if (want == null) return;
                for (int i = 0; i < want.Count; i++) {
                    string tid = want[i];
                    if (string.IsNullOrEmpty(tid)) continue;
                    bool has = false;
                    if (pActor.traits != null) {
                        foreach (ActorTrait t in pActor.traits) {
                            if (t != null && t.id == tid) { has = true; break; }
                        }
                    }
                    if (!has) {
                        try { pActor.addTrait(tid, false); } catch { }
                    }
                }
            } catch (Exception e) {
                Main.LogInfo("生物学:复活补特质失败 " + e.Message);
            }
        }

        // 器官/伤情状态搬回原 id(这是模组自己的表,直接放回去就行)
        private static void RestoreOrgans(Actor pActor, Grave pGrave) {
            try {
                if (pGrave.Organs == null) return;
                HealthSimulator.PutState(pGrave.Id, pGrave.Organs);
            } catch (Exception e) {
                Main.LogInfo("生物学:复活还原器官状态失败 " + e.Message);
            }
        }

        // 生前是国王,而且那个王国还在 → 重新加冕
        private static void RecrownIfKing(Actor pActor, Grave pGrave) {
            if (!pGrave.WasKing) return;
            try {
                Kingdom k = World.world.kingdoms.get(pGrave.KingdomId);
                if (k == null || !k.isAlive()) {
                    Main.LogInfo("生物学:生前的王国已不在,不再加冕");
                    return;
                }
                k.setKing(pActor, false);
                Main.LogInfo("生物学:复活并重新加冕 <" + pGrave.Name + ">");
            } catch (Exception e) {
                Main.LogError("生物学:复活重新加冕失败 " + e);
            }
        }

        /// <summary> 显示与复活都接上了。这里留着当开关用,以后要临时关掉复活按钮改这里 </summary>
        public static bool Ready { get { return true; } }
    }
}
