using System.Collections.Generic;
using UnityEngine;

namespace RimWorldMod {

    // 全单位低频处理非致命持续衰竭;选中单位仅做 UI/属性同步,不会重复扣血。
    public class HealthDrainBehaviour : MonoBehaviour {
        private const float WorldCheckInterval = 1f;
        private const int BatchSize = 64;
        private float _lastWorldCheck;
        private float _lastSelectedCheck;
        private int _nextActor;

        private void Update() {
            try {
                float now = Time.unscaledTime;
                if (now >= _lastWorldCheck + WorldCheckInterval) {
                    _lastWorldCheck = now;
                    ProcessWorldBatch();
                }
                if (now >= _lastSelectedCheck + 0.2f) {
                    _lastSelectedCheck = now;
                    ProcessSelectedUnit();
                }
            } catch (System.Exception e) {
                Main.LogError("生物学:持续衰竭处理异常 " + e);
            }
        }

        private void ProcessWorldBatch() {
            try {
                if (World.world == null || World.world.isPaused() || World.world.units == null) return;
                List<Actor> actors = World.world.units.getSimpleList();
                if (actors == null || actors.Count == 0) {
                    _nextActor = 0;
                    return;
                }
                if (_nextActor >= actors.Count) _nextActor = 0;
                int count = Mathf.Min(BatchSize, actors.Count);
                for (int i = 0; i < count; i++) {
                    if (_nextActor >= actors.Count) _nextActor = 0;
                    Actor actor = actors[_nextActor++];
                    if (actor == null || !actor.isAlive()) continue;
                    MortalityGuard.ClampHealthToMax(actor);
                    DrainIfCritical(actor);
                }
            } catch (System.Exception e) {
                Main.LogError("生物学:全单位持续衰竭异常 " + e);
            }
        }

        private void ProcessSelectedUnit() {
            if (!SelectedUnit.isSet()) return;
            Actor actor = SelectedUnit.unit;
            if (actor == null || !actor.isAlive() || !HealthSimulator.IsOrganSupported(actor)) return;
            try {
                OrganStats.ApplyStats(actor);
                BrainStat.ApplyStats(actor);
                MortalityGuard.ClampHealthToMax(actor);
                if (!HealthSimulator.HasStomach(actor) && actor.data != null && actor.data.nutrition > 0) {
                    actor.data.nutrition = 0;
                }
                UnitHealthTab.RefreshHeaderValues(actor);
            } catch (System.Exception e) {
                Main.LogError("生物学:选中单位属性同步异常 " + e);
            }
        }

        // 只读已有状态,避免为世界中每个单位创建器官 state。
        private void DrainIfCritical(Actor pActor) {
            try {
                ActorWoundState state;
                if (!HealthSimulator.TryGetState(pActor.getID(), out state)) return;
                bool boneFailed = state != null && state.Mods != null
                    && state.Mods.FunctionallyFailedOrgans != null
                    && state.Mods.FunctionallyFailedOrgans.Contains("bone");
                if (boneFailed) OrganEditorUI.ApplyBoneFailureConsequences(pActor, state);
                float ratio = boneFailed ? 0.01f : 0f;
                string reason = boneFailed ? "关节骨衰竭" : "";
                if (HasModDisease(state, "chest", "respiratory_failure")) {
                    ratio = 0.02f;
                    reason = "呼吸衰竭";
                }
                if (HasModDisease(state, "blood", "uremia") && ratio < 0.015f) {
                    ratio = 0.015f;
                    reason = "尿毒症";
                }
                if (HasModDisease(state, "blood", "internal_bleeding") && ratio < 0.03f) {
                    ratio = 0.03f;
                    reason = "内出血";
                }
                if (HasModDisease(state, "intestine", "no_stomach") && ratio < 0.02f) {
                    ratio = 0.02f;
                    reason = "无胃症";
                }
                if (HasModDisease(state, "intestine", "anal_blockage") && ratio < 0.01f) {
                    ratio = 0.01f;
                    reason = "肛门堵塞";
                }
                bool paralysis = HasModDisease(state, "spine", "paralysis");
                if (paralysis && ratio < 0.01f) {
                    ratio = 0.01f;
                    reason = "瘫痪";
                }
                if (paralysis) {
                    try {
                        pActor.makeConfused(-1f, true);
                    } catch (System.Exception ce) {
                        Main.LogError("生物学:瘫痪施加行动限制失败 " + ce);
                    }
                }
                if (ratio > 0f && pActor.isAlive() && pActor.getHealth() > 0f) {
                    pActor.getHit(pActor.getHealth() * ratio, false, AttackType.Divine, null, false, false, false);
                    Main.LogInfo("生物学:持续扣血 " + reason);
                }
            } catch (System.Exception e) {
                Main.LogError("生物学:持续扣血异常 " + e);
            }
        }

        private static bool HasModDisease(ActorWoundState pState, string pHost, string pDiseaseId) {
            if (pState == null || pState.Mods == null || pState.Mods.ModDiseases == null) return false;
            string cur;
            return pState.Mods.ModDiseases.TryGetValue(pHost, out cur) && cur == pDiseaseId;
        }
    }
}
