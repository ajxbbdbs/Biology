using System;
using NeoModLoader.General;
using NeoModLoader.General.UI.Tab;
using NeoModLoader.ui;
using NeoModLoader.ui.prefabs;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace RimWorldMod {
    /// <summary>WorldBox 底部主 PowerTab：墓园窗口、种族美化和服装显示。</summary>
    public static class BiologyPowerTab {
        public const string TabId = "biology";
        private const string RaceIconPath = "ui/icons/Texture Beautification";
        private const string ClothedIconPath = "ui/icons/Clothed Outfit";
        private const string NudeIconPath = "ui/icons/Nude Outfit";
        private const string SettingsIconPath = "ui/icons/iconOptions";
        private const string SettingsFallbackIconPath = "ui/Icons/iconOptions";
        private const string CthulhuIconPath = "ui/icons/iconCthulhuBrain";
        private static readonly Color DisabledIconColor = new Color(0.32f, 0.32f, 0.32f, 1f);
        private static PowersTab _tab;
        private static PowerButton _graveButton;
        private static PowerButton _raceButton;
        private static PowerButton _clothingButton;
        private static PowerButton _settingsButton;
        private static PowerButton _cthulhuButton;
        private static bool _creating;
        private static bool _loggedTabState;
        private static bool _loggedSettingsIconFallback;
        private static bool _lastRaceState;
        private static bool _lastClothingState;
        private static Sprite _lastRaceSprite;
        private static Sprite _lastClothingSprite;
        private static bool _stateCached;
        private static readonly Dictionary<int, Vector3> BaseIconScales =
            new Dictionary<int, Vector3>();
        private static readonly Dictionary<int, Vector2> BaseIconSizes =
            new Dictionary<int, Vector2>();
        private static Vector3 _templateIconScale = Vector3.one;
        private static Vector2 _templateIconSize = Vector2.zero;
        private static bool _templateIconMetricsCached;

        public static bool Ensure() {
            if (_creating) return false;
            PowersTab found = FindTab();
            if (found != null) {
                _tab = found;
                CacheButtons();
                if (_cthulhuButton == null && _tab != null) CreateCthulhuButton();
                if (!HasExactButtons()) {
                    Main.LogError("生物学:已存在的底部PowerTab按钮结构异常，等待重新加载界面");
                    return false;
                }
                BindClickOnce(_raceButton, ToggleRaceBeautification);
                BindClickOnce(_clothingButton, ToggleClothing);
                BindClickOnce(_settingsButton, OpenModSettings);
                CacheTemplateIconMetrics(_graveButton);
                ApplyIconState(_graveButton, Icon("ui/Icons/iconFavoritesList", "ui/icons/iconBiology"),
                    Color.white, false, false, "ensure");
                ApplyIconState(_settingsButton, SettingsIcon(), Color.white, false, false, "ensure");
                _tab.sortButtons();
                RefreshStateIfChanged();
                LogTabStateOnce();
                return true;
            }
            if (CanvasMain.instance == null || CanvasMain.instance.canvas_windows == null
                || Resources.FindObjectsOfTypeAll<PowersTab>().Length == 0) return false;

            _creating = true;
            try {
                BioGraveTab.Initialize();
                _tab = TabManager.CreateTab(TabId, "bio_power_tab_title", "bio_power_tab_desc",
                    RequiredIcon("ui/icons/iconBiology"));

                _graveButton = PowerButtonCreator.CreateSimpleButton("bio_power_graves",
                    BioGraveTab.Open, Icon("ui/Icons/iconFavoritesList", "ui/icons/iconBiology"));
                SetTip(_graveButton, "bio_power_graves_title", "bio_power_graves_desc");
                CacheTemplateIconMetrics(_graveButton);

                _raceButton = PowerButtonCreator.CreateSimpleButton("bio_power_race",
                    ToggleRaceBeautification, RequiredIcon(RaceIconPath));
                SetTip(_raceButton, "bio_power_race_title", "bio_power_race_desc");

                _cthulhuButton = PowerButtonCreator.CreateGodPowerButton("golden_brain", RequiredIcon(CthulhuIconPath));
                SetTip(_cthulhuButton, "bio_power_cthulhu_brain_title", "bio_power_cthulhu_brain_desc");

                _clothingButton = PowerButtonCreator.CreateSimpleButton("bio_power_clothing",
                    ToggleClothing, RequiredIcon(ClothedIconPath));
                SetTip(_clothingButton, "bio_power_clothing_title", "bio_power_clothing_desc");

                _settingsButton = PowerButtonCreator.CreateSimpleButton("bio_power_mod_settings",
                    OpenModSettings, SettingsIcon());
                SetTip(_settingsButton, "bio_power_mod_settings_title", "bio_power_mod_settings_desc");
                BindClickOnce(_raceButton, ToggleRaceBeautification);
                BindClickOnce(_clothingButton, ToggleClothing);
                BindClickOnce(_settingsButton, OpenModSettings);

                PowerButtonCreator.AddButtonToTab(_graveButton, _tab);
                PowerButtonCreator.AddButtonToTab(_raceButton, _tab);
                PowerButtonCreator.AddButtonToTab(_cthulhuButton, _tab);
                PowerButtonCreator.AddButtonToTab(_clothingButton, _tab);
                PowerButtonCreator.AddButtonToTab(_settingsButton, _tab);
                _tab.sortButtons();

                ApplyIconState(_graveButton, Icon("ui/Icons/iconFavoritesList", "ui/icons/iconBiology"),
                    Color.white, false, false, "create");
                ApplyIconState(_settingsButton, SettingsIcon(), Color.white, false, false, "create");
                RefreshState();
                LogTabStateOnce();
                Main.LogInfo("生物学:底部PowerTab已创建，包含5个按钮");
                return true;
            } catch (Exception e) {
                Main.LogError("生物学:创建底部PowerTab失败 " + e);
                _tab = null;
                return false;
            } finally {
                _creating = false;
            }
        }

        private static PowersTab FindTab() {
            if (_tab != null && _tab.gameObject != null) {
                PowerTabAsset currentAsset = _tab.getAsset();
                if (currentAsset != null && currentAsset.id == TabId) return _tab;
            }
            if (CanvasMain.instance == null || CanvasMain.instance.canvas_ui == null) return null;
            _tab = PowerButtonCreator.GetTab(TabId);
            return _tab;
        }

                private static bool HasExactButtons() {
            if (_tab == null) return false;
            int count = 0;
            for (int i = 0; i < _tab.transform.childCount; i++) {
                PowerButton button = _tab.transform.GetChild(i).GetComponent<PowerButton>();
                if (button != null && IsBiologyButton(button.name)) count++;
            }
            return count == 5 && _graveButton != null && _raceButton != null
                && _clothingButton != null && _settingsButton != null && _cthulhuButton != null;
        }
private static bool IsBiologyButton(string pName) {
            return pName == "bio_power_graves" || pName == "bio_power_race"
                || pName == "bio_power_clothing" || pName == "bio_power_mod_settings"
                || pName == "golden_brain";
        }

        private static void LogTabStateOnce() {
            if (_loggedTabState || _tab == null) return;
            _loggedTabState = true;
            PowerTabAsset asset = _tab.getAsset();
            Main.LogInfo("生物学:PowerTab状态 name=" + _tab.name
                + " asset.id=" + (asset != null ? asset.id : "<null>")
                + " graves.parent=" + ParentPath(_graveButton)
                + " race.parent=" + ParentPath(_raceButton)
                + " cthulhu.parent=" + ParentPath(_cthulhuButton)
                + " settings.parent=" + ParentPath(_settingsButton)
                + " biologyButtons=" + CountBiologyButtons());
        }

        private static int CountBiologyButtons() {
            if (_tab == null) return 0;
            int count = 0;
            PowerButton[] buttons = _tab.GetComponentsInChildren<PowerButton>(true);
            for (int i = 0; i < buttons.Length; i++)
                if (buttons[i] != null && IsBiologyButton(buttons[i].name)) count++;
            return count;
        }

        private static string ParentPath(PowerButton pButton) {
            if (pButton == null || pButton.transform.parent == null) return "<null>";
            string path = pButton.transform.parent.name;
            Transform parent = pButton.transform.parent.parent;
            while (parent != null) {
                path = parent.name + "/" + path;
                parent = parent.parent;
            }
            return path;
        }

        private static void SetTip(PowerButton pButton, string pTitle, string pDescription) {
            if (pButton == null) return;
            TipButton tip = pButton.GetComponent<TipButton>()
                ?? pButton.gameObject.AddComponent<TipButton>();
            tip.textOnClick = pTitle;
            tip.textOnClickDescription = pDescription;
        }

        private static Sprite RequiredIcon(string pPath) {
            Sprite sprite = SpriteTextureLoader.getSprite(pPath);
            if (sprite == null) throw new InvalidOperationException("Missing sprite: " + pPath);
            return sprite;
        }

        private static Sprite SettingsIcon() {
            Sprite sprite = SpriteTextureLoader.getSprite(SettingsIconPath);
            if (sprite != null) return sprite;
            sprite = SpriteTextureLoader.getSprite(SettingsFallbackIconPath);
            if (sprite == null) throw new InvalidOperationException(
                "Missing sprites: " + SettingsIconPath + ", " + SettingsFallbackIconPath);
            if (!_loggedSettingsIconFallback) {
                _loggedSettingsIconFallback = true;
                Main.LogInfo("生物学:原版设置齿轮加载失败，使用已确认的原版fallback "
                    + SettingsFallbackIconPath);
            }
            return sprite;
        }

        private static Sprite Icon(params string[] pPaths) {
            for (int i = 0; i < pPaths.Length; i++) {
                Sprite sprite = SpriteTextureLoader.getSprite(pPaths[i]);
                if (sprite != null) return sprite;
            }
            return RequiredIcon("ui/icons/iconBiology");
        }

        private static void CacheButtons() {
            _graveButton = FindButton("bio_power_graves");
            _raceButton = FindButton("bio_power_race");
            _clothingButton = FindButton("bio_power_clothing");
            _settingsButton = FindButton("bio_power_mod_settings");
            _cthulhuButton = FindButton("golden_brain");
        }

        private static PowerButton FindButton(string pName) {
            if (_tab == null) return null;
            PowerButton[] buttons = _tab.GetComponentsInChildren<PowerButton>(true);
            for (int i = 0; i < buttons.Length; i++)
                if (buttons[i] != null && buttons[i].name == pName) return buttons[i];
            return null;
        }

        private static void BindClickOnce(PowerButton pButton, UnityAction pAction) {
            if (pButton == null) return;
            Button button = pButton.GetComponent<Button>();
            if (button == null) throw new InvalidOperationException(
                "PowerButton is missing Button: " + pButton.name);
            button.onClick.RemoveAllListeners();
            button.onClick.AddListener(pAction);
        }

        private static bool RaceBeautificationOn() {
            return Main.ReadFeatureSwitch("矮人贴图", Main.DwarfSkin)
                || Main.ReadFeatureSwitch("人类贴图", Main.HumanSkin);
        }

        private static void ToggleRaceBeautification() {
            bool next = !RaceBeautificationOn();
            Main.SetDwarfSkinEnabled(next);
            Main.SetHumanSkinEnabled(next);
            RefreshState(true, "race-click");
        }

        private static void ToggleClothing() {
            Main.SetHideClothingEnabled(!Main.ReadFeatureSwitch("隐藏服装", Main.HideClothing));
            RefreshState(true, "clothing-click");
        }

        private static void OpenModSettings() {
            try {
                var config = Main.Instance != null ? Main.Instance.GetConfig() : null;
                if (config == null) throw new InvalidOperationException("Biology ModConfig is unavailable");
                ModConfigureWindow.ShowWindow(config);
                Main.LogInfo("生物学:已打开当前模组配置窗口");
            } catch (Exception e) {
                Main.LogError("生物学:打开当前模组配置窗口失败 " + e);
                // 这是玩家主动点击设置按钮后的必要反馈，不属于启动诊断提示。
                try { WorldTip.showNow("无法打开生物学模组设置，请查看日志。", false, "top"); }
                catch (Exception tipError) {
                    Main.LogError("生物学:显示配置窗口错误提示失败 " + tipError);
                }
            }
        }

        private static void CreateCthulhuButton() {
            if (_tab == null || _cthulhuButton != null) return;
            _cthulhuButton = PowerButtonCreator.CreateGodPowerButton("golden_brain", RequiredIcon(CthulhuIconPath));
            SetTip(_cthulhuButton, "bio_power_cthulhu_brain_title", "bio_power_cthulhu_brain_desc");
            PowerButtonCreator.AddButtonToTab(_cthulhuButton, _tab);
            _tab.sortButtons();
        }


        public static void RefreshState() {
            RefreshState(false, "state-change");
        }

        public static void RefreshStateIfChanged() {
            bool race = RaceBeautificationOn();
            bool clothing = Main.ReadFeatureSwitch("隐藏服装", Main.HideClothing);
            Sprite raceSprite = _raceButton != null && _raceButton.icon != null
                ? _raceButton.icon.overrideSprite : null;
            Sprite clothingSprite = _clothingButton != null && _clothingButton.icon != null
                ? _clothingButton.icon.overrideSprite : null;
            if (!_stateCached || race != _lastRaceState || clothing != _lastClothingState
                || raceSprite != _lastRaceSprite || clothingSprite != _lastClothingSprite) {
                Main.SyncFeatureSwitchesFromConfig();
                RefreshState(false, "poll-change");
            }
        }

        private static void RefreshState(bool pLog, string pReason) {
            bool race = RaceBeautificationOn();
            bool clothing = Main.ReadFeatureSwitch("隐藏服装", Main.HideClothing);
            _lastRaceState = race;
            _lastClothingState = clothing;
            _stateCached = true;
            SetTip(_raceButton, "bio_power_race_title", "bio_power_race_desc");
            SetTip(_clothingButton, "bio_power_clothing_title", "bio_power_clothing_desc");
            Sprite raceIcon = RequiredIcon(RaceIconPath);
            Sprite clothingIcon = RequiredIcon(clothing ? NudeIconPath : ClothedIconPath);
            _lastRaceSprite = raceIcon;
            _lastClothingSprite = clothingIcon;
            if (_raceButton != null) ApplyIconState(_raceButton, raceIcon,
                race ? Color.white : DisabledIconColor, true, pLog, pReason);
            if (_clothingButton != null) ApplyIconState(_clothingButton,
                clothingIcon, Color.white, true, pLog, pReason);
        }

        private static void ApplyIconState(PowerButton pButton, Sprite pSprite, Color pColor,
            bool pDoubleSize, bool pLog, string pReason) {
            if (pButton == null) return;
            Image icon = pButton.icon;
            if (icon == null) throw new InvalidOperationException(
                "PowerButton.icon is null: " + pButton.name);

            // NML CreateSimpleButton writes both properties on this exact public Image field.
            icon.sprite = pSprite;
            icon.overrideSprite = pSprite;
            icon.color = pColor;
            icon.raycastTarget = false;
            ApplyFixedVisualScale(icon.rectTransform, pDoubleSize ? 2f : 1f);

            Transform legacyOverlay = pButton.transform.Find("BioSelectedOverlay");
            if (legacyOverlay != null) {
                Image overlayImage = legacyOverlay.GetComponent<Image>();
                if (overlayImage != null) overlayImage.raycastTarget = false;
                legacyOverlay.gameObject.SetActive(false);
                UnityEngine.Object.Destroy(legacyOverlay.gameObject);
            }

            if (pLog) {
                bool configValue = Main.ReadFeatureSwitch("隐藏服装", Main.HideClothing);
                RectTransform rect = icon.rectTransform;
                Main.LogInfo("生物学:PowerButton刷新 reason=" + pReason
                    + " HideClothing=" + Main.HideClothing
                    + " config=" + configValue
                    + " sprite=" + (icon.overrideSprite != null ? icon.overrideSprite.name : "<null>")
                    + " image=" + FullPath(icon.transform)
                    + " scale=" + rect.localScale
                    + " size=" + rect.rect.size);
            }
        }

        private static void CacheTemplateIconMetrics(PowerButton pButton) {
            if (_templateIconMetricsCached || pButton == null || pButton.icon == null) return;
            RectTransform rect = pButton.icon.rectTransform;
            _templateIconScale = rect.localScale;
            _templateIconSize = rect.sizeDelta;
            _templateIconMetricsCached = true;
            int id = rect.GetInstanceID();
            BaseIconScales[id] = _templateIconScale;
            BaseIconSizes[id] = _templateIconSize;
        }

        private static void ApplyFixedVisualScale(RectTransform pRect, float pMultiplier) {
            int id = pRect.GetInstanceID();
            Vector3 baseScale;
            Vector2 baseSize;
            if (pMultiplier == 1f && _templateIconMetricsCached) {
                // 设置齿轮永远恢复 CreateSimpleButton 的原始模板尺寸，不采信可能已是 2x 的旧缓存。
                baseScale = _templateIconScale;
                baseSize = _templateIconSize;
                BaseIconScales[id] = baseScale;
                BaseIconSizes[id] = baseSize;
            } else if (!BaseIconScales.TryGetValue(id, out baseScale)) {
                baseScale = pRect.localScale;
                baseSize = pRect.sizeDelta;
                BaseIconScales[id] = baseScale;
                BaseIconSizes[id] = baseSize;
            } else {
                baseSize = BaseIconSizes[id];
            }
            pRect.localScale = new Vector3(baseScale.x * pMultiplier,
                baseScale.y * pMultiplier, baseScale.z);
            pRect.sizeDelta = baseSize;
        }

        private static string FullPath(Transform pTransform) {
            if (pTransform == null) return "<null>";
            string path = pTransform.name;
            Transform parent = pTransform.parent;
            while (parent != null) {
                path = parent.name + "/" + path;
                parent = parent.parent;
            }
            return path;
        }
    }
}
