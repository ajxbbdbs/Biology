using System.Collections.Generic;

namespace RimWorldMod
{
    public class Disease
    {
        public string Id;
        private readonly string _name;
        private readonly string _desc;
        public string Category;
        public List<string> Organs = new List<string>();
        public int Severity;
        public bool Infectious;
        public bool Cancer;
        public bool GeneralInfection;

        public Disease(string pId, string pName, string pDesc, string pCategory, int pSeverity, bool pInfectious = false, bool pCancer = false, bool pGeneral = false, params string[] pOrgans)
        {
            Id = pId;
            _name = pName;
            _desc = pDesc;
            Category = pCategory;
            Severity = pSeverity;
            Infectious = pInfectious;
            Cancer = pCancer;
            GeneralInfection = pGeneral;
            Organs.AddRange(pOrgans);
        }

        public string Name { get { return BioText.T("bio_disease_" + Id, _name); } }
        public string Desc { get { return BioText.T("bio_disease_" + Id + "_desc", _desc); } }
    }

    public enum BindingKind
    {
        Direct,
        RandomInfectious,
        RandomCancer,
        RandomInfection,
        Curse,
        DeathMark,
    }

    public class TraitBinding
    {
        public List<string> TraitIds = new List<string>();
        public List<string> TraitNames = new List<string>();
        public string Display;
        public BindingKind Kind = BindingKind.Direct;
        public List<KeyValuePair<Disease, int>> DiseaseHits = new List<KeyValuePair<Disease, int>>();
        public List<KeyValuePair<string, int>> Boosts = new List<KeyValuePair<string, int>>();
        public bool BoostAll;
        public int BoostAllAmount;
        public int Severity;
        public List<KeyValuePair<string, int>> Penalties = new List<KeyValuePair<string, int>>();

        public TraitBinding(string pDisplay, params string[] pIds)
        {
            Display = pDisplay;
            TraitIds.AddRange(pIds);
        }

        public TraitBinding Names(params string[] pNames)
        {
            TraitNames.AddRange(pNames);
            return this;
        }

        public TraitBinding Give(Disease pDisease, int pSeverity)
        {
            DiseaseHits.Add(new KeyValuePair<Disease, int>(pDisease, pSeverity));
            return this;
        }

        public TraitBinding Boost(string pOrganId, int pAmount)
        {
            Boosts.Add(new KeyValuePair<string, int>(pOrganId, pAmount));
            return this;
        }

        public TraitBinding BoostAllOrgans(int pAmount)
        {
            BoostAll = true;
            BoostAllAmount = pAmount;
            return this;
        }

        public TraitBinding Penalty(string pOrganId, int pPercent)
        {
            Penalties.Add(new KeyValuePair<string, int>(pOrganId, pPercent));
            return this;
        }
    }

    public static class DiseaseLibrary
    {
        public static readonly List<Disease> All = new List<Disease> {
            // ===== 心血管系统 =====
            new Disease("angina", "心绞痛", "心脏供血不足,活动时胸部剧痛", "心血管", 20, false, false, false, "heart"),
            new Disease("cad", "冠心病", "冠状动脉粥样硬化,心肌供血受阻", "心血管", 35, false, false, false, "heart"),
            new Disease("myocarditis", "心肌炎", "心肌炎症,心脏搏动无力", "心血管", 45, false, false, false, "heart"),
            new Disease("pericarditis", "心包炎", "心包膜发炎,压迫心脏", "心血管", 30, false, false, false, "heart"),
            new Disease("arrhythmia", "心律失常", "心跳节律紊乱", "心血管", 25, false, false, false, "heart"),
            new Disease("heart_failure", "心力衰竭", "心脏泵血功能衰竭", "心血管", 60, false, false, false, "heart"),
            new Disease("heart_attack", "心肌梗死", "冠状动脉阻塞,心肌坏死", "心血管", 80, false, false, false, "heart"),
            new Disease("hypertension", "高血压", "血压长期过高,血管壁受损", "心血管", 20, false, false, false, "heart", "blood"),
            new Disease("atherosclerosis", "动脉粥样硬化", "动脉内壁脂质斑块沉积", "心血管", 30, false, false, false, "blood"),
            new Disease("varicose", "静脉曲张", "静脉扩张迂曲", "心血管", 15, false, false, false, "blood", "leg"),
            new Disease("thrombosis", "血栓", "血管内凝块堵塞血流", "心血管", 50, false, false, false, "blood"),
            new Disease("rheumatic_heart", "风湿性心脏病", "风湿热损伤心瓣膜", "心血管", 40, false, false, false, "heart"),

            // ===== 呼吸系统 =====
            new Disease("asthma", "哮喘", "气道慢性炎症,反复喘息", "呼吸", 50, false, false, false, "lung"),
            new Disease("pneumonia", "肺炎", "肺部感染,肺泡充满炎性渗出物", "呼吸", 55, true, false, true, "lung"),
            new Disease("tuberculosis", "肺结核", "结核杆菌感染,肺部空洞", "呼吸", 60, true, false, false, "lung"),
            new Disease("bronchitis", "支气管炎", "支气管黏膜炎症", "呼吸", 35, false, false, false, "lung"),
            new Disease("emphysema", "肺气肿", "肺泡结构破坏,气体交换障碍", "呼吸", 45, false, false, false, "lung"),
            new Disease("pneumoconiosis", "尘肺", "粉尘颗粒沉积肺部", "呼吸", 40, false, false, false, "lung"),
            new Disease("lung_cancer", "肺癌", "肺部恶性肿瘤", "呼吸", 75, false, true, false, "lung"),
            new Disease("pleurisy", "胸膜炎", "胸膜炎症,呼吸时疼痛", "呼吸", 40, false, false, false, "chest"),
            new Disease("pulmonary_embolism", "肺栓塞", "肺动脉被血栓阻塞", "呼吸", 70, false, false, false, "lung"),
            new Disease("bronchiectasis", "支气管扩张", "支气管永久性扩张", "呼吸", 35, false, false, false, "lung"),
            new Disease("influenza", "流行性感冒", "流感病毒感染,高热乏力", "呼吸", 30, true, false, false, "lung", "head"),
            new Disease("common_cold", "感冒", "上呼吸道病毒感染", "呼吸", 15, true, false, false, "nose", "head"),

            // ===== 消化系统 =====
            new Disease("gastric_ulcer", "胃溃疡", "胃壁黏膜溃烂", "消化", 60, false, false, false, "stomach"),
            new Disease("gastritis", "胃炎", "胃黏膜炎症", "消化", 40, false, false, false, "stomach"),
            new Disease("malnutrition", "营养不良", "营养吸收障碍,身体机能下降", "消化", 45, false, false, false, "stomach", "intestine"),
            new Disease("stomach_cancer", "胃癌", "胃部恶性肿瘤", "消化", 75, false, true, false, "stomach"),
            new Disease("hepatitis", "肝炎", "肝脏炎症,肝功能受损", "消化", 50, true, false, true, "liver"),
            new Disease("cirrhosis", "肝硬化", "肝脏纤维化硬化", "消化", 65, false, false, false, "liver"),
            new Disease("liver_cancer", "肝癌", "肝脏恶性肿瘤", "消化", 75, false, true, false, "liver"),
            new Disease("fatty_liver", "脂肪肝", "肝细胞脂肪堆积", "消化", 55, false, false, false, "liver"),
            new Disease("gallstone", "胆结石", "胆囊内结石形成", "消化", 35, false, false, false, "liver"),
            new Disease("cholecystitis", "胆囊炎", "胆囊炎症", "消化", 40, false, false, false, "liver"),
            new Disease("enteritis", "肠炎", "肠道炎症,腹泻腹痛", "消化", 40, true, false, false, "intestine"),
            new Disease("appendicitis", "阑尾炎", "阑尾感染肿胀", "消化", 45, false, false, false, "intestine"),
            new Disease("bowel_obstruction", "肠梗阻", "肠道阻塞,内容物无法通过", "消化", 60, false, false, false, "intestine"),
            new Disease("anal_abscess", "肛周脓肿", "肛门周围感染化脓", "消化", 45, true, false, false, "anus"),
            new Disease("colon_cancer", "结肠癌", "肠道恶性肿瘤", "消化", 75, false, true, false, "intestine"),
            new Disease("hemorrhoid", "痔疮", "直肠肛门静脉丛曲张", "消化", 15, false, false, false, "intestine", "anus"),
            new Disease("anal_fissure", "肛裂", "肛管黏膜撕裂,排便剧痛", "消化", 35, false, false, false, "anus"),
            new Disease("gerd", "胃食管反流", "胃酸反流灼伤食道", "消化", 25, false, false, false, "stomach"),

            // ===== 神经系统 =====
            new Disease("concussion", "脑震荡", "头部撞击导致的脑损伤", "神经", 70, false, false, false, "brain"),
            new Disease("stroke", "中风", "脑部血管破裂或堵塞", "神经", 60, false, false, false, "brain"),
            new Disease("cerebral_thrombosis", "脑血栓", "脑部血管血栓堵塞,危及生命", "神经", 80, false, false, false, "brain"),
            new Disease("migraine", "偏头痛", "反复发作的剧烈头痛", "神经", 30, false, false, false, "brain"),
            new Disease("epilepsy", "癫痫", "脑部异常放电,抽搐发作", "神经", 45, false, false, false, "brain"),
            new Disease("parkinson", "帕金森病", "运动功能障碍,震颤僵硬", "神经", 55, false, false, false, "brain"),
            new Disease("alzheimer", "阿尔茨海默病", "认知功能进行性衰退", "神经", 60, false, false, false, "brain"),
            new Disease("meningitis", "脑膜炎", "脑膜感染发炎", "神经", 65, true, false, false, "brain"),
            new Disease("brain_tumor", "脑瘤", "脑部肿瘤压迫神经", "神经", 75, false, true, false, "brain"),
            new Disease("neuritis", "神经炎", "外周神经炎症疼痛", "神经", 35, false, false, false, "spine"),
            new Disease("trigeminal", "三叉神经痛", "面部阵发性剧痛", "神经", 25, false, false, false, "head"),
            new Disease("insomnia", "失眠症", "长期入睡困难", "神经", 20, false, false, false, "brain"),
            new Disease("hydrocephalus", "脑积水", "脑室积液压迫脑组织", "神经", 55, false, false, false, "brain"),

            // ===== 感官 =====
            new Disease("cataract", "白内障", "晶状体混浊,视力模糊", "感官", 40, false, false, false, "eye_l", "eye_r"),
            new Disease("glaucoma", "青光眼", "眼压升高损伤视神经", "感官", 45, false, false, false, "eye_l", "eye_r"),
            new Disease("retinal_detach", "视网膜脱落", "视网膜脱离,视野缺损", "感官", 60, false, false, false, "eye_l", "eye_r"),
            new Disease("macular", "黄斑变性", "中心视力逐渐丧失", "感官", 50, false, false, false, "eye_l", "eye_r"),
            new Disease("color_blind", "色盲", "色觉辨别障碍", "感官", 15, false, false, false, "eye_l", "eye_r"),
            new Disease("night_blind", "夜盲症", "暗光环境下视力极差", "感官", 25, false, false, false, "eye_l", "eye_r"),
            new Disease("otitis", "中耳炎", "中耳感染化脓", "感官", 45, true, false, false, "ear"),
            new Disease("deafness", "耳聋", "听力完全丧失", "感官", 60, false, false, false, "ear"),
            new Disease("tinnitus", "耳鸣", "持续性耳鸣", "感官", 20, false, false, false, "ear"),
            new Disease("rhinitis", "鼻炎", "鼻腔黏膜炎症", "感官", 35, false, false, false, "nose"),
            new Disease("sinusitis", "鼻窦炎", "鼻窦感染发炎", "感官", 45, true, false, false, "nose"),
            new Disease("nasal_cancer", "鼻癌", "鼻腔恶性肿瘤", "感官", 70, false, true, false, "nose"),
            new Disease("periodontitis", "牙周炎", "牙周组织感染萎缩", "感官", 40, false, false, false, "mouth", "teeth"),
            new Disease("dental_caries", "龋齿", "牙齿蛀蚀损坏", "感官", 35, false, false, false, "teeth"),

            // ===== 骨骼肌肉 =====
            new Disease("fracture", "残疾", "肢体受损或缺失,行动受限", "运动", 40, false, false, false, "bone", "shoulder", "arm", "hand", "leg", "foot", "spine"),
            new Disease("fracture_leg", "残疾", "双腿受损或缺失,行动受限", "运动", 40, false, false, false, "leg"),
            new Disease("fracture_foot", "残疾(双脚)", "双脚受损或缺失,行动受限", "运动", 40, false, false, false, "foot", "leg"),
            new Disease("osteoporosis", "骨质疏松", "骨密度下降,易骨折", "骨骼", 55, false, false, false, "bone"),
            new Disease("joint_bone_failure", "关节骨衰竭", "关节与骨骼功能完全丧失,持续损害生命", "骨骼", 100, false, false, false, "bone"),
            new Disease("arthritis", "关节炎", "关节炎症,活动受限", "骨骼", 45, false, false, false, "bone"),
            new Disease("gout", "痛风", "尿酸盐结晶沉积关节", "骨骼", 50, false, false, false, "bone"),
            new Disease("rickets", "佝偻病", "维生素D缺乏,骨骼软化", "骨骼", 40, false, false, false, "bone"),
            new Disease("scoliosis", "脊柱侧弯", "脊柱向侧方弯曲", "骨骼", 35, false, false, false, "spine"),
            new Disease("disc_herniation", "椎间盘突出", "椎间盘压迫神经根", "骨骼", 50, false, false, false, "spine"),
            new Disease("muscle_atrophy", "肌肉萎缩", "肌肉组织退化无力", "骨骼", 45, false, false, false, "muscle"),
            new Disease("rheumatism", "风湿病", "自身免疫性关节与肌肉炎症", "骨骼", 55, false, false, false, "bone", "muscle"),
            new Disease("tenosynovitis", "腱鞘炎", "肌腱鞘发炎疼痛", "骨骼", 35, false, false, false, "hand"),
            new Disease("bone_cancer", "骨癌", "骨骼恶性肿瘤", "骨骼", 75, false, true, false, "bone"),
            new Disease("osteomyelitis", "骨髓炎", "骨髓腔感染化脓", "骨骼", 60, true, false, false, "bone"),

            // ===== 泌尿系统 =====
            new Disease("kidney_failure", "肾衰竭", "肾功能衰竭,代谢废物堆积", "泌尿", 60, false, false, false, "kidney"),
            new Disease("kidney_stone", "肾结石", "肾脏内结石形成", "泌尿", 40, false, false, false, "kidney"),
            new Disease("nephritis", "肾炎", "肾脏炎症,滤过功能受损", "泌尿", 50, false, false, false, "kidney"),
            new Disease("weakness", "体质虚弱", "体力与抵抗力下降", "泌尿", 40, false, false, false, "kidney"),
            new Disease("stamina_loss", "耐力下降", "活动耐力明显下降", "呼吸", 40, false, false, false, "lung"),
            new Disease("blindness", "失明", "双眼视力完全丧失", "感官", 80, false, false, false, "eye_l", "eye_r"),
            new Disease("poison_susceptibility", "中毒易感", "肝脏解毒能力下降,更易中毒", "消化", 45, false, false, false, "liver"),
            new Disease("hormone_imbalance", "激素失衡", "内分泌失调,激素水平紊乱", "生殖", 45, false, false, false, "testicle", "ovary", "uterus"),
            new Disease("incontinence", "失禁", "肛门括约肌功能丧失,大小便失控", "消化", 50, false, false, false, "anus"),
            new Disease("anal_tear", "肛裂", "肛门黏膜撕裂,排便剧痛", "消化", 55, false, false, false, "anus"),
            new Disease("rotten_anus", "烂屁眼", "肛门组织严重溃烂坏死", "消化", 70, false, false, false, "anus"),
            new Disease("vagina_frequent_sex", "频繁性交", "性交频率过高,阴道略显疲劳", "生殖", 30, false, false, false, "vagina"),
            new Disease("vagina_loose", "阴道松弛", "阴道松弛扩张,弹性下降", "生殖", 50, false, false, false, "vagina"),
            new Disease("loose_pussy", "骚逼", "阴道极度松弛,近乎完全失禁", "生殖", 70, false, false, false, "vagina"),
            new Disease("pyelonephritis", "肾盂肾炎", "肾盂及肾实质感染", "泌尿", 45, true, false, false, "kidney"),
            new Disease("cystitis", "膀胱炎", "膀胱感染发炎", "泌尿", 40, true, false, false, "bladder"),
            new Disease("uremia", "尿毒症", "肾功能完全丧失", "泌尿", 80, false, false, false, "kidney"),
            new Disease("kidney_cancer", "肾癌", "肾脏恶性肿瘤", "泌尿", 75, false, true, false, "kidney"),
            new Disease("uti", "尿道感染", "尿路感染,排尿灼痛", "泌尿", 30, true, false, false, "bladder"),

            // ===== 血液内分泌 =====
            new Disease("anemia", "贫血", "血液携氧能力下降,乏力苍白", "血液", 60, false, false, false, "blood"),
            new Disease("leukemia", "白血病", "造血系统恶性肿瘤", "血液", 80, false, true, false, "blood", "bone"),
            new Disease("hemophilia", "血友病", "凝血功能障碍,出血不止", "血液", 50, false, false, false, "blood"),
            new Disease("diabetes", "糖尿病", "血糖代谢异常,多器官受损", "血液", 60, false, false, false, "blood", "eye_l", "eye_r", "kidney"),
            new Disease("lymphoma", "淋巴瘤", "淋巴系统恶性肿瘤", "血液", 70, false, true, false, "blood", "bone"),
            new Disease("purpura", "紫癜", "皮下出血瘀斑", "血液", 25, false, false, false, "skin", "blood"),
            new Disease("scurvy", "坏血病", "维生素C缺乏,牙龈出血", "血液", 30, false, false, false, "mouth", "skin"),
            new Disease("mutism", "失语", "声带与嘴巴功能异常,无法言语", "血液", 40, false, false, false, "mouth"),
            new Disease("frailty", "身体脆弱", "全身器官脆弱,极易受伤", "血液", 30, false, false, false, "bone", "muscle", "heart", "blood"),
            new Disease("hair_loss", "毛发脱落", "毛发完全脱落,失去保暖与保护", "皮肤", 25, false, false, false, "skin"),
            new Disease("scale_loss", "鳞片缺失", "鳞片脱落,失去防护", "皮肤", 30, false, false, false, "skin"),
            new Disease("fur_loss", "皮毛缺失", "皮毛脱落,体温难以维持", "皮肤", 30, false, false, false, "skin"),
            new Disease("feather_loss", "羽毛缺失", "羽毛脱落,失去保暖与飞行能力", "皮肤", 30, false, false, false, "skin"),
            new Disease("tail_loss", "尾巴缺失", "尾巴缺失,平衡感下降", "骨骼", 25, false, false, false, "spine"),

            // ===== 生殖系统 =====
            new Disease("impotence", "阳痿", "性功能障碍,难以勃起或维持勃起", "生殖", 0, false, false, false, "testicle", "prostate", "uterus", "ovary"),
            new Disease("premature", "早泄", "射精过早,难以自控", "生殖", 0, false, false, false, "testicle", "prostate", "uterus", "ovary"),
            new Disease("ovarian_cyst", "卵巢囊肿", "卵巢囊性增生", "生殖", 40, false, false, false, "ovary"),
            new Disease("uterine_fibroid", "子宫肌瘤", "子宫平滑肌良性肿瘤", "生殖", 40, false, false, false, "uterus"),
            new Disease("prostatitis", "前列腺炎", "前列腺炎症", "生殖", 45, true, false, false, "prostate"),
            new Disease("bph", "前列腺增生", "前列腺肥大压迫尿道", "生殖", 35, false, false, false, "prostate"),
            new Disease("breast_cancer", "乳腺癌", "乳腺恶性肿瘤", "生殖", 70, false, true, false, "chest"),
            new Disease("cervical_cancer", "宫颈癌", "宫颈恶性肿瘤", "生殖", 75, false, true, false, "uterus"),
            new Disease("orchitis", "睾丸炎", "睾丸感染发炎", "生殖", 45, true, false, false, "testicle"),

            // ===== 皮肤 =====
            new Disease("burn", "烧伤", "皮肤组织灼伤坏死", "皮肤", 30, false, false, false, "skin"),
            new Disease("eczema", "湿疹", "皮肤瘙痒起疹", "皮肤", 35, false, false, false, "skin"),
            new Disease("dermatitis", "皮炎", "皮肤发炎红肿", "皮肤", 30, false, false, false, "skin"),
            new Disease("acne", "痤疮", "毛囊皮脂腺发炎", "皮肤", 20, false, false, false, "skin"),
            new Disease("psoriasis", "牛皮癣", "银屑病,皮肤鳞屑斑块", "皮肤", 40, false, false, false, "skin"),
            new Disease("skin_cancer", "皮肤癌", "皮肤恶性肿瘤", "皮肤", 70, false, true, false, "skin"),
            new Disease("frostbite", "冻伤", "低温导致皮肤组织损伤", "皮肤", 45, false, false, false, "skin"),
            new Disease("urticaria", "荨麻疹", "风团样皮疹,瘙痒", "皮肤", 25, false, false, false, "skin"),
            new Disease("scabies", "疥疮", "疥螨寄生引起的皮肤病", "皮肤", 40, true, false, false, "skin"),

            // ===== 感染性疾病 =====
            new Disease("sepsis", "败血症", "病原体入血,全身感染", "感染", 60, true, false, true, "blood"),
            new Disease("tetanus", "破伤风", "破伤风杆菌毒素,肌肉强直", "感染", 55, false, false, false, "muscle"),
            new Disease("rabies", "狂犬病", "狂犬病毒感染,神经系统受累", "感染", 70, true, false, false, "brain"),
            new Disease("cholera", "霍乱", "霍乱弧菌感染,剧烈腹泻", "感染", 55, true, false, false, "intestine"),
            new Disease("dysentery", "痢疾", "痢疾杆菌感染,脓血便", "感染", 45, true, false, false, "intestine"),
            new Disease("typhoid", "伤寒", "伤寒杆菌感染,持续高热", "感染", 50, true, false, false, "intestine"),
            new Disease("malaria", "疟疾", "疟原虫感染,周期性寒战高热", "感染", 40, true, false, false, "liver", "blood"),
            new Disease("bubonic_plague", "鼠疫", "鼠疫杆菌感染,肺部等器官受创", "感染", 60, true, false, false, "lung", "blood"),
            new Disease("curse_affliction", "诅咒", "被诅咒侵蚀,全身机能衰退", "诅咒", 0, false, false, false),
            new Disease("anthrax", "炭疽", "炭疽杆菌感染,皮肤溃疡", "感染", 50, true, false, false, "skin", "lung"),
            new Disease("smallpox", "天花", "天花病毒感染,全身脓疱", "感染", 60, true, false, false, "skin"),
            new Disease("parasite", "寄生虫感染", "肠道寄生虫掠夺营养", "感染", 40, true, false, false, "intestine"),

            // ===== 精神疾病 =====
            new Disease("schizophrenia", "精神分裂", "严重精神障碍,幻觉妄想", "精神", 50, false, false, false, "brain"),
            new Disease("anxiety", "焦虑症", "过度焦虑紧张,心神不宁", "精神", 45, false, false, false, "brain"),
            new Disease("depression", "抑郁症", "持续情绪低落,意志消沉", "精神", 40, false, false, false, "brain"),
            new Disease("ocd", "强迫症", "强迫思维与强迫行为", "精神", 35, false, false, false, "brain"),
            new Disease("delusion", "妄想症", "系统性妄想,多疑", "精神", 50, false, false, false, "brain"),
            new Disease("bipolar", "躁郁症", "情绪在狂躁与抑郁间剧烈波动", "精神", 45, false, false, false, "brain"),
            new Disease("mania", "狂躁症", "极度亢奋易怒,冲动失控", "精神", 50, false, false, false, "brain"),
            new Disease("somnambulism", "梦游症", "睡眠中无意识行走", "精神", 25, false, false, false, "brain"),
            new Disease("ptsd", "创伤后应激障碍", "创伤记忆反复闪回", "精神", 40, false, false, false, "brain"),
            new Disease("dwarfism", "侏儒症", "生长发育迟缓,四肢骨骼短小", "骨骼", 45, false, false, false, "bone"),
            new Disease("nerve_damage", "神经传导障碍", "神经信号传导受阻,肢体反应迟钝", "神经", 40, false, false, false, "spine", "brain"),
            new Disease("brain_deterioration", "脑退化", "脑组织慢性退化,智力与精神下降", "神经", 50, false, false, false, "brain"),
            new Disease("respiratory_failure", "呼吸衰竭", "肺缺失,无法呼吸,持续窒息", "呼吸", 90, false, false, false, "chest"),
            new Disease("paralysis", "瘫痪", "脊椎受损,下半身完全失去行动能力", "骨骼", 80, false, false, false, "spine"),
            new Disease("internal_bleeding", "内出血", "腹部暴露,内脏大出血不止", "血液", 85, false, false, false, "blood", "abdomen"),
            new Disease("no_stomach", "无胃症", "胃被摘除,无法消化食物", "消化", 80, false, false, false, "stomach", "intestine"),
            new Disease("anal_blockage", "肛门堵塞", "肛门缺失,排泄物无法排出", "消化", 70, false, false, false, "intestine", "anus"),
        };

        public static readonly List<TraitBinding> Bindings = BuildBindings();

        private static List<TraitBinding> BuildBindings()
        {
            Disease cat = Find("cataract");
            Disease gla = Find("glaucoma");
            Disease con = Find("concussion");
            Disease fra = Find("fracture");
            Disease bur = Find("burn");
            Disease pl = Find("bubonic_plague");
            Disease fl = Find("fatty_liver");
            Disease dia = Find("diabetes");
            Disease ast = Find("asthma");
            Disease art = Find("arthritis");
            Disease ane = Find("anemia");
            Disease gu = Find("gastric_ulcer");
            Disease mig = Find("migraine");
            Disease anx = Find("anxiety");
            Disease sch = Find("schizophrenia");
            Disease kf = Find("kidney_failure");
            Disease imp = Find("impotence");
            Disease prem = Find("premature");
            Disease ost = Find("osteoporosis");
            Disease hem = Find("hemophilia");
            Disease mania = Find("mania");
            Disease alz = Find("alzheimer");
            Disease dwarf = Find("dwarfism");
            Disease nerve = Find("nerve_damage");
            Disease braind = Find("brain_deterioration");
            Disease ptsdx = Find("ptsd");
            Disease scol = Find("scoliosis");
            Disease osteo = Find("osteoporosis");

            List<TraitBinding> list = new List<TraitBinding>();

            list.Add(new TraitBinding("白内障(双眼50%)", "shortsighted", "nearsighted", "short_sighted")
                .Names("近视", "短视", "Short Sighted", "Shortsighted", "Nearsighted")
                .Give(cat, 50));

            list.Add(new TraitBinding("独眼(随机一只眼睛0%)", "eyepatch", "one_eyed", "oneeye")
                .Names("独眼", "One Eyed", "One-Eyed", "Eyepatch", "Eye Patch")
                .Penalty("eye_random", 100));

            list.Add(new TraitBinding("脑震荡(大脑70%)", "stupid", "dumb")
                .Names("愚蠢", "Stupid", "Dumb")
                .Give(con, 70));

            list.Add(new TraitBinding("残疾(四肢40%)", "crippled")
                .Names("残疾", "Crippled")
                .Give(fra, 40));

            list.Add(new TraitBinding("烧伤(皮肤30%)", "skinburns", "skin_burns", "burningskin")
                .Names("烧伤皮肤", "Skin Burns", "Burned Skin")
                .Give(bur, 30));

            // 诅咒:全身大范围衰减,百病缠身
            TraitBinding curse = new TraitBinding("诅咒(全身衰减·百病缠身)", "cursed")
                .Names("诅咒", "被诅咒", "Cursed", "Curse");
            curse.Kind = BindingKind.Curse;
            list.Add(curse);

            // 瘟疫:肺部等器官受损
            list.Add(new TraitBinding("瘟疫(肺部等受损)", "plague")
                .Names("瘟疫", "Plague", "Bubonic Plague")
                .Give(pl, 60));

            // 死印:脑血栓、急性心脏病、癌症,离死不远
            TraitBinding deathMark = new TraitBinding("死印(脑血栓·急性心脏病·癌症)", "death_mark")
                .Names("死印", "死亡印记", "Death Mark");
            deathMark.Kind = BindingKind.DeathMark;
            list.Add(deathMark);

            TraitBinding tumor = new TraitBinding("肿瘤扩散(随机一种癌症·对应器官受损)", "tumor_infection", "tumorinfection")
                .Names("肿瘤感染", "Tumor Infection", "肿瘤扩散")
                .Penalty("cancer_random", 40);
            tumor.Kind = BindingKind.RandomCancer;
            list.Add(tumor);

            list.Add(new TraitBinding("丧尸化(大脑-50%·全身+50%)", "infected", "zombie")
                .Names("丧尸化", "丧尸", "感染", "Infected", "Zombie")
                .Penalty("brain", 50)
                .BoostAllOrgans(50)
                .Give(braind, 40));

            list.Add(new TraitBinding("蘑菇孢子(大脑-50%·全身+50%)", "mush_spores", "mushroom")
                .Names("蘑菇孢子", "菌孢", "Mush Spores", "Mushroom")
                .Penalty("brain", 50)
                .BoostAllOrgans(50)
                .Give(braind, 40));

            list.Add(new TraitBinding("脂肪肝(肝70%)·糖尿病(全身60%)", "fat")
                .Names("肥胖", "Fat")
                .Give(fl, 70).Give(dia, 60));

            list.Add(new TraitBinding("四肢迟缓(手脚受损)", "slow")
                .Names("缓慢", "Slow")
                .Give(fra, 40).Give(art, 40)
                .Penalty("hand", 15).Penalty("hand", 15)
                .Penalty("foot", 15).Penalty("foot", 15));

            list.Add(new TraitBinding("羸弱(全身-20%)", "weak")
                .Names("羸弱", "弱小", "Weak")
                .Penalty("body", 20));

            list.Add(new TraitBinding("胃溃疡(胃60%)", "gluttonous")
                .Names("贪吃", "Gluttonous")
                .Give(gu, 60));

            list.Add(new TraitBinding("狂躁症(大脑受损·狂躁)", "hotheaded", "irritable", "angry")
                .Names("急躁", "暴躁", "易怒", "Hotheaded", "Irritable", "Angry", "Bad Temper")
                .Give(mania, 60)
                .Penalty("brain", 20));

            list.Add(new TraitBinding("偏执(心理状态)", "paranoid")
                .Names("偏执", "多疑", "Paranoid"));

            list.Add(new TraitBinding("反社会人格(高智商·大脑+50%)", "psychopath")
                .Names("反社会人格", "精神病态", "Psychopath")
                .Boost("brain", 50));

            list.Add(new TraitBinding("肾衰竭(肾30%)", "unlucky")
                .Names("不幸", "Unlucky")
                .Give(kf, 30));

            list.Add(new TraitBinding("阳痿/早泄(生殖系统)", "sterile", "infertile")
                .Names("不孕", "不孕症", "绝后", "Sterile", "Infertile")
                .Give(imp, 0).Give(prem, 0));

            list.Add(new TraitBinding("骨质疏松(骨骼60%)·血友病(血液50%)", "frail")
                .Names("脆弱体质", "体质脆弱", "Frail", "Fragile Health")
                .Give(ost, 60).Give(hem, 50));

            // ===== 增益特质 → 超能强化(器官耐久可超过100%,上限200%) =====
            list.Add(new TraitBinding("视力强化(双眼150%)", "eagle_eyed")
                .Names("鹰眼", "鹰之眼", "Eagle Eye", "Eagle Eyed")
                .Boost("eye_l", 50).Boost("eye_r", 50));

            list.Add(new TraitBinding("肺力强化(肺)", "titan_lungs")
                .Names("巨肺", "泰坦肺", "Titan Lungs")
                .Boost("lung", 40).Boost("lung", 40));

            list.Add(new TraitBinding("心脑强化(心脏/大脑)", "heart_of_wizard")
                .Names("法师之心", "Heart of Wizard")
                .Boost("heart", 40).Boost("brain", 40));

            list.Add(new TraitBinding("心跳强化(心脏)", "mega_heartbeat")
                .Names("巨型心跳", "Mega Heartbeat")
                .Boost("heart", 40));

            list.Add(new TraitBinding("超能体质(全身130%)", "super_health")
                .Names("超级健康", "Super Health")
                .BoostAllOrgans(30));

            list.Add(new TraitBinding("不朽(全身140%)", "immortal")
                .Names("不朽", "Immortal")
                .BoostAllOrgans(40));

            list.Add(new TraitBinding("祝福(全身+100%)", "blessed")
                .Names("祝福", "受祝福", "Blessed", "Blessing")
                .BoostAllOrgans(100));

            list.Add(new TraitBinding("再生强化(全身120%)", "regeneration")
                .Names("再生", "Regeneration")
                .BoostAllOrgans(20));

            list.Add(new TraitBinding("治愈光环(全身120%)", "healing_aura")
                .Names("治愈光环", "Healing Aura", "治愈")
                .BoostAllOrgans(20));

            list.Add(new TraitBinding("免疫强化(全身120%)", "immune")
                .Names("免疫", "Immune")
                .BoostAllOrgans(20));

            list.Add(new TraitBinding("坚韧强化(全身115%)", "tough")
                .Names("坚韧", "Tough")
                .BoostAllOrgans(15));

            list.Add(new TraitBinding("太阳祝福(全身115%)", "sunblessed")
                .Names("太阳祝福", "Sun Blessed")
                .BoostAllOrgans(15));

            list.Add(new TraitBinding("天选之人(全身135%)", "chosen_one")
                .Names("天选之人", "Chosen One")
                .BoostAllOrgans(35));

            list.Add(new TraitBinding("神迹之子(全身125%)", "miracle_born", "miracle_bearer")
                .Names("神迹之子", "神迹承载者", "Miracle Born", "Miracle Bearer")
                .BoostAllOrgans(25));

            list.Add(new TraitBinding("生命力强化", "boosted_vitality")
                .Names("强健体魄", "Boosted Vitality")
                .Boost("heart", 25).Boost("liver", 20).Boost("kidney", 20).Boost("kidney", 20));

            list.Add(new TraitBinding("长寿强化", "long_liver")
                .Names("长寿", "Long Lived", "Long Liver")
                .Boost("heart", 15).Boost("liver", 15).Boost("kidney", 15).Boost("kidney", 15));

            list.Add(new TraitBinding("力量强化(四肢)", "strong")
                .Names("强壮", "Strong")
                .Boost("arm", 30).Boost("arm", 30).Boost("leg", 30).Boost("leg", 30)
                .Boost("hand", 20).Boost("hand", 20).Boost("foot", 20).Boost("foot", 20));

            list.Add(new TraitBinding("巨人强化(四肢)", "giant")
                .Names("巨人", "Giant")
                .Boost("arm", 30).Boost("arm", 30).Boost("leg", 30).Boost("leg", 30)
                .Boost("hand", 20).Boost("hand", 20).Boost("foot", 20).Boost("foot", 20)
                // 关节骨那一条是和渺小对称补上的(渺小 Penalty("bone", 25)),
                // 这样"体型 ⇄ 关节骨"两个方向都成立,见 OrganEditorUI.SyncBoneTrait
                .Boost("bone", 25));

            list.Add(new TraitBinding("敏捷强化(四肢)", "agile")
                .Names("敏捷", "Agile")
                .Boost("arm", 20).Boost("arm", 20).Boost("leg", 20).Boost("leg", 20));

            list.Add(new TraitBinding("迅捷强化(腿足)", "fast")
                .Names("迅捷", "Fast")
                .Boost("leg", 20).Boost("leg", 20).Boost("foot", 20).Boost("foot", 20));

            list.Add(new TraitBinding("轻盈强化(腿足)", "weightless")
                .Names("失重", "Weightless")
                .Boost("leg", 20).Boost("leg", 20).Boost("foot", 20).Boost("foot", 20));

            list.Add(new TraitBinding("皮肤硬化(皮肤140%)", "hard_skin")
                .Names("硬皮", "Hard Skin")
                .Boost("skin", 40));

            list.Add(new TraitBinding("魅力强化(皮肤/毛发)", "attractive")
                .Names("魅力", "Attractive")
                .Boost("skin", 25).Boost("hair", 25));

            list.Add(new TraitBinding("生育强化(生殖器官)", "fertile")
                .Names("多产", "兴旺", "Fertile")
                .Boost("uterus", 25).Boost("ovary", 25).Boost("vagina", 25).Boost("testicle", 25).Boost("prostate", 25).Boost("penis", 25));

            list.Add(new TraitBinding("天才强化(大脑)", "genius")
                .Names("天才", "Genius")
                .Boost("brain", 25));

            list.Add(new TraitBinding("明智(大脑+40%·全身-10%)", "wise")
                .Names("明智", "睿智", "智者", "Wise", "Wisdom")
                .Boost("brain", 40)
                .Penalty("body", 10));

            list.Add(new TraitBinding("意志强化(大脑)", "strong_minded")
                .Names("意志坚定", "Strong Minded")
                .Boost("brain", 20));

            list.Add(new TraitBinding("战斗反射(大脑/脊椎)", "battle_reflexes")
                .Names("战斗反射", "Battle Reflexes")
                .Boost("brain", 20).Boost("spine", 20));

            list.Add(new TraitBinding("奥术反射(大脑)", "arcane_reflexes")
                .Names("奥术反射", "Arcane Reflexes")
                .Boost("brain", 25));

            list.Add(new TraitBinding("老将(全身115%·精神受损·伤疤)", "veteran")
                .Names("老将", "老兵", "Veteran")
                .BoostAllOrgans(15)
                .Penalty("brain", 15)
                .Penalty("skin", 20)
                .Penalty("bone_random", 30)
                .Give(braind, 30));

            list.Add(new TraitBinding("胃力强化(胃+40%)", "flesh_eater")
                .Names("食肉者", "Flesh Eater", "食肉")
                .Boost("stomach", 40));

            list.Add(new TraitBinding("幸运强化(全身105%)", "lucky")
                .Names("幸运", "Lucky")
                .BoostAllOrgans(5));

            list.Add(new TraitBinding("抗酸硬化(皮肤)", "acid_proof")
                .Names("抗酸", "Acid Proof")
                .Boost("skin", 25));

            list.Add(new TraitBinding("抗火硬化(皮肤)", "fire_proof")
                .Names("抗火", "Fire Proof")
                .Boost("skin", 25));

            list.Add(new TraitBinding("抗冻硬化(皮肤)", "freeze_proof")
                .Names("抗冻", "Freeze Proof")
                .Boost("skin", 25));

            list.Add(new TraitBinding("抗毒强化(全身110%)", "poison_immune")
                .Names("抗毒", "Poison Immune")
                .BoostAllOrgans(10));

            list.Add(new TraitBinding("火血强化(血液)", "fire_blood")
                .Names("火血", "Fire Blood")
                .Boost("blood", 30));

            list.Add(new TraitBinding("酸血强化(血液)", "acid_blood")
                .Names("酸血", "Acid Blood")
                .Boost("blood", 30));

            list.Add(new TraitBinding("荆棘强化(皮肤)", "thorns")
                .Names("荆棘", "Thorns")
                .Boost("skin", 20));

            list.Add(new TraitBinding("弑君者(全身-10%·创伤后应激)", "kingslayer")
                .Names("弑君者", "Kingslayer")
                .Penalty("body", 10).Give(ptsdx, 40));
            list.Add(new TraitBinding("猎巫人(全身-10%·创伤后应激)", "mageslayer")
                .Names("猎巫人", "屠法师", "Mageslayer")
                .Penalty("body", 10).Give(ptsdx, 40));
            list.Add(new TraitBinding("屠龙者(全身-10%·创伤后应激)", "dragonslayer")
                .Names("屠龙者", "Dragonslayer")
                .Penalty("body", 10).Give(ptsdx, 40));
            list.Add(new TraitBinding("金牙强化(牙齿/嘴巴)", "golden_tooth")
                .Names("金牙", "Golden Tooth")
                .Boost("teeth", 20).Boost("mouth", 20));
            list.Add(new TraitBinding("充能强化(大脑/心脏)", "energized")
                .Names("充能", "Energized")
                .Boost("brain", 20).Boost("heart", 20));
            list.Add(new TraitBinding("护盾强化(皮肤)", "bubble_defense")
                .Names("泡泡护盾", "Bubble Defense")
                .Boost("skin", 25));
            list.Add(new TraitBinding("月光之子(全身115%)", "moonchild")
                .Names("月之子", "Moonchild")
                .BoostAllOrgans(15));
            list.Add(new TraitBinding("暗夜之子(全身115%)", "nightchild")
                .Names("夜之子", "Nightchild")
                .BoostAllOrgans(15));
            list.Add(new TraitBinding("剧毒强化(血液)", "poisonous")
                .Names("剧毒", "Poisonous")
                .Boost("blood", 25));
            list.Add(new TraitBinding("毒液强化(血液)", "venomous")
                .Names("毒液", "Venomous")
                .Boost("blood", 25));
            list.Add(new TraitBinding("闪光强化(皮肤)", "shiny")
                .Names("闪闪发光", "Shiny")
                .Boost("skin", 20));

            // ===== 哑巴/毒牙等特质 → 器官影响 =====
            Disease mut = Find("mutism");
            Disease frai = Find("frailty");
            if (mut != null)
            {
                list.Add(new TraitBinding("失语(嘴巴受损)", "mute", "mutism")
                    .Names("哑巴", "失语", "Mute", "Mutism", "Dumb")
                    .Give(mut, 60));
            }
            // 野蛮:大脑-15%
            list.Add(new TraitBinding("野蛮(大脑-15%)", "savage")
                .Names("野蛮", "狂野", "Savage")
                .Penalty("brain", 15));
            // 笨拙:全身-10% + 神经传导障碍
            if (nerve != null)
            {
                list.Add(new TraitBinding("笨拙(全身-10%·神经传导障碍)", "clumsy")
                    .Names("笨拙", "Clumsy")
                    .Give(nerve, 50)
                    .Penalty("body", 10));
            }
            // 渺小:侏儒症 + 四肢/骨骼降低
            if (dwarf != null)
            {
                list.Add(new TraitBinding("渺小(侏儒症·骨骼四肢受损)", "tiny")
                    .Names("渺小", "侏儒", "Tiny")
                    .Give(dwarf, 50)
                    .Penalty("bone", 25)
                    .Penalty("arm", 15).Penalty("arm", 15)
                    .Penalty("leg", 15).Penalty("leg", 15));
            }
            // 丑陋:面部相关属性-10%
            list.Add(new TraitBinding("丑陋(面部-10%)", "ugly")
                .Names("丑陋", "丑", "Ugly")
                .Penalty("face", 10));
            // 柔软皮肤:肤质下降(皮肤-20%)
            list.Add(new TraitBinding("柔软皮肤(皮肤-20%)", "soft_skin")
                .Names("柔软皮肤", "软皮", "Soft Skin")
                .Penalty("skin", 20));
            // 生命脆弱
            if (frai != null)
            {
                list.Add(new TraitBinding("生命脆弱(全身-10%)", "fragile_health")
                    .Names("生命脆弱", "脆弱体质", "体质脆弱", "身体脆弱", "Frail", "Fragile Health")
                    .Give(frai, 40)
                    .Penalty("body", 10));
            }

            // 嗜血:大脑 -50%
            list.Add(new TraitBinding("嗜血(大脑-50%)", "bloodlust")
                .Names("嗜血", "血瘾", "Bloodlust", "Blood Lust")
                .Penalty("brain", 50));

            return list;
        }

        public static Disease Find(string pId)
        {
            foreach (Disease d in All)
            {
                if (d.Id == pId) return d;
            }
            return null;
        }

        public static TraitBinding FindBinding(string pTraitId, string pTraitName)
        {
            if (!string.IsNullOrEmpty(pTraitId))
            {
                foreach (TraitBinding b in Bindings)
                {
                    foreach (string id in b.TraitIds)
                    {
                        if (string.Equals(id, pTraitId, System.StringComparison.OrdinalIgnoreCase)) return b;
                    }
                }
            }
            if (!string.IsNullOrEmpty(pTraitName))
            {
                foreach (TraitBinding b in Bindings)
                {
                    foreach (string name in b.TraitNames)
                    {
                        if (pTraitName.Contains(name) || name.Contains(pTraitName)) return b;
                    }
                }
            }
            return null;
        }

        public static Disease PickRandomInfectious(System.Random pRng)
        {
            List<Disease> pool = new List<Disease>();
            foreach (Disease d in All)
            {
                if (d.Infectious) pool.Add(d);
            }
            return pool.Count == 0 ? null : pool[pRng.Next(pool.Count)];
        }

        public static Disease PickRandomCancer(System.Random pRng)
        {
            List<Disease> pool = new List<Disease>();
            foreach (Disease d in All)
            {
                if (d.Cancer) pool.Add(d);
            }
            return pool.Count == 0 ? null : pool[pRng.Next(pool.Count)];
        }

        public static Disease PickRandomInfection(System.Random pRng)
        {
            List<Disease> pool = new List<Disease>();
            foreach (Disease d in All)
            {
                if (d.GeneralInfection) pool.Add(d);
            }
            return pool.Count == 0 ? null : pool[pRng.Next(pool.Count)];
        }

        public static Disease PickRandomGeneral(System.Random pRng, HashSet<string> pAvailableOrgans)
        {
            List<Disease> pool = new List<Disease>();
            foreach (Disease d in All)
            {
                if (d.Cancer) continue;
                bool fits = true;
                foreach (string o in d.Organs)
                {
                    if (!pAvailableOrgans.Contains(o)) { fits = false; break; }
                }
                if (fits) pool.Add(d);
            }
            return pool.Count == 0 ? null : pool[pRng.Next(pool.Count)];
        }
    }
}