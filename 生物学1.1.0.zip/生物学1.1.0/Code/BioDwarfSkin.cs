using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace RimWorldMod
{

    /// <summary>
    /// 矮人贴图接管(由「模组设置 → 功能开关 → 矮人贴图」控制)。
    ///
    /// 原版矮人一张皮 40x22:身体 10x10 四帧走 + 四帧游,头另外从 heads_male/heads_female
    /// 那张 16x14 里切(每个头才 2x3 像素)。重绘的这套整体放大了一圈:走路一帧 16x16、
    /// 游泳一帧 18x16,头单独一格 16x16,所以没法靠「同尺寸顶掉原版子精灵」那条路走,
    /// 只能在烘贴图那一步整体换掉。
    ///
    /// 换的时候干三件事:
    ///   1. 身体按装备挑一套:皮革甲→Leather,精金甲→Adamantine,其它六种金属甲→
    ///      ChameleonMetal 那套「变色铠甲」+ 该金属的五级色(见 BioDwarfMetal),
    ///      没穿甲的国王→RoyalRobe,其余没穿甲的→Casual/Casual1。
    ///   2. 头按单位 id 定死一个(重绘图男 7 个、女 6 个),再往上叠装饰物:
    ///      有「金牙」特质叠皇冠,否则按头盔材质叠皮革盔/精金盔/变色盔。
    ///   3. 把身体和「头+装饰物」交给原版 createNewSpriteUnit 去拼,拼的位置照
    ///      dwarf example.psd 里量出来的偏移(见 WalkHead*/SwimHead*/Gear*)。
    ///      这样王国色、肤色表型、僵尸化、图集分配全都还是原版那一套。
    ///
    /// 头发换色跟着 BioHeadHair 那套走:重绘的头用的正是它认的发色关键色
    /// (255,145,102 / 255,181,112),所以矮人的头发也会按单位发色变。
    /// </summary>
    public static class BioDwarfSkin
    {

        // 重绘图在模组 GameResources 下的位置
        private const string FolderBody = "ui/dwarfskin/body";
        private const string FolderHead = "ui/dwarfskin/head";
        private const string FolderGear = "ui/dwarfskin/gear";

        /// <summary> 原版矮人贴图目录,用来认出「这个单位是矮人」 </summary>
        private const string DwarfBasePath = "actors/species/civs/dwarf/";

        // 头部那一格的边长;合成头+装饰物时画布往外留的边
        // (变色盔 11 px 宽、左边从 7 开始,会超出 16 的格子,所以必须留边)
        private const int HeadTile = 16;
        private const int Pad = 8;

        // ===== 几何(全部是 Unity 坐标:原点左下、y 向上) =====
        // 走路偏移男女共用同一套;游泳因为男女水线和姿势不同,仍按男女各一套。
        private static readonly int[] WalkHeadX = { -4, -4, -4, -4, -4 };
        private static readonly int[] WalkHeadY = { 5, 5, 6, 6, 5 };
        private static readonly int[][] SwimHeadX = {
            new[] { -3, -2, -2, -2, -2 },
            new[] { -3, -2, -2, -2, -2 },
        };
        private static readonly int[][] SwimHeadY = {
            new[] { 3, 2, 2, 2, 3 },
            new[] { 3, 2, 2, 2, 4 },
        };

        // ===== 服饰 =====
        private const int OutfitCasual = 0;
        private const int OutfitCasual1 = 1;
        private const int OutfitNude = 2;
        private const int OutfitLeather = 3;
        private const int OutfitAdamantine = 4;
        private const int OutfitChameleon = 5;
        private const int OutfitRoyalRobe = 6;
        private const int OutfitCount = 7;

        // 文件名里的服饰段。Casual 有两套,区别在动画段末尾多一个 "1"
        // (Dwarf_Male_Casual_Walking_0 / Dwarf_Male_Casual_Walking1_0)
        private static readonly string[] OutfitPart = {
            "Casual", "Casual", "Nude", "Leather", "Adamantine", "ChameleonMetal", "RoyalRobe",
        };
        private static readonly string[] OutfitVariant = { "", "1", "", "", "", "", "" };

        // ===== 装饰物(头盔/皇冠) =====
        private const int GearNone = 0;
        private const int GearLeather = 1;
        private const int GearAdamantine = 2;
        private const int GearChameleon = 3;
        private const int GearCrown = 4;
        private const int GearCount = 5;

        private static readonly string[] GearFile = {
            null, "Dwarf_Helmet_Leather", "Dwarf_Helmet_Adamantine",
            "Dwarf_Helmet_ChameleonMetal", "Dwarf_Crown",
        };
        // 装饰物相对头格的偏移,男女共用一套。
        private static readonly int[] GearX = { 0, 6, 7, 5, 7 };
        private static readonly int[] GearY = { 0, 7, 5, 5, 8 };
        private static readonly string[] GearNames = { "无", "皮革盔", "精金盔", "变色盔", "皇冠" };

        // 重绘图里男女各有几个头
        private const int HeadCountMale = 7;
        private const int HeadCountFemale = 6;

        /// <summary>
        /// 「裸体」那套要不要用在没穿甲的单位身上。默认关:游戏里没有「没穿衣服」这个状态,
        /// 平民光着到处走大概不是想要的效果,所以这套图先留着不接。想接的话改成 true,
        /// 会按单位 id 三分之一的概率出现(和 Casual/Casual1 一起轮)。
        /// </summary>
        private const bool UseNudeForUnarmored = false;

        // ===== 缓存 =====

        // 文件名(小写) → NML 从 GameResources 读进来的原图
        private static readonly Dictionary<string, Sprite> _raw = new Dictionary<string, Sprite>();

        // 身体键 → 换好金属色的身体精灵
        private static readonly Dictionary<int, Sprite> _bodies = new Dictionary<int, Sprite>();

        // 头键 → 头+装饰物合成后的精灵,以及它相对「头那一格左下角」的偏移
        private static readonly Dictionary<int, Sprite> _heads = new Dictionary<int, Sprite>();
        private static readonly Dictionary<int, Vector2> _headOffsets = new Dictionary<int, Vector2>();

        // ActorAsset → 是不是矮人那套贴图(每帧都要问,所以问一次记下来)
        private static readonly Dictionary<ActorAsset, bool> _isDwarf = new Dictionary<ActorAsset, bool>();

        // 每一帧都要新建一个 AnimationFrameData 太浪费,烘贴图是单线程的,复用一个就行
        private static readonly AnimationFrameData _frameData = new AnimationFrameData();

        private static bool _loaded;
        private static int _bakeCount, _skipCount;

        // 自定义肤色关键色 → 标准绿色关键色的映射。
        // 游戏的 DynamicColorPixelTool 只认 Toolbox 里的 4 个标准绿
        // (#B8FF96 / #00FF00 / #00AF00 / #4A831F),自定义颜色需要先映射过去。
        private static readonly Color32 _stdGreen2 = new Color32(0, 175, 0, 255);
        private static readonly Color32 _stdGreen3 = new Color32(74, 131, 31, 255);

        private static void ReplaceCustomSkinMarkers(Color32[] px)
        {
            for (int i = 0; i < px.Length; i++)
            {
                Color32 c = px[i];
                if (c.a == 0) continue;
                if (c.r == 52 && c.g == 221 && c.b == 52)
                    px[i] = _stdGreen2;
                else if (c.r == 57 && c.g == 134 && c.b == 57)
                    px[i] = _stdGreen3;
            }
        }

        /// <summary> 单位窗口那个蹦跳的小人正在给谁烘贴图(头像框那条路拿不到 Actor) </summary>
        internal static Actor UIActor;

        // ===== 读图 =====

        /// <summary>
        /// 第一次要用的时候把三个目录下的重绘图全读进来。一张都没读到就不算读过,
        /// 下次再试 —— 模组设置的回调有可能在资源还没加载好的时候就先响一次。
        /// </summary>
        private static void EnsureLoaded()
        {
            if (_loaded) return;
            int n = Read(FolderBody) + Read(FolderHead) + Read(FolderGear);
            if (n == 0)
            {
                Main.LogError("生物学[矮人贴图] 一张图都没读到,先不接管:检查 GameResources/"
                    + FolderBody + "/ 之类的目录还在不在,以及 NeoModLoader 有没有把它们当资源加载");
                return;
            }
            _loaded = true;
            Main.LogInfo("生物学[矮人贴图] 读到重绘图 " + n + " 张");
        }

        private static int Read(string pFolder)
        {
            int n = 0;
            try
            {
                Sprite[] arr = SpriteTextureLoader.getSpriteList(pFolder, true);
                if (arr == null) return 0;
                foreach (Sprite sp in arr)
                {
                    if (sp == null || sp.texture == null) continue;
                    _raw[sp.name.ToLower()] = sp;
                    n++;
                }
            }
            catch (Exception e)
            {
                Main.LogError("生物学[矮人贴图] 读取 " + pFolder + " 失败 " + e);
            }
            return n;
        }

        private static Sprite Raw(string pName)
        {
            Sprite sp;
            if (_raw.TryGetValue(pName.ToLower(), out sp)) return sp;
            if (_missing.Add(pName)) Main.LogError("生物学[矮人贴图] 缺图 " + pName + ".png");
            return null;
        }

        // 已经报过「缺图」的名字,同一张只报一次
        private static readonly HashSet<string> _missing = new HashSet<string>();

        // ===== 认矮人 =====

        /// <summary>
        /// 这个种族用的是不是原版矮人那套贴图。按贴图目录认而不是按 id 认,
        /// 这样矮人僵尸、亚种换皮那些克隆出来的种族也能一起认出来。
        /// </summary>
        private static bool IsDwarfAsset(ActorAsset pAsset)
        {
            if (pAsset == null) return false;
            bool known;
            if (_isDwarf.TryGetValue(pAsset, out known)) return known;
            known = false;
            try
            {
                ActorTextureSubAsset tex = pAsset.texture_asset;
                known = tex != null && tex.texture_path_base == DwarfBasePath;
            }
            catch (Exception e)
            {
                Main.LogError("生物学[矮人贴图] 判断种族失败 " + e);
            }
            _isDwarf[pAsset] = known;
            return known;
        }

        /// <summary>
        /// 这个单位要不要换图。婴儿排除在外:重绘图里没有小孩那一套,
        /// 硬拿大人的图贴上去婴儿会比大人还高。
        /// </summary>
        private static bool Handles(Actor pActor)
        {
            if (pActor == null || !IsDwarfAsset(pActor.asset)) return false;
            try
            {
                if (pActor.isEgg() || pActor.isBaby()) return false;
            }
            catch
            {
                return false;
            }
            return true;
        }

        /// <summary> 帧名("walk_2"/"swim_0")→ 游泳与否 + 帧号;认不出来返回 false </summary>
        private static bool ParseFrame(string pName, out bool pSwim, out int pFrame)
        {
            pSwim = false;
            pFrame = 0;
            if (string.IsNullOrEmpty(pName)) return false;
            if (pName.StartsWith("walk_")) pSwim = false;
            else if (pName.StartsWith("swim_")) pSwim = true;
            else return false;
            int i = pName.IndexOf('_') + 1;
            if (i <= 0 || i >= pName.Length) return false;
            if (!int.TryParse(pName.Substring(i), out pFrame)) return false;
            return pFrame >= 0 && pFrame < 5;
        }

        // ===== 按装备决定长什么样 =====

        /// <summary> 一个矮人当前该穿什么、头上戴什么 </summary>
        internal struct Look
        {
            public bool Male;
            public int Head;         // 重绘头下标
            public int Outfit;       // OutfitXxx
            public int ArmorMetal;   // 变色甲用哪种金属;-1 = 这套不变色
            public int Gear;         // GearXxx
            public int GearMetal;    // 变色盔用哪种金属;-1 = 这套不变色
        }

        /// <summary> 装备格里那件东西的材质;空格子返回 null </summary>
        private static string MaterialOf(ActorEquipmentSlot pSlot)
        {
            try
            {
                if (pSlot == null || pSlot.isEmpty()) return null;
                Item item = pSlot.getItem();
                if (item == null) return null;
                EquipmentAsset asset = item.getAsset();
                return asset == null ? null : asset.material;
            }
            catch
            {
                return null;
            }
        }

        /// <summary> 同一个单位每次算出来都得一样,所以只按 id 取模,不掺随机 </summary>
        private static int StableIndex(long pId, int pCount)
        {
            if (pCount <= 1) return 0;
            long v = pId % pCount;
            if (v < 0) v += pCount;
            return (int)v;
        }

        private static int HeadIndex(long pId, bool pMale)
        {
            return StableIndex(pId, pMale ? HeadCountMale : HeadCountFemale);
        }

        /// <summary> 没穿甲的时候穿什么:国王穿王袍,其余在休闲装两套(可选加裸体)里按 id 定死 </summary>
        private static int UnarmoredOutfit(Actor pActor)
        {
            try
            {
                if (pActor.is_profession_king) return OutfitRoyalRobe;
            }
            catch { }
            int n = UseNudeForUnarmored ? 3 : 2;
            int i = StableIndex(pActor.data.id / 7, n);
            if (i == 0) return OutfitCasual;
            if (i == 1) return OutfitCasual1;
            return OutfitNude;
        }

        /// <summary> 从装备栏和特质里算出这个矮人当前的样子 </summary>
        internal static Look LookOf(Actor pActor)
        {
            Look look = new Look();
            look.ArmorMetal = -1;
            look.GearMetal = -1;
            look.Gear = GearNone;
            look.Male = true;
            try
            {
                look.Male = pActor.isSexMale();
            }
            catch { }
            look.Head = HeadIndex(pActor.data.id, look.Male);
            if (Main.HideClothing) {
                look.Outfit = OutfitNude;
                look.ArmorMetal = -1;
                look.Gear = GearNone;
                look.GearMetal = -1;
                return look;
            }

            ActorEquipment eq = pActor.equipment;
            string armor = eq == null ? null : MaterialOf(eq.armor);
            if (armor == "leather")
            {
                look.Outfit = OutfitLeather;
            }
            else if (armor == "adamantine")
            {
                look.Outfit = OutfitAdamantine;
            }
            else
            {
                int metal = BioDwarfMetal.IndexOf(armor);
                if (metal >= 0)
                {
                    look.Outfit = OutfitChameleon;
                    look.ArmorMetal = metal;
                }
                else
                {
                    look.Outfit = UnarmoredOutfit(pActor);
                }
            }

            // 金牙的戴皇冠。皇冠贴在头顶(y 8..10),头盔盖的是 y 5..13,两个叠一块儿
            // 只会看见头盔中间横一道金边,所以做成二选一:有金牙就只戴皇冠。
            bool crown = false;
            try
            {
                crown = pActor.hasTrait("golden_tooth");
            }
            catch { }
            if (crown)
            {
                look.Gear = GearCrown;
                return look;
            }
            string helmet = eq == null ? null : MaterialOf(eq.helmet);
            if (helmet == "leather")
            {
                look.Gear = GearLeather;
            }
            else if (helmet == "adamantine")
            {
                look.Gear = GearAdamantine;
            }
            else
            {
                int metal = BioDwarfMetal.IndexOf(helmet);
                if (metal >= 0)
                {
                    look.Gear = GearChameleon;
                    look.GearMetal = metal;
                }
            }
            return look;
        }

        // ===== 身体精灵 =====

        private static Sprite Body(bool pMale, bool pSwim, int pFrame, int pOutfit, int pMetal)
        {
            int key = ((pMale ? 1 : 0) * 2 + (pSwim ? 1 : 0)) * 8 + pFrame;
            key = (key * OutfitCount + pOutfit) * 8 + (pMetal + 1);
            Sprite sp;
            if (_bodies.TryGetValue(key, out sp)) return sp;
            sp = BuildBody(pMale, pSwim, pFrame, pOutfit, pMetal);
            _bodies[key] = sp;
            return sp;
        }

        private static Sprite BuildBody(bool pMale, bool pSwim, int pFrame, int pOutfit, int pMetal)
        {
            string name = "Dwarf_" + (pMale ? "Male" : "Female") + "_" + OutfitPart[pOutfit] + "_"
                        + (pSwim ? "Swimming" : "Walking") + OutfitVariant[pOutfit] + "_" + pFrame;
            Sprite raw = Raw(name);
            if (raw == null || raw.texture == null) return null;
            int w = raw.texture.width;
            int h = raw.texture.height;
            Color32[] px;
            try
            {
                px = raw.texture.GetPixels32();
            }
            catch (Exception e)
            {
                Main.LogError("生物学[矮人贴图] " + name + " 读不出像素 " + e.Message);
                return null;
            }
            ReplaceCustomSkinMarkers(px);
            // 变色甲那套整身都是品红五级,这里先换成金属色;换完图里没品红了,
            // 原版那套「品红→王国衣服色」就碰不到铠甲。休闲装/王袍留着不动。
            if (pOutfit == OutfitChameleon) BioDwarfMetal.Recolor(px, pMetal);

            Texture2D tex = new Texture2D(w, h, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Point;
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.SetPixels32(px);
            tex.Apply(false, false);
            // 走路那套脚贴着格子底边(和原版 walk_* 的 pivot.y=0 一致);
            // 游泳那套抬 1 px(原版 swim_* 是 0.1 × 10 px = 1 px),这样水线对得上
            float pivotY = pSwim ? 1f : 0f;
            Sprite sp = Sprite.Create(tex, new Rect(0f, 0f, w, h),
                new Vector2(0.5f, pivotY / h), 1f, 0, SpriteMeshType.FullRect);
            sp.name = "dwarfskin_" + name
                + (pOutfit == OutfitChameleon ? "_" + BioDwarfMetal.NameOf(pMetal) : "");
            return sp;
        }

        // ===== 头 + 装饰物 =====

        /// <summary>
        /// 合成好的「头 + 装饰物」。pOffset 是这张图的左下角相对「头那一格左下角」的偏移
        /// (合成完裁掉了空白,所以要把裁掉的量补回去,拼身体的时候要用)。
        /// </summary>
        private static Sprite Head(bool pMale, int pHead, int pGear, int pGearMetal, out Vector2 pOffset)
        {
            int key = ((pMale ? 1 : 0) * 16 + pHead) * GearCount + pGear;
            key = key * 8 + (pGearMetal + 1);
            Sprite sp;
            if (_heads.TryGetValue(key, out sp))
            {
                pOffset = _headOffsets[key];
                return sp;
            }
            sp = BuildHead(pMale, pHead, pGear, pGearMetal, out pOffset);
            _heads[key] = sp;
            _headOffsets[key] = pOffset;
            return sp;
        }

        private static Sprite BuildHead(bool pMale, int pHead, int pGear, int pGearMetal, out Vector2 pOffset)
        {
            pOffset = Vector2.zero;
            int cw = HeadTile + Pad * 2;
            int ch = HeadTile + Pad * 2;
            Color32[] buf = new Color32[cw * ch];
            string headName = "Dwarf_Head_" + (pMale ? "Male" : "Female") + "_" + pHead;
            if (!Blit(buf, cw, ch, Raw(headName), Pad, Pad, -1)) return null;
            if (pGear != GearNone)
            {
                Blit(buf, cw, ch, Raw(GearFile[pGear]),
                    Pad + GearX[pGear], Pad + GearY[pGear],
                    pGear == GearChameleon ? pGearMetal : -1);
            }

            int x0 = cw, y0 = ch, x1 = -1, y1 = -1;
            for (int y = 0; y < ch; y++)
            {
                for (int x = 0; x < cw; x++)
                {
                    if (buf[x + y * cw].a == 0) continue;
                    if (x < x0) x0 = x;
                    if (x > x1) x1 = x;
                    if (y < y0) y0 = y;
                    if (y > y1) y1 = y;
                }
            }
            if (x1 < 0) return null;

            int w = x1 - x0 + 1;
            int h = y1 - y0 + 1;
            Color32[] cropped = new Color32[w * h];
            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    cropped[x + y * w] = buf[(x0 + x) + (y0 + y) * cw];
                }
            }
            Texture2D tex = new Texture2D(w, h, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Point;
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.SetPixels32(cropped);
            tex.Apply(false, false);
            // pivot 放在左下角,这样原版拼头的时候 pos_head_new 就是这张图的左下角坐标
            Sprite sp = Sprite.Create(tex, new Rect(0f, 0f, w, h), Vector2.zero, 1f, 0, SpriteMeshType.FullRect);
            sp.name = "dwarfskin_head_" + (pMale ? "m" : "f") + pHead + "_" + GearNames[pGear];
            pOffset = new Vector2(x0 - Pad, y0 - Pad);
            return sp;
        }

        /// <summary> 把一张小图不透明的像素铺进合成画布(坐标都是左下原点);pMetal≥0 时顺手换金属色 </summary>
        private static bool Blit(Color32[] pDst, int pDstW, int pDstH, Sprite pSrc,
            int pX, int pY, int pMetal)
        {
            if (pSrc == null || pSrc.texture == null) return false;
            int w = pSrc.texture.width;
            int h = pSrc.texture.height;
            Color32[] px;
            try
            {
                px = pSrc.texture.GetPixels32();
            }
            catch (Exception e)
            {
                Main.LogError("生物学[矮人贴图] " + pSrc.name + " 读不出像素 " + e.Message);
                return false;
            }
            ReplaceCustomSkinMarkers(px);
            if (pMetal >= 0) BioDwarfMetal.Recolor(px, pMetal);
            for (int y = 0; y < h; y++)
            {
                int dy = pY + y;
                if (dy < 0 || dy >= pDstH) continue;
                for (int x = 0; x < w; x++)
                {
                    Color32 c = px[x + y * w];
                    if (c.a == 0) continue;
                    int dx = pX + x;
                    if (dx < 0 || dx >= pDstW) continue;
                    pDst[dx + dy * pDstW] = c;
                }
            }
            return true;
        }

        // ===== 贴图缓存键 =====

        /// <summary>
        /// 走的是原版那本贴图缓存(DynamicSpritesLibrary.units),所以键不能和原版
        /// (最高到 1e15)或者发色那套(1e17 × 32)撞上。这里整段用负数,彻底分开。
        /// </summary>
        private static long CacheKey(Look pLook, bool pSwim, int pFrame, bool pForUI,
            int pPhenotypeIndex, int pPhenotypeShade, ColorAsset pColor, int pHairSlot)
        {
            long k = pLook.Male ? 1L : 0L;
            k = k * 2 + (pSwim ? 1 : 0);
            k = k * 8 + pFrame;
            k = k * OutfitCount + pLook.Outfit;
            k = k * 8 + (pLook.ArmorMetal + 1);
            k = k * 16 + pLook.Head;
            k = k * GearCount + pLook.Gear;
            k = k * 8 + (pLook.GearMetal + 1);
            k = k * 2 + (pForUI ? 1 : 0);
            k = k * 64 + (pPhenotypeIndex & 63);
            k = k * 8 + (pPhenotypeShade & 7);
            k = k * 8192 + (pColor == null ? 0 : (pColor.index_id & 8191));
            k = k * 32 + (pHairSlot & 31);
            return -k - 1;
        }

        // ===== 烘贴图 =====

        // 单位窗口那条路只给 id 不给 Actor,所以世界里算过的样子记一份给它用
        private static readonly Dictionary<long, Look> _lastLook = new Dictionary<long, Look>();

        /// <summary>
        /// 真正拼图那一步:身体 + (头+装饰物) 交给原版 createNewSpriteUnit。
        /// 头的位置由我们自己造的 AnimationFrameData 决定(原版那份是按 10x10 的旧图量的,用不了)。
        /// </summary>
        private static Sprite Bake(Look pLook, bool pSwim, int pFrame, ColorAsset pColor,
            ActorAsset pAsset, int pPhenotypeIndex, int pPhenotypeShade,
            UnitTextureAtlasID pAtlasID, Color32[] pHairRamp, bool pWithHead)
        {
            Sprite body = Body(pLook.Male, pSwim, pFrame, pLook.Outfit, pLook.ArmorMetal);
            if (body == null) return null;

            Sprite head = null;
            AnimationFrameData frame = null;
            if (pWithHead)
            {
                Vector2 headOffset;
                head = Head(pLook.Male, pLook.Head, pLook.Gear, pLook.GearMetal, out headOffset);
                if (head != null)
                {
                    int sex = pLook.Male ? 0 : 1;
                    int hx = pSwim ? SwimHeadX[sex][pFrame] : WalkHeadX[pFrame];
                    int hy = pSwim ? SwimHeadY[sex][pFrame] : WalkHeadY[pFrame];
                    frame = _frameData;
                    frame.id = body.name;
                    frame.show_head = true;
                    frame.show_item = false;
                    frame.size_unit = body.rect.size;
                    frame.pos_head = Vector2.zero;
                    frame.pos_head_new = new Vector2(hx + headOffset.x, hy + headOffset.y);
                }
            }

            // 头发换色借 BioHeadHair 那条 drawPixelsAll 的钩子,它只在 pHead=true 时动手
            BioHeadHair.BeginHairBake(pHairRamp);
            try
            {
                Sprite sprite = DynamicSpriteCreator.createNewSpriteUnit(frame, body, head,
                    pColor, pAsset, pPhenotypeIndex, pPhenotypeShade, pAtlasID);
                _bakeCount++;
                return sprite;
            }
            finally
            {
                BioHeadHair.EndHairBake();
            }
        }

        /// <summary>
        /// 世界里那条路。由 BioHeadHair.GetSpriteUnitPrefix 开头调用:
        /// 返回 true 表示这一帧我们自己出图了,原版 getSpriteUnit 不用再跑。
        /// </summary>
        internal static bool TryBakeWorld(ref Sprite pResult, Sprite pMainSprite, Actor pActor,
            ColorAsset pKingdomColor, int pPhenotypeIndex, int pPhenotypeShade,
            UnitTextureAtlasID pAtlasID)
        {
            if (!Main.DwarfSkin || pActor == null || pMainSprite == null) return false;
            if (pKingdomColor == null) return false;
            if (!Handles(pActor)) return false;
            try
            {
                EnsureLoaded();
                if (!_loaded) return false;
                bool swim;
                int frame;
                if (!ParseFrame(pMainSprite.name, out swim, out frame))
                {
                    _skipCount++;
                    return false;
                }
                Look look = LookOf(pActor);
                Remember(pActor.data.id, look);

                int hair = BioHairColor.GetIndex(pActor);
                bool white = BioHairColor.IsWhiteHaired(pActor);
                int hairSlot = hair + (white ? BioHairColor.Count : 0);
                long key = CacheKey(look, swim, frame, false,
                    pPhenotypeIndex, pPhenotypeShade, pKingdomColor, hairSlot);

                DynamicSpritesAsset units = DynamicSpritesLibrary.units;
                Sprite sprite = units.getSprite(key);
                if ((object)sprite == null)
                {
                    sprite = Bake(look, swim, frame, pKingdomColor, pActor.asset,
                        pPhenotypeIndex, pPhenotypeShade, pAtlasID,
                        BioHairColor.RampOf(hair, white), pActor.has_rendered_sprite_head);
                    if (sprite == null) return false;
                    units.addSprite(key, sprite);
                }
                pResult = sprite;
                return true;
            }
            catch (Exception e)
            {
                Main.LogError("生物学[矮人贴图] 烘贴图失败,这一帧回退原版 " + e);
                return false;
            }
        }

        private static void Remember(long pId, Look pLook)
        {
            if (_lastLook.Count > 4096) _lastLook.Clear();
            _lastLook[pId] = pLook;
        }

        /// <summary>
        /// 单位窗口头像框那条路。它只给 id 不给 Actor,所以先看 UnitAvatarLoader 存下来的那个,
        /// 拿不到就用世界里算过的那份(Remember),还拿不到就按 id 给个默认样子。
        /// </summary>
        internal static bool TryBakeUI(ref Sprite pResult, ActorAsset pAsset, Sprite pMainSprite,
            bool pAdult, ActorSex pSex, int pPhenotypeIndex, int pPhenotypeShade,
            ColorAsset pKingdomColor, long pActorId, bool pKing, bool pWise, bool pEgg)
        {
            if (!Main.DwarfSkin || pAsset == null || pMainSprite == null) return false;
            if (pKingdomColor == null || pEgg || !pAdult) return false;
            if (!IsDwarfAsset(pAsset)) return false;
            try
            {
                EnsureLoaded();
                if (!_loaded) return false;
                bool swim;
                int frame;
                if (!ParseFrame(pMainSprite.name, out swim, out frame))
                {
                    _skipCount++;
                    return false;
                }

                Look look;
                Actor actor = UIActor;
                if (actor != null && actor.data != null && actor.data.id == pActorId)
                {
                    look = LookOf(actor);
                    Remember(pActorId, look);
                }
                else if (!_lastLook.TryGetValue(pActorId, out look))
                {
                    look = new Look();
                    look.ArmorMetal = -1;
                    look.GearMetal = -1;
                    look.Gear = GearNone;
                    look.Male = pSex == ActorSex.Male;
                    look.Head = HeadIndex(pActorId, look.Male);
                    look.Outfit = Main.HideClothing ? OutfitNude : (pKing ? OutfitRoyalRobe
                        : (StableIndex(pActorId / 7, 2) == 0 ? OutfitCasual : OutfitCasual1));
                }
                if (Main.HideClothing) {
                    look.Outfit = OutfitNude;
                    look.ArmorMetal = -1;
                    look.Gear = GearNone;
                    look.GearMetal = -1;
                }

                int hair = BioHairColor.GetIndexById(pActorId);
                bool white = pWise && pAsset.texture_asset != null && pAsset.texture_asset.has_old_heads;
                int hairSlot = hair + (white ? BioHairColor.Count : 0);
                long key = CacheKey(look, swim, frame, true,
                    pPhenotypeIndex, pPhenotypeShade, pKingdomColor, hairSlot);

                DynamicSpritesAsset units = DynamicSpritesLibrary.units;
                Sprite sprite = units.getSprite(key);
                if ((object)sprite == null)
                {
                    sprite = Bake(look, swim, frame, pKingdomColor, pAsset,
                        pPhenotypeIndex, pPhenotypeShade, pAsset.texture_atlas,
                        BioHairColor.RampOf(hair, white), true);
                    if (sprite == null) return false;
                    units.addSprite(key, sprite);
                }
                pResult = sprite;
                return true;
            }
            catch (Exception e)
            {
                Main.LogError("生物学[矮人贴图] 头像框烘贴图失败,回退原版 " + e);
                return false;
            }
        }

        // ===== 补丁 =====

        private static bool _patched;

        public static void Ensure()
        {
            if (_patched) return;
            _patched = true;
            Harmony harmony = new Harmony("rimworld_health_dwarfskin");
            int ok = 0;
            // 头像框那条路只给 actor id,拿不到装备。UnitAvatarLoader.load(Actor) 是同步把
            // 整套动画帧烘完的,所以在它前后把当前单位挂出来给 TryBakeUI 用。
            ok += Patch(harmony, AccessTools.Method(typeof(UnitAvatarLoader), "load",
                new[] { typeof(Actor) }), nameof(AvatarLoadPrefix), null, nameof(AvatarLoadFinalizer),
                "头像框记住当前单位");
            // 重绘的走/游各五帧,原版矮人只有四帧,取容器的时候顺手补一帧
            ok += Patch(harmony, AccessTools.Method(typeof(ActorAnimationLoader), "getAnimationContainer"),
                null, nameof(ContainerPostfix), null, "矮人动画补到五帧");
            Main.LogInfo("生物学:矮人贴图补丁 " + ok + "/2 装上了");
        }

        private static int Patch(Harmony pHarmony, System.Reflection.MethodInfo pTarget,
            string pPrefix, string pPostfix, string pFinalizer, string pWhat)
        {
            try
            {
                if (pTarget == null)
                {
                    Main.LogError("生物学:找不到目标方法 —— " + pWhat + " 装不上");
                    return 0;
                }
                pHarmony.Patch(pTarget,
                    prefix: pPrefix == null ? null
                        : new HarmonyMethod(AccessTools.Method(typeof(BioDwarfSkin), pPrefix)),
                    postfix: pPostfix == null ? null
                        : new HarmonyMethod(AccessTools.Method(typeof(BioDwarfSkin), pPostfix)),
                    finalizer: pFinalizer == null ? null
                        : new HarmonyMethod(AccessTools.Method(typeof(BioDwarfSkin), pFinalizer)));
                Main.LogInfo("生物学:补丁已装 " + pTarget.DeclaringType.Name + "." + pTarget.Name
                    + " —— " + pWhat);
                return 1;
            }
            catch (Exception e)
            {
                Main.LogError("生物学:补丁装不上 " + pWhat + " " + e);
                return 0;
            }
        }

        public static void AvatarLoadPrefix(Actor pActor)
        {
            UIActor = pActor;
        }

        public static void AvatarLoadFinalizer()
        {
            UIActor = null;
        }

        // ===== 第五帧 =====
        // 重绘的走/游各五帧,原版矮人的动画数组只有 walk_0..3 / swim_0..3。这里给矮人的
        // 动画容器补上 walk_4 / swim_4:拿第四帧的原版精灵克隆一个同尺寸的占位(它自己的
        // 像素永远不会被画出来 —— 身体那一步整块换成重绘图了),帧数据照抄第四帧。
        // 关掉开关时再把数组缩回四帧,不给原版留后遗症。

        // 见过的矮人动画容器,开关切换时按这份名单统一改
        private static readonly List<AnimationContainerUnit> _containers =
            new List<AnimationContainerUnit>();

        public static void ContainerPostfix(AnimationContainerUnit __result)
        {
            if (__result == null) return;
            try
            {
                if (__result.id == null || !__result.id.StartsWith(DwarfBasePath)) return;
                // 婴儿那套还是原版的 10x10 图,别去动它的帧数和手持位置
                if (__result.id.EndsWith("/child")) return;
                if (!_containers.Contains(__result)) _containers.Add(__result);
                if (Main.DwarfSkin) Extend(__result); else Restore(__result);
            }
            catch (Exception e)
            {
                Main.LogError("生物学[矮人贴图] 补动画帧失败 " + e);
            }
        }

        /// <summary> 开关切换时把已经建好的容器一起改过来 </summary>
        private static void SyncContainers()
        {
            foreach (AnimationContainerUnit c in _containers)
            {
                try
                {
                    if (Main.DwarfSkin) Extend(c); else Restore(c);
                }
                catch (Exception e)
                {
                    Main.LogError("生物学[矮人贴图] 同步动画帧失败 " + e);
                }
            }
        }

        private static void Extend(AnimationContainerUnit pContainer)
        {
            Extend(pContainer, pContainer.walking, "walk_");
            Extend(pContainer, pContainer.swimming, "swim_");
            OverrideItemPos(pContainer);
        }

        // ===== 手里那件东西的位置 =====
        // 原版的 walk_*_item 是按 10x10 的身体量的:pivot 左边 3.5 px。重绘的身体宽 16,
        // pivot 挪到了 8,照原样画武器会飘在胸口。重绘图五帧的左手都固定在最左一列
        // (x=0、自下往上第 6~7 行),所以锚点统一改成 pivot 左边 7.5 px、离地 6.5 px。
        // 游泳那几帧原版本来就没有 *_item,不用管。
        private static readonly Vector2 WalkItemPos = new Vector2(-7.5f, 6.5f);

        // 改之前的原值,关开关的时候放回去
        private static readonly Dictionary<AnimationFrameData, Vector2> _itemPosBackup =
            new Dictionary<AnimationFrameData, Vector2>();

        private static void OverrideItemPos(AnimationContainerUnit pContainer)
        {
            for (int i = 0; i < 5; i++)
            {
                AnimationFrameData fd;
                if (!pContainer.dict_frame_data.TryGetValue("walk_" + i, out fd) || fd == null) continue;
                if (!fd.show_item) continue;
                if (!_itemPosBackup.ContainsKey(fd)) _itemPosBackup[fd] = fd.pos_item;
                fd.pos_item = WalkItemPos;
            }
        }

        private static void RestoreItemPos(AnimationContainerUnit pContainer)
        {
            for (int i = 0; i < 5; i++)
            {
                AnimationFrameData fd;
                if (!pContainer.dict_frame_data.TryGetValue("walk_" + i, out fd) || fd == null) continue;
                Vector2 old;
                if (_itemPosBackup.TryGetValue(fd, out old)) fd.pos_item = old;
            }
        }

        private static void Extend(AnimationContainerUnit pContainer, ActorAnimation pAnim, string pPrefix)
        {
            if (pAnim == null || pAnim.frames == null || pAnim.frames.Length != 4) return;
            string last = pPrefix + "3";
            string added = pPrefix + "4";
            Sprite clone;
            if (!pContainer.sprites.TryGetValue(added, out clone))
            {
                Sprite src = pAnim.frames[3];
                if (src == null) return;
                Rect r = src.rect;
                clone = Sprite.Create(src.texture, r,
                    new Vector2(src.pivot.x / r.width, src.pivot.y / r.height), 1f, 0,
                    SpriteMeshType.FullRect);
                clone.name = added;
                pContainer.sprites[added] = clone;
            }
            if (!pContainer.dict_frame_data.ContainsKey(added))
            {
                AnimationFrameData src;
                pContainer.dict_frame_data.TryGetValue(last, out src);
                AnimationFrameData fd = new AnimationFrameData();
                fd.id = added;
                if (src != null)
                {
                    fd.sheet_path = src.sheet_path;
                    fd.pos_head = src.pos_head;
                    fd.pos_head_new = src.pos_head_new;
                    fd.pos_item = src.pos_item;
                    fd.size_unit = src.size_unit;
                    fd.show_head = src.show_head;
                    fd.show_item = src.show_item;
                }
                pContainer.dict_frame_data[added] = fd;
            }
            Sprite[] frames = new Sprite[5];
            Array.Copy(pAnim.frames, frames, 4);
            frames[4] = clone;
            pAnim.frames = frames;
        }

        private static void Restore(AnimationContainerUnit pContainer)
        {
            Restore(pContainer.walking);
            Restore(pContainer.swimming);
            RestoreItemPos(pContainer);
        }

        private static void Restore(ActorAnimation pAnim)
        {
            if (pAnim == null || pAnim.frames == null || pAnim.frames.Length != 5) return;
            Sprite[] frames = new Sprite[4];
            Array.Copy(pAnim.frames, frames, 4);
            pAnim.frames = frames;
        }

        // ===== 对外 =====

        /// <summary> BioHeadHair 用:开关开着的时候矮人的头由这边全权接管,那边不必再换 </summary>
        internal static bool TakesOverHeads(Actor pActor)
        {
            return Main.DwarfSkin && pActor != null && IsDwarfAsset(pActor.asset);
        }

        /// <summary>
        /// 开关变了。动画帧长度跟着改,再把世界里所有矮人的贴图缓存丢掉,
        /// 让它们下一帧重新取图(不然已经烘好的图会一直挂着)。
        /// </summary>
        public static void OnSwitchChanged()
        {
            try
            {
                if (Main.DwarfSkin) EnsureLoaded();
                _lastLook.Clear();
                _bodies.Clear();
                _heads.Clear();
                _headOffsets.Clear();
                SyncContainers();
                RefreshAll();
                Main.LogInfo("生物学[矮人贴图] 已" + (Main.DwarfSkin ? "启用" : "关闭")
                    + ";身体图 " + _bodies.Count + " 张、头 " + _heads.Count + " 个、烘过 "
                    + _bakeCount + " 次、认不出帧名跳过 " + _skipCount + " 次");
            }
            catch (Exception e)
            {
                Main.LogError("生物学[矮人贴图] 切换开关失败 " + e);
            }
        }

        /// <summary> 让世界里所有矮人重取贴图 </summary>
        private static void RefreshAll()
        {
            try
            {
                int n = 0;
                if (World.world != null && World.world.units != null) {
                    foreach (Actor a in World.world.units)
                    {
                        if (a == null || !IsDwarfAsset(a.asset)) continue;
                        a.clearSprites();
                        a.clearLastColorCache();
                        n++;
                    }
                }
                Main.LogInfo("生物学[矮人贴图] 已刷新 " + n + " 个矮人");
                UnitAvatarLoader[] loaders = Resources.FindObjectsOfTypeAll<UnitAvatarLoader>();
                int avatars = 0;
                for (int i = 0; i < loaders.Length; i++) {
                    UnitAvatarLoader loader = loaders[i];
                    Actor actor = loader != null ? loader._actor : null;
                    if (actor == null || !IsDwarfAsset(actor.asset)) continue;
                    loader.load(actor);
                    avatars++;
                }
                Main.LogInfo("生物学[矮人贴图] 已刷新 " + avatars + " 个活动头像");
            }
            catch (Exception e)
            {
                Main.LogError("生物学[矮人贴图] 刷新矮人失败 " + e);
            }
        }
    }
}
